---
name: Rystem - Get Rystem Docs / Auth
description: Rystem Framework docs: Social Authentication - Blazor Client, Social Authentication - Server Setup, Social Authentication - TypeScript/React Client. Use for auth questions in Rystem.
---

# Rystem - Get Rystem Docs / Auth

> Auto-generated from Rystem MCP manifest (tool: `get-rystem-docs`, category: `auth`)

---

## Social Authentication - Blazor Client

> Add Google, Microsoft, Facebook, GitHub social login buttons to your Blazor Server/WASM app with automatic token management and routing protection

---
title: Social Authentication - Blazor Client
description: Add Google, Microsoft, Facebook, GitHub social login buttons to your Blazor Server/WASM app with automatic token management and routing protection
---

# Social Authentication - Blazor Client

Add **social login UI** to your Blazor Server or Blazor WebAssembly application.

**Features:**
- Pre-built social login buttons (Google, Microsoft, Facebook, GitHub, etc.)
- Automatic JWT token management
- Protected routing with authentication
- Cascading user context
- Auto-refresh tokens

---

## Installation

```bash
dotnet add package Rystem.Authentication.Social.Blazor --version 9.1.3
```

---

## Setup JavaScript

Add the JavaScript library in `App.razor` (in the `<head>` or before `</body>`):

```razor
<script src="_content/Rystem.Authentication.Social.Blazor/socialauthentications.js"></script>
```

---

## Configuration

### Program.cs (Blazor Server)

```csharp
var builder = WebApplication.CreateBuilder(args);

builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();

// Social Login UI
builder.Services.AddSocialLoginUI(options =>
{
    options.ApiUrl = "https://localhost:7017"; // Your API URL
    options.Google.ClientId = builder.Configuration["SocialLogin:Google:ClientId"];
    options.Microsoft.ClientId = builder.Configuration["SocialLogin:Microsoft:ClientId"];
    options.Facebook.ClientId = builder.Configuration["SocialLogin:Facebook:ClientId"];
    options.GitHub.ClientId = builder.Configuration["SocialLogin:GitHub:ClientId"];
});

// Optional: Repository with authorization interceptor
builder.Services.AddRepository<User, Guid>(repositoryBuilder =>
{
    repositoryBuilder.WithApiClient(apiBuilder =>
    {
        apiBuilder
            .WithHttpClient("https://localhost:7017")
            .WithDefaultRetryPolicy();
    });
});

builder.Services.AddDefaultAuthorizationInterceptorForApiHttpClient();

var app = builder.Build();

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseAntiforgery();

app
    .MapRazorComponents<App>()
    .AddInteractiveServerRenderMode();

app.Run();
```

### appsettings.json

```json
{
  "SocialLogin": {
    "Google": {
      "ClientId": "YOUR_GOOGLE_CLIENT_ID.apps.googleusercontent.com"
    },
    "Microsoft": {
      "ClientId": "YOUR_MICROSOFT_CLIENT_ID"
    },
    "Facebook": {
      "ClientId": "YOUR_FACEBOOK_APP_ID"
    },
    "GitHub": {
      "ClientId": "YOUR_GITHUB_CLIENT_ID"
    }
  }
}
```

---

## Router Setup

Replace the default router in `Routes.razor` with `SocialAuthenticationRouter`:

```razor
<SocialAuthenticationRouter 
    AppAssembly="typeof(Program).Assembly" 
    DefaultLayout="typeof(Layout.MainLayout)">
</SocialAuthenticationRouter>
```

**Features:**
- Automatically redirects unauthenticated users to login page
- Cascades `SocialUserWrapper` to all components
- Manages token refresh automatically

---

## Login Page

Create a login page with pre-built social buttons:

```razor
@page "/login"
@using Rystem.Authentication.Social.Blazor

<h3>Login</h3>

<SocialLoginButtons></SocialLoginButtons>
```

### Custom Button Order

```razor
@page "/login"
@using Rystem.Authentication.Social.Blazor

<h3>Login with Social</h3>

<SocialLoginButtons Buttons="@customOrder"></SocialLoginButtons>

@code {
    private Type[] customOrder = new[]
    {
        typeof(GoogleButton),
        typeof(MicrosoftButton),
        typeof(FacebookButton),
        typeof(GitHubButton),
        typeof(LinkedinButton),
        typeof(XButton),
        typeof(InstagramButton),
        typeof(PinterestButton)
    };
}
```

---

## Logout

### Pre-built Logout Button

```razor
<SocialLogout></SocialLogout>
```

### Custom Logout

```razor
@code {
    [CascadingParameter(Name = "SocialUser")]
    public SocialUserWrapper? SocialUser { get; set; }
    
    private async Task LogoutAsync()
    {
        if (SocialUser != null)
        {
            await SocialUser.LogoutAsync(forceRefresh: false);
        }
    }
}

<button @onclick="LogoutAsync">Logout</button>
```

---

## Access User Information

Use the cascading `SocialUserWrapper` parameter:

```razor
@page "/profile"

<h3>Profile</h3>

@if (SocialUser?.IsAuthenticated == true)
{
    <p>Username: @SocialUser.Username</p>
    <p>Email: @SocialUser.Email</p>
    <p>Token Expires: @SocialUser.ExpiresAt</p>
}
else
{
    <p>Not authenticated</p>
}

@code {
    [CascadingParameter(Name = "SocialUser")]
    public SocialUserWrapper? SocialUser { get; set; }
}
```

---

## Protected Routes

Use `@attribute [Authorize]` to protect pages:

```razor
@page "/dashboard"
@attribute [Authorize]

<h3>Dashboard</h3>

<p>Welcome, @SocialUser?.Username!</p>

@code {
    [CascadingParameter(Name = "SocialUser")]
    public SocialUserWrapper? SocialUser { get; set; }
}
```

---

## Complete Example

### App.razor

```razor
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <base href="/" />
    <link rel="stylesheet" href="bootstrap/bootstrap.min.css" />
    <link rel="stylesheet" href="app.css" />
    <HeadOutlet />
    <script src="_content/Rystem.Authentication.Social.Blazor/socialauthentications.js"></script>
</head>
<body>
    <Routes />
    <script src="_framework/blazor.web.js"></script>
</body>
</html>
```

### Routes.razor

```razor
<SocialAuthenticationRouter 
    AppAssembly="typeof(Program).Assembly" 
    DefaultLayout="typeof(Layout.MainLayout)">
</SocialAuthenticationRouter>
```

### MainLayout.razor

```razor
@inherits LayoutComponentBase

<div class="page">
    <div class="sidebar">
        <NavMenu />
    </div>
    
    <main>
        <div class="top-row px-4">
            @if (SocialUser?.IsAuthenticated == true)
            {
                <span>Hello, @SocialUser.Username</span>
                <SocialLogout></SocialLogout>
            }
        </div>
        
        <article class="content px-4">
            @Body
        </article>
    </main>
</div>

@code {
    [CascadingParameter(Name = "SocialUser")]
    public SocialUserWrapper? SocialUser { get; set; }
}
```

### Login.razor

```razor
@page "/login"
@using Rystem.Authentication.Social.Blazor

<div class="login-container">
    <h3>Sign In</h3>
    <p>Choose a social provider to continue</p>
    
    <SocialLoginButtons></SocialLoginButtons>
</div>

<style>
    .login-container {
        max-width: 400px;
        margin: 100px auto;
        padding: 20px;
        text-align: center;
    }
</style>
```

### Dashboard.razor

```razor
@page "/dashboard"
@attribute [Authorize]
@inject IRepository<User, Guid> UserRepository

<h3>Dashboard</h3>

@if (SocialUser?.IsAuthenticated == true)
{
    <div class="user-info">
        <h4>Welcome, @SocialUser.Username!</h4>
        <p>Email: @SocialUser.Email</p>
        <p>Token expires: @SocialUser.ExpiresAt.ToString("g")</p>
    </div>
    
    @if (users != null)
    {
        <h5>Users (@users.Count)</h5>
        <ul>
            @foreach (var user in users)
            {
                <li>@user.Email</li>
            }
        </ul>
    }
}

@code {
    [CascadingParameter(Name = "SocialUser")]
    public SocialUserWrapper? SocialUser { get; set; }
    
    private List<User>? users;
    
    protected override async Task OnInitializedAsync()
    {
        // Fetch users from API (with automatic auth token)
        users = await UserRepository.Query().ToListAsync();
    }
}
```

---

## Real-World Examples

### Admin Panel with Role Check

```razor
@page "/admin"
@attribute [Authorize(Roles = "Admin")]

<h3>Admin Panel</h3>

@if (SocialUser?.HasRole("Admin") == true)
{
    <p>You have admin access</p>
    
    <button @onclick="DeleteAllUsers">Delete All Users</button>
}

@code {
    [CascadingParameter(Name = "SocialUser")]
    public SocialUserWrapper? SocialUser { get; set; }
    
    private async Task DeleteAllUsers()
    {
        // Admin action
    }
}
```

### Token Refresh on API Call

```razor
@inject IRepository<Order, Guid> OrderRepository

@code {
    [CascadingParameter(Name = "SocialUser")]
    public SocialUserWrapper? SocialUser { get; set; }
    
    private async Task LoadOrdersAsync()
    {
        try
        {
            // Automatic token refresh if expired
            var orders = await OrderRepository.Query().ToListAsync();
        }
        catch (UnauthorizedAccessException)
        {
            // Token expired and refresh failed
            await SocialUser!.LogoutAsync(false);
        }
    }
}
```

### Multi-Tenant Dashboard

```razor
@page "/tenant-dashboard"
@attribute [Authorize]
@inject IRepository<Tenant, Guid> TenantRepository

<h3>Tenant Dashboard</h3>

@if (tenant != null)
{
    <h4>@tenant.Name</h4>
    <p>Domain: @tenant.EmailDomain</p>
    <p>Users: @tenant.UserCount</p>
}

@code {
    [CascadingParameter(Name = "SocialUser")]
    public SocialUserWrapper? SocialUser { get; set; }
    
    private Tenant? tenant;
    
    protected override async Task OnInitializedAsync()
    {
        var tenantId = SocialUser?.GetClaim("TenantId");
        
        if (Guid.TryParse(tenantId, out var id))
        {
            tenant = await TenantRepository.GetAsync(id);
        }
    }
}
```

---

## SocialUserWrapper API

```csharp
public class SocialUserWrapper
{
    public string Username { get; set; }
    public string Email { get; set; }
    public bool IsAuthenticated { get; set; }
    public DateTime ExpiresAt { get; set; }
    public string AccessToken { get; set; }
    
    public bool HasRole(string role);
    public string? GetClaim(string claimType);
    public Task LogoutAsync(bool forceRefresh);
    public Task RefreshTokenAsync();
}
```

---

## Available Social Buttons

- `GoogleButton`
- `MicrosoftButton`
- `FacebookButton`
- `GitHubButton`
- `LinkedinButton`
- `XButton` (Twitter)
- `InstagramButton`
- `PinterestButton`
- `TikTokButton`
- `AmazonButton`

---

## Benefits

- ✅ **Pre-built UI Components**: Social buttons, logout, router
- ✅ **Automatic Token Management**: Refresh tokens automatically
- ✅ **Protected Routing**: `[Authorize]` attribute support
- ✅ **Cascading User Context**: Access user from any component
- ✅ **Repository Integration**: Auto-inject auth headers

---

## Related Tools

- **[Social Authentication - Server Setup](https://rystem.net/mcp/tools/auth-social-server.md)** - API configuration
- **[Social Authentication - TypeScript Client](https://rystem.net/mcp/tools/auth-social-typescript.md)** - React/Vue integration
- **[Repository API Client - .NET](https://rystem.net/mcp/tools/repository-api-client-dotnet.md)** - Repository with auth

---

## References

- **NuGet Package**: [Rystem.Authentication.Social.Blazor](https://www.nuget.org/packages/Rystem.Authentication.Social.Blazor) v9.1.3
- **Documentation**: https://rystem.net
- **GitHub**: https://github.com/KeyserDSoze/Rystem

---

## Social Authentication - Server Setup

> Configure Google, Microsoft, Facebook, GitHub, LinkedIn, X, Instagram, Pinterest social login with automatic token management and user provider integration for your REST API

---
title: Social Authentication - Server Setup
description: Configure Google, Microsoft, Facebook, GitHub, LinkedIn, X, Instagram, Pinterest social login with automatic token management and user provider integration for your REST API
---

# Social Authentication - Server Setup

Add **social login** (OAuth 2.0) to your API with automatic **JWT token management**.

**Supported Providers:**
- Google
- Microsoft (Azure AD)
- Facebook
- GitHub
- LinkedIn
- X (Twitter)
- Instagram
- Pinterest
- Amazon

---

## Installation

```bash
dotnet add package Rystem.Authentication.Social --version 9.1.3
```

---

## Configuration

### Basic Setup

```csharp
builder.Services.AddSocialLogin(
    socialProviders =>
    {
        // Google OAuth
        socialProviders.Google.ClientId = configuration["SocialLogin:Google:ClientId"];
        socialProviders.Google.ClientSecret = configuration["SocialLogin:Google:ClientSecret"];
        socialProviders.Google.AddUris(configuration["SocialLogin:Google:AllowedDomains"]!.Split(','));
        
        // Microsoft OAuth
        socialProviders.Microsoft.ClientId = configuration["SocialLogin:Microsoft:ClientId"];
        socialProviders.Microsoft.ClientSecret = configuration["SocialLogin:Microsoft:ClientSecret"];
        socialProviders.Microsoft.AddUris(configuration["SocialLogin:Microsoft:AllowedDomains"]!.Split(','));
        
        // Facebook OAuth
        socialProviders.Facebook.ClientId = configuration["SocialLogin:Facebook:ClientId"];
        socialProviders.Facebook.ClientSecret = configuration["SocialLogin:Facebook:ClientSecret"];
        socialProviders.Facebook.AddUris(configuration["SocialLogin:Facebook:AllowedDomains"]!.Split(','));
    },
    tokenSettings =>
    {
        tokenSettings.BearerTokenExpiration = TimeSpan.FromHours(1);
        tokenSettings.RefreshTokenExpiration = TimeSpan.FromDays(10);
    }
);
```

### appsettings.json

```json
{
  "SocialLogin": {
    "Google": {
      "ClientId": "YOUR_GOOGLE_CLIENT_ID.apps.googleusercontent.com",
      "ClientSecret": "YOUR_GOOGLE_CLIENT_SECRET",
      "AllowedDomains": "http://localhost:5173,https://yourdomain.com"
    },
    "Microsoft": {
      "ClientId": "YOUR_MICROSOFT_CLIENT_ID",
      "ClientSecret": "YOUR_MICROSOFT_CLIENT_SECRET",
      "AllowedDomains": "http://localhost:5173,https://yourdomain.com"
    },
    "Facebook": {
      "ClientId": "YOUR_FACEBOOK_APP_ID",
      "ClientSecret": "YOUR_FACEBOOK_APP_SECRET",
      "AllowedDomains": "http://localhost:5173,https://yourdomain.com"
    },
    "GitHub": {
      "ClientId": "YOUR_GITHUB_CLIENT_ID",
      "ClientSecret": "YOUR_GITHUB_CLIENT_SECRET",
      "AllowedDomains": "http://localhost:5173,https://yourdomain.com"
    }
  }
}
```

---

## Add Endpoints

```csharp
var app = builder.Build();

app.UseAuthentication();
app.UseAuthorization();

// Add social login endpoints
app.UseSocialLoginEndpoints();

app.Run();
```

**Endpoints Added:**
- `POST /api/social/google` - Google OAuth callback
- `POST /api/social/microsoft` - Microsoft OAuth callback
- `POST /api/social/facebook` - Facebook OAuth callback
- `POST /api/social/github` - GitHub OAuth callback
- `POST /api/social/refresh` - Refresh JWT token
- `GET /api/social/user` - Get current user info

---

## User Provider

Create a **user provider** to integrate with your database or storage:

```csharp
public class SocialUserProvider : ISocialUserProvider
{
    private readonly IRepository<User, Guid> _userRepository;
    
    public SocialUserProvider(IRepository<User, Guid> userRepository)
    {
        _userRepository = userRepository;
    }
    
    public async Task<SocialUser> GetAsync(
        string username, 
        IEnumerable<Claim> claims, 
        CancellationToken cancellationToken)
    {
        // Find user by email/username
        var user = await _userRepository
            .Query()
            .Where(x => x.Email == username)
            .FirstOrDefaultAsync(cancellationToken);
        
        if (user == null)
        {
            // Create new user on first social login
            user = new User
            {
                Id = Guid.NewGuid(),
                Email = username,
                Name = claims.FirstOrDefault(x => x.Type == ClaimTypes.Name)?.Value,
                CreatedAt = DateTime.UtcNow
            };
            
            await _userRepository.InsertAsync(user, cancellationToken);
        }
        
        // Return SocialUser (or custom subclass)
        return new AppSocialUser
        {
            Username = user.Email,
            Email = user.Email,
            UserId = user.Id,
            Roles = user.Roles
        };
    }
    
    public async IAsyncEnumerable<Claim> GetClaimsAsync(
        string? username, 
        CancellationToken cancellationToken)
    {
        var user = await _userRepository
            .Query()
            .Where(x => x.Email == username)
            .FirstOrDefaultAsync(cancellationToken);
        
        if (user != null)
        {
            yield return new Claim(ClaimTypes.NameIdentifier, user.Id.ToString());
            yield return new Claim(ClaimTypes.Name, user.Email);
            yield return new Claim(ClaimTypes.Email, user.Email);
            
            foreach (var role in user.Roles)
            {
                yield return new Claim(ClaimTypes.Role, role);
            }
        }
    }
}

// Custom SocialUser with additional properties
public class AppSocialUser : SocialUser
{
    public Guid UserId { get; set; }
    public List<string> Roles { get; set; } = new();
}
```

### Register User Provider

```csharp
builder.Services.AddSocialLogin<SocialUserProvider>(
    socialProviders => { /* ... */ },
    tokenSettings => { /* ... */ }
);
```

---

## Complete Example

```csharp
using Rystem.Authentication.Social;
using RepositoryFramework.InMemory;

var builder = WebApplication.CreateBuilder(args);

// Social Login with User Provider
builder.Services.AddSocialLogin<SocialUserProvider>(
    socialProviders =>
    {
        // Google
        socialProviders.Google.ClientId = builder.Configuration["SocialLogin:Google:ClientId"];
        socialProviders.Google.ClientSecret = builder.Configuration["SocialLogin:Google:ClientSecret"];
        socialProviders.Google.AddUris([.. builder.Configuration["SocialLogin:Google:AllowedDomains"]!.Split(',')]);
        
        // Microsoft
        socialProviders.Microsoft.ClientId = builder.Configuration["SocialLogin:Microsoft:ClientId"];
        socialProviders.Microsoft.ClientSecret = builder.Configuration["SocialLogin:Microsoft:ClientSecret"];
        socialProviders.Microsoft.AddUris([.. builder.Configuration["SocialLogin:Microsoft:AllowedDomains"]!.Split(',')]);
        
        // GitHub
        socialProviders.GitHub.ClientId = builder.Configuration["SocialLogin:GitHub:ClientId"];
        socialProviders.GitHub.ClientSecret = builder.Configuration["SocialLogin:GitHub:ClientSecret"];
        
        // LinkedIn
        socialProviders.Linkedin.ClientId = builder.Configuration["SocialLogin:Linkedin:ClientId"];
        socialProviders.Linkedin.ClientSecret = builder.Configuration["SocialLogin:Linkedin:ClientSecret"];
        socialProviders.Linkedin.AddUris([.. builder.Configuration["SocialLogin:Linkedin:AllowedDomains"]!.Split(',')]);
        
        // X (Twitter)
        socialProviders.X.ClientId = builder.Configuration["SocialLogin:X:ClientId"];
        socialProviders.X.ClientSecret = builder.Configuration["SocialLogin:X:ClientSecret"];
        socialProviders.X.AddUris([.. builder.Configuration["SocialLogin:X:AllowedDomains"]!.Split(',')]);
        
        // Instagram
        socialProviders.Instagram.ClientId = builder.Configuration["SocialLogin:Instagram:ClientId"];
        socialProviders.Instagram.ClientSecret = builder.Configuration["SocialLogin:Instagram:ClientSecret"];
        socialProviders.Instagram.AddUris([.. builder.Configuration["SocialLogin:Instagram:AllowedDomains"]!.Split(',')]);
        
        // Pinterest
        socialProviders.Pinterest.ClientId = builder.Configuration["SocialLogin:Pinterest:ClientId"];
        socialProviders.Pinterest.ClientSecret = builder.Configuration["SocialLogin:Pinterest:ClientSecret"];
        socialProviders.Pinterest.AddUris([.. builder.Configuration["SocialLogin:Pinterest:AllowedDomains"]!.Split(',')]);
    },
    tokenSettings =>
    {
        tokenSettings.BearerTokenExpiration = TimeSpan.FromHours(1);
        tokenSettings.RefreshTokenExpiration = TimeSpan.FromDays(10);
    },
    ServiceLifetime.Transient
);

// Repository for users
builder.Services.AddRepository<User, Guid>(repositoryBuilder =>
{
    repositoryBuilder.WithEntityFramework<AppDbContext>();
});

// Authorization policies
builder.Services.AddAuthorization(options =>
{
    options.AddPolicy("AuthenticatedUsers", policy => 
        policy.RequireClaim(ClaimTypes.NameIdentifier));
    
    options.AddPolicy("AdminOnly", policy =>
        policy.RequireRole("Admin"));
});

// CORS for frontend
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowFrontend", policy =>
    {
        policy.WithOrigins("http://localhost:5173", "https://yourdomain.com")
              .AllowAnyHeader()
              .AllowAnyMethod()
              .AllowCredentials();
    });
});

var app = builder.Build();

app.UseCors("AllowFrontend");
app.UseHttpsRedirection();
app.UseAuthentication();
app.UseAuthorization();

// Social login endpoints
app.UseSocialLoginEndpoints();

// Protected API endpoints
app.MapGet("/api/profile", (ClaimsPrincipal user) =>
{
    return new
    {
        UserId = user.FindFirst(ClaimTypes.NameIdentifier)?.Value,
        Email = user.FindFirst(ClaimTypes.Email)?.Value,
        Name = user.FindFirst(ClaimTypes.Name)?.Value
    };
})
.RequireAuthorization("AuthenticatedUsers");

app.Run();
```

---

## Real-World Examples

### Multi-Tenant SaaS

```csharp
public class MultiTenantSocialUserProvider : ISocialUserProvider
{
    private readonly IRepository<User, Guid> _userRepository;
    private readonly IRepository<Tenant, Guid> _tenantRepository;
    
    public async Task<SocialUser> GetAsync(
        string username, 
        IEnumerable<Claim> claims, 
        CancellationToken cancellationToken)
    {
        var email = username;
        var domain = email.Split('@')[1];
        
        // Find tenant by email domain
        var tenant = await _tenantRepository
            .Query()
            .Where(x => x.EmailDomain == domain)
            .FirstOrDefaultAsync(cancellationToken);
        
        if (tenant == null)
        {
            tenant = new Tenant
            {
                Id = Guid.NewGuid(),
                EmailDomain = domain,
                Name = domain,
                CreatedAt = DateTime.UtcNow
            };
            await _tenantRepository.InsertAsync(tenant, cancellationToken);
        }
        
        // Find or create user
        var user = await _userRepository
            .Query()
            .Where(x => x.Email == email && x.TenantId == tenant.Id)
            .FirstOrDefaultAsync(cancellationToken);
        
        if (user == null)
        {
            user = new User
            {
                Id = Guid.NewGuid(),
                Email = email,
                TenantId = tenant.Id,
                CreatedAt = DateTime.UtcNow
            };
            await _userRepository.InsertAsync(user, cancellationToken);
        }
        
        return new TenantSocialUser
        {
            Username = email,
            UserId = user.Id,
            TenantId = tenant.Id
        };
    }
    
    public async IAsyncEnumerable<Claim> GetClaimsAsync(string? username, CancellationToken cancellationToken)
    {
        var user = await _userRepository
            .Query()
            .Where(x => x.Email == username)
            .FirstOrDefaultAsync(cancellationToken);
        
        if (user != null)
        {
            yield return new Claim(ClaimTypes.NameIdentifier, user.Id.ToString());
            yield return new Claim(ClaimTypes.Email, user.Email);
            yield return new Claim("TenantId", user.TenantId.ToString());
        }
    }
}
```

### Role-Based Access Control

```csharp
public class RbacSocialUserProvider : ISocialUserProvider
{
    private readonly IRepository<User, Guid> _userRepository;
    private readonly IRepository<UserRole, Guid> _roleRepository;
    
    public async IAsyncEnumerable<Claim> GetClaimsAsync(string? username, CancellationToken cancellationToken)
    {
        var user = await _userRepository
            .Query()
            .Where(x => x.Email == username)
            .FirstOrDefaultAsync(cancellationToken);
        
        if (user != null)
        {
            yield return new Claim(ClaimTypes.NameIdentifier, user.Id.ToString());
            yield return new Claim(ClaimTypes.Name, user.Email);
            
            // Get roles from database
            var roles = await _roleRepository
                .Query()
                .Where(x => x.UserId == user.Id)
                .ToListAsync(cancellationToken);
            
            foreach (var role in roles)
            {
                yield return new Claim(ClaimTypes.Role, role.RoleName);
                
                // Add permissions as claims
                foreach (var permission in role.Permissions)
                {
                    yield return new Claim("Permission", permission);
                }
            }
        }
    }
}

// Usage in controller
[Authorize(Policy = "RequireAdminRole")]
[HttpGet("admin/dashboard")]
public IActionResult AdminDashboard()
{
    return Ok(new { Message = "Admin Dashboard" });
}

// Policy setup
builder.Services.AddAuthorization(options =>
{
    options.AddPolicy("RequireAdminRole", policy =>
        policy.RequireRole("Admin"));
    
    options.AddPolicy("CanDeleteUsers", policy =>
        policy.RequireClaim("Permission", "users.delete"));
});
```

### Audit Trail

```csharp
public class AuditSocialUserProvider : ISocialUserProvider
{
    private readonly IRepository<User, Guid> _userRepository;
    private readonly IRepository<LoginAudit, Guid> _auditRepository;
    
    public async Task<SocialUser> GetAsync(
        string username, 
        IEnumerable<Claim> claims, 
        CancellationToken cancellationToken)
    {
        var provider = claims.FirstOrDefault(x => x.Type == "provider")?.Value ?? "Unknown";
        
        var user = await _userRepository
            .Query()
            .Where(x => x.Email == username)
            .FirstOrDefaultAsync(cancellationToken);
        
        if (user == null)
        {
            user = new User
            {
                Id = Guid.NewGuid(),
                Email = username,
                CreatedAt = DateTime.UtcNow
            };
            await _userRepository.InsertAsync(user, cancellationToken);
        }
        
        // Log login attempt
        await _auditRepository.InsertAsync(new LoginAudit
        {
            Id = Guid.NewGuid(),
            UserId = user.Id,
            Provider = provider,
            LoginAt = DateTime.UtcNow,
            IpAddress = GetClientIpAddress(),
            UserAgent = GetUserAgent()
        }, cancellationToken);
        
        return new SocialUser
        {
            Username = user.Email
        };
    }
}
```

---

## OAuth Provider Setup

### Google OAuth

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create project → APIs & Services → Credentials
3. Create OAuth 2.0 Client ID
4. Add **Authorized redirect URIs**: `http://localhost:5173`, `https://yourdomain.com`
5. Copy **Client ID** and **Client Secret**

### Microsoft OAuth

1. Go to [Azure Portal](https://portal.azure.com/)
2. Azure Active Directory → App registrations → New registration
3. Add **Redirect URIs** (Web): `http://localhost:5173`, `https://yourdomain.com`
4. Certificates & secrets → New client secret
5. Copy **Application (client) ID** and **Client secret**

### GitHub OAuth

1. Go to [GitHub Settings](https://github.com/settings/developers)
2. OAuth Apps → New OAuth App
3. Set **Authorization callback URL**: `http://localhost:5173`
4. Copy **Client ID** and generate **Client Secret**

---

## Benefits

- ✅ **Multiple Providers**: Google, Microsoft, Facebook, GitHub, LinkedIn, X, Instagram, Pinterest
- ✅ **Automatic Token Management**: JWT with refresh tokens
- ✅ **Customizable User Provider**: Integrate with any database or storage
- ✅ **Claims-Based Auth**: Full support for roles, permissions, custom claims
- ✅ **CORS Support**: Ready for frontend integration

---

## Related Tools

- **[Social Authentication - Blazor Client](https://rystem.net/mcp/tools/auth-social-blazor.md)** - Blazor integration
- **[Social Authentication - TypeScript Client](https://rystem.net/mcp/tools/auth-social-typescript.md)** - React/Vue/Angular integration
- **[Authentication Flow Setup](https://rystem.net/mcp/prompts/auth-flow.md)** - General auth setup guide

---

## References

- **NuGet Package**: [Rystem.Authentication.Social](https://www.nuget.org/packages/Rystem.Authentication.Social) v9.1.3
- **Documentation**: https://rystem.net
- **GitHub**: https://github.com/KeyserDSoze/Rystem

---

## Social Authentication - TypeScript/React Client

> Add Google, Microsoft, Facebook, GitHub social login to your React/Vue/Angular app with automatic JWT token management and user context hooks

---
title: Social Authentication - TypeScript/React Client
description: Add Google, Microsoft, Facebook, GitHub social login to your React/Vue/Angular app with automatic JWT token management and user context hooks
---

# Social Authentication - TypeScript/React Client

Add **social login** to your React, Vue, or Angular application with automatic **JWT token management**.

**Features:**
- Pre-built social login buttons
- React hooks for token and user
- Automatic token refresh
- TypeScript support
- Framework agnostic core

---

## Installation

```bash
npm install rystem.authentication.social.react
```

---

## Setup

Configure social login in your app's entry point (`main.tsx` or `App.tsx`):

```typescript
import { setupSocialLogin, SocialLoginWrapper } from 'rystem.authentication.social.react';

setupSocialLogin(config => {
    config.apiUri = "https://localhost:7017"; // Your API URL
    config.google.clientId = "YOUR_GOOGLE_CLIENT_ID.apps.googleusercontent.com";
    config.microsoft.clientId = "YOUR_MICROSOFT_CLIENT_ID";
    config.facebook.clientId = "YOUR_FACEBOOK_APP_ID";
    config.github.clientId = "YOUR_GITHUB_CLIENT_ID";
    config.automaticRefresh = true; // Auto-refresh expired tokens
    config.onLoginFailure = (error) => {
        console.error(`Login failed: ${error.message}`, error);
    };
});

function App() {
    return (
        <SocialLoginWrapper>
            <YourApp />
        </SocialLoginWrapper>
    );
}

export default App;
```

---

## Login Buttons

### Default Buttons (All Providers)

```typescript
import { SocialLoginButtons } from 'rystem.authentication.social.react';

export const LoginPage = () => {
    return (
        <div>
            <h1>Sign In</h1>
            <SocialLoginButtons />
        </div>
    );
};
```

### Custom Button Order

```typescript
import { 
    SocialLoginButtons,
    GoogleButton,
    MicrosoftButton,
    FacebookButton,
    GitHubButton,
    LinkedinButton,
    XButton,
    InstagramButton,
    PinterestButton,
    TikTokButton,
    AmazonButton
} from 'rystem.authentication.social.react';

const customOrder = [
    GoogleButton,
    MicrosoftButton,
    GitHubButton,
    FacebookButton,
    LinkedinButton,
    XButton,
    InstagramButton,
    PinterestButton,
    TikTokButton,
    AmazonButton
];

export const LoginPage = () => {
    return (
        <div>
            <h1>Choose Provider</h1>
            <SocialLoginButtons buttons={customOrder} />
        </div>
    );
};
```

---

## Access Token

Use the `useSocialToken()` hook to get the current JWT token:

```typescript
import { useSocialToken } from 'rystem.authentication.social.react';

export const Dashboard = () => {
    const token = useSocialToken();
    
    // Check if token is expired
    if (token.isExpired) {
        return <LoginPage />;
    }
    
    return (
        <div>
            <h1>Dashboard</h1>
            <p>Token: {token.accessToken}</p>
            <p>Expires at: {token.expiresAt.toLocaleString()}</p>
        </div>
    );
};
```

### Use Token in API Requests

```typescript
import { useSocialToken } from 'rystem.authentication.social.react';
import { useEffect, useState } from 'react';

export const UserList = () => {
    const token = useSocialToken();
    const [users, setUsers] = useState([]);
    
    useEffect(() => {
        if (!token.isExpired) {
            fetch('https://localhost:7017/api/users', {
                headers: {
                    'Authorization': `Bearer ${token.accessToken}`
                }
            })
            .then(res => res.json())
            .then(data => setUsers(data));
        }
    }, [token]);
    
    return (
        <ul>
            {users.map(user => <li key={user.id}>{user.email}</li>)}
        </ul>
    );
};
```

---

## Access User

Use the `useSocialUser()` hook to get current user information:

```typescript
import { useSocialUser } from 'rystem.authentication.social.react';

export const Profile = () => {
    const user = useSocialUser();
    
    if (!user.isAuthenticated) {
        return <p>Not logged in</p>;
    }
    
    return (
        <div>
            <h1>Profile</h1>
            <p>Username: {user.username}</p>
            <p>Email: {user.email}</p>
            <p>Provider: {user.provider}</p>
        </div>
    );
};
```

---

## Logout

### Pre-built Logout Button

```typescript
import { SocialLogoutButton } from 'rystem.authentication.social.react';

export const Header = () => {
    return (
        <header>
            <h1>My App</h1>
            <SocialLogoutButton>
                Sign Out
            </SocialLogoutButton>
        </header>
    );
};
```

### Custom Logout

```typescript
import { useContext } from 'react';
import { SocialLoginContextLogout } from 'rystem.authentication.social.react';

export const Header = () => {
    const logout = useContext(SocialLoginContextLogout);
    
    return (
        <header>
            <h1>My App</h1>
            <button onClick={() => logout()}>
                Logout
            </button>
        </header>
    );
};
```

---

## Force Refresh Token

```typescript
import { useContext } from 'react';
import { SocialLoginContextRefresh } from 'rystem.authentication.social.react';

export const Settings = () => {
    const forceRefresh = useContext(SocialLoginContextRefresh);
    
    return (
        <div>
            <h1>Settings</h1>
            <button onClick={() => forceRefresh()}>
                Refresh Token
            </button>
        </div>
    );
};
```

---

## Complete Example

```typescript
import { useState, useContext } from 'react';
import {
    setupSocialLogin,
    SocialLoginWrapper,
    SocialLoginButtons,
    SocialLoginContextLogout,
    SocialLoginContextRefresh,
    SocialLogoutButton,
    useSocialToken,
    useSocialUser,
    GoogleButton,
    MicrosoftButton,
    FacebookButton,
    GitHubButton,
    LinkedinButton,
    XButton,
    InstagramButton,
    PinterestButton
} from 'rystem.authentication.social.react';

// Setup
setupSocialLogin(config => {
    config.apiUri = "https://localhost:7017";
    config.google.clientId = "23769141170-lfs24avv5qrj00m4cbmrm202c0fc6gcg.apps.googleusercontent.com";
    config.microsoft.clientId = "0b90db07-be9f-4b29-b673-9e8ee9265927";
    config.facebook.clientId = "345885718092912";
    config.github.clientId = "97154d062f2bb5d28620";
    config.automaticRefresh = true;
    config.onLoginFailure = (error) => {
        alert(`Login failed: ${error.message}`);
    };
});

// Custom button order
const buttonOrder = [
    MicrosoftButton,
    GoogleButton,
    LinkedinButton,
    FacebookButton,
    GitHubButton,
    XButton,
    InstagramButton,
    PinterestButton
];

// Main component
const AppContent = () => {
    const token = useSocialToken();
    const user = useSocialUser();
    const forceRefresh = useContext(SocialLoginContextRefresh);
    const logout = useContext(SocialLoginContextLogout);
    
    if (token.isExpired) {
        return (
            <div className="login-page">
                <h1>Welcome</h1>
                <p>Sign in to continue</p>
                <SocialLoginButtons buttons={buttonOrder} />
            </div>
        );
    }
    
    return (
        <div className="dashboard">
            <header>
                <h1>Dashboard</h1>
                <div>
                    {user.isAuthenticated && <span>Hello, {user.username}</span>}
                    <button onClick={() => forceRefresh()}>Refresh</button>
                    <SocialLogoutButton>Logout</SocialLogoutButton>
                </div>
            </header>
            
            <main>
                <div className="user-info">
                    <h2>User Information</h2>
                    <p>Username: {user.username}</p>
                    <p>Email: {user.email}</p>
                    <p>Provider: {user.provider}</p>
                </div>
                
                <div className="token-info">
                    <h2>Token</h2>
                    <p>Access Token: {token.accessToken.substring(0, 50)}...</p>
                    <p>Expires At: {token.expiresAt.toLocaleString()}</p>
                    <p>Is Expired: {token.isExpired ? 'Yes' : 'No'}</p>
                </div>
            </main>
        </div>
    );
};

function App() {
    return (
        <SocialLoginWrapper>
            <AppContent />
        </SocialLoginWrapper>
    );
}

export default App;
```

---

## Error Handling

The `onLoginFailure` callback receives error codes:

```typescript
setupSocialLogin(config => {
    config.onLoginFailure = (error) => {
        switch (error.code) {
            case 3:
                console.error('Error clicking social button', error);
                break;
            case 15:
                console.error('Error retrieving token', error);
                break;
            case 10:
                console.error('Error retrieving user', error);
                break;
            default:
                console.error('Unknown error', error);
        }
        
        // Show user-friendly message
        alert(`Login failed: ${error.message}`);
    };
});
```

**Error Codes:**
- `3`: Error during social button click
- `15`: Error during token retrieval
- `10`: Error during user retrieval
- `0` or `"DotNet"`: Integration error with .NET API

---

## Real-World Examples

### Protected Routes with React Router

```typescript
import { Navigate } from 'react-router-dom';
import { useSocialToken } from 'rystem.authentication.social.react';

const ProtectedRoute = ({ children }) => {
    const token = useSocialToken();
    
    if (token.isExpired) {
        return <Navigate to="/login" replace />;
    }
    
    return children;
};

// Usage
<Route path="/dashboard" element={
    <ProtectedRoute>
        <Dashboard />
    </ProtectedRoute>
} />
```

### Axios Interceptor

```typescript
import axios from 'axios';
import { useSocialToken } from 'rystem.authentication.social.react';

export const useApiClient = () => {
    const token = useSocialToken();
    
    const apiClient = axios.create({
        baseURL: 'https://localhost:7017/api'
    });
    
    apiClient.interceptors.request.use(config => {
        if (!token.isExpired) {
            config.headers.Authorization = `Bearer ${token.accessToken}`;
        }
        return config;
    });
    
    return apiClient;
};

// Usage
const apiClient = useApiClient();
const users = await apiClient.get('/users');
```

### Multi-Tenant Dashboard

```typescript
import { useSocialUser } from 'rystem.authentication.social.react';

export const TenantDashboard = () => {
    const user = useSocialUser();
    const tenantId = user.claims?.find(c => c.type === 'TenantId')?.value;
    
    return (
        <div>
            <h1>Tenant Dashboard</h1>
            <p>Tenant ID: {tenantId}</p>
        </div>
    );
};
```

---

## TypeScript Types

```typescript
interface SocialLoginConfig {
    apiUri: string;
    automaticRefresh: boolean;
    onLoginFailure?: (error: LoginError) => void;
    google: { clientId: string };
    microsoft: { clientId: string };
    facebook: { clientId: string };
    github: { clientId: string };
}

interface SocialToken {
    accessToken: string;
    refreshToken: string;
    expiresAt: Date;
    isExpired: boolean;
}

interface SocialUser {
    username: string;
    email: string;
    provider: string;
    isAuthenticated: boolean;
    claims?: Claim[];
}

interface LoginError {
    code: number;
    message: string;
    provider: string;
}
```

---

## Benefits

- ✅ **React Hooks**: `useSocialToken()`, `useSocialUser()`
- ✅ **Pre-built Components**: Login buttons, logout button
- ✅ **Automatic Refresh**: Tokens refresh automatically
- ✅ **TypeScript**: Full type support
- ✅ **Framework Agnostic**: Core library works with any framework

---

## Related Tools

- **[Social Authentication - Server Setup](https://rystem.net/mcp/tools/auth-social-server.md)** - API configuration
- **[Social Authentication - Blazor Client](https://rystem.net/mcp/tools/auth-social-blazor.md)** - Blazor integration
- **[Repository API Client - TypeScript](https://rystem.net/mcp/tools/repository-api-client-typescript.md)** - Repository with auth

---

## References

- **NPM Package**: [rystem.authentication.social.react](https://www.npmjs.com/package/rystem.authentication.social.react)
- **Documentation**: https://rystem.net
- **GitHub**: https://github.com/KeyserDSoze/Rystem
