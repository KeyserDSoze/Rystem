---
name: Rystem - Get Rystem Docs / Authentication
description: Rystem Framework docs: Rystem.Authentication.Social, Rystem.Authentication.Social.Abstractions, Rystem.Authentication.Social.Blazor. Use for authentication questions in Rystem.
---

# Rystem - Get Rystem Docs / Authentication

> Auto-generated from Rystem MCP manifest (tool: `get-rystem-docs`, category: `authentication`)

---

## Rystem.Authentication.Social

> Rystem.Authentication.Social is the server-side social-login package in the Authentication area.

# Rystem.Authentication.Social

`Rystem.Authentication.Social` is the server-side social-login package in the Authentication area.

It is not a full identity platform. Its job is narrower:

- accept provider-specific codes or access tokens from a client
- validate or exchange them through a provider-specific `ITokenChecker`
- issue ASP.NET Core bearer tokens
- expose a small authenticated `/User` endpoint

## Installation

```bash
dotnet add package Rystem.Authentication.Social
```

## Architecture

The server package revolves around two entry points:

- `AddSocialLogin<TProvider>(...)`
- `UseSocialLoginEndpoints()`

The high-level flow is:

1. configure one or more providers in `SocialLoginBuilder`
2. implement `ISocialUserProvider` for app-specific claims and user payloads
3. call `AddSocialLogin<TProvider>(...)`
4. call `UseSocialLoginEndpoints()`
5. let a Blazor or TypeScript client complete the browser-side OAuth flow and call the token endpoint

The package then issues standard ASP.NET bearer tokens through `Results.SignIn(...)`.

## Registration

The real public registration method is:

```csharp
builder.Services.AddSocialLogin<MySocialUserProvider>(settings =>
{
    settings.Google.ClientId = builder.Configuration["SocialLogin:Google:ClientId"];
    settings.Google.ClientSecret = builder.Configuration["SocialLogin:Google:ClientSecret"];
    settings.Google.AddUris("https://localhost:7100", "https://app.example.com");

    settings.Microsoft.ClientId = builder.Configuration["SocialLogin:Microsoft:ClientId"];
    settings.Microsoft.ClientSecret = builder.Configuration["SocialLogin:Microsoft:ClientSecret"];
    settings.Microsoft.AddUris("https://localhost:7100", "https://app.example.com");

    settings.GitHub.ClientId = builder.Configuration["SocialLogin:GitHub:ClientId"];
    settings.GitHub.ClientSecret = builder.Configuration["SocialLogin:GitHub:ClientSecret"];
}, bearer =>
{
    bearer.BearerTokenExpiration = TimeSpan.FromHours(1);
    bearer.RefreshTokenExpiration = TimeSpan.FromDays(10);
});
```

Signature:

```csharp
IServiceCollection AddSocialLogin<TProvider>(
    Action<SocialLoginBuilder> settings,
    Action<BearerTokenOptions>? action = null,
    ServiceLifetime userProviderLifeTime = ServiceLifetime.Transient)
    where TProvider : class, ISocialUserProvider
```

What it registers:

- ASP.NET bearer-token authentication
- `ISocialUserProvider`
- one named `ITokenChecker` per provider, plus the internal `DotNet` checker for refresh-token reuse
- named `HttpClient`s only for providers whose configuration is active

## Provider configuration model

`SocialLoginBuilder` currently exposes these providers:

- `Google`
- `Microsoft`
- `Facebook`
- `GitHub`
- `Amazon`
- `Linkedin`
- `X`
- `Instagram`
- `Pinterest`
- `TikTok`

The activation rules depend on the settings type:

| Settings type | Used by | Active when |
| --- | --- | --- |
| `SocialDefaultLoginSettings` | Facebook, Amazon | always `true` |
| `SocialLoginSettings` | base type | `ClientId != null` |
| `SocialLoginWithSecretsSettings` | GitHub | `ClientId` and `ClientSecret` are set |
| `SocialLoginWithSecretsAndRedirectSettings` | Google, Microsoft, Linkedin, X, Instagram, Pinterest, TikTok | client id, client secret, and at least one allowed URI are set |

For redirect-based providers, add allowed origins with:

```csharp
settings.Google.AddUri("https://app.example.com");
settings.Google.AddUris("https://app.example.com", "https://staging.example.com");
settings.Google.AddDomainWithProtocolAndPort("localhost", "https", 7100);
```

Important detail: allowed redirects are matched by scheme, host, and port. The stored path is not used as a differentiator when validating the incoming domain.

## `ISocialUserProvider`

`ISocialUserProvider` is the application extension point.

```csharp
public interface ISocialUserProvider
{
    Task<ISocialUser> GetAsync(string username, IEnumerable<Claim> claims, CancellationToken cancellationToken);
    IAsyncEnumerable<Claim> GetClaimsAsync(TokenResponse response, CancellationToken cancellationToken);
}
```

Responsibilities:

- `GetClaimsAsync(...)` controls which claims are embedded into the issued bearer token
- `GetAsync(...)` controls what `/api/Authentication/Social/User` returns

The sample provider in `src/Authentication/Tests/Rystem.Authentication.Social.TestApi/Services/SocialUserProvider.cs` shows both:

- adding `ClaimTypes.Name`
- adding a custom language claim with `RystemClaimTypes.Language`
- returning a richer app user model that implements `ISocialUser`

## Endpoints

Expose the runtime endpoints with:

```csharp
app.UseSocialLoginEndpoints();
```

This method does more than mapping endpoints: it also calls `UseAuthentication()` and `UseAuthorization()` internally.

### `api/Authentication/Social/Token`

This endpoint is mapped with `Map(...)`, so it accepts any verb. In practice the bundled clients use:

- `GET` for simple exchanges
- `POST` when they need to send extra body parameters such as `code_verifier`

Inputs:

| Name | Source | Meaning |
| --- | --- | --- |
| `provider` | query | `ProviderType` value |
| `code` | query | authorization code, provider access token, or refresh token depending on provider |
| `redirectPath` | query | optional redirect path from the client |
| `additionalParameters` | JSON body | optional provider-specific extras like PKCE `code_verifier` |

Behavior:

- reads `Origin` first, then `Referer`
- derives a domain from those headers
- builds a `TokenCheckerSettings` object with `Domain`, `RedirectPath`, and `AdditionalParameters`
- resolves the provider-specific named `ITokenChecker`
- on success builds a `ClaimsPrincipal` and returns `Results.SignIn(...)`

The actual wire payload is the ASP.NET bearer-token sign-in response, not a custom social-auth DTO.

### `api/Authentication/Social/User`

This endpoint requires authorization and returns either:

- `ISocialUserProvider.GetAsync(...)` output, when a provider is registered
- or `ISocialUser.OnlyUsername(...)` when no provider is available

## Refresh flow and the `DotNet` provider

`ProviderType.DotNet` is the package's internal refresh path, not a social provider.

It validates a refresh token previously issued by ASP.NET bearer auth and only accepts it when the original token domain matches the current request domain claim.

## Important caveats

### `Origin` or `Referer` is effectively required

The token endpoint refuses to proceed when it cannot infer a non-empty domain from `Origin` or `Referer`, even for providers that do not use redirect whitelists in their settings object.

### Redirect behavior is provider-specific

The overall contract supports `redirectPath`, but provider implementations are not fully uniform. Some use the computed redirect URI, while others rely on harder-coded callback shapes.

### Allowed URI validation is host-oriented

For redirect-whitelist providers, matching is based on scheme, host, and port. Multiple callback paths on the same host are not distinguished during domain validation.

### This package issues bearer tokens; it does not define your user model

Your claims and `/User` payload come from `ISocialUserProvider`. Without it, the package falls back to a username-only response.

## Grounded by sample files

- `src/Authentication/Tests/Rystem.Authentication.Social.TestApi/Program.cs`
- `src/Authentication/Tests/Rystem.Authentication.Social.TestApi/Services/SocialUserProvider.cs`
- `src/Authentication/Rystem.Authentication.Social/Extensions/ServiceCollectionExtensions.cs`
- `src/Authentication/Rystem.Authentication.Social/Extensions/EndpointRouteBuilderExtensions.cs`

Use this package when you want a small ASP.NET Core token-exchange backend for social-login clients, not a full end-to-end identity platform.

---

## Rystem.Authentication.Social.Abstractions

> Rystem.Authentication.Social.Abstractions contains the shared contracts and models used by the Authentication/Social packages.

# Rystem.Authentication.Social.Abstractions

`Rystem.Authentication.Social.Abstractions` contains the shared contracts and models used by the Authentication/Social packages.

It is the common .NET vocabulary between:

- `Rystem.Authentication.Social`
- `Rystem.Authentication.Social.Blazor`

The TypeScript client mirrors many of the same concepts, but it does not consume this package directly.

## Installation

```bash
dotnet add package Rystem.Authentication.Social.Abstractions
```

## What this package adds

The core public types are:

- `ProviderType`
- `ISocialUser`
- `ILocalizedSocialUser`
- `TokenResponse`
- `TokenCheckerSettings`
- `RystemClaimTypes`

## `ProviderType`

`ProviderType` identifies the server-side token checker to use.

Current values are:

- `DotNet`
- `Google`
- `Microsoft`
- `Facebook`
- `GitHub`
- `Amazon`
- `Linkedin`
- `X`
- `Instagram`
- `Pinterest`
- `TikTok`

Important note: `DotNet` is not a social provider. It is the internal provider used when refreshing bearer tokens that were already issued by the server package.

## `ISocialUser`

`ISocialUser` is the minimum user contract across the stack.

```csharp
public interface ISocialUser
{
    string? Username { get; set; }
}
```

The interface also exposes static helpers in the current implementation:

- `ISocialUser.Empty`
- `ISocialUser.OnlyUsername(username)`

Those helpers are used by the server package when no custom `ISocialUserProvider` is present.

## `ILocalizedSocialUser`

`ILocalizedSocialUser` extends `ISocialUser` with:

```csharp
string? Language { get; set; }
```

This matters mainly for the Blazor package, where the login flow can persist a language choice and feed the localization middleware.

## `TokenResponse`

`TokenResponse` is the normalized result of a successful provider check inside the server package.

```csharp
public sealed class TokenResponse
{
    public required string Username { get; set; }
    public required List<Claim> Claims { get; set; }
}
```

Important detail: `TokenResponse.Empty` is currently just `null`.

## `TokenCheckerSettings`

`TokenCheckerSettings` carries request context from the token endpoint into a provider-specific token checker.

```csharp
public sealed class TokenCheckerSettings
{
    public string? Domain { get; set; }
    public string? RedirectPath { get; set; }
    public Dictionary<string, string>? AdditionalParameters { get; set; }
}
```

Use cases:

- `Domain` comes from `Origin` or `Referer`
- `RedirectPath` lets a client communicate the callback path it used
- `AdditionalParameters` carries provider-specific extras such as PKCE `code_verifier`

Helper methods:

- `GetRedirectUri()` combines `Domain` and `RedirectPath`
- `GetParameter(key)` reads from `AdditionalParameters`
- `WithParameter(key, value)` appends a parameter fluently

Example:

```csharp
var settings = new TokenCheckerSettings
{
    Domain = "https://app.example.com",
    RedirectPath = "/account/login"
}.WithParameter("code_verifier", verifier);

string redirectUri = settings.GetRedirectUri();
```

## `RystemClaimTypes`

This package currently defines one custom claim constant:

- `RystemClaimTypes.Language`

It is intended for language values such as `en`, `it`, or `es` and is used by the sample social user provider plus the Blazor localization flow.

## Important caveats

### This package is shared-model oriented, not truly dependency-minimal

Even though it is called `Abstractions`, its project file currently references token and OIDC-related packages. So it is not a pure POCO-only dependency.

### `DotNet` is easy to misunderstand

If you see `ProviderType.DotNet`, think refresh-token reuse inside the server package, not an external login provider.

## Grounded by source files

- `src/Authentication/Rystem.Authentication.Social.Abstractions/Models/ProviderType.cs`
- `src/Authentication/Rystem.Authentication.Social.Abstractions/Models/ISocialUser.cs`
- `src/Authentication/Rystem.Authentication.Social.Abstractions/Models/ILocalizedSocialUser.cs`
- `src/Authentication/Rystem.Authentication.Social.Abstractions/Models/TokenResponse.cs`
- `src/Authentication/Rystem.Authentication.Social.Abstractions/Models/TokenCheckerSettings.cs`

Use this package when you need the shared Authentication/Social contracts without taking a dependency on the full server or Blazor runtime package.

---

## Rystem.Authentication.Social.Blazor

> Rystem.Authentication.Social.Blazor is the Blazor-side companion to Rystem.Authentication.Social.

# Rystem.Authentication.Social.Blazor

`Rystem.Authentication.Social.Blazor` is the Blazor-side companion to `Rystem.Authentication.Social`.

It handles browser-local state, callback processing, token retrieval, user loading, and a small amount of localization glue. It does not replace your server package and it does not register arbitrary social-login providers by itself.

## Installation

```bash
dotnet add package Rystem.Authentication.Social.Blazor
```

## Architecture

The Blazor package is centered around:

- `AddSocialLoginUI(...)`
- `UseSocialLoginAuthorization()`
- `SocialLoginManager`
- UI components like `SocialAuthentication` and `SocialAuthenticationRouter`

The normal flow is:

1. register the Blazor package with the API base URL and provider client ids
2. include the package JavaScript asset in the host page
3. wrap the app or route tree in `SocialAuthentication` or `SocialAuthenticationRouter`
4. let `SocialLoginManager` read stored state, process the OAuth callback, exchange codes with the server, and load the authenticated user

## Registration

The real setup API is:

```csharp
builder.Services.AddSocialLoginUI(settings =>
{
    settings.ApiUrl = "https://localhost:7017";
    settings.Google.ClientId = builder.Configuration["SocialLogin:Google:ClientId"];
    settings.Microsoft.ClientId = builder.Configuration["SocialLogin:Microsoft:ClientId"];
    settings.Platform.RedirectPath = "/account/login";
});
```

`AddSocialLoginUI(...)` currently registers:

- singleton `SocialLoginAppSettings`
- scoped `SocialLoginLocalStorageService`
- named `HttpClient` for `SocialLoginManager`
- transient `SocialLoginManager`
- singleton `LocalizationMiddleware`
- scoped `IAuthorizationHeaderProvider` via `SocialLoginAuthorizationHeaderProvider`

### Middleware

```csharp
app.UseSocialLoginAuthorization();
```

In the current implementation this only adds the localization middleware. It does not set up authentication middleware or map social-login endpoints.

## Required host-page script

The package needs its JS asset loaded explicitly. The sample app does this in `src/Authentication/Tests/RystemAuthentication.Social.TestBlazorApp/Components/App.razor`:

```html
<script src="_content/Rystem.Authentication.Social.Blazor/socialauthentications.js"></script>
```

Without that script, local storage helpers and language cookie helpers will not work.

## Configuration model

`SocialLoginAppSettings` currently exposes:

- `ApiUrl`
- `Google`
- `Facebook`
- `Microsoft`
- `Platform`
- `LoginMode`

Important runtime note: the built-in `<SocialLogin>` component currently renders only Microsoft and Google buttons, even though `SocialLoginAppSettings` also exposes `Facebook`.

Another important detail: the current runtime flow is effectively driven by `Platform.LoginMode`; the top-level `LoginMode` property exists on the settings type but is not the part the runtime actively reads during callback handling.

### Platform behavior

`Platform.RedirectPath` is interpreted like this by `SocialLoginManager.GetFullRedirectUri()`:

- full URI if it contains `://`
- web-relative path if it starts with `/`
- default to `/account/login` under the current base URI when omitted

`Platform.LoginMode` exists, but popup support is not meaningfully implemented in this Blazor package. In practice the flow is redirect-oriented.

## Components

### `SocialAuthentication<TUser>`

`SocialAuthentication<TUser>` wraps authenticated content.

- when no user is loaded, it renders `<SocialLogin>` plus optional `LoginPage`
- when a user is loaded, it cascades `SocialUser` and `LogoutCallback`
- if the user implements `ILocalizedSocialUser`, it persists the language locally

Sample usage from `src/Authentication/Tests/RystemAuthentication.Social.TestBlazorApp/Components/Routes.razor`:

```razor
<SocialAuthenticationRouter AppAssembly="typeof(Program).Assembly"
                            DefaultLayout="typeof(Layout.MainLayout)"
                            TUser="SocialUser"
                            SetUser="SetUserAsync">
    <LoginPage>
        <h1>Your customization here.</h1>
    </LoginPage>
</SocialAuthenticationRouter>
```

### `SocialAuthenticationRouter<TUser>`

This is a wrapper around Blazor's router that nests every route inside `SocialAuthentication<TUser>`.

Use it when you want route-level protection with the package's built-in login shell.

### `SocialLogin`

`SocialLogin` renders the built-in login buttons above optional child content.

Current built-in button support:

- Microsoft
- Google

### `SocialLogout`

`SocialLogout` renders a logout button and participates in the package's local state cleanup flow.

## `SocialLoginManager`

`SocialLoginManager` is the imperative entry point.

Key methods:

- `FetchTokenAsync()`
- `MeAsync<TUser>()`
- `LogoutAsync()`
- `GetFullRedirectUri()`

### Token resolution flow

`FetchTokenAsync()` currently does this:

1. tries local storage token first
2. if expired, tries refresh through `/api/Authentication/Social/Token?provider=DotNet&code=<refreshToken>`
3. if no token, reads `code` and `state` from the current URI
4. validates the stored local state
5. exchanges the callback code with the server

The callback exchange includes:

- `Origin` based on the current base URI
- `redirectPath` from the current page path
- optional request body containing `code_verifier`

### User loading flow

`MeAsync<TUser>()` calls `/api/Authentication/Social/User` with the bearer token. If that call returns `401`, it attempts a `DotNet` refresh first and retries.

When user loading succeeds, `SocialLoginAuthorizationHeaderProvider` is updated with the current bearer token so other consumers can read it.

## Localization behavior

If the loaded user implements `ILocalizedSocialUser`, the package:

- stores the language through the JS helper
- writes the `lang` cookie
- updates `CultureInfo.CurrentCulture` and `CultureInfo.CurrentUICulture`

`UseSocialLoginAuthorization()` then applies that cookie through `LocalizationMiddleware` on later requests.

## Important caveats

### This package depends on the server package

It expects a backend that exposes:

- `/api/Authentication/Social/Token`
- `/api/Authentication/Social/User`

Without `Rystem.Authentication.Social` on the server side, the Blazor flow cannot complete.

### The built-in UI is narrower than the config surface

The settings type exposes `Facebook`, but the built-in `<SocialLogin>` component currently renders only Microsoft and Google buttons.

### PKCE support is effectively Microsoft-specific today

The current callback implementation looks for `microsoft_code_verifier` in local storage when building the token exchange request.

### `UseSocialLoginAuthorization()` is only localization middleware

Despite its name, it does not configure auth handlers or attach bearer tokens to your API clients by itself.

If you want repository/API client calls to reuse the stored social token, you need a separate integration layer. The sample app does that with `AddDefaultSocialLoginAuthorizationInterceptorForApiHttpClient()` from `RepositoryFramework.Api.Client.Authentication.BlazorServer` in `src/Authentication/Tests/RystemAuthentication.Social.TestBlazorApp/Program.cs`.

### Logout cleanup is split across manager and component code

`SocialLoginManager.LogoutAsync()` clears token storage and the in-memory authorization header, while `SocialAuthentication` also clears state and optionally forces a page reload.

## Grounded by sample and source files

- `src/Authentication/Tests/RystemAuthentication.Social.TestBlazorApp/Program.cs`
- `src/Authentication/Tests/RystemAuthentication.Social.TestBlazorApp/Components/App.razor`
- `src/Authentication/Tests/RystemAuthentication.Social.TestBlazorApp/Components/Routes.razor`
- `src/Authentication/Rystem.Authentication.Social.Blazor/Services/SocialLoginManager.cs`
- `src/Authentication/Rystem.Authentication.Social.Blazor/Components/SocialAuthentication.razor`
- `src/Authentication/Rystem.Authentication.Social.Blazor/Components/SocialAuthenticationRouter.razor`

Use this package when you want a Blazor UI and local-session wrapper around the server-side social-login endpoints, not when you need a fully standalone auth system.
