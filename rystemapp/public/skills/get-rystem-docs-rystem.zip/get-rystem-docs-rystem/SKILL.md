---
name: Rystem - Get Rystem Docs / Rystem
description: Rystem Framework docs: Async Lock, Background Jobs, ConcurrentList, CSV and Minimization and 11 more. Use for rystem questions in Rystem.
---

# Rystem - Get Rystem Docs / Rystem

> Auto-generated from Rystem MCP manifest (tool: `get-rystem-docs`, category: `rystem`)

---

## Async Lock

> Prevent race conditions in async code with key-based locking - execute async methods sequentially by resource ID, user ID, or any custom key with in-memory or Redis distributed locks

---
title: Async Lock
description: Prevent race conditions in async code with key-based locking - execute async methods sequentially by resource ID, user ID, or any custom key with in-memory or Redis distributed locks
---

# Async Lock

Execute **async methods sequentially** using key-based locking to prevent race conditions.

**Use Cases:**
- Prevent concurrent updates to the same resource
- Lock by ID (user, order, product, etc.)
- Ensure single execution per key
- Process queued operations in order
- Distributed locking across multiple instances

---

## Why Async Lock?

The C# `lock` keyword **doesn't work with async methods**:

```csharp
// ❌ This doesn't compile
lock (_someLock)
{
    await DoSomethingAsync(); // Error: Cannot await in lock
}
```

Async Lock solves this problem:

```csharp
// ✅ This works
await _lock.ExecuteAsync(async () => 
{
    await DoSomethingAsync();
}, key: "resource-123");
```

---

## Installation

```bash
# In-memory lock (single instance)
dotnet add package Rystem.Concurrency --version 9.1.3

# Distributed lock (multi-instance with Redis)
dotnet add package Rystem.Concurrency.Redis --version 9.1.3
```

---

## In-Memory Lock (Single Instance)

### Configuration

```csharp
builder.Services.AddLock();
```

### Usage

```csharp
public class OrderService
{
    private readonly ILock _lock;
    private readonly IRepository<Order, Guid> _orderRepository;
    
    public OrderService(ILock @lock, IRepository<Order, Guid> orderRepository)
    {
        _lock = @lock;
        _orderRepository = orderRepository;
    }
    
    public async Task ProcessOrderAsync(Guid orderId)
    {
        // Lock by order ID - only one execution per order at a time
        await _lock.ExecuteAsync(async () =>
        {
            var order = await _orderRepository.GetAsync(orderId);
            
            if (order.Status == OrderStatus.Pending)
            {
                order.Status = OrderStatus.Processing;
                await _orderRepository.UpdateAsync(order);
                
                // Process order...
                await Task.Delay(1000); // Simulate processing
                
                order.Status = OrderStatus.Completed;
                await _orderRepository.UpdateAsync(order);
            }
        }, key: $"order-{orderId}");
    }
}
```

---

## Distributed Lock with Redis (Multi-Instance)

### Configuration

```csharp
builder.Services.AddRedisLock(options =>
{
    options.ConnectionString = configuration["ConnectionString:Redis"];
});
```

### appsettings.json

```json
{
  "ConnectionString": {
    "Redis": "localhost:6379,ssl=false"
  }
}
```

### Usage

Same API as in-memory lock, but **works across multiple app instances**:

```csharp
public class InventoryService
{
    private readonly ILock _redisLock;
    private readonly IRepository<Product, Guid> _productRepository;
    
    public InventoryService(ILock redisLock, IRepository<Product, Guid> productRepository)
    {
        _redisLock = redisLock;
        _productRepository = productRepository;
    }
    
    public async Task DecrementStockAsync(Guid productId, int quantity)
    {
        // Distributed lock - works across all instances
        await _redisLock.ExecuteAsync(async () =>
        {
            var product = await _productRepository.GetAsync(productId);
            
            if (product.Stock >= quantity)
            {
                product.Stock -= quantity;
                await _productRepository.UpdateAsync(product);
            }
            else
            {
                throw new InvalidOperationException("Insufficient stock");
            }
        }, key: $"product-{productId}");
    }
}
```

---

## Complete Example

```csharp
using Rystem.Concurrency;

var builder = WebApplication.CreateBuilder(args);

// In-memory lock for single instance
builder.Services.AddLock();

// OR Distributed Redis lock for multi-instance
// builder.Services.AddRedisLock(options =>
// {
//     options.ConnectionString = builder.Configuration["ConnectionString:Redis"];
// });

builder.Services.AddRepository<BankAccount, Guid>(repositoryBuilder =>
{
    repositoryBuilder.WithEntityFramework<AppDbContext>();
});

var app = builder.Build();

app.MapPost("/transfer", async (
    Guid fromAccountId,
    Guid toAccountId,
    decimal amount,
    ILock @lock,
    IRepository<BankAccount, Guid> accountRepository) =>
{
    // Lock BOTH accounts to prevent race conditions
    var lockKey = string.Join("-", 
        new[] { fromAccountId, toAccountId }.OrderBy(x => x));
    
    await @lock.ExecuteAsync(async () =>
    {
        var fromAccount = await accountRepository.GetAsync(fromAccountId);
        var toAccount = await accountRepository.GetAsync(toAccountId);
        
        if (fromAccount.Balance >= amount)
        {
            fromAccount.Balance -= amount;
            toAccount.Balance += amount;
            
            await accountRepository.UpdateAsync(fromAccount);
            await accountRepository.UpdateAsync(toAccount);
            
            return Results.Ok(new { Success = true });
        }
        
        return Results.BadRequest("Insufficient funds");
    }, key: lockKey);
});

app.Run();
```

---

## Real-World Examples

### E-Commerce: Purchase Item

```csharp
public class PurchaseService
{
    private readonly ILock _lock;
    private readonly IRepository<Product, Guid> _productRepository;
    private readonly IRepository<Order, Guid> _orderRepository;
    
    public PurchaseService(
        ILock @lock,
        IRepository<Product, Guid> productRepository,
        IRepository<Order, Guid> orderRepository)
    {
        _lock = @lock;
        _productRepository = productRepository;
        _orderRepository = orderRepository;
    }
    
    public async Task<Order> PurchaseAsync(Guid productId, Guid userId, int quantity)
    {
        return await _lock.ExecuteAsync(async () =>
        {
            var product = await _productRepository.GetAsync(productId);
            
            if (product.Stock < quantity)
                throw new InvalidOperationException("Insufficient stock");
            
            // Decrement stock
            product.Stock -= quantity;
            await _productRepository.UpdateAsync(product);
            
            // Create order
            var order = new Order
            {
                Id = Guid.NewGuid(),
                UserId = userId,
                ProductId = productId,
                Quantity = quantity,
                Total = product.Price * quantity,
                Status = OrderStatus.Completed,
                CreatedAt = DateTime.UtcNow
            };
            
            await _orderRepository.InsertAsync(order);
            
            return order;
        }, key: $"product-{productId}"); // Lock per product
    }
}
```

### User Profile Update

```csharp
public class UserService
{
    private readonly ILock _lock;
    private readonly IRepository<User, Guid> _userRepository;
    
    public UserService(ILock @lock, IRepository<User, Guid> userRepository)
    {
        _lock = @lock;
        _userRepository = userRepository;
    }
    
    public async Task UpdateProfileAsync(Guid userId, UserProfile profile)
    {
        await _lock.ExecuteAsync(async () =>
        {
            var user = await _userRepository.GetAsync(userId);
            
            user.Name = profile.Name;
            user.Email = profile.Email;
            user.UpdatedAt = DateTime.UtcNow;
            
            await _userRepository.UpdateAsync(user);
        }, key: $"user-{userId}");
    }
}
```

### Multi-Resource Lock (Prevent Deadlock)

```csharp
public class TransferService
{
    private readonly ILock _lock;
    private readonly IRepository<Wallet, Guid> _walletRepository;
    
    public TransferService(ILock @lock, IRepository<Wallet, Guid> walletRepository)
    {
        _lock = @lock;
        _walletRepository = walletRepository;
    }
    
    public async Task TransferAsync(Guid fromWalletId, Guid toWalletId, decimal amount)
    {
        // Lock both wallets - order IDs to prevent deadlock
        var sortedIds = new[] { fromWalletId, toWalletId }.OrderBy(x => x);
        var lockKey = string.Join("-", sortedIds);
        
        await _lock.ExecuteAsync(async () =>
        {
            var fromWallet = await _walletRepository.GetAsync(fromWalletId);
            var toWallet = await _walletRepository.GetAsync(toWalletId);
            
            if (fromWallet.Balance < amount)
                throw new InvalidOperationException("Insufficient balance");
            
            fromWallet.Balance -= amount;
            toWallet.Balance += amount;
            
            await _walletRepository.UpdateAsync(fromWallet);
            await _walletRepository.UpdateAsync(toWallet);
        }, key: lockKey);
    }
}
```

### File Upload with Quota Check

```csharp
public class FileUploadService
{
    private readonly ILock _lock;
    private readonly IContentRepository _storage;
    private readonly IRepository<UserQuota, Guid> _quotaRepository;
    
    public FileUploadService(
        ILock @lock,
        IContentRepository storage,
        IRepository<UserQuota, Guid> quotaRepository)
    {
        _lock = @lock;
        _storage = storage;
        _quotaRepository = quotaRepository;
    }
    
    public async Task UploadFileAsync(Guid userId, string fileName, byte[] data)
    {
        await _lock.ExecuteAsync(async () =>
        {
            var quota = await _quotaRepository.GetAsync(userId);
            
            if (quota.UsedBytes + data.Length > quota.MaxBytes)
                throw new InvalidOperationException("Quota exceeded");
            
            // Upload file
            await _storage.UploadAsync($"users/{userId}/{fileName}", data);
            
            // Update quota
            quota.UsedBytes += data.Length;
            await _quotaRepository.UpdateAsync(quota);
        }, key: $"user-quota-{userId}");
    }
}
```

### Background Job with Lock

```csharp
public class DataSyncJob : IBackgroundJob
{
    private readonly ILock _lock;
    private readonly IRepository<SyncStatus, string> _syncRepository;
    private readonly IExternalApiClient _apiClient;
    
    public DataSyncJob(
        ILock @lock,
        IRepository<SyncStatus, string> syncRepository,
        IExternalApiClient apiClient)
    {
        _lock = @lock;
        _syncRepository = syncRepository;
        _apiClient = apiClient;
    }
    
    public async Task ActionToDoAsync(CancellationToken cancellationToken)
    {
        // Prevent multiple instances from syncing simultaneously
        await _lock.ExecuteAsync(async () =>
        {
            var status = await _syncRepository.GetAsync("global-sync");
            
            if (status.LastSyncAt > DateTime.UtcNow.AddMinutes(-5))
                return; // Skip if synced recently
            
            var data = await _apiClient.GetDataAsync(cancellationToken);
            
            // Process data...
            
            status.LastSyncAt = DateTime.UtcNow;
            await _syncRepository.UpdateAsync(status);
        }, key: "data-sync-global");
    }
    
    public Task OnException(Exception exception) => Task.CompletedTask;
}
```

---

## API Reference

### ILock Interface

```csharp
public interface ILock
{
    /// <summary>
    /// Execute action with async lock
    /// </summary>
    Task ExecuteAsync(Func<Task> action, string key);
    
    /// <summary>
    /// Execute func with async lock and return result
    /// </summary>
    Task<T> ExecuteAsync<T>(Func<Task<T>> func, string key);
}
```

---

## How It Works

### In-Memory Lock

Uses `SemaphoreSlim` per key:

```
Key: "product-21"  → SemaphoreSlim (1 concurrent)
Key: "product-22"  → SemaphoreSlim (1 concurrent)
Key: "user-123"    → SemaphoreSlim (1 concurrent)
```

**Multiple requests for same key:**
```
Request 1 → Lock "product-21" → Execute → Release
Request 2 → Wait for lock      → Execute → Release
Request 3 → Wait for lock      → Execute → Release
```

**Concurrent requests for different keys:**
```
Request 1 → Lock "product-21" → Execute → Release
Request 2 → Lock "product-22" → Execute → Release (concurrent)
Request 3 → Lock "user-123"   → Execute → Release (concurrent)
```

### Redis Lock

Uses **distributed lock** with Redis:
- All app instances share the same lock
- Prevents race conditions across multiple servers
- Automatic lock expiration (prevents deadlock if app crashes)

---

## When to Use

### Use Async Lock When:
- ✅ Updating the same resource from multiple requests
- ✅ Decrementing stock, quotas, balances
- ✅ Processing orders, payments, transfers
- ✅ Need to queue operations per resource
- ✅ Multiple app instances (use Redis lock)

### Don't Use When:
- ❌ Read-only operations
- ❌ Operations on different resources (no conflict)
- ❌ Single-threaded execution already guaranteed

---

## Benefits

- ✅ **Async/Await Support**: Works with async methods
- ✅ **Key-Based**: Lock per resource ID, not globally
- ✅ **Distributed**: Redis support for multi-instance apps
- ✅ **Prevents Race Conditions**: Ensures sequential execution
- ✅ **Simple API**: Just wrap your code with `ExecuteAsync()`

---

## Related Tools

- **[Race Condition](https://rystem.net/mcp/tools/rystem-race-condition.md)** - Allow only first request, block others
- **[Concurrency Control](https://rystem.net/mcp/resources/concurrency.md)** - Best practices
- **[Background Jobs](https://rystem.net/mcp/tools/rystem-backgroundjob.md)** - Scheduled tasks with lock

---

## References

- **NuGet Package (In-Memory)**: [Rystem.Concurrency](https://www.nuget.org/packages/Rystem.Concurrency) v9.1.3
- **NuGet Package (Redis)**: [Rystem.Concurrency.Redis](https://www.nuget.org/packages/Rystem.Concurrency.Redis) v9.1.3
- **Documentation**: https://rystem.net
- **GitHub**: https://github.com/KeyserDSoze/Rystem

---

## Background Jobs

> Schedule recurring tasks with CRON expressions - run automated jobs, data sync, cleanup tasks, notifications, and periodic processing in your .NET application

---
title: Background Jobs
description: Schedule recurring tasks with CRON expressions - run automated jobs, data sync, cleanup tasks, notifications, and periodic processing in your .NET application
---

# Background Jobs

Schedule **recurring tasks** in your .NET application using **CRON expressions**.

**Use Cases:**
- Data synchronization
- Report generation
- Cleanup tasks
- Email/notification sending
- API polling
- Cache warming
- Database maintenance

---

## Installation

```bash
dotnet add package Rystem.BackgroundJob --version 9.1.3
```

---

## Configuration

### Basic Setup

```csharp
builder.Services.AddBackgroundJob<EmailNotificationJob>(options =>
{
    options.Cron = "0 */5 * * * *"; // Every 5 minutes
    options.RunImmediately = true;  // Run on startup
});
```

### CRON Expression Format

```
┌───────────── second (0 - 59)
│ ┌───────────── minute (0 - 59)
│ │ ┌───────────── hour (0 - 23)
│ │ │ ┌───────────── day of month (1 - 31)
│ │ │ │ ┌───────────── month (1 - 12)
│ │ │ │ │ ┌───────────── day of week (0 - 6) (Sunday=0)
│ │ │ │ │ │
│ │ │ │ │ │
* * * * * *
```

**Common Examples:**
- `0 */5 * * * *` - Every 5 minutes
- `0 0 * * * *` - Every hour
- `0 0 3 * * *` - Every day at 3:00 AM
- `0 0 0 * * 1` - Every Monday at midnight
- `0 30 9-17 * * 1-5` - Monday-Friday, 9:30 AM to 5:30 PM (every hour)

🔗 **CRON Helper**: https://crontab.guru/

---

## Create a Background Job

Implement `IBackgroundJob` interface:

```csharp
using System.Timers;

public class DataSyncJob : IBackgroundJob
{
    private readonly IRepository<User, Guid> _userRepository;
    private readonly IExternalApiClient _apiClient;
    private readonly ILogger<DataSyncJob> _logger;
    
    public DataSyncJob(
        IRepository<User, Guid> userRepository,
        IExternalApiClient apiClient,
        ILogger<DataSyncJob> logger)
    {
        _userRepository = userRepository;
        _apiClient = apiClient;
        _logger = logger;
    }
    
    // Main method called when CRON fires
    public async Task ActionToDoAsync(CancellationToken cancellationToken)
    {
        _logger.LogInformation("Starting data sync...");
        
        var externalUsers = await _apiClient.GetUsersAsync(cancellationToken);
        
        foreach (var externalUser in externalUsers)
        {
            var user = await _userRepository
                .Query()
                .Where(x => x.ExternalId == externalUser.Id)
                .FirstOrDefaultAsync(cancellationToken);
            
            if (user == null)
            {
                // Create new user
                await _userRepository.InsertAsync(new User
                {
                    Id = Guid.NewGuid(),
                    ExternalId = externalUser.Id,
                    Email = externalUser.Email,
                    Name = externalUser.Name,
                    SyncedAt = DateTime.UtcNow
                }, cancellationToken);
            }
            else
            {
                // Update existing user
                user.Email = externalUser.Email;
                user.Name = externalUser.Name;
                user.SyncedAt = DateTime.UtcNow;
                await _userRepository.UpdateAsync(user, cancellationToken);
            }
        }
        
        _logger.LogInformation("Data sync completed: {Count} users", externalUsers.Count);
    }
    
    // Called when exception occurs in ActionToDoAsync
    public Task OnException(Exception exception)
    {
        _logger.LogError(exception, "Error during data sync");
        return Task.CompletedTask;
    }
}
```

---

## Register and Warm Up

### Registration

```csharp
var builder = WebApplication.CreateBuilder(args);

// Register multiple background jobs
builder.Services
    .AddBackgroundJob<DataSyncJob>(options =>
    {
        options.Cron = "0 0 */6 * * *"; // Every 6 hours
        options.RunImmediately = true;
    })
    .AddBackgroundJob<CleanupJob>(options =>
    {
        options.Cron = "0 0 2 * * *"; // Daily at 2:00 AM
    })
    .AddBackgroundJob<ReportJob>(options =>
    {
        options.Cron = "0 0 9 * * 1"; // Every Monday at 9:00 AM
    });
```

### Warm Up (Start Jobs)

```csharp
var app = builder.Build();

// Start all background jobs
await app.Services.WarmUpAsync();

app.Run();
```

---

## Multiple Jobs with Same Class

Use the `Key` property to register multiple instances:

```csharp
builder.Services
    .AddBackgroundJob<NotificationJob>(options =>
    {
        options.Cron = "0 0 9 * * *";
        options.Key = "morning-notifications";
    })
    .AddBackgroundJob<NotificationJob>(options =>
    {
        options.Cron = "0 0 18 * * *";
        options.Key = "evening-notifications";
    });
```

---

## Complete Example

```csharp
using System.Timers;
using RepositoryFramework;

// Program.cs
var builder = WebApplication.WebBuilder(args);

builder.Services.AddRepository<Order, Guid>(repositoryBuilder =>
{
    repositoryBuilder.WithEntityFramework<AppDbContext>();
});

builder.Services.AddRepository<EmailLog, Guid>(repositoryBuilder =>
{
    repositoryBuilder.WithEntityFramework<AppDbContext>();
});

builder.Services
    .AddBackgroundJob<OrderStatusUpdateJob>(options =>
    {
        options.Cron = "0 */10 * * * *"; // Every 10 minutes
        options.RunImmediately = false;
    })
    .AddBackgroundJob<DailyReportJob>(options =>
    {
        options.Cron = "0 0 8 * * *"; // Daily at 8:00 AM
        options.RunImmediately = false;
    })
    .AddBackgroundJob<CacheWarmUpJob>(options =>
    {
        options.Cron = "0 */30 * * * *"; // Every 30 minutes
        options.RunImmediately = true; // Run on startup
    })
    .AddBackgroundJob<CleanupOldLogsJob>(options =>
    {
        options.Cron = "0 0 3 * * *"; // Daily at 3:00 AM
    });

var app = builder.Build();

// Warm up background jobs
await app.Services.WarmUpAsync();

app.Run();

// ============================================
// OrderStatusUpdateJob.cs
// ============================================
public class OrderStatusUpdateJob : IBackgroundJob
{
    private readonly IRepository<Order, Guid> _orderRepository;
    private readonly ILogger<OrderStatusUpdateJob> _logger;
    
    public OrderStatusUpdateJob(
        IRepository<Order, Guid> orderRepository,
        ILogger<OrderStatusUpdateJob> logger)
    {
        _orderRepository = orderRepository;
        _logger = logger;
    }
    
    public async Task ActionToDoAsync(CancellationToken cancellationToken)
    {
        var pendingOrders = await _orderRepository
            .Query()
            .Where(x => x.Status == OrderStatus.Processing 
                     && x.UpdatedAt < DateTime.UtcNow.AddHours(-24))
            .ToListAsync(cancellationToken);
        
        foreach (var order in pendingOrders)
        {
            order.Status = OrderStatus.Cancelled;
            order.CancelledReason = "Timeout - no update in 24 hours";
            await _orderRepository.UpdateAsync(order, cancellationToken);
        }
        
        _logger.LogInformation(
            "Order status update completed: {Count} orders cancelled", 
            pendingOrders.Count
        );
    }
    
    public Task OnException(Exception exception)
    {
        _logger.LogError(exception, "Error updating order statuses");
        return Task.CompletedTask;
    }
}

// ============================================
// DailyReportJob.cs
// ============================================
public class DailyReportJob : IBackgroundJob
{
    private readonly IRepository<Order, Guid> _orderRepository;
    private readonly IEmailService _emailService;
    private readonly ILogger<DailyReportJob> _logger;
    
    public DailyReportJob(
        IRepository<Order, Guid> orderRepository,
        IEmailService emailService,
        ILogger<DailyReportJob> logger)
    {
        _orderRepository = orderRepository;
        _emailService = emailService;
        _logger = logger;
    }
    
    public async Task ActionToDoAsync(CancellationToken cancellationToken)
    {
        var yesterday = DateTime.UtcNow.Date.AddDays(-1);
        
        var orders = await _orderRepository
            .Query()
            .Where(x => x.CreatedAt >= yesterday && x.CreatedAt < yesterday.AddDays(1))
            .ToListAsync(cancellationToken);
        
        var report = new
        {
            Date = yesterday.ToString("yyyy-MM-dd"),
            TotalOrders = orders.Count,
            TotalRevenue = orders.Sum(x => x.Total),
            CompletedOrders = orders.Count(x => x.Status == OrderStatus.Completed),
            CancelledOrders = orders.Count(x => x.Status == OrderStatus.Cancelled)
        };
        
        await _emailService.SendReportAsync(
            "admin@company.com",
            $"Daily Report - {report.Date}",
            report,
            cancellationToken
        );
        
        _logger.LogInformation("Daily report sent: {TotalOrders} orders", report.TotalOrders);
    }
    
    public Task OnException(Exception exception)
    {
        _logger.LogError(exception, "Error generating daily report");
        return Task.CompletedTask;
    }
}

// ============================================
// CleanupOldLogsJob.cs
// ============================================
public class CleanupOldLogsJob : IBackgroundJob
{
    private readonly IRepository<EmailLog, Guid> _emailLogRepository;
    private readonly ILogger<CleanupOldLogsJob> _logger;
    
    public CleanupOldLogsJob(
        IRepository<EmailLog, Guid> emailLogRepository,
        ILogger<CleanupOldLogsJob> logger)
    {
        _emailLogRepository = emailLogRepository;
        _logger = logger;
    }
    
    public async Task ActionToDoAsync(CancellationToken cancellationToken)
    {
        var cutoffDate = DateTime.UtcNow.AddDays(-90); // Keep last 90 days
        
        var oldLogs = await _emailLogRepository
            .Query()
            .Where(x => x.CreatedAt < cutoffDate)
            .ToListAsync(cancellationToken);
        
        foreach (var log in oldLogs)
        {
            await _emailLogRepository.DeleteAsync(log.Id, cancellationToken);
        }
        
        _logger.LogInformation("Cleanup completed: {Count} old logs deleted", oldLogs.Count);
    }
    
    public Task OnException(Exception exception)
    {
        _logger.LogError(exception, "Error during cleanup");
        return Task.CompletedTask;
    }
}
```

---

## Real-World Examples

### API Data Polling

```csharp
public class WeatherDataPollingJob : IBackgroundJob
{
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly IRepository<WeatherData, Guid> _weatherRepository;
    private readonly ILogger<WeatherDataPollingJob> _logger;
    
    public WeatherDataPollingJob(
        IHttpClientFactory httpClientFactory,
        IRepository<WeatherData, Guid> weatherRepository,
        ILogger<WeatherDataPollingJob> logger)
    {
        _httpClientFactory = httpClientFactory;
        _weatherRepository = weatherRepository;
        _logger = logger;
    }
    
    public async Task ActionToDoAsync(CancellationToken cancellationToken)
    {
        var client = _httpClientFactory.CreateClient("WeatherApi");
        
        var cities = new[] { "New York", "London", "Tokyo", "Sydney" };
        
        foreach (var city in cities)
        {
            var response = await client.GetFromJsonAsync<WeatherApiResponse>(
                $"/weather?city={city}",
                cancellationToken
            );
            
            if (response != null)
            {
                await _weatherRepository.InsertAsync(new WeatherData
                {
                    Id = Guid.NewGuid(),
                    City = city,
                    Temperature = response.Temperature,
                    Humidity = response.Humidity,
                    Timestamp = DateTime.UtcNow
                }, cancellationToken);
            }
        }
        
        _logger.LogInformation("Weather data updated for {Count} cities", cities.Length);
    }
    
    public Task OnException(Exception exception)
    {
        _logger.LogError(exception, "Error polling weather data");
        return Task.CompletedTask;
    }
}

// Registration
builder.Services.AddBackgroundJob<WeatherDataPollingJob>(options =>
{
    options.Cron = "0 */15 * * * *"; // Every 15 minutes
});
```

### Database Backup

```csharp
public class DatabaseBackupJob : IBackgroundJob
{
    private readonly IContentRepository _blobStorage;
    private readonly IConfiguration _configuration;
    private readonly ILogger<DatabaseBackupJob> _logger;
    
    public DatabaseBackupJob(
        IContentRepositoryFactory factory,
        IConfiguration configuration,
        ILogger<DatabaseBackupJob> logger)
    {
        _blobStorage = factory.Create("backup-storage");
        _configuration = configuration;
        _logger = logger;
    }
    
    public async Task ActionToDoAsync(CancellationToken cancellationToken)
    {
        var connectionString = _configuration.GetConnectionString("DefaultConnection");
        var timestamp = DateTime.UtcNow.ToString("yyyyMMdd-HHmmss");
        var backupFileName = $"database-backup-{timestamp}.bak";
        
        // Create backup (example for SQL Server)
        var backupPath = Path.Combine(Path.GetTempPath(), backupFileName);
        
        // Execute backup command (simplified)
        await ExecuteDatabaseBackupAsync(connectionString, backupPath, cancellationToken);
        
        // Upload to blob storage
        var backupData = await File.ReadAllBytesAsync(backupPath, cancellationToken);
        await _blobStorage.UploadAsync(
            $"backups/{backupFileName}",
            backupData,
            new ContentRepositoryOptions
            {
                Tags = new Dictionary<string, string>
                {
                    { "type", "database-backup" },
                    { "date", DateTime.UtcNow.ToString("o") }
                }
            }
        );
        
        // Cleanup local file
        File.Delete(backupPath);
        
        _logger.LogInformation("Database backup completed: {FileName}", backupFileName);
    }
    
    public Task OnException(Exception exception)
    {
        _logger.LogError(exception, "Error during database backup");
        return Task.CompletedTask;
    }
    
    private Task ExecuteDatabaseBackupAsync(string connectionString, string path, CancellationToken ct)
    {
        // Implementation specific to your database
        return Task.CompletedTask;
    }
}

// Registration
builder.Services.AddBackgroundJob<DatabaseBackupJob>(options =>
{
    options.Cron = "0 0 2 * * *"; // Daily at 2:00 AM
});
```

### Email Digest

```csharp
public class WeeklyDigestJob : IBackgroundJob
{
    private readonly IRepository<User, Guid> _userRepository;
    private readonly IRepository<Article, Guid> _articleRepository;
    private readonly IEmailService _emailService;
    private readonly ILogger<WeeklyDigestJob> _logger;
    
    public WeeklyDigestJob(
        IRepository<User, Guid> userRepository,
        IRepository<Article, Guid> articleRepository,
        IEmailService emailService,
        ILogger<WeeklyDigestJob> logger)
    {
        _userRepository = userRepository;
        _articleRepository = articleRepository;
        _emailService = emailService;
        _logger = logger;
    }
    
    public async Task ActionToDoAsync(CancellationToken cancellationToken)
    {
        var lastWeek = DateTime.UtcNow.AddDays(-7);
        
        var topArticles = await _articleRepository
            .Query()
            .Where(x => x.PublishedAt >= lastWeek)
            .OrderByDescending(x => x.Views)
            .Take(10)
            .ToListAsync(cancellationToken);
        
        var subscribedUsers = await _userRepository
            .Query()
            .Where(x => x.EmailSubscription == true)
            .ToListAsync(cancellationToken);
        
        foreach (var user in subscribedUsers)
        {
            await _emailService.SendDigestAsync(
                user.Email,
                user.Name,
                topArticles,
                cancellationToken
            );
        }
        
        _logger.LogInformation(
            "Weekly digest sent to {Count} users with {Articles} articles",
            subscribedUsers.Count,
            topArticles.Count
        );
    }
    
    public Task OnException(Exception exception)
    {
        _logger.LogError(exception, "Error sending weekly digest");
        return Task.CompletedTask;
    }
}

// Registration
builder.Services.AddBackgroundJob<WeeklyDigestJob>(options =>
{
    options.Cron = "0 0 9 * * 1"; // Every Monday at 9:00 AM
});
```

### Cache Warming

```csharp
public class CacheWarmUpJob : IBackgroundJob
{
    private readonly IRepository<Product, Guid> _productRepository;
    private readonly IMemoryCache _cache;
    private readonly ILogger<CacheWarmUpJob> _logger;
    
    public CacheWarmUpJob(
        IRepository<Product, Guid> productRepository,
        IMemoryCache cache,
        ILogger<CacheWarmUpJob> logger)
    {
        _productRepository = productRepository;
        _cache = cache;
        _logger = logger;
    }
    
    public async Task ActionToDoAsync(CancellationToken cancellationToken)
    {
        // Load top 100 products into cache
        var topProducts = await _productRepository
            .Query()
            .OrderByDescending(x => x.Views)
            .Take(100)
            .ToListAsync(cancellationToken);
        
        foreach (var product in topProducts)
        {
            _cache.Set(
                $"product:{product.Id}",
                product,
                TimeSpan.FromHours(1)
            );
        }
        
        _logger.LogInformation("Cache warmed up with {Count} products", topProducts.Count);
    }
    
    public Task OnException(Exception exception)
    {
        _logger.LogError(exception, "Error warming up cache");
        return Task.CompletedTask;
    }
}

// Registration
builder.Services.AddBackgroundJob<CacheWarmUpJob>(options =>
{
    options.Cron = "0 */30 * * * *"; // Every 30 minutes
    options.RunImmediately = true;   // Run on startup
});
```

---

## Background Job Options

```csharp
public class BackgroundJobOptions
{
    /// <summary>
    /// CRON expression (6 fields: second minute hour day month dayOfWeek)
    /// </summary>
    public string Cron { get; set; }
    
    /// <summary>
    /// Run job immediately on startup (before first CRON trigger)
    /// </summary>
    public bool RunImmediately { get; set; } = false;
    
    /// <summary>
    /// Unique key to allow multiple jobs with same class
    /// </summary>
    public string? Key { get; set; }
}
```

---

## IBackgroundJob Interface

```csharp
namespace System.Timers
{
    public interface IBackgroundJob
    {
        /// <summary>
        /// Main method called when CRON expression fires
        /// </summary>
        Task ActionToDoAsync(CancellationToken cancellationToken = default);
        
        /// <summary>
        /// Called when exception occurs in ActionToDoAsync
        /// </summary>
        Task OnException(Exception exception);
    }
}
```

---

## Best Practices

- ✅ **Use CancellationToken**: Respect cancellation for graceful shutdown
- ✅ **Handle Exceptions**: Always implement `OnException` with logging
- ✅ **Keep Jobs Lightweight**: Long-running tasks should process in batches
- ✅ **Use Dependency Injection**: Inject repositories, services, loggers
- ✅ **Test CRON Expressions**: Use https://crontab.guru/ to validate
- ✅ **Monitor Job Execution**: Log start, completion, and errors
- ✅ **Avoid Overlapping**: Ensure job completes before next trigger

---

## Related Tools

- **[Concurrency Control](https://rystem.net/mcp/resources/concurrency.md)** - Prevent duplicate job execution
- **[Repository Pattern](https://rystem.net/mcp/tools/repository-setup.md)** - Data access in jobs
- **[Content Repository](https://rystem.net/mcp/tools/content-repository.md)** - File storage in jobs

---

## References

- **NuGet Package**: [Rystem.BackgroundJob](https://www.nuget.org/packages/Rystem.BackgroundJob) v9.1.3
- **Documentation**: https://rystem.net
- **CRON Helper**: https://crontab.guru/
- **GitHub**: https://github.com/KeyserDSoze/Rystem

---

## ConcurrentList

> Thread-safe List implementation with automatic locking for concurrent access - provides all List<T> operations with built-in concurrency control

---
title: ConcurrentList
description: Thread-safe List implementation with automatic locking for concurrent access - provides all List<T> operations with built-in concurrency control
---

# ConcurrentList

A **thread-safe** implementation of `List<T>` with automatic locking for concurrent access.

---

## Installation

```bash
dotnet add package Rystem --version 9.1.3
```

---

## Quick Start

```csharp
using Rystem;

var items = new ConcurrentList<string>();

// Thread-safe Add
items.Add("Item 1");
items.Add("Item 2");

// Thread-safe access
var count = items.Count;
var firstItem = items[0];

// Thread-safe iteration
foreach (var item in items)
{
    Console.WriteLine(item);
}
```

---

## Why ConcurrentList?

### The Problem with List<T>

`List<T>` is **not thread-safe**. Concurrent access can cause:
- Race conditions
- Index out of range exceptions
- Collection modified during enumeration exceptions

```csharp
// ❌ NOT THREAD-SAFE
var list = new List<string>();

Parallel.For(0, 1000, i =>
{
    list.Add($"Item {i}"); // Race condition!
});
```

### The Solution: ConcurrentList<T>

```csharp
// ✅ THREAD-SAFE
var list = new ConcurrentList<string>();

Parallel.For(0, 1000, i =>
{
    list.Add($"Item {i}"); // Safe!
});
```

---

## Features

All standard `List<T>` operations with **automatic locking**:

### Add and Insert

```csharp
var items = new ConcurrentList<int>();

items.Add(1);
items.AddRange(new[] { 2, 3, 4 });
items.Insert(0, 0); // Insert at beginning

// Result: [0, 1, 2, 3, 4]
```

### Remove and Clear

```csharp
items.Remove(2);        // Remove specific item
items.RemoveAt(0);      // Remove at index
items.RemoveAll(x => x > 3); // Remove all matching
items.Clear();          // Remove all
```

### Access and Search

```csharp
var firstItem = items[0];           // Index access
var contains = items.Contains(3);   // Check existence
var index = items.IndexOf(3);       // Find index
var count = items.Count;            // Get count
```

### Enumeration

```csharp
foreach (var item in items)
{
    Console.WriteLine(item);
}

var filtered = items.Where(x => x > 10).ToList();
```

---

## Real-World Examples

### Parallel Data Processing

```csharp
public async Task<List<OrderDetails>> ProcessOrdersAsync(List<Guid> orderIds)
{
    var results = new ConcurrentList<OrderDetails>();
    
    await TaskManager.WhenAll(
        async (index, cancellationToken) =>
        {
            var orderId = orderIds[index];
            var details = await GetOrderDetailsAsync(orderId, cancellationToken).NoContext();
            
            results.Add(details); // Thread-safe
        },
        times: orderIds.Count,
        concurrentTasks: 10,
        runEverytimeASlotIsFree: true
    ).NoContext();
    
    return results.ToList();
}
```

### Background Job Processing

```csharp
public class OrderProcessingJob : IBackgroundJob
{
    private readonly ConcurrentList<string> _processedOrders = new();
    private readonly ConcurrentList<string> _failedOrders = new();
    
    public async Task ExecuteAsync(CancellationToken cancellationToken)
    {
        var orders = await orderRepository.QueryAsync(
            x => x.Status == OrderStatus.Pending,
            cancellationToken
        ).NoContext();
        
        await TaskManager.WhenAll(
            async (index, ct) =>
            {
                var order = orders[index];
                
                try
                {
                    await ProcessOrderAsync(order, ct).NoContext();
                    _processedOrders.Add(order.Id.ToString());
                }
                catch (Exception ex)
                {
                    logger.LogError(ex, "Failed to process order {OrderId}", order.Id);
                    _failedOrders.Add(order.Id.ToString());
                }
            },
            times: orders.Count,
            concurrentTasks: 5,
            runEverytimeASlotIsFree: true
        ).NoContext();
        
        logger.LogInformation(
            "Processed: {Processed}, Failed: {Failed}",
            _processedOrders.Count,
            _failedOrders.Count
        );
    }
}
```

### Event Collector

```csharp
public class EventCollector
{
    private readonly ConcurrentList<DomainEvent> _events = new();
    
    public void RecordEvent(DomainEvent domainEvent)
    {
        _events.Add(domainEvent); // Thread-safe
    }
    
    public async Task FlushEventsAsync()
    {
        if (_events.Count == 0) return;
        
        // Create a copy and clear
        var eventsToSave = _events.ToList();
        _events.Clear();
        
        // Save to database
        await eventRepository.InsertAsync(eventsToSave).NoContext();
    }
}
```

### Cache Management

```csharp
public class CacheManager<T>
{
    private readonly ConcurrentList<CacheEntry<T>> _cache = new();
    private readonly int _maxSize;
    
    public CacheManager(int maxSize = 1000)
    {
        _maxSize = maxSize;
    }
    
    public void Add(string key, T value)
    {
        // Remove oldest entries if cache is full
        if (_cache.Count >= _maxSize)
        {
            var toRemove = _cache.OrderBy(x => x.AccessTime).Take(100).ToList();
            foreach (var entry in toRemove)
            {
                _cache.Remove(entry);
            }
        }
        
        _cache.Add(new CacheEntry<T>
        {
            Key = key,
            Value = value,
            AccessTime = DateTime.UtcNow
        });
    }
    
    public T Get(string key)
    {
        var entry = _cache.FirstOrDefault(x => x.Key == key);
        if (entry != null)
        {
            entry.AccessTime = DateTime.UtcNow; // Update access time
            return entry.Value;
        }
        
        return default;
    }
}

public class CacheEntry<T>
{
    public string Key { get; set; }
    public T Value { get; set; }
    public DateTime AccessTime { get; set; }
}
```

### Real-Time Log Aggregation

```csharp
public class LogAggregator
{
    private readonly ConcurrentList<LogEntry> _logs = new();
    private readonly Timer _flushTimer;
    
    public LogAggregator()
    {
        _flushTimer = new Timer(FlushLogs, null, TimeSpan.FromSeconds(10), TimeSpan.FromSeconds(10));
    }
    
    public void Log(LogLevel level, string message)
    {
        _logs.Add(new LogEntry
        {
            Level = level,
            Message = message,
            Timestamp = DateTime.UtcNow
        });
    }
    
    private async void FlushLogs(object state)
    {
        if (_logs.Count == 0) return;
        
        var logsToSave = _logs.ToList();
        _logs.Clear();
        
        await logRepository.InsertAsync(logsToSave).NoContext();
    }
}
```

### Web Scraper

```csharp
public class WebScraper
{
    private readonly ConcurrentList<ScrapedData> _results = new();
    
    public async Task<List<ScrapedData>> ScrapeUrlsAsync(List<string> urls)
    {
        await TaskManager.WhenAll(
            async (index, cancellationToken) =>
            {
                var url = urls[index];
                
                try
                {
                    var html = await httpClient.GetStringAsync(url, cancellationToken).NoContext();
                    var data = ParseHtml(html);
                    
                    _results.Add(data); // Thread-safe
                }
                catch (Exception ex)
                {
                    logger.LogError(ex, "Failed to scrape {Url}", url);
                }
            },
            times: urls.Count,
            concurrentTasks: 10,
            runEverytimeASlotIsFree: true
        ).NoContext();
        
        return _results.ToList();
    }
}
```

---

## Comparison with Other Collections

| Collection | Thread-Safe | Ordered | Random Access | Use Case |
|------------|-------------|---------|---------------|----------|
| `List<T>` | ❌ | ✅ | ✅ | Single-threaded |
| `ConcurrentBag<T>` | ✅ | ❌ | ❌ | Unordered concurrent |
| `ConcurrentQueue<T>` | ✅ | ✅ (FIFO) | ❌ | FIFO queue |
| `ConcurrentStack<T>` | ✅ | ✅ (LIFO) | ❌ | LIFO stack |
| **`ConcurrentList<T>`** | ✅ | ✅ | ✅ | Ordered concurrent with indexing |

---

## When to Use ConcurrentList

### ✅ Use ConcurrentList When:
- Multiple threads need to **add/remove items concurrently**
- You need **ordered collection** with **index access**
- You want **List<T> behavior** in multi-threaded scenarios
- You're using `Parallel.For`, `TaskManager`, or similar parallel constructs

### ❌ Don't Use ConcurrentList When:
- Single-threaded application → Use `List<T>`
- Only adding items (no removal) → Use `ConcurrentBag<T>`
- FIFO queue → Use `ConcurrentQueue<T>`
- High-performance requirements → Consider lock-free alternatives

---

## Benefits

- ✅ **Thread-Safe**: Automatic locking for all operations
- ✅ **Familiar API**: Same as `List<T>`
- ✅ **Ordered**: Maintains insertion order
- ✅ **Index Access**: Support for `items[index]`
- ✅ **LINQ Support**: Works with LINQ queries
- ✅ **No External Dependencies**: Built into Rystem

---

## Related Tools

- **[Task Extensions](https://rystem.net/mcp/tools/rystem-task-extensions.md)** - TaskManager for concurrent execution
- **[Concurrency](https://rystem.net/mcp/resources/concurrency.md)** - Distributed locks and semaphores
- **[Background Jobs](https://rystem.net/mcp/resources/background-jobs.md)** - Scheduled background processing

---

## References

- **NuGet Package**: [Rystem](https://www.nuget.org/packages/Rystem) v9.1.3
- **Documentation**: https://rystem.net
- **GitHub**: https://github.com/KeyserDSoze/Rystem

---

## CSV and Minimization

> Serialize any IEnumerable to CSV with ToCsv() or use minimization for compact binary-like serialization with ToMinimize() and FromMinimization() - smaller than JSON with type safety

---
title: CSV and Minimization
description: Serialize any IEnumerable to CSV with ToCsv() or use minimization for compact binary-like serialization with ToMinimize() and FromMinimization() - smaller than JSON with type safety
---

# CSV and Minimization

Transform any `IEnumerable` data into **CSV strings** or use **minimization** for even more compact serialization.

---

## Installation

```bash
dotnet add package Rystem --version 9.1.3
```

---

## CSV Serialization

### Convert to CSV

Transform any collection into a **CSV string**:

```csharp
using Rystem;

public class Product
{
    public Guid Id { get; set; }
    public string Name { get; set; }
    public decimal Price { get; set; }
    public bool IsActive { get; set; }
}

var products = new List<Product>
{
    new Product { Id = Guid.NewGuid(), Name = "Laptop", Price = 999.99m, IsActive = true },
    new Product { Id = Guid.NewGuid(), Name = "Mouse", Price = 29.99m, IsActive = true },
    new Product { Id = Guid.NewGuid(), Name = "Keyboard", Price = 79.99m, IsActive = false }
};

string csv = products.ToCsv();

Console.WriteLine(csv);
```

**Output:**

```csv
Id,Name,Price,IsActive
a1b2c3d4-e5f6-7890-1234-567890abcdef,Laptop,999.99,True
f1e2d3c4-b5a6-7890-1234-567890abcdef,Mouse,29.99,True
g1h2i3j4-k5l6-7890-1234-567890abcdef,Keyboard,79.99,False
```

---

## Minimization (Compact Serialization)

**Minimization** is a brand new serialization format based on CSV that produces **smaller output than JSON** while maintaining type safety.

### Serialize with ToMinimize

```csharp
var products = new List<Product>
{
    new Product { Id = Guid.NewGuid(), Name = "Laptop", Price = 999.99m, IsActive = true },
    new Product { Id = Guid.NewGuid(), Name = "Mouse", Price = 29.99m, IsActive = true }
};

string minimized = products.ToMinimize();

Console.WriteLine(minimized);
// Output is compact, similar to CSV but with type information
```

### Deserialize with FromMinimization

```csharp
string minimized = GetMinimizedDataFromSomewhere();

var products = minimized.FromMinimization<List<Product>>();

foreach (var product in products)
{
    Console.WriteLine($"{product.Name}: ${product.Price}");
}
```

---

## Comparison: JSON vs CSV vs Minimization

**Example Data:**

```csharp
public class CsvModel
{
    public int Id { get; set; }
    public string Name { get; set; }
    public decimal Price { get; set; }
}

var models = new List<CsvModel>
{
    new CsvModel { Id = 1, Name = "Product A", Price = 10.50m },
    new CsvModel { Id = 2, Name = "Product B", Price = 20.75m },
    new CsvModel { Id = 3, Name = "Product C", Price = 30.00m }
};
```

**JSON Serialization:**

```json
[
  {"Id":1,"Name":"Product A","Price":10.50},
  {"Id":2,"Name":"Product B","Price":20.75},
  {"Id":3,"Name":"Product C","Price":30.00}
]
```

**Size**: ~140 bytes

**CSV Serialization:**

```csv
Id,Name,Price
1,Product A,10.50
2,Product B,20.75
3,Product C,30.00
```

**Size**: ~65 bytes (53% smaller than JSON)

**Minimization:**

```
1|Product A|10.50|2|Product B|20.75|3|Product C|30.00
```

**Size**: ~55 bytes (60% smaller than JSON)

---

## Real-World Examples

### Export to CSV File

```csharp
public async Task ExportProductsToCsvAsync(List<Product> products, string filePath)
{
    string csv = products.ToCsv();
    await File.WriteAllTextAsync(filePath, csv);
}

// Usage
await ExportProductsToCsvAsync(products, "products.csv");
```

### API Response with Minimization

```csharp
[HttpGet("orders/minimized")]
public async Task<IActionResult> GetOrdersMinimizedAsync()
{
    var orders = await orderRepository.QueryAsync(x => x.Status == OrderStatus.Completed);
    
    string minimized = orders.ToMinimize();
    
    return Content(minimized, "text/plain");
}
```

**Client-side:**

```csharp
var response = await httpClient.GetStringAsync("/api/orders/minimized");
var orders = response.FromMinimization<List<Order>>();
```

### Cache with Minimization

```csharp
public class ProductCache
{
    private readonly IDistributedCache _cache;
    
    public async Task SetProductsAsync(List<Product> products)
    {
        string minimized = products.ToMinimize();
        byte[] bytes = minimized.ToByteArray();
        
        await _cache.SetAsync("products", bytes, new DistributedCacheEntryOptions
        {
            AbsoluteExpirationRelativeToNow = TimeSpan.FromHours(1)
        });
    }
    
    public async Task<List<Product>> GetProductsAsync()
    {
        var bytes = await _cache.GetAsync("products");
        if (bytes == null) return null;
        
        string minimized = bytes.ConvertToString();
        return minimized.FromMinimization<List<Product>>();
    }
}
```

**Benefits:**
- ✅ **Smaller cache size** (60% smaller than JSON)
- ✅ **Faster serialization/deserialization**
- ✅ **Lower bandwidth usage**

### Bulk Data Transfer

```csharp
public class DataSyncService
{
    public async Task SyncOrdersAsync()
    {
        // Get 10,000 orders
        var orders = await orderRepository.QueryAsync(x => x.CreatedDate > DateTime.UtcNow.AddDays(-30));
        
        // Minimize for transfer (much smaller than JSON)
        string minimized = orders.ToMinimize();
        
        // Send to remote server
        await httpClient.PostAsync("/api/sync/orders", new StringContent(minimized));
        
        logger.LogInformation(
            "Synced {Count} orders. Size: {Size} bytes (vs {JsonSize} bytes for JSON)",
            orders.Count,
            minimized.Length,
            orders.ToJson().Length
        );
    }
}
```

### Report Generation

```csharp
public class ReportGenerator
{
    public async Task<string> GenerateSalesReportAsync(DateTime startDate, DateTime endDate)
    {
        var sales = await salesRepository.QueryAsync(x => 
            x.Date >= startDate && x.Date <= endDate);
        
        var reportData = sales.Select(s => new
        {
            s.Date,
            s.ProductName,
            s.Quantity,
            s.Total
        }).ToList();
        
        // Generate CSV for Excel/Google Sheets
        return reportData.ToCsv();
    }
}

// Usage
string csv = await reportGenerator.GenerateSalesReportAsync(
    DateTime.UtcNow.AddMonths(-1),
    DateTime.UtcNow
);

await File.WriteAllTextAsync("sales_report.csv", csv);
```

---

## When to Use What?

| Format | Use Case | Pros | Cons |
|--------|----------|------|------|
| **JSON** | APIs, human-readable data | Standard, widely supported | Larger size, slower |
| **CSV** | Excel exports, reports | Human-readable, standard | No nested objects |
| **Minimization** | Cache, bulk transfers | Smallest size, fast | Not human-readable |

---

## Benefits

- ✅ **CSV**: Standard format for Excel/Google Sheets
- ✅ **Minimization**: 60% smaller than JSON
- ✅ **Type Safety**: FromMinimization maintains types
- ✅ **Performance**: Faster serialization/deserialization
- ✅ **Easy to Use**: Simple extension methods

---

## Related Tools

- **[JSON Extensions](https://rystem.net/mcp/tools/rystem-json-extensions.md)** - JSON serialization
- **[Text Extensions](https://rystem.net/mcp/tools/rystem-text-extensions.md)** - String/byte/stream utilities
- **[Content Repository](https://rystem.net/mcp/resources/content-repo.md)** - File storage

---

## References

- **NuGet Package**: [Rystem](https://www.nuget.org/packages/Rystem) v9.1.3
- **Documentation**: https://rystem.net
- **GitHub**: https://github.com/KeyserDSoze/Rystem

---

## Dependency Injection Factory Pattern

> Advanced factory pattern for Rystem.DependencyInjection - register multiple named services with AddFactory(), use IFactory<T> for runtime service resolution, decorators, fallbacks, and automatic assembly scanning

---
title: Dependency Injection Factory Pattern
description: Advanced factory pattern for Rystem.DependencyInjection - register multiple named services with AddFactory(), use IFactory<T> for runtime service resolution, decorators, fallbacks, and automatic assembly scanning
---

# Dependency Injection Factory Pattern

Advanced **factory pattern** for **Rystem.DependencyInjection** to register and resolve multiple implementations of the same interface by **name**.

---

## Installation

```bash
dotnet add package Rystem.DependencyInjection --version 9.1.3
```

---

## Why Use Factory Pattern?

When you need **multiple implementations** of the same interface and want to **choose at runtime** which one to use:

### ❌ Traditional DI Problem

```csharp
// Can only register one implementation
services.AddScoped<IPaymentGateway, StripePaymentGateway>();

// This replaces the previous registration!
services.AddScoped<IPaymentGateway, PayPalPaymentGateway>();
```

### ✅ Factory Pattern Solution

```csharp
// Register multiple implementations by name
services.AddFactory<IPaymentGateway, StripePaymentGateway>(
    "stripe", 
    ServiceLifetime.Scoped
);

services.AddFactory<IPaymentGateway, PayPalPaymentGateway>(
    "paypal", 
    ServiceLifetime.Scoped
);

// Resolve by name at runtime
var factory = serviceProvider.GetRequiredService<IFactory<IPaymentGateway>>();
var stripe = factory.Create("stripe");
var paypal = factory.Create("paypal");
```

---

## Quick Start

### 1. Define Interface and Implementations

```csharp
public interface INotificationService
{
    Task SendAsync(string message);
}

public class EmailNotificationService : INotificationService
{
    public async Task SendAsync(string message)
    {
        // Send email
        await Task.CompletedTask;
    }
}

public class SmsNotificationService : INotificationService
{
    public async Task SendAsync(string message)
    {
        // Send SMS
        await Task.CompletedTask;
    }
}
```

### 2. Register with Factory

```csharp
services.AddFactory<INotificationService, EmailNotificationService>(
    "email",
    ServiceLifetime.Scoped
);

services.AddFactory<INotificationService, SmsNotificationService>(
    "sms",
    ServiceLifetime.Scoped
);
```

### 3. Resolve by Name

```csharp
public class NotificationController : ControllerBase
{
    private readonly IFactory<INotificationService> _factory;
    
    public NotificationController(IFactory<INotificationService> factory)
    {
        _factory = factory;
    }
    
    [HttpPost("send")]
    public async Task<IActionResult> SendNotification(string type, string message)
    {
        var service = _factory.Create(type); // "email" or "sms"
        await service.SendAsync(message);
        
        return Ok();
    }
}
```

---

## Factory with Options

Pass **configuration options** to each factory service:

### 1. Define Options

```csharp
public class PaymentGatewayOptions
{
    public string ApiKey { get; set; }
    public string BaseUrl { get; set; }
}
```

### 2. Implement IServiceWithOptions

```csharp
public class StripePaymentGateway : IPaymentGateway, IServiceWithOptions<PaymentGatewayOptions>
{
    public PaymentGatewayOptions Options { get; set; }
    
    public async Task<bool> ProcessPaymentAsync(decimal amount)
    {
        // Use Options.ApiKey and Options.BaseUrl
        var client = new HttpClient { BaseAddress = new Uri(Options.BaseUrl) };
        client.DefaultRequestHeaders.Add("Authorization", $"Bearer {Options.ApiKey}");
        
        // Process payment
        return true;
    }
}

public class PayPalPaymentGateway : IPaymentGateway, IServiceWithOptions<PaymentGatewayOptions>
{
    public PaymentGatewayOptions Options { get; set; }
    
    public async Task<bool> ProcessPaymentAsync(decimal amount)
    {
        // Use Options.ApiKey and Options.BaseUrl
        // Process payment
        return true;
    }
}
```

### 3. Register with Options

```csharp
services.AddFactory<IPaymentGateway, StripePaymentGateway, PaymentGatewayOptions>(
    options =>
    {
        options.ApiKey = "sk_test_stripe_key";
        options.BaseUrl = "https://api.stripe.com";
    },
    "stripe",
    ServiceLifetime.Scoped
);

services.AddFactory<IPaymentGateway, PayPalPaymentGateway, PaymentGatewayOptions>(
    options =>
    {
        options.ApiKey = "paypal_api_key";
        options.BaseUrl = "https://api.paypal.com";
    },
    "paypal",
    ServiceLifetime.Scoped
);
```

---

## Service Lifetimes

Factory pattern respects **service lifetimes**: Singleton, Scoped, Transient.

### Complete Example

```csharp
public interface IMyService
{
    string GetName();
    string Id { get; }
}

public class SingletonService : IMyService, IServiceWithOptions<ServiceOptions>
{
    public ServiceOptions Options { get; set; }
    public string Id { get; } = Guid.NewGuid().ToString();
    
    public string GetName() => $"{Options.ServiceName} with id {Id}";
}

public class TransientService : IMyService, IServiceWithOptions<ServiceOptions>
{
    public ServiceOptions Options { get; set; }
    public string Id { get; } = Guid.NewGuid().ToString();
    
    public string GetName() => $"{Options.ServiceName} with id {Id}";
}

public class ScopedService : IMyService, IServiceWithOptions<ServiceOptions>
{
    public ServiceOptions Options { get; set; }
    public string Id { get; } = Guid.NewGuid().ToString();
    
    public string GetName() => $"{Options.ServiceName} with id {Id}";
}

public class ServiceOptions
{
    public string ServiceName { get; set; }
}
```

**Registration:**

```csharp
services.AddFactory<IMyService, SingletonService, ServiceOptions>(
    x => x.ServiceName = "singleton",
    "singleton",
    ServiceLifetime.Singleton
);

services.AddFactory<IMyService, TransientService, ServiceOptions>(
    x => x.ServiceName = "transient",
    "transient",
    ServiceLifetime.Transient
);

services.AddFactory<IMyService, ScopedService, ServiceOptions>(
    x => x.ServiceName = "scoped",
    "scoped",
    ServiceLifetime.Scoped
);
```

**Usage:**

```csharp
var factory1 = serviceProvider.GetService<IFactory<IMyService>>();
var factory2 = serviceProvider.GetService<IFactory<IMyService>>();

var singleton1 = factory1.Create("singleton").Id;
var singleton2 = factory2.Create("singleton").Id;
Assert.Equal(singleton1, singleton2); // ✅ Same instance

var transient1 = factory1.Create("transient").Id;
var transient2 = factory2.Create("transient").Id;
Assert.NotEqual(transient1, transient2); // ✅ Different instances

var scoped1 = factory1.Create("scoped").Id;
var scoped2 = factory2.Create("scoped").Id;
Assert.Equal(scoped1, scoped2); // ✅ Same instance within scope
```

---

## Built Options (Async Factory)

Use **`IServiceOptions<T>`** for **asynchronous configuration building**:

### 1. Define Built Options

```csharp
public class DatabaseConnectionOptions
{
    public string ConnectionString { get; set; }
}

public class BuiltDatabaseOptions : IServiceOptions<DatabaseConnectionOptions>
{
    public string ServerName { get; set; }
    public string DatabaseName { get; set; }
    
    public Task<Func<DatabaseConnectionOptions>> BuildAsync()
    {
        return Task.FromResult(() => new DatabaseConnectionOptions
        {
            ConnectionString = $"Server={ServerName};Database={DatabaseName};..."
        });
    }
}
```

### 2. Register with AddFactoryAsync

```csharp
await services.AddFactoryAsync<IDatabaseService, SqlServerService, BuiltDatabaseOptions, DatabaseConnectionOptions>(
    x =>
    {
        x.ServerName = "localhost";
        x.DatabaseName = "MyDatabase";
    },
    "sqlserver"
);

await services.AddFactoryAsync<IDatabaseService, PostgresService, BuiltDatabaseOptions, DatabaseConnectionOptions>(
    x =>
    {
        x.ServerName = "localhost";
        x.DatabaseName = "MyDatabase";
    },
    "postgres"
);
```

**Use Cases:**
- Fetch secrets from Azure Key Vault
- Load configuration from remote API
- Decrypt configuration values
- Build connection strings dynamically

---

## Decorator Pattern

Add **decorators** to existing services to **wrap functionality** without modifying original code.

### Without Factory

```csharp
public interface ITestService
{
    string GetName();
}

public class TestService : ITestService
{
    public string Id { get; } = Guid.NewGuid().ToString();
    public string GetName() => $"TestService {Id}";
}

public class TestServiceDecorator : ITestService, IDecoratorService<ITestService>
{
    public ITestService DecoratedService { get; private set; }
    
    public void SetDecoratedService(ITestService service)
    {
        DecoratedService = service;
    }
    
    public string GetName()
    {
        return $"[DECORATED] {DecoratedService.GetName()}";
    }
}
```

**Registration:**

```csharp
services.AddService<ITestService, TestService>(ServiceLifetime.Scoped);
services.AddDecoration<ITestService, TestServiceDecorator>(null, ServiceLifetime.Scoped);
```

**Usage:**

```csharp
var decorator = provider.GetRequiredService<ITestService>();
Console.WriteLine(decorator.GetName());
// Output: "[DECORATED] TestService abc-123"

var previousService = provider.GetRequiredService<IDecoratedService<ITestService>>();
Console.WriteLine(previousService.GetName());
// Output: "TestService abc-123"
```

### With Factory

Decorate only **specific factory services**:

```csharp
services.AddFactory<IPaymentGateway, StripePaymentGateway>(
    "stripe",
    ServiceLifetime.Scoped
);

services.AddFactory<IPaymentGateway, PayPalPaymentGateway>(
    "paypal",
    ServiceLifetime.Scoped
);

// Decorate only "stripe"
services.AddDecoration<IPaymentGateway, LoggingPaymentGatewayDecorator>(
    "stripe",
    ServiceLifetime.Scoped
);
```

**Usage:**

```csharp
var factory = provider.GetRequiredService<IFactory<IPaymentGateway>>();

var stripe = factory.Create("stripe");
// Returns LoggingPaymentGatewayDecorator wrapping StripePaymentGateway

var paypal = factory.Create("paypal");
// Returns PayPalPaymentGateway (no decoration)

var originalStripe = factory.CreateWithoutDecoration("stripe");
// Returns original StripePaymentGateway without decorator
```

---

## Factory Fallback

Handle **missing factory keys** with fallback services:

### Class-Based Fallback

```csharp
public class PaymentGatewayFallback : IFactoryFallback<IPaymentGateway>
{
    public IPaymentGateway Create(string key)
    {
        // Return default implementation when key not found
        return new DefaultPaymentGateway();
    }
}

services.AddFactoryFallback<IPaymentGateway, PaymentGatewayFallback>();
```

### Action-Based Fallback

```csharp
services.AddActionAsFallbackWithServiceProvider<IPaymentGateway>(fallbackBuilder =>
{
    var logger = fallbackBuilder.ServiceProvider.GetRequiredService<ILogger<PaymentGateway>>();
    logger.LogWarning("Payment gateway {Key} not found, using default", fallbackBuilder.Key);
    
    return new DefaultPaymentGateway();
});
```

**Usage:**

```csharp
var factory = provider.GetRequiredService<IFactory<IPaymentGateway>>();

var stripe = factory.Create("stripe"); // Returns StripePaymentGateway
var unknown = factory.Create("unknown"); // Returns DefaultPaymentGateway from fallback
```

---

## Assembly Scanning

Automatically discover and register services by scanning assemblies.

### Manual Scan

```csharp
public interface IAnything { }

internal class ServiceA : IAnything { }
internal class ServiceB : IAnything { }
internal class ServiceC : IAnything { }

services.Scan<IAnything>(ServiceLifetime.Scoped, typeof(IAnything).Assembly);
```

### IScannable Interface

```csharp
public interface IAnything { }

internal class ServiceA : IAnything, IScannable<IAnything> { }
internal class ServiceB : IAnything, IScannable<IAnything> { }

services.Scan(ServiceLifetime.Scoped, typeof(IAnything).Assembly);
```

### Override Lifetime

```csharp
internal class ServiceA : IAnything, IScannable<IAnything>, ISingletonScannable { }
internal class ServiceB : IAnything, IScannable<IAnything>, IScopedScannable { }
internal class ServiceC : IAnything, IScannable<IAnything>, ITransientScannable { }

services.Scan(ServiceLifetime.Scoped, typeof(IAnything).Assembly);
// ServiceA -> Singleton (overridden)
// ServiceB -> Scoped (overridden)
// ServiceC -> Transient (overridden)
```

### Scan from Different Sources

```csharp
// Scan dependency context
services.ScanDependencyContext(ServiceLifetime.Scoped);

// Scan calling assembly
services.ScanCallingAssembly(ServiceLifetime.Scoped);

// Scan current domain
services.ScanCurrentDomain(ServiceLifetime.Scoped);

// Scan entry assembly
services.ScanEntryAssembly(ServiceLifetime.Scoped);

// Scan executing assembly
services.ScanExecutingAssembly(ServiceLifetime.Scoped);

// Scan from specific type
services.ScanFromType<Program>(ServiceLifetime.Scoped);

// Scan from multiple types
services.ScanFromTypes<Program, Startup>(ServiceLifetime.Scoped);
```

### Scan with References

Scan assemblies **and all referenced assemblies**:

```csharp
services.ScanWithReferences(ServiceLifetime.Scoped, typeof(Program).Assembly);
```

---

## Real-World Examples

### Payment Gateway Factory

```csharp
public interface IPaymentGateway
{
    Task<PaymentResult> ProcessAsync(decimal amount, string currency);
}

public class PaymentGatewayOptions
{
    public string ApiKey { get; set; }
    public string BaseUrl { get; set; }
}

public class StripePaymentGateway : IPaymentGateway, IServiceWithOptions<PaymentGatewayOptions>
{
    public PaymentGatewayOptions Options { get; set; }
    
    public async Task<PaymentResult> ProcessAsync(decimal amount, string currency)
    {
        // Stripe implementation
        return new PaymentResult { Success = true };
    }
}

public class PayPalPaymentGateway : IPaymentGateway, IServiceWithOptions<PaymentGatewayOptions>
{
    public PaymentGatewayOptions Options { get; set; }
    
    public async Task<PaymentResult> ProcessAsync(decimal amount, string currency)
    {
        // PayPal implementation
        return new PaymentResult { Success = true };
    }
}

// Registration
services.AddFactory<IPaymentGateway, StripePaymentGateway, PaymentGatewayOptions>(
    x =>
    {
        x.ApiKey = configuration["Stripe:ApiKey"];
        x.BaseUrl = "https://api.stripe.com";
    },
    "stripe",
    ServiceLifetime.Scoped
);

services.AddFactory<IPaymentGateway, PayPalPaymentGateway, PaymentGatewayOptions>(
    x =>
    {
        x.ApiKey = configuration["PayPal:ApiKey"];
        x.BaseUrl = "https://api.paypal.com";
    },
    "paypal",
    ServiceLifetime.Scoped
);

// Usage
public class OrderService
{
    private readonly IFactory<IPaymentGateway> _paymentFactory;
    
    public OrderService(IFactory<IPaymentGateway> paymentFactory)
    {
        _paymentFactory = paymentFactory;
    }
    
    public async Task<bool> ProcessOrderAsync(Order order)
    {
        var gateway = _paymentFactory.Create(order.PaymentMethod);
        var result = await gateway.ProcessAsync(order.Total, order.Currency);
        
        return result.Success;
    }
}
```

### Multi-Database Repository

```csharp
public interface IDatabaseRepository<T>
{
    Task<T> GetAsync(Guid id);
    Task InsertAsync(T entity);
}

public class SqlServerRepository<T> : IDatabaseRepository<T>, IServiceWithOptions<DatabaseOptions>
{
    public DatabaseOptions Options { get; set; }
    
    public async Task<T> GetAsync(Guid id)
    {
        // SQL Server implementation
        return default;
    }
    
    public async Task InsertAsync(T entity)
    {
        // SQL Server implementation
    }
}

public class MongoDbRepository<T> : IDatabaseRepository<T>, IServiceWithOptions<DatabaseOptions>
{
    public DatabaseOptions Options { get; set; }
    
    public async Task<T> GetAsync(Guid id)
    {
        // MongoDB implementation
        return default;
    }
    
    public async Task InsertAsync(T entity)
    {
        // MongoDB implementation
    }
}

// Registration
services.AddFactory<IDatabaseRepository<Product>, SqlServerRepository<Product>, DatabaseOptions>(
    x => x.ConnectionString = configuration.GetConnectionString("SqlServer"),
    "sqlserver",
    ServiceLifetime.Scoped
);

services.AddFactory<IDatabaseRepository<Product>, MongoDbRepository<Product>, DatabaseOptions>(
    x => x.ConnectionString = configuration.GetConnectionString("MongoDb"),
    "mongodb",
    ServiceLifetime.Scoped
);

// Usage
public class ProductService
{
    private readonly IFactory<IDatabaseRepository<Product>> _repositoryFactory;
    
    public ProductService(IFactory<IDatabaseRepository<Product>> repositoryFactory)
    {
        _repositoryFactory = repositoryFactory;
    }
    
    public async Task MigrateProductAsync(Product product, string fromDb, string toDb)
    {
        var sourceRepo = _repositoryFactory.Create(fromDb);
        var targetRepo = _repositoryFactory.Create(toDb);
        
        var productData = await sourceRepo.GetAsync(product.Id);
        await targetRepo.InsertAsync(productData);
    }
}
```

### Logging with Decorator

```csharp
public class LoggingPaymentGatewayDecorator : IPaymentGateway, IDecoratorService<IPaymentGateway>
{
    private readonly ILogger<LoggingPaymentGatewayDecorator> _logger;
    public IPaymentGateway DecoratedService { get; private set; }
    
    public LoggingPaymentGatewayDecorator(ILogger<LoggingPaymentGatewayDecorator> logger)
    {
        _logger = logger;
    }
    
    public void SetDecoratedService(IPaymentGateway service)
    {
        DecoratedService = service;
    }
    
    public async Task<PaymentResult> ProcessAsync(decimal amount, string currency)
    {
        _logger.LogInformation("Processing payment: {Amount} {Currency}", amount, currency);
        
        var result = await DecoratedService.ProcessAsync(amount, currency);
        
        _logger.LogInformation("Payment result: {Success}", result.Success);
        
        return result;
    }
}

// Add logging to all payment gateways
services.AddDecoration<IPaymentGateway, LoggingPaymentGatewayDecorator>(
    null, // Apply to all
    ServiceLifetime.Scoped
);
```

---

## Warm Up

Execute initialization code **after service provider is built**:

```csharp
builder.Services.AddWarmUp(() =>
{
    // Initialize cache
    var cache = serviceProvider.GetRequiredService<ICache>();
    cache.LoadAsync().Wait();
});

builder.Services.AddWarmUp(async () =>
{
    // Async warm-up
    var database = serviceProvider.GetRequiredService<IDatabase>();
    await database.MigrateAsync();
});

var app = builder.Build();
await app.Services.WarmUpAsync();
```

---

## Benefits

- ✅ **Runtime Resolution**: Choose implementation by name at runtime
- ✅ **Multiple Implementations**: Register multiple services of same interface
- ✅ **Lifetime Support**: Singleton, Scoped, Transient work as expected
- ✅ **Options Pattern**: Configure each service independently
- ✅ **Decorators**: Wrap services without modifying code
- ✅ **Fallbacks**: Handle missing keys gracefully
- ✅ **Assembly Scanning**: Auto-discover services

---

## Related Tools

- **[Repository Pattern](https://rystem.net/mcp/tools/repository-setup.md)** - Uses factory pattern for multiple repositories
- **[Service Setup](https://rystem.net/mcp/prompts/service-setup.md)** - DI setup patterns
- **[Discriminated Union](https://rystem.net/mcp/tools/rystem-discriminated-union.md)** - Type-safe unions

---

## References

- **NuGet Package**: [Rystem.DependencyInjection](https://www.nuget.org/packages/Rystem.DependencyInjection) v9.1.3
- **Documentation**: https://rystem.net
- **GitHub**: https://github.com/KeyserDSoze/Rystem

---

## Discriminated Union with AnyOf

> Implement type-safe discriminated unions in C# with AnyOf - supports up to 8 types, automatic JSON serialization/deserialization with intelligent type detection, pattern matching, and selector attributes

---
title: Discriminated Union with AnyOf
description: Implement type-safe discriminated unions in C# with AnyOf - supports up to 8 types, automatic JSON serialization/deserialization with intelligent type detection, pattern matching, and selector attributes
---

# Discriminated Union with AnyOf

## What is a Discriminated Union?

A **discriminated union** is a type that can hold **one of several predefined types** at a time. It provides a way to represent and operate on data that may take different forms, ensuring **type safety** and improving **code readability**.

Unlike traditional inheritance or interfaces, discriminated unions allow you to work with completely unrelated types in a type-safe manner.

**Example:**

```csharp
AnyOf<int, string, bool> value;
```

The `value` can hold an integer, a string, or a boolean, but **never more than one type at a time**.

---

## Why Use AnyOf Instead of Interfaces?

Traditional C# requires a common interface or base class to work with multiple types polymorphically:

```csharp
// Traditional approach - requires interface
public interface IResult { }
public class SuccessResult : IResult { public string Data { get; set; } }
public class ErrorResult : IResult { public int Code { get; set; } }

public IResult GetResult() => new SuccessResult { Data = "OK" };
```

**With AnyOf**, you don't need interfaces:

```csharp
// AnyOf approach - no interfaces needed
public class SuccessResult { public string Data { get; set; } }
public class ErrorResult { public int Code { get; set; } }

public AnyOf<SuccessResult, ErrorResult> GetResult()
{
    if (success)
        return new SuccessResult { Data = "OK" };
    else
        return new ErrorResult { Code = 500 };
}
```

**Benefits:**
- ✅ No need to define interfaces or base classes
- ✅ Works with completely unrelated types
- ✅ Type safety at compile time
- ✅ Automatic JSON serialization with intelligent type detection
- ✅ Pattern matching support

---

## Installation

```bash
dotnet add package Rystem --version 9.1.3
```

---

## Quick Start

### Basic Usage

```csharp
using Rystem;

// Define a union that can be int OR string
AnyOf<int, string> value;

// Implicit conversion from int
value = 42;

// Implicit conversion from string
value = "Hello";

// Check which type is currently stored
if (value.Is<int>())
{
    int number = value.AsT0; // Access as first type (int)
    Console.WriteLine($"Integer: {number}");
}
else if (value.Is<string>())
{
    string text = value.AsT1; // Access as second type (string)
    Console.WriteLine($"String: {text}");
}
```

### Returning from Methods

```csharp
public AnyOf<int, string> GetSomething(bool check)
{
    if (check)
        return 42;           // Returns int
    else
        return "Hello";      // Returns string
}

var result = GetSomething(true);
result.Switch(
    i => Console.WriteLine($"Got integer: {i}"),
    s => Console.WriteLine($"Got string: {s}")
);
```

---

## Supported Types

AnyOf supports up to **8 types**:

- `AnyOf<T0, T1>` - 2 types
- `AnyOf<T0, T1, T2>` - 3 types
- `AnyOf<T0, T1, T2, T3>` - 4 types
- ... up to ...
- `AnyOf<T0, T1, T2, T3, T4, T5, T6, T7>` - 8 types

**Example with 4 types:**

```csharp
public AnyOf<int, string, bool, DateTime> GetValue(int choice)
{
    return choice switch
    {
        1 => 42,
        2 => "Hello",
        3 => true,
        4 => DateTime.Now,
        _ => throw new ArgumentException()
    };
}
```

---

## Accessing Values

### Type Checking

```csharp
AnyOf<int, string, bool> value = "Hello";

// Check if value is of specific type
bool isInt = value.Is<int>();        // false
bool isString = value.Is<string>();  // true
bool isBool = value.Is<bool>();      // false

// Check by index
bool isFirstType = value.IsT0;       // false (int)
bool isSecondType = value.IsT1;      // true (string)
bool isThirdType = value.IsT2;       // false (bool)
```

### Retrieving Values

```csharp
AnyOf<int, string, bool> value = "Hello";

// Access by type index
string text = value.AsT1;  // "Hello"
// int number = value.AsT0; // Throws exception if not int

// Safe access with TryGet
if (value.TryGet<string>(out var result))
{
    Console.WriteLine($"Got string: {result}");
}
```

---

## Pattern Matching

### Match Method (Returns Value)

The `Match` method allows you to provide **delegates for each possible type**, returning a value based on the stored type.

```csharp
var union = new AnyOf<int, string>(42);

var result = union.Match(
    i => $"Integer: {i}",
    s => $"String: {s}"
);

Console.WriteLine(result); // Outputs: "Integer: 42"
```

**With 3 types:**

```csharp
var union = new AnyOf<int, string, bool>(true);

var result = union.Match(
    i => $"Number: {i}",
    s => $"Text: {s}",
    b => $"Boolean: {b}"
);

Console.WriteLine(result); // Outputs: "Boolean: True"
```

### Switch Method (Performs Actions)

The `Switch` method allows you to **perform different actions** based on the stored type without returning a value.

```csharp
var union = new AnyOf<int, string>("Hello");

union.Switch(
    i => Console.WriteLine($"Integer: {i}"),
    s => Console.WriteLine($"String: {s}")
);
// Outputs: "String: Hello"
```

### Async Pattern Matching

**Async Match Example:**

```csharp
var union = new AnyOf<int, string>("Hello");

var result = await union.MatchAsync(
    async i => await Task.FromResult($"Integer: {i}"),
    async s => await Task.FromResult($"String: {s}")
);

Console.WriteLine(result); // Outputs: "String: Hello"
```

**Async Switch Example:**

```csharp
await union.SwitchAsync(
    async i => 
    { 
        await Task.Delay(100); 
        Console.WriteLine($"Integer: {i}"); 
    },
    async s => 
    { 
        await Task.Delay(100); 
        Console.WriteLine($"String: {s}"); 
    }
);
```

---

## JSON Serialization and Deserialization

One of the **most powerful features** of AnyOf is its **automatic JSON integration** with **intelligent type detection**.

### How It Works: Signature-Based Deserialization

When deserializing JSON, the library uses a **"Signature"** mechanism:

1. Analyzes the **property names** present in the JSON
2. Matches them to a predefined signature for each class in the union
3. Instantiates the correct class based on the match

**Example:**

```csharp
public class FirstClass
{
    public string FirstProperty { get; set; }
    public string SecondProperty { get; set; }
}

public class SecondClass
{
    public string FirstProperty { get; set; }
    public string SecondProperty { get; set; }
}

public class Container
{
    public AnyOf<FirstClass, SecondClass> Value { get; set; }
}
```

**Serialization:**

```csharp
var container = new Container
{
    Value = new FirstClass 
    { 
        FirstProperty = "First", 
        SecondProperty = "Second" 
    }
};

var json = container.ToJson();
// {"Value":{"FirstProperty":"First","SecondProperty":"Second"}}
```

**Deserialization:**

```csharp
var deserialized = json.FromJson<Container>();
// Automatically detects and deserializes as FirstClass
```

### Complete Example

```csharp
public class TestClass
{
    public AnyOf<FirstClass, SecondClass> OneClass_String { get; set; }
    public AnyOf<SecondClass, FirstClass> SecondClass_OneClass { get; set; }
    public AnyOf<FirstClass, string> OneClass_string__2 { get; set; }
    public AnyOf<bool, int> Bool_Int { get; set; }
    public AnyOf<decimal, bool> Decimal_Bool { get; set; }
}

var testClass = new TestClass
{
    OneClass_String = new FirstClass 
    { 
        FirstProperty = "OneClass_String.FirstProperty", 
        SecondProperty = "OneClass_String.SecondProperty" 
    },
    SecondClass_OneClass = new SecondClass
    {
        FirstProperty = "SecondClass_OneClass.FirstProperty",
        SecondProperty = "SecondClass_OneClass.SecondProperty"
    },
    OneClass_string__2 = "ExampleString",
    Bool_Int = 3,
    Decimal_Bool = true
};

// Serialize
var json = testClass.ToJson();

// Deserialize with automatic type detection
var deserialized = json.FromJson<TestClass>();

// Access values
Console.WriteLine(deserialized.OneClass_String.AsT0.FirstProperty); 
// Outputs: OneClass_String.FirstProperty
```

---

## Handling Ambiguous Classes with Attributes

When two classes have the **same properties** (same signature), you need attributes to disambiguate them.

### AnyOfJsonSelector Attribute

Use `[AnyOfJsonSelector]` to specify which **property value** identifies each class.

**Example:**

```csharp
public class ChosenClass
{
    public AnyOf<TheFirstChoice, TheSecondChoice>? FirstProperty { get; set; }
    public string? SecondProperty { get; set; }
}

public class TheFirstChoice
{
    [AnyOfJsonSelector("first")]
    public string Type { get; init; }
    public int Flexy { get; set; }
}

public class TheSecondChoice
{
    [AnyOfJsonSelector("third", "second")]
    public string Type { get; init; }
    public int Flexy { get; set; }
}
```

**How it works:**

1. **If `Type == "first"`** → Deserializes as `TheFirstChoice`
2. **If `Type == "third"` or `Type == "second"`** → Deserializes as `TheSecondChoice`

**Test Case 1:**

```csharp
var testClass = new ChosenClass
{
    FirstProperty = new TheSecondChoice
    {
        Type = "first",  // Selector matches TheFirstChoice
        Flexy = 1,
    }
};

var json = testClass.ToJson();
var deserialized = json.FromJson<ChosenClass>();

Assert.True(deserialized.FirstProperty.Is<TheFirstChoice>());
```

**Test Case 2:**

```csharp
var testClass = new ChosenClass
{
    FirstProperty = new TheSecondChoice
    {
        Type = "third",  // Selector matches TheSecondChoice
        Flexy = 1,
    }
};

var json = testClass.ToJson();
var deserialized = json.FromJson<ChosenClass>();

Assert.True(deserialized.FirstProperty.Is<TheSecondChoice>());
```

---

## Advanced Attributes

### AnyOfJsonDefault - Set Default Class

Mark a class as the **default choice** when no other match is found:

```csharp
[AnyOfJsonDefault]
public sealed class RunResult : ApiBaseResponse
{
    // Default fallback class
}
```

### AnyOfJsonRegexSelector - Regex Matching

Use **regex patterns** to match property values:

```csharp
public sealed class FifthGetClass
{
    [AnyOfJsonRegexSelector("fift[^.]*.")]
    public string? FirstProperty { get; set; }
    public string? SecondProperty { get; set; }
}
```

- If `FirstProperty` matches the regex `fift[^.]*.`, deserializes as `FifthGetClass`

### AnyOfJsonClassSelector - Class-Level Selector

Apply selectors at the **class level** instead of property level:

```csharp
[AnyOfJsonClassSelector(nameof(FirstProperty), "first.F")]
public sealed class FirstGetClass
{
    public string? FirstProperty { get; set; }
    public string? SecondProperty { get; set; }
}
```

- If `FirstProperty == "first.F"`, deserializes as `FirstGetClass`

### AnyOfJsonRegexClassSelector - Class-Level Regex

Apply **regex selectors** at the class level:

```csharp
[AnyOfJsonRegexClassSelector(nameof(FirstProperty), "secon[^.]*.[^.]*")]
public sealed class SecondGetClass
{
    public string? FirstProperty { get; set; }
    public string? SecondProperty { get; set; }
}
```

- If `FirstProperty` matches `secon[^.]*.[^.]*`, deserializes as `SecondGetClass`

---

## Real-World Use Cases

### API Response Handling

```csharp
public class SuccessResponse
{
    public string Data { get; set; }
    public int StatusCode { get; set; }
}

public class ErrorResponse
{
    public string Message { get; set; }
    public int ErrorCode { get; set; }
}

public class ApiClient
{
    public async Task<AnyOf<SuccessResponse, ErrorResponse>> CallApiAsync()
    {
        var response = await httpClient.GetAsync("/api/endpoint");
        
        if (response.IsSuccessStatusCode)
        {
            var data = await response.Content.ReadAsStringAsync();
            return new SuccessResponse 
            { 
                Data = data, 
                StatusCode = (int)response.StatusCode 
            };
        }
        else
        {
            return new ErrorResponse 
            { 
                Message = "Request failed", 
                ErrorCode = (int)response.StatusCode 
            };
        }
    }
}

// Usage
var result = await apiClient.CallApiAsync();
result.Switch(
    success => Console.WriteLine($"Success: {success.Data}"),
    error => Console.WriteLine($"Error: {error.Message}")
);
```

### Domain Events

```csharp
public class OrderCreatedEvent
{
    public Guid OrderId { get; set; }
    public decimal Total { get; set; }
}

public class OrderCancelledEvent
{
    public Guid OrderId { get; set; }
    public string Reason { get; set; }
}

public class OrderShippedEvent
{
    public Guid OrderId { get; set; }
    public string TrackingNumber { get; set; }
}

public class EventHandler
{
    public void HandleEvent(AnyOf<OrderCreatedEvent, OrderCancelledEvent, OrderShippedEvent> domainEvent)
    {
        domainEvent.Switch(
            created => ProcessOrderCreated(created),
            cancelled => ProcessOrderCancelled(cancelled),
            shipped => ProcessOrderShipped(shipped)
        );
    }
}
```

### Validation Results

```csharp
public class ValidationSuccess
{
    public string Message { get; set; }
}

public class ValidationError
{
    public List<string> Errors { get; set; }
}

public class Validator
{
    public AnyOf<ValidationSuccess, ValidationError> Validate(User user)
    {
        var errors = new List<string>();
        
        if (string.IsNullOrEmpty(user.Email))
            errors.Add("Email is required");
        
        if (user.Age < 18)
            errors.Add("User must be 18 or older");
        
        if (errors.Any())
            return new ValidationError { Errors = errors };
        
        return new ValidationSuccess { Message = "Validation successful" };
    }
}

// Usage
var result = validator.Validate(user);
var message = result.Match(
    success => success.Message,
    error => string.Join(", ", error.Errors)
);
```

---

## Benefits of Using AnyOf

1. **Type Safety**: Ensures only predefined types are used at compile time
2. **No Interfaces Required**: Works with completely unrelated types
3. **Automatic JSON Support**: Intelligent type detection during deserialization
4. **Code Clarity**: Reduces boilerplate for type management
5. **Pattern Matching**: Clean, functional-style code with `Match` and `Switch`
6. **Flexible Disambiguation**: Multiple attributes for complex scenarios

---

## Related Tools

- **[Repository Pattern Setup](https://rystem.net/mcp/tools/repository-setup.md)** - Use AnyOf for flexible repository return types
- **[DDD Single Domain](https://rystem.net/mcp/tools/ddd-single-domain.md)** - Use AnyOf for domain events
- **[JSON Extensions](https://rystem.net/mcp/tools/rystem-json-extensions.md)** - JSON serialization utilities

---

## References

- **NuGet Package**: [Rystem](https://www.nuget.org/packages/Rystem) v9.1.3
- **Documentation**: https://rystem.net
- **GitHub**: https://github.com/KeyserDSoze/Rystem

---

## JSON Extensions

> Simple JSON serialization and deserialization with ToJson() and FromJson<T>() - no more JsonSerializer.Serialize boilerplate

---
title: JSON Extensions
description: Simple JSON serialization and deserialization with ToJson() and FromJson<T>() - no more JsonSerializer.Serialize boilerplate
---

# JSON Extensions

Simple **JSON serialization and deserialization** extension methods. No more `JsonSerializer.Serialize` boilerplate!

---

## Installation

```bash
dotnet add package Rystem --version 9.1.3
```

---

## Quick Start

### Serialize to JSON

```csharp
using Rystem;

public class User
{
    public Guid Id { get; set; }
    public string Name { get; set; }
    public string Email { get; set; }
}

var user = new User
{
    Id = Guid.NewGuid(),
    Name = "John Doe",
    Email = "john@example.com"
};

string json = user.ToJson();

Console.WriteLine(json);
// {"Id":"a1b2c3d4-e5f6-7890-1234-567890abcdef","Name":"John Doe","Email":"john@example.com"}
```

### Deserialize from JSON

```csharp
string json = "{\"Id\":\"a1b2c3d4-e5f6-7890-1234-567890abcdef\",\"Name\":\"John Doe\",\"Email\":\"john@example.com\"}";

var user = json.FromJson<User>();

Console.WriteLine($"Name: {user.Name}, Email: {user.Email}");
```

---

## Before and After

### Before (Standard C#)

```csharp
// Serialize
var options = new JsonSerializerOptions { WriteIndented = false };
string json = JsonSerializer.Serialize(user, options);

// Deserialize
var user = JsonSerializer.Deserialize<User>(json, options);
```

### After (With Rystem)

```csharp
// Serialize
string json = user.ToJson();

// Deserialize
var user = json.FromJson<User>();
```

**Benefits:**
- ✅ Less boilerplate
- ✅ Cleaner code
- ✅ Easier to read
- ✅ No need to remember JsonSerializer class name

---

## Real-World Examples

### API Response Handling

```csharp
public async Task<User> GetUserAsync(Guid userId)
{
    var response = await httpClient.GetAsync($"/api/users/{userId}");
    var json = await response.Content.ReadAsStringAsync();
    
    return json.FromJson<User>();
}
```

### Configuration Loading

```csharp
public class ConfigManager
{
    public AppConfig LoadConfig(string filePath)
    {
        string json = File.ReadAllText(filePath);
        return json.FromJson<AppConfig>();
    }
    
    public void SaveConfig(AppConfig config, string filePath)
    {
        string json = config.ToJson();
        File.WriteAllText(filePath, json);
    }
}
```

### Cache Storage

```csharp
public class CacheService
{
    private readonly IDistributedCache _cache;
    
    public async Task SetAsync<T>(string key, T value)
    {
        string json = value.ToJson();
        byte[] bytes = json.ToByteArray();
        await _cache.SetAsync(key, bytes);
    }
    
    public async Task<T> GetAsync<T>(string key)
    {
        var bytes = await _cache.GetAsync(key);
        if (bytes == null) return default;
        
        string json = bytes.ConvertToString();
        return json.FromJson<T>();
    }
}
```

### Logging

```csharp
public class OrderService
{
    private readonly ILogger<OrderService> _logger;
    
    public async Task ProcessOrderAsync(Order order)
    {
        _logger.LogInformation("Processing order: {OrderJson}", order.ToJson());
        
        try
        {
            // Process order
            await ProcessAsync(order);
            
            _logger.LogInformation("Order processed successfully: {OrderId}", order.Id);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error processing order: {OrderJson}", order.ToJson());
            throw;
        }
    }
}
```

### Message Queue

```csharp
public class QueuePublisher
{
    private readonly IQueue _queue;
    
    public async Task PublishAsync<T>(T message)
    {
        string json = message.ToJson();
        byte[] body = json.ToByteArray();
        
        await _queue.SendAsync(body);
    }
}

public class QueueConsumer
{
    public async Task<T> ReceiveAsync<T>()
    {
        var body = await _queue.ReceiveAsync();
        string json = body.ConvertToString();
        
        return json.FromJson<T>();
    }
}
```

### Deep Clone

```csharp
public static class ObjectExtensions
{
    public static T DeepClone<T>(this T obj)
    {
        string json = obj.ToJson();
        return json.FromJson<T>();
    }
}

// Usage
var originalOrder = new Order { Id = Guid.NewGuid(), Total = 100 };
var clonedOrder = originalOrder.DeepClone();

clonedOrder.Total = 200;
// originalOrder.Total is still 100
```

### Event Sourcing

```csharp
public class EventStore
{
    public async Task SaveEventAsync<T>(T domainEvent) where T : IDomainEvent
    {
        var eventData = new EventData
        {
            EventId = Guid.NewGuid(),
            EventType = typeof(T).Name,
            Data = domainEvent.ToJson(),
            Timestamp = DateTime.UtcNow
        };
        
        await eventRepository.InsertAsync(eventData);
    }
    
    public async Task<T> LoadEventAsync<T>(Guid eventId) where T : IDomainEvent
    {
        var eventData = await eventRepository.GetAsync(eventId);
        return eventData.Data.FromJson<T>();
    }
}
```

---

## Working with Collections

### List Serialization

```csharp
var users = new List<User>
{
    new User { Id = Guid.NewGuid(), Name = "John", Email = "john@example.com" },
    new User { Id = Guid.NewGuid(), Name = "Jane", Email = "jane@example.com" }
};

string json = users.ToJson();
var deserializedUsers = json.FromJson<List<User>>();
```

### Dictionary Serialization

```csharp
var settings = new Dictionary<string, string>
{
    { "Theme", "Dark" },
    { "Language", "en-US" }
};

string json = settings.ToJson();
var deserializedSettings = json.FromJson<Dictionary<string, string>>();
```

---

## Integration with Other Rystem Tools

### With AnyOf (Discriminated Unions)

```csharp
var result = new AnyOf<SuccessResponse, ErrorResponse>(
    new SuccessResponse { Data = "OK" }
);

string json = result.ToJson();
var deserialized = json.FromJson<AnyOf<SuccessResponse, ErrorResponse>>();
```

### With Repository Pattern

```csharp
public class ProductService
{
    private readonly IRepository<Product> _repository;
    private readonly ILogger _logger;
    
    public async Task<Product> CreateProductAsync(string productJson)
    {
        var product = productJson.FromJson<Product>();
        
        _logger.LogInformation("Creating product: {ProductJson}", product.ToJson());
        
        return await _repository.InsertAsync(product);
    }
}
```

---

## Benefits

- ✅ **Simplicity**: No more `JsonSerializer.Serialize` boilerplate
- ✅ **Readability**: Cleaner, more readable code
- ✅ **Consistency**: Same pattern across entire codebase
- ✅ **Less Typing**: Shorter method names
- ✅ **Easier Testing**: Simple to serialize/deserialize in tests

---

## Related Tools

- **[CSV and Minimization](https://rystem.net/mcp/tools/rystem-csv.md)** - Alternative serialization formats
- **[Text Extensions](https://rystem.net/mcp/tools/rystem-text-extensions.md)** - String/byte/stream utilities
- **[Discriminated Union](https://rystem.net/mcp/tools/rystem-discriminated-union.md)** - Type-safe unions with JSON support
- **[Repository API](https://rystem.net/mcp/tools/repository-api-server.md)** - JSON APIs

---

## References

- **NuGet Package**: [Rystem](https://www.nuget.org/packages/Rystem) v9.1.3
- **Documentation**: https://rystem.net
- **GitHub**: https://github.com/KeyserDSoze/Rystem

---

## LINQ Expression Serializer

> Serialize and deserialize LINQ expressions as strings - enables dynamic queries, expression storage in database, and runtime expression compilation with Serialize(), Deserialize(), and DeserializeAsDynamic()

---
title: LINQ Expression Serializer
description: Serialize and deserialize LINQ expressions as strings - enables dynamic queries, expression storage in database, and runtime expression compilation with Serialize(), Deserialize(), and DeserializeAsDynamic()
---

# LINQ Expression Serializer

Serialize and deserialize **LINQ expressions** as strings. This allows you to:
- Store expressions in databases
- Send expressions over the network
- Build dynamic queries at runtime
- Create configurable filters and sorting

---

## Installation

```bash
dotnet add package Rystem --version 9.1.3
```

---

## Quick Start

### Serialize Expression to String

```csharp
using Rystem;

Expression<Func<Product, bool>> expression = p => p.Price > 100 && p.IsActive;

string serialized = expression.Serialize();

Console.WriteLine(serialized);
// Output: "p => ((p.Price > 100) AndAlso p.IsActive)"
```

### Deserialize String to Expression

```csharp
string expressionString = "p => ((p.Price > 100) AndAlso p.IsActive)";

var expression = expressionString.Deserialize<Product, bool>();

// Use with LINQ
var filteredProducts = products.Where(expression.Compile()).ToList();
```

---

## Serialize and Deserialize

### Basic Example

```csharp
public class MakeIt
{
    public string X { get; set; }
    public List<string> Samules { get; set; }
    public bool Sol { get; set; }
    public Guid E { get; set; }
    public int Id { get; set; }
    public MakeType Type { get; set; }
}

public enum MakeType
{
    Yes = 1,
    No = 2
}

// Variables used in expression
string q = "dasda";
string k = "ccccde";
bool IsOk = true;
Guid id = Guid.Parse("bf46510b-b7e6-4ba2-88da-cef208aa81f2");
int V = 32;
MakeType qq = MakeType.No;

// Complex expression
Expression<Func<MakeIt, bool>> expression = ƒ => 
    ƒ.X == q && 
    ƒ.Samules.Any(x => x == k) && 
    ƒ.Sol && 
    (ƒ.X.Contains(q) || ƒ.Sol.Equals(IsOk)) && 
    (ƒ.E == id | ƒ.Id == V) && 
    (ƒ.Type == MakeType.Yes || ƒ.Type == qq);

// Serialize
var serialized = expression.Serialize();

Console.WriteLine(serialized);
// Output:
// "ƒ => ((((((ƒ.X == \"dasda\") AndAlso ƒ.Samules.Any(x => (x == \"ccccde\"))) AndAlso ƒ.Sol) AndAlso (ƒ.X.Contains(\"dasda\") OrElse ƒ.Sol.Equals(True))) AndAlso ((ƒ.E == Guid.Parse(\"bf46510b-b7e6-4ba2-88da-cef208aa81f2\")) Or (ƒ.Id == 32))) AndAlso ((ƒ.Type == 1) OrElse (ƒ.Type == 2)))"

// Deserialize
var newExpression = serialized.Deserialize<MakeIt, bool>();

// Use with LINQ
var result = makes.Where(newExpression.Compile()).ToList();
```

---

## Deserialize and Compile in One Step

Use `DeserializeAndCompile()` to get a compiled expression directly:

```csharp
string expressionString = "p => p.Price > 100";

var compiledFunc = expressionString.DeserializeAndCompile<Product, bool>();

// Use directly with LINQ
var filteredProducts = products.Where(compiledFunc).ToList();
```

---

## Dynamic LINQ with DeserializeAsDynamic

For **dynamic queries** with `OrderBy`, `ThenBy`, etc., use `DeserializeAsDynamic()`:

```csharp
public class MakeIt
{
    public int Id { get; set; }
    public string Name { get; set; }
    public decimal Price { get; set; }
}

// Serialize an expression
Expression<Func<MakeIt, int>> expression = x => x.Id;
string value = expression.Serialize();

// Deserialize as dynamic
LambdaExpression newLambda = value.DeserializeAsDynamic<MakeIt>();

// Use with dynamic LINQ
var got = makes.AsQueryable();
var sorted = got.OrderByDescending(newLambda)
                .ThenByDescending(newLambda)
                .ToList();
```

---

## Change Return Type

You can **change the return type** of a lambda expression at runtime:

```csharp
Expression<Func<Product, int>> expression = p => p.Id;
string value = expression.Serialize();

LambdaExpression newLambda = value.DeserializeAsDynamic<Product>();

// Change return type to bool
newLambda = newLambda.ChangeReturnType<bool>();

// Or with Type
newLambda = newLambda.ChangeReturnType(typeof(bool));
```

---

## Limitations

⚠️ **Only primitives are allowed** in the expression body:
- `int`, `string`, `bool`, `decimal`, `Guid`, `DateTime`, etc.
- Enums
- Method calls on primitives (e.g., `string.Contains()`, `Guid.Parse()`)

❌ **Not supported**:
- Complex object initialization inside expressions
- Anonymous types
- Method calls on non-primitive types (unless they are primitives like `string`, `Guid`)

---

## Real-World Examples

### Store Filters in Database

```csharp
public class SavedFilter
{
    public Guid Id { get; set; }
    public string Name { get; set; }
    public string Expression { get; set; }
}

// Save filter
var filter = new SavedFilter
{
    Id = Guid.NewGuid(),
    Name = "Active Products Over $100",
    Expression = ((Expression<Func<Product, bool>>)(p => p.Price > 100 && p.IsActive)).Serialize()
};

await filterRepository.InsertAsync(filter);

// Load and apply filter
var savedFilter = await filterRepository.GetAsync(filterId);
var expression = savedFilter.Expression.Deserialize<Product, bool>();
var products = await productRepository.QueryAsync(expression.Compile());
```

### Dynamic Sorting from User Input

```csharp
public class SortOptions
{
    public string SortBy { get; set; } // "Id", "Name", "Price"
    public bool Descending { get; set; }
}

public async Task<List<Product>> GetProductsAsync(SortOptions options)
{
    var products = await productRepository.QueryAsync(x => x.IsActive);
    
    // Build expression from user input
    Expression<Func<Product, object>> sortExpression = options.SortBy switch
    {
        "Id" => p => p.Id,
        "Name" => p => p.Name,
        "Price" => p => p.Price,
        _ => p => p.Id
    };
    
    // Serialize and deserialize as dynamic
    var dynamicExpression = sortExpression.Serialize().DeserializeAsDynamic<Product>();
    
    // Apply sorting
    var query = products.AsQueryable();
    return options.Descending
        ? query.OrderByDescending(dynamicExpression).ToList()
        : query.OrderBy(dynamicExpression).ToList();
}
```

### API Query Parameters

```csharp
[HttpGet]
public async Task<IActionResult> GetOrders([FromQuery] string? filter)
{
    IQueryable<Order> query = dbContext.Orders;
    
    if (!string.IsNullOrEmpty(filter))
    {
        // Client sends: "o => o.Total > 500 && o.Status == 1"
        var expression = filter.Deserialize<Order, bool>();
        query = query.Where(expression.Compile()).AsQueryable();
    }
    
    return Ok(await query.ToListAsync());
}
```

### Dynamic Reports

```csharp
public class ReportDefinition
{
    public string Name { get; set; }
    public string FilterExpression { get; set; }
    public string GroupByExpression { get; set; }
}

public async Task<ReportResult> GenerateReportAsync(ReportDefinition definition)
{
    // Apply filter
    var filterExpr = definition.FilterExpression.Deserialize<Order, bool>();
    var orders = await orderRepository.QueryAsync(filterExpr.Compile());
    
    // Apply grouping
    var groupByExpr = definition.GroupByExpression.DeserializeAsDynamic<Order>();
    var grouped = orders.AsQueryable().GroupBy(groupByExpr).ToList();
    
    return new ReportResult
    {
        Name = definition.Name,
        Groups = grouped
    };
}
```

---

## Benefits

- ✅ **Store Expressions**: Save filters/queries in database
- ✅ **Dynamic Queries**: Build queries at runtime from user input
- ✅ **Type Safety**: Still uses strongly-typed expressions
- ✅ **LINQ Integration**: Works with `Where`, `OrderBy`, `GroupBy`, etc.
- ✅ **Serializable**: Send expressions over network or save to storage

---

## Related Tools

- **[Repository Pattern](https://rystem.net/mcp/tools/repository-setup.md)** - Use with repository Query methods
- **[Repository API Server](https://rystem.net/mcp/tools/repository-api-server.md)** - Send LINQ expressions via API
- **[JSON Extensions](https://rystem.net/mcp/tools/rystem-json-extensions.md)** - JSON utilities for serialization

---

## References

- **NuGet Package**: [Rystem](https://www.nuget.org/packages/Rystem) v9.1.3
- **Documentation**: https://rystem.net
- **GitHub**: https://github.com/KeyserDSoze/Rystem
- **Unit Tests**: [SystemLinq.cs](https://github.com/KeyserDSoze/RystemV3/blob/master/src/Rystem.Test/Rystem.Test.UnitTest/System.Linq/SystemLinq.cs)

---

## In-Memory Queue

> Buffer operations in-memory and process in batches - collect items until buffer size or time limit is reached, then execute batch processing with FIFO/LIFO support

---
title: In-Memory Queue
description: Buffer operations in-memory and process in batches - collect items until buffer size or time limit is reached, then execute batch processing with FIFO/LIFO support
---

# In-Memory Queue

Buffer operations **in-memory** and process them **in batches** based on size or time limits.

**Use Cases:**
- Batch insert to database
- Bulk email sending
- Event aggregation
- Log buffering
- API request batching
- Data pipeline buffering

---

## How It Works

Items are added to an **in-memory queue** and processed when:
1. **Buffer size reached**: Queue has `MaximumBuffer` items
2. **Time limit reached**: `MaximumRetentionCronFormat` time expires

**Example:**
- `MaximumBuffer = 1000` → Process when 1000 items in queue
- `MaximumRetentionCronFormat = "*/3 * * * * *"` → Process every 3 seconds (even if < 1000 items)
- `BackgroundJobCronFormat = "*/1 * * * * *"` → Check every 1 second if processing needed

---

## Installation

```bash
dotnet add package Rystem.Queue --version 9.1.3
```

---

## Configuration

### FIFO Queue (First In First Out)

```csharp
builder.Services.AddMemoryQueue<Sample, SampleQueueManager>(options =>
{
    options.MaximumBuffer = 1000;                           // Process after 1000 items
    options.MaximumRetentionCronFormat = "*/3 * * * * *";   // Process after 3 seconds
    options.BackgroundJobCronFormat = "*/1 * * * * *";      // Check every 1 second
});
```

### LIFO Stack (Last In First Out)

```csharp
builder.Services.AddMemoryStackQueue<Sample, SampleQueueManager>(options =>
{
    options.MaximumBuffer = 1000;
    options.MaximumRetentionCronFormat = "*/3 * * * * *";
    options.BackgroundJobCronFormat = "*/1 * * * * *";
});
```

---

## Queue Manager

Create a manager to process batches:

```csharp
public class SampleQueueManager : IQueueManager<Sample>
{
    private readonly IRepository<Sample, Guid> _repository;
    private readonly ILogger<SampleQueueManager> _logger;
    
    public SampleQueueManager(
        IRepository<Sample, Guid> repository,
        ILogger<SampleQueueManager> logger)
    {
        _repository = repository;
        _logger = logger;
    }
    
    public async Task ManageAsync(IEnumerable<Sample> items)
    {
        // Process batch
        var itemList = items.ToList();
        _logger.LogInformation("Processing {Count} items", itemList.Count);
        
        foreach (var item in itemList)
        {
            await _repository.InsertAsync(item);
        }
        
        _logger.LogInformation("Batch processing completed");
    }
}
```

---

## Warm Up

Start the background job:

```csharp
var app = builder.Build();

// Start queue background job
await app.Services.WarmUpAsync();

app.Run();
```

---

## Usage

### Add Items to Queue

```csharp
public class OrderService
{
    private readonly IQueue<OrderEvent> _queue;
    
    public OrderService(IQueue<OrderEvent> queue)
    {
        _queue = queue;
    }
    
    public async Task CreateOrderAsync(Order order)
    {
        // Add to queue (non-blocking)
        await _queue.AddAsync(new OrderEvent
        {
            Id = Guid.NewGuid(),
            OrderId = order.Id,
            Timestamp = DateTime.UtcNow
        });
        
        // Returns immediately, batch processing happens later
    }
}
```

### Check Queue Status

```csharp
var count = await _queue.CountAsync();
Console.WriteLine($"Queue has {count} items");
```

---

## Complete Example

```csharp
using Rystem.Queue;

var builder = WebApplication.CreateBuilder(args);

// Configure queue
builder.Services.AddMemoryQueue<LogEntry, LogBatchProcessor>(options =>
{
    options.MaximumBuffer = 100;                           // Process after 100 logs
    options.MaximumRetentionCronFormat = "*/5 * * * * *";  // Process after 5 seconds
    options.BackgroundJobCronFormat = "*/1 * * * * *";     // Check every 1 second
});

builder.Services.AddRepository<LogEntry, Guid>(repositoryBuilder =>
{
    repositoryBuilder.WithEntityFramework<AppDbContext>();
});

var app = builder.Build();

// Start queue processing
await app.Services.WarmUpAsync();

// API endpoint
app.MapPost("/log", async (LogEntry log, IQueue<LogEntry> queue) =>
{
    await queue.AddAsync(log);
    return Results.Ok("Log queued");
});

app.Run();

// ============================================
// LogBatchProcessor.cs
// ============================================
public class LogBatchProcessor : IQueueManager<LogEntry>
{
    private readonly IRepository<LogEntry, Guid> _logRepository;
    private readonly ILogger<LogBatchProcessor> _logger;
    
    public LogBatchProcessor(
        IRepository<LogEntry, Guid> logRepository,
        ILogger<LogBatchProcessor> logger)
    {
        _logRepository = logRepository;
        _logger = logger;
    }
    
    public async Task ManageAsync(IEnumerable<LogEntry> items)
    {
        var logs = items.ToList();
        
        _logger.LogInformation("Processing batch of {Count} logs", logs.Count);
        
        // Bulk insert
        foreach (var log in logs)
        {
            await _logRepository.InsertAsync(log);
        }
        
        _logger.LogInformation("Batch insert completed");
    }
}

public class LogEntry
{
    public Guid Id { get; set; }
    public string Level { get; set; }
    public string Message { get; set; }
    public DateTime Timestamp { get; set; }
}
```

---

## Real-World Examples

### Batch Email Sending

```csharp
// Configuration
builder.Services.AddMemoryQueue<EmailMessage, EmailBatchSender>(options =>
{
    options.MaximumBuffer = 50;                            // Send 50 emails at once
    options.MaximumRetentionCronFormat = "0 */10 * * * *"; // Send every 10 minutes
    options.BackgroundJobCronFormat = "0 */1 * * * * *";   // Check every minute
});

// Queue Manager
public class EmailBatchSender : IQueueManager<EmailMessage>
{
    private readonly IEmailService _emailService;
    private readonly ILogger<EmailBatchSender> _logger;
    
    public EmailBatchSender(IEmailService emailService, ILogger<EmailBatchSender> logger)
    {
        _emailService = emailService;
        _logger = logger;
    }
    
    public async Task ManageAsync(IEnumerable<EmailMessage> items)
    {
        var emails = items.ToList();
        
        _logger.LogInformation("Sending batch of {Count} emails", emails.Count);
        
        await _emailService.SendBulkAsync(emails);
        
        _logger.LogInformation("Email batch sent successfully");
    }
}

// Usage
public class NotificationService
{
    private readonly IQueue<EmailMessage> _emailQueue;
    
    public NotificationService(IQueue<EmailMessage> emailQueue)
    {
        _emailQueue = emailQueue;
    }
    
    public async Task SendWelcomeEmailAsync(User user)
    {
        await _emailQueue.AddAsync(new EmailMessage
        {
            To = user.Email,
            Subject = "Welcome!",
            Body = $"Hello {user.Name}, welcome to our platform!"
        });
    }
}
```

### Event Aggregation

```csharp
// Configuration
builder.Services.AddMemoryQueue<AnalyticsEvent, AnalyticsProcessor>(options =>
{
    options.MaximumBuffer = 1000;                          // Process 1000 events
    options.MaximumRetentionCronFormat = "*/30 * * * * *"; // Process every 30 seconds
    options.BackgroundJobCronFormat = "*/10 * * * * *";    // Check every 10 seconds
});

// Queue Manager
public class AnalyticsProcessor : IQueueManager<AnalyticsEvent>
{
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly ILogger<AnalyticsProcessor> _logger;
    
    public AnalyticsProcessor(
        IHttpClientFactory httpClientFactory,
        ILogger<AnalyticsProcessor> logger)
    {
        _httpClientFactory = httpClientFactory;
        _logger = logger;
    }
    
    public async Task ManageAsync(IEnumerable<AnalyticsEvent> items)
    {
        var events = items.ToList();
        
        _logger.LogInformation("Processing {Count} analytics events", events.Count);
        
        var client = _httpClientFactory.CreateClient("Analytics");
        await client.PostAsJsonAsync("/batch", events);
        
        _logger.LogInformation("Analytics batch sent");
    }
}

// Usage
public class TrackingService
{
    private readonly IQueue<AnalyticsEvent> _analyticsQueue;
    
    public TrackingService(IQueue<AnalyticsEvent> analyticsQueue)
    {
        _analyticsQueue = analyticsQueue;
    }
    
    public async Task TrackPageViewAsync(Guid userId, string page)
    {
        await _analyticsQueue.AddAsync(new AnalyticsEvent
        {
            UserId = userId,
            EventType = "PageView",
            Page = page,
            Timestamp = DateTime.UtcNow
        });
    }
}
```

### Database Bulk Insert

```csharp
// Configuration
builder.Services.AddMemoryQueue<Product, ProductBatchInserter>(options =>
{
    options.MaximumBuffer = 500;                           // Bulk insert 500 products
    options.MaximumRetentionCronFormat = "0 */5 * * * *";  // Insert every 5 minutes
    options.BackgroundJobCronFormat = "0 */1 * * * * *";   // Check every minute
});

// Queue Manager
public class ProductBatchInserter : IQueueManager<Product>
{
    private readonly AppDbContext _dbContext;
    private readonly ILogger<ProductBatchInserter> _logger;
    
    public ProductBatchInserter(AppDbContext dbContext, ILogger<ProductBatchInserter> logger)
    {
        _dbContext = dbContext;
        _logger = logger;
    }
    
    public async Task ManageAsync(IEnumerable<Product> items)
    {
        var products = items.ToList();
        
        _logger.LogInformation("Bulk inserting {Count} products", products.Count);
        
        // EF Core bulk insert
        await _dbContext.Products.AddRangeAsync(products);
        await _dbContext.SaveChangesAsync();
        
        _logger.LogInformation("Bulk insert completed");
    }
}

// Usage
public class ImportService
{
    private readonly IQueue<Product> _productQueue;
    
    public ImportService(IQueue<Product> productQueue)
    {
        _productQueue = productQueue;
    }
    
    public async Task ImportProductAsync(Product product)
    {
        await _productQueue.AddAsync(product);
    }
}
```

### Log Buffering

```csharp
// Configuration
builder.Services.AddMemoryQueue<AuditLog, AuditLogWriter>(options =>
{
    options.MaximumBuffer = 200;                           // Write 200 logs
    options.MaximumRetentionCronFormat = "*/10 * * * * *"; // Write every 10 seconds
    options.BackgroundJobCronFormat = "*/2 * * * * *";     // Check every 2 seconds
});

// Queue Manager
public class AuditLogWriter : IQueueManager<AuditLog>
{
    private readonly IContentRepository _blobStorage;
    private readonly ILogger<AuditLogWriter> _logger;
    
    public AuditLogWriter(
        IContentRepositoryFactory factory,
        ILogger<AuditLogWriter> logger)
    {
        _blobStorage = factory.Create("audit-logs");
        _logger = logger;
    }
    
    public async Task ManageAsync(IEnumerable<AuditLog> items)
    {
        var logs = items.ToList();
        
        _logger.LogInformation("Writing {Count} audit logs", logs.Count);
        
        var fileName = $"audit-{DateTime.UtcNow:yyyyMMdd-HHmmss}.json";
        var json = JsonSerializer.Serialize(logs);
        var data = Encoding.UTF8.GetBytes(json);
        
        await _blobStorage.UploadAsync($"logs/{fileName}", data);
        
        _logger.LogInformation("Audit logs written to {FileName}", fileName);
    }
}
```

### API Request Batching

```csharp
// Configuration
builder.Services.AddMemoryQueue<SyncRequest, ApiSyncBatcher>(options =>
{
    options.MaximumBuffer = 100;                           // Batch 100 requests
    options.MaximumRetentionCronFormat = "*/20 * * * * *"; // Sync every 20 seconds
    options.BackgroundJobCronFormat = "*/5 * * * * *";     // Check every 5 seconds
});

// Queue Manager
public class ApiSyncBatcher : IQueueManager<SyncRequest>
{
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly ILogger<ApiSyncBatcher> _logger;
    
    public ApiSyncBatcher(
        IHttpClientFactory httpClientFactory,
        ILogger<ApiSyncBatcher> logger)
    {
        _httpClientFactory = httpClientFactory;
        _logger = logger;
    }
    
    public async Task ManageAsync(IEnumerable<SyncRequest> items)
    {
        var requests = items.ToList();
        
        _logger.LogInformation("Syncing {Count} requests", requests.Count);
        
        var client = _httpClientFactory.CreateClient("ExternalApi");
        
        var response = await client.PostAsJsonAsync("/batch-sync", new
        {
            Items = requests,
            Timestamp = DateTime.UtcNow
        });
        
        response.EnsureSuccessStatusCode();
        
        _logger.LogInformation("Batch sync completed");
    }
}
```

---

## FIFO vs LIFO

### FIFO (Queue) - First In First Out

```csharp
services.AddMemoryQueue<Item, ItemProcessor>(options => { ... });

// Items processed in order added:
// Add: Item1 → Item2 → Item3
// Process: Item1 → Item2 → Item3
```

**Use when:** Order matters (logs, events, messages)

### LIFO (Stack) - Last In First Out

```csharp
services.AddMemoryStackQueue<Item, ItemProcessor>(options => { ... });

// Items processed in reverse order:
// Add: Item1 → Item2 → Item3
// Process: Item3 → Item2 → Item1
```

**Use when:** Most recent items should be processed first

---

## Custom Integration (Distributed Queue)

Create custom integration for distributed queues (Azure Storage Queue, Event Hub, Service Bus):

```csharp
// Configuration
builder.Services.AddQueueIntegration<Sample, SampleQueueManager, AzureStorageQueueIntegration>(
    options =>
    {
        options.MaximumBuffer = 1000;
        options.MaximumRetentionCronFormat = "*/3 * * * * *";
        options.BackgroundJobCronFormat = "*/1 * * * * *";
    }
);

// Custom Integration
public class AzureStorageQueueIntegration : IQueueIntegration<Sample>
{
    private readonly QueueClient _queueClient;
    
    public AzureStorageQueueIntegration(IConfiguration configuration)
    {
        _queueClient = new QueueClient(
            configuration["Azure:StorageConnectionString"],
            "sample-queue"
        );
    }
    
    public async Task AddAsync(Sample item)
    {
        var message = JsonSerializer.Serialize(item);
        await _queueClient.SendMessageAsync(message);
    }
    
    public async Task<int> CountAsync()
    {
        var properties = await _queueClient.GetPropertiesAsync();
        return properties.Value.ApproximateMessagesCount;
    }
    
    // Implement other IQueueIntegration methods...
}
```

---

## Configuration Options

```csharp
public class QueueOptions
{
    /// <summary>
    /// Maximum items in queue before processing
    /// </summary>
    public int MaximumBuffer { get; set; } = 1000;
    
    /// <summary>
    /// CRON: Maximum time before processing (6 fields)
    /// Example: "*/3 * * * * *" = every 3 seconds
    /// </summary>
    public string MaximumRetentionCronFormat { get; set; }
    
    /// <summary>
    /// CRON: How often to check if processing needed (6 fields)
    /// Should be <= MaximumRetentionCronFormat
    /// Example: "*/1 * * * * *" = every 1 second
    /// </summary>
    public string BackgroundJobCronFormat { get; set; }
}
```

---

## IQueueManager Interface

```csharp
public interface IQueueManager<T>
{
    /// <summary>
    /// Process batch of items
    /// Called when MaximumBuffer reached or MaximumRetention expired
    /// </summary>
    Task ManageAsync(IEnumerable<T> items);
}
```

---

## IQueue Interface

```csharp
public interface IQueue<T>
{
    /// <summary>
    /// Add item to queue
    /// </summary>
    Task AddAsync(T item);
    
    /// <summary>
    /// Get current queue count
    /// </summary>
    Task<int> CountAsync();
}
```

---

## Best Practices

- ✅ **Set appropriate buffer size**: Balance memory usage vs batch efficiency
- ✅ **Use shorter check intervals**: `BackgroundJobCronFormat` ≤ `MaximumRetentionCronFormat`
- ✅ **Handle failures**: Implement retry logic in `ManageAsync`
- ✅ **Log batch processing**: Track queue size, processing time
- ✅ **Monitor memory**: Large buffers can consume significant memory
- ✅ **Use FIFO for ordered processing**: Logs, events, messages
- ✅ **Use LIFO for recency priority**: Notifications, cache updates

---

## When to Use

### Use In-Memory Queue When:
- ✅ Batching database inserts
- ✅ Bulk email sending
- ✅ Event aggregation
- ✅ Log buffering
- ✅ API request batching
- ✅ Single instance application

### Use Distributed Queue Instead When:
- ❌ Multiple app instances (use Azure Queue/Service Bus)
- ❌ Need persistence (queue survives app restart)
- ❌ Cross-service communication
- ❌ Guaranteed delivery required

---

## Benefits

- ✅ **Performance**: Batch processing reduces database round-trips
- ✅ **Efficiency**: Aggregate API calls, reduce network overhead
- ✅ **Simplicity**: Easy configuration with DI
- ✅ **Flexible**: Time-based or size-based processing
- ✅ **Dependency Injection**: Queue manager supports DI

---

## Related Tools

- **[Background Jobs](https://rystem.net/mcp/tools/rystem-backgroundjob.md)** - Scheduled recurring tasks
- **[Async Lock](https://rystem.net/mcp/tools/rystem-async-lock.md)** - Prevent concurrent processing
- **[Repository Pattern](https://rystem.net/mcp/tools/repository-setup.md)** - Batch database operations

---

## References

- **NuGet Package**: [Rystem.Queue](https://www.nuget.org/packages/Rystem.Queue) v9.1.3
- **Documentation**: https://rystem.net
- **CRON Helper**: https://crontab.guru/
- **GitHub**: https://github.com/KeyserDSoze/Rystem

---

## Race Condition

> Allow only the first request to execute within a time window - block duplicate operations with key-based race condition prevention for purchases, payments, submissions

---
title: Race Condition
description: Allow only the first request to execute within a time window - block duplicate operations with key-based race condition prevention for purchases, payments, submissions
---

# Race Condition

Allow **only the first request** to execute within a time window, **block all others**.

**Use Cases:**
- Prevent duplicate purchases
- Block double-click submissions
- Allow only first payment attempt
- Prevent concurrent API calls
- Debounce user actions

---

## What is Race Condition?

A **race condition** occurs when multiple operations compete to execute, and only one should win.

**Example:** User clicks "Purchase" button twice:
- ❌ Without protection: 2 purchases created
- ✅ With race condition: Only first purchase created, second blocked

Learn more: [Race Condition on Wikipedia](https://en.wikipedia.org/wiki/Race_condition)

---

## Installation

```bash
dotnet add package Rystem.Concurrency --version 9.1.3
```

---

## Configuration

```csharp
builder.Services.AddRaceCondition();
```

---

## Usage

### Basic Example

```csharp
public class PurchaseService
{
    private readonly IRaceCondition _raceCondition;
    private readonly IRepository<Order, Guid> _orderRepository;
    
    public PurchaseService(
        IRaceCondition raceCondition,
        IRepository<Order, Guid> orderRepository)
    {
        _raceCondition = raceCondition;
        _orderRepository = orderRepository;
    }
    
    public async Task<Order?> PurchaseItemAsync(Guid itemId, Guid userId)
    {
        // Only first request succeeds, others blocked for 5 seconds
        return await _raceCondition.ExecuteAsync(
            async () =>
            {
                var order = new Order
                {
                    Id = Guid.NewGuid(),
                    ItemId = itemId,
                    UserId = userId,
                    CreatedAt = DateTime.UtcNow
                };
                
                await _orderRepository.InsertAsync(order);
                return order;
            },
            key: $"purchase-item-{itemId}-user-{userId}",
            timeWindow: TimeSpan.FromSeconds(5)
        );
    }
}
```

**What happens:**
1. **First request** (t=0s): Executes, creates order
2. **Second request** (t=1s): Blocked, returns `null`
3. **Third request** (t=3s): Blocked, returns `null`
4. **Fourth request** (t=6s): Executes (after time window expired)

---

## API Reference

```csharp
public interface IRaceCondition
{
    /// <summary>
    /// Execute action if no other execution with same key is in progress
    /// </summary>
    /// <param name="action">Action to execute</param>
    /// <param name="key">Unique key for this operation</param>
    /// <param name="timeWindow">Block duration from first execution</param>
    /// <returns>Action result or null if blocked</returns>
    Task<T?> ExecuteAsync<T>(
        Func<Task<T>> action, 
        string key, 
        TimeSpan timeWindow
    );
}
```

---

## Complete Example

```csharp
using Rystem.Concurrency;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddRaceCondition();

builder.Services.AddRepository<Order, Guid>(repositoryBuilder =>
{
    repositoryBuilder.WithEntityFramework<AppDbContext>();
});

var app = builder.Build();

app.MapPost("/purchase", async (
    Guid itemId,
    Guid userId,
    IRaceCondition raceCondition,
    IRepository<Order, Guid> orderRepository) =>
{
    var result = await raceCondition.ExecuteAsync(
        async () =>
        {
            var order = new Order
            {
                Id = Guid.NewGuid(),
                ItemId = itemId,
                UserId = userId,
                Status = OrderStatus.Completed,
                CreatedAt = DateTime.UtcNow
            };
            
            await orderRepository.InsertAsync(order);
            return order;
        },
        key: $"purchase-{itemId}-{userId}",
        timeWindow: TimeSpan.FromSeconds(5)
    );
    
    if (result != null)
        return Results.Ok(result);
    else
        return Results.Conflict("Duplicate request detected");
});

app.Run();
```

---

## Real-World Examples

### Prevent Double Purchase

```csharp
public class CheckoutService
{
    private readonly IRaceCondition _raceCondition;
    private readonly IRepository<Product, Guid> _productRepository;
    private readonly IRepository<Order, Guid> _orderRepository;
    
    public CheckoutService(
        IRaceCondition raceCondition,
        IRepository<Product, Guid> productRepository,
        IRepository<Order, Guid> orderRepository)
    {
        _raceCondition = raceCondition;
        _productRepository = productRepository;
        _orderRepository = orderRepository;
    }
    
    public async Task<Order?> CheckoutAsync(Guid productId, Guid userId)
    {
        return await _raceCondition.ExecuteAsync(
            async () =>
            {
                var product = await _productRepository.GetAsync(productId);
                
                if (product.Stock <= 0)
                    throw new InvalidOperationException("Out of stock");
                
                product.Stock--;
                await _productRepository.UpdateAsync(product);
                
                var order = new Order
                {
                    Id = Guid.NewGuid(),
                    ProductId = productId,
                    UserId = userId,
                    Price = product.Price,
                    Status = OrderStatus.Completed,
                    CreatedAt = DateTime.UtcNow
                };
                
                await _orderRepository.InsertAsync(order);
                return order;
            },
            key: $"checkout-{productId}-{userId}",
            timeWindow: TimeSpan.FromSeconds(10) // Block for 10 seconds
        );
    }
}
```

### Payment Processing

```csharp
public class PaymentService
{
    private readonly IRaceCondition _raceCondition;
    private readonly IPaymentGateway _paymentGateway;
    private readonly IRepository<Transaction, Guid> _transactionRepository;
    
    public PaymentService(
        IRaceCondition raceCondition,
        IPaymentGateway paymentGateway,
        IRepository<Transaction, Guid> transactionRepository)
    {
        _raceCondition = raceCondition;
        _paymentGateway = paymentGateway;
        _transactionRepository = transactionRepository;
    }
    
    public async Task<Transaction?> ProcessPaymentAsync(Guid orderId, decimal amount)
    {
        return await _raceCondition.ExecuteAsync(
            async () =>
            {
                var paymentResult = await _paymentGateway.ChargeAsync(amount);
                
                var transaction = new Transaction
                {
                    Id = Guid.NewGuid(),
                    OrderId = orderId,
                    Amount = amount,
                    PaymentId = paymentResult.Id,
                    Status = TransactionStatus.Completed,
                    CreatedAt = DateTime.UtcNow
                };
                
                await _transactionRepository.InsertAsync(transaction);
                return transaction;
            },
            key: $"payment-{orderId}",
            timeWindow: TimeSpan.FromSeconds(30) // Block for 30 seconds
        );
    }
}
```

### Form Submission

```csharp
public class FormService
{
    private readonly IRaceCondition _raceCondition;
    private readonly IRepository<FormSubmission, Guid> _submissionRepository;
    
    public FormService(
        IRaceCondition raceCondition,
        IRepository<FormSubmission, Guid> submissionRepository)
    {
        _raceCondition = raceCondition;
        _submissionRepository = submissionRepository;
    }
    
    public async Task<FormSubmission?> SubmitFormAsync(Guid userId, FormData data)
    {
        return await _raceCondition.ExecuteAsync(
            async () =>
            {
                var submission = new FormSubmission
                {
                    Id = Guid.NewGuid(),
                    UserId = userId,
                    Data = data,
                    SubmittedAt = DateTime.UtcNow
                };
                
                await _submissionRepository.InsertAsync(submission);
                
                // Send confirmation email
                await SendConfirmationEmailAsync(userId);
                
                return submission;
            },
            key: $"form-submit-{userId}",
            timeWindow: TimeSpan.FromSeconds(5) // Block double-click
        );
    }
}
```

### API Rate Limiting Per User

```csharp
public class ApiService
{
    private readonly IRaceCondition _raceCondition;
    private readonly IExternalApiClient _apiClient;
    
    public ApiService(
        IRaceCondition raceCondition,
        IExternalApiClient apiClient)
    {
        _raceCondition = raceCondition;
        _apiClient = apiClient;
    }
    
    public async Task<ApiResponse?> CallExternalApiAsync(Guid userId, ApiRequest request)
    {
        return await _raceCondition.ExecuteAsync(
            async () =>
            {
                var response = await _apiClient.SendAsync(request);
                return response;
            },
            key: $"api-call-{userId}",
            timeWindow: TimeSpan.FromSeconds(1) // Max 1 call per second
        );
    }
}
```

### Prevent Concurrent Seat Booking

```csharp
public class BookingService
{
    private readonly IRaceCondition _raceCondition;
    private readonly IRepository<Seat, Guid> _seatRepository;
    private readonly IRepository<Booking, Guid> _bookingRepository;
    
    public BookingService(
        IRaceCondition raceCondition,
        IRepository<Seat, Guid> seatRepository,
        IRepository<Booking, Guid> bookingRepository)
    {
        _raceCondition = raceCondition;
        _seatRepository = seatRepository;
        _bookingRepository = bookingRepository;
    }
    
    public async Task<Booking?> BookSeatAsync(Guid seatId, Guid userId)
    {
        return await _raceCondition.ExecuteAsync(
            async () =>
            {
                var seat = await _seatRepository.GetAsync(seatId);
                
                if (seat.IsBooked)
                    throw new InvalidOperationException("Seat already booked");
                
                seat.IsBooked = true;
                await _seatRepository.UpdateAsync(seat);
                
                var booking = new Booking
                {
                    Id = Guid.NewGuid(),
                    SeatId = seatId,
                    UserId = userId,
                    BookedAt = DateTime.UtcNow
                };
                
                await _bookingRepository.InsertAsync(booking);
                return booking;
            },
            key: $"seat-{seatId}",
            timeWindow: TimeSpan.FromSeconds(10)
        );
    }
}
```

---

## Difference from Async Lock

### Async Lock (Queue Execution)

```csharp
// Async Lock: ALL requests execute (queued)
await _lock.ExecuteAsync(async () =>
{
    // Request 1: Executes immediately
    // Request 2: Waits, then executes
    // Request 3: Waits, then executes
}, key: "item-21");
```

**Result:** All 3 requests execute in order

### Race Condition (Block Duplicates)

```csharp
// Race Condition: ONLY FIRST executes (others blocked)
await _raceCondition.ExecuteAsync(async () =>
{
    // Request 1: Executes
    // Request 2: Returns null (blocked)
    // Request 3: Returns null (blocked)
}, key: "item-21", timeWindow: TimeSpan.FromSeconds(5));
```

**Result:** Only first request executes, others return `null`

---

## Use Cases Comparison

| Scenario | Use Async Lock | Use Race Condition |
|----------|---------------|-------------------|
| **Purchase item** | If you want to queue purchases | If you want to block duplicates ✅ |
| **Update profile** | If all updates should apply ✅ | If only first update matters |
| **Payment** | If retry payments should queue | If duplicates should be blocked ✅ |
| **Seat booking** | If you want to queue bookings | If only first booking wins ✅ |
| **Form submit** | If resubmits should queue | If duplicates should be blocked ✅ |

---

## When to Use

### Use Race Condition When:
- ✅ Prevent duplicate purchases
- ✅ Block double-click submissions
- ✅ Allow only first payment
- ✅ Debounce user actions
- ✅ Rate limit API calls per user

### Use Async Lock Instead When:
- ❌ Need to queue all operations (not block them)
- ❌ All requests should eventually execute
- ❌ Need ordered execution

---

## Best Practices

- ✅ **Choose appropriate time window**: Long enough to cover operation + network delay
- ✅ **Use specific keys**: `"purchase-{itemId}-{userId}"` not just `"purchase"`
- ✅ **Handle null results**: Inform user about duplicate request
- ✅ **Log blocked requests**: Monitor for potential issues
- ✅ **Test time windows**: Ensure they match your use case

---

## Benefits

- ✅ **Prevents Duplicates**: Only first request executes
- ✅ **Simple API**: Just wrap with `ExecuteAsync()`
- ✅ **Key-Based**: Different resources don't block each other
- ✅ **Time Window**: Automatic expiration
- ✅ **Thread-Safe**: Works with concurrent requests

---

## Related Tools

- **[Async Lock](https://rystem.net/mcp/tools/rystem-async-lock.md)** - Queue operations, execute all
- **[Concurrency Control](https://rystem.net/mcp/resources/concurrency.md)** - Best practices
- **[Background Jobs](https://rystem.net/mcp/tools/rystem-backgroundjob.md)** - Scheduled tasks

---

## References

- **NuGet Package**: [Rystem.Concurrency](https://www.nuget.org/packages/Rystem.Concurrency) v9.1.3
- **Documentation**: https://rystem.net
- **Wikipedia**: https://en.wikipedia.org/wiki/Race_condition
- **GitHub**: https://github.com/KeyserDSoze/Rystem

---

## Reflection Utilities

> Advanced reflection helpers for C# - includes NameOfCallingClass(), FetchProperties() caching, IsTheSameTypeOrASon() type checking, CreateInstance() mocking for abstracts/interfaces, and IsNullable() for nullability detection

---
title: Reflection Utilities
description: Advanced reflection helpers for C# - includes NameOfCallingClass(), FetchProperties() caching, IsTheSameTypeOrASon() type checking, CreateInstance() mocking for abstracts/interfaces, and IsNullable() for nullability detection
---

# Reflection Utilities

Advanced **reflection helpers** for C# to simplify common reflection tasks with performance optimizations.

---

## Installation

```bash
dotnet add package Rystem --version 9.1.3
```

---

## Name of Calling Class

Get the name of the class that called your method:

```csharp
using Rystem;

public class MyService
{
    public void DoSomething()
    {
        // Get calling class name
        string callerName = ReflectionHelper.NameOfCallingClass(deep: 1, fullName: false);
        
        Console.WriteLine($"Called by: {callerName}");
    }
}
```

**Parameters:**
- **`deep`**: How many levels up the call stack
  - `deep = 1`: Immediate caller
  - `deep = 2`: Caller of the caller
  - etc.
- **`fullName`**: If `true`, returns full namespace + class name

**Example:**

```csharp
public class Controller
{
    public void ProcessRequest()
    {
        var service = new Service();
        service.DoWork(); // Will print "Controller"
    }
}

public class Service
{
    public void DoWork()
    {
        string caller = ReflectionHelper.NameOfCallingClass(1, fullName: false);
        Console.WriteLine($"Called by: {caller}"); // Outputs: "Controller"
    }
}
```

---

## Cached Property, Field, and Constructor Access

Improve performance by **caching** reflection metadata:

### Fetch Properties

```csharp
public class Product
{
    public Guid Id { get; set; }
    public string Name { get; set; }
    public decimal Price { get; set; }
}

// Fetch and cache properties
var properties = typeof(Product).FetchProperties();

foreach (var prop in properties)
{
    Console.WriteLine($"Property: {prop.Name}, Type: {prop.PropertyType}");
}
```

### Fetch Constructors

```csharp
var constructors = typeof(Product).FetchConstructors();

foreach (var ctor in constructors)
{
    Console.WriteLine($"Constructor with {ctor.GetParameters().Length} parameters");
}
```

### Fetch Fields

```csharp
public class Config
{
    public static readonly string Version = "1.0";
    private int _counter;
}

var fields = typeof(Config).FetchFields();

foreach (var field in fields)
{
    Console.WriteLine($"Field: {field.Name}, Type: {field.FieldType}");
}
```

**Benefits:**
- ✅ **Performance**: Results are cached for subsequent calls
- ✅ **Consistency**: Always returns the same cached collection
- ✅ **Convenience**: No need to manually cache reflection metadata

---

## Type Relationship Checking

Check if a type is a **parent, child, or same type** as another:

### IsTheSameTypeOrASon

Check if an object is the same type or a **derived type**:

```csharp
public class Sulo { }
public class Zalo : Sulo { }
public class Folli : Sulo { }

Zalo zalo = new();
Zalo zalo2 = new();
Folli folli = new();
Sulo sulo = new();
object quo = new();
int x = 2;
decimal y = 3;

// Same type or child
Assert.True(zalo.IsTheSameTypeOrASon(sulo));      // Zalo is son of Sulo ✅
Assert.True(folli.IsTheSameTypeOrASon(sulo));     // Folli is son of Sulo ✅
Assert.True(zalo.IsTheSameTypeOrASon(zalo2));     // Zalo is same as Zalo ✅
Assert.True(zalo.IsTheSameTypeOrASon(quo));       // Zalo is son of object ✅
Assert.False(sulo.IsTheSameTypeOrASon(zalo));     // Sulo is NOT son of Zalo ❌
```

### IsTheSameTypeOrAParent

Check if an object is the same type or a **parent type**:

```csharp
Assert.True(sulo.IsTheSameTypeOrAParent(zalo));   // Sulo is parent of Zalo ✅
Assert.False(y.IsTheSameTypeOrAParent(x));        // decimal is NOT parent of int ❌
```

---

## Mock Abstracts and Interfaces

Create **instances of abstract classes or interfaces** at runtime:

### Mocking an Abstract Class

```csharp
public abstract class Alzio
{
    private protected string X { get; }
    public string O => X;
    public string A { get; set; }
    
    public Alzio(string x)
    {
        X = x;
    }
}

// Create instance of abstract class
var mocked = typeof(Alzio).CreateInstance("AAA") as Alzio;
mocked.A = "rrrr";

Console.WriteLine(mocked.O); // Outputs: "AAA"
Console.WriteLine(mocked.A); // Outputs: "rrrr"
```

### Alternative Syntax

```csharp
// From null instance
Alzio alzio = null!;
var mocked = alzio.CreateInstance("AAA");
mocked.A = "rrrr";

// Using Mocking class
var mocked = Mocking.CreateInstance<Alzio>("AAA");
```

### Mocking an Interface

```csharp
public interface IService
{
    string Name { get; set; }
    int Calculate(int x, int y);
}

// Create instance of interface
var mocked = Mocking.CreateInstance<IService>();
mocked.Name = "TestService";

// Note: Methods will have default behavior (return default values)
```

**Use Cases:**
- Testing without mock frameworks
- Dynamic type creation
- Plugin systems
- Proxy generation

---

## Check Nullability

Detect if properties, fields, or parameters are **nullable reference types**:

### Example Class

```csharp
private sealed class InModel
{
    public string? A { get; set; }
    public string B { get; set; }
    public string? C;
    public string D;
    
    public InModel(string? b, string c)
    {
        A = b;
        B = c;
    }
    
    public void SetSomething(string? b, string c)
    {
        A = b;
        B = c;
    }
}
```

### Check Constructor Parameters

```csharp
var type = typeof(InModel);
var constructorParameters = type.GetConstructors().First().GetParameters().ToList();

Assert.True(constructorParameters[0].IsNullable());   // string? b ✅
Assert.False(constructorParameters[1].IsNullable());  // string c ❌
```

### Check Method Parameters

```csharp
var methodParameters = type.GetMethod(nameof(InModel.SetSomething))
                           .GetParameters()
                           .ToList();

Assert.True(methodParameters[0].IsNullable());   // string? b ✅
Assert.False(methodParameters[1].IsNullable());  // string c ❌
```

### Check Properties

```csharp
var properties = type.GetProperties().ToList();

Assert.True(properties[0].IsNullable());   // string? A ✅
Assert.False(properties[1].IsNullable());  // string B ❌
```

### Check Fields

```csharp
var fields = type.GetFields().ToList();

Assert.True(fields[0].IsNullable());   // string? C ✅
Assert.False(fields[1].IsNullable());  // string D ❌
```

---

## Real-World Examples

### Validation with Nullability Check

```csharp
public class Validator
{
    public List<string> ValidateNullability<T>(T instance)
    {
        var errors = new List<string>();
        var properties = typeof(T).FetchProperties();
        
        foreach (var prop in properties)
        {
            var value = prop.GetValue(instance);
            
            if (value == null && !prop.IsNullable())
            {
                errors.Add($"Property {prop.Name} cannot be null");
            }
        }
        
        return errors;
    }
}
```

### Plugin System with Abstract Mocking

```csharp
public abstract class Plugin
{
    public abstract string Name { get; }
    public abstract void Execute();
}

public class PluginManager
{
    public Plugin LoadPlugin(Type pluginType)
    {
        if (!pluginType.IsSubclassOf(typeof(Plugin)))
            throw new ArgumentException("Type must inherit from Plugin");
        
        return pluginType.CreateInstance() as Plugin;
    }
}
```

### Type Hierarchy Checker

```csharp
public class TypeAnalyzer
{
    public bool CanAssign(object source, Type targetType)
    {
        return source.IsTheSameTypeOrASon(Activator.CreateInstance(targetType));
    }
    
    public bool IsCompatible(Type parent, Type child)
    {
        var parentInstance = parent.CreateInstance();
        var childInstance = child.CreateInstance();
        
        return childInstance.IsTheSameTypeOrASon(parentInstance);
    }
}
```

---

## Benefits

- ✅ **Performance**: Cached reflection metadata
- ✅ **Type Safety**: Check type relationships at runtime
- ✅ **Testing**: Mock abstracts/interfaces without frameworks
- ✅ **Nullability**: Detect nullable reference types
- ✅ **Debugging**: Identify calling classes

---

## Related Tools

- **[Discriminated Union](https://rystem.net/mcp/tools/rystem-discriminated-union.md)** - Type-safe unions
- **[Repository Pattern](https://rystem.net/mcp/tools/repository-setup.md)** - Uses reflection for entity mapping
- **[DDD](https://rystem.net/mcp/tools/ddd-single-domain.md)** - Domain model reflection

---

## References

- **NuGet Package**: [Rystem](https://www.nuget.org/packages/Rystem) v9.1.3
- **Documentation**: https://rystem.net
- **GitHub**: https://github.com/KeyserDSoze/Rystem
- **Unit Tests**: [ReflectionTest.cs](https://github.com/KeyserDSoze/RystemV3/blob/master/src/Rystem.Test/Rystem.Test.UnitTest/System.Reflection/ReflectionTest.cs)

---

## Stopwatch Utilities

> Monitor execution time of methods, tasks, and actions with Rystem's Stopwatch helpers - includes Start/Stop, Monitor, and MonitorAsync with automatic time tracking

---
title: Stopwatch Utilities
description: Monitor execution time of methods, tasks, and actions with Rystem's Stopwatch helpers - includes Start/Stop, Monitor, and MonitorAsync with automatic time tracking
---

# Stopwatch Utilities

Monitor the **execution time** of actions, tasks, or methods with Rystem's enhanced Stopwatch utilities.

---

## Installation

```bash
dotnet add package Rystem --version 9.1.3
```

---

## Quick Start

### Start and Stop

```csharp
using Rystem;

var started = Stopwatch.Start();

// Do something
await Task.Delay(2000);

var result = started.Stop();

Console.WriteLine($"Elapsed: {result.ElapsedMilliseconds}ms");
```

---

## Monitor Synchronous Actions

Use `Monitor()` to execute an action and automatically measure its execution time:

```csharp
var result = Stopwatch.Monitor(() =>
{
    Thread.Sleep(2000);
    // Your code here
});

Console.WriteLine($"Elapsed: {result.ElapsedMilliseconds}ms");
```

**With return value:**

```csharp
var result = Stopwatch.Monitor(() =>
{
    Thread.Sleep(2000);
    return 42;
});

Console.WriteLine($"Result: {result.Value}");
Console.WriteLine($"Elapsed: {result.ElapsedMilliseconds}ms");
```

---

## Monitor Asynchronous Tasks

Use `MonitorAsync()` for async operations:

```csharp
var result = await Stopwatch.MonitorAsync(async () =>
{
    await Task.Delay(2000);
    // Your async code here
});

Console.WriteLine($"Elapsed: {result.ElapsedMilliseconds}ms");
```

**With return value:**

```csharp
var result = await Stopwatch.MonitorAsync(async () =>
{
    await Task.Delay(2000);
    return 42;
});

Console.WriteLine($"Result: {result.Value}");
Console.WriteLine($"Elapsed: {result.ElapsedMilliseconds}ms");
```

---

## Result Properties

All monitoring methods return a result with:

- **`ElapsedMilliseconds`**: Time in milliseconds
- **`ElapsedTicks`**: Time in ticks
- **`Elapsed`**: TimeSpan representation
- **`Value`** (when applicable): Return value of the monitored operation

---

## Real-World Examples

### API Call Monitoring

```csharp
public async Task<OrderResponse> GetOrderAsync(Guid orderId)
{
    var result = await Stopwatch.MonitorAsync(async () =>
    {
        return await httpClient.GetFromJsonAsync<OrderResponse>($"/api/orders/{orderId}");
    });

    logger.LogInformation(
        "Order {OrderId} retrieved in {ElapsedMs}ms",
        orderId,
        result.ElapsedMilliseconds
    );

    return result.Value;
}
```

### Database Query Performance

```csharp
public async Task<List<Product>> GetProductsAsync()
{
    var result = await Stopwatch.MonitorAsync(async () =>
    {
        return await dbContext.Products
            .Where(p => p.IsActive)
            .ToListAsync();
    });

    if (result.ElapsedMilliseconds > 1000)
    {
        logger.LogWarning(
            "Slow query detected: {ElapsedMs}ms",
            result.ElapsedMilliseconds
        );
    }

    return result.Value;
}
```

### Background Job Monitoring

```csharp
public async Task ProcessOrdersAsync()
{
    var result = await Stopwatch.MonitorAsync(async () =>
    {
        var orders = await orderRepository.QueryAsync(x => x.Status == OrderStatus.Pending);
        
        foreach (var order in orders)
        {
            await ProcessOrderAsync(order);
        }
        
        return orders.Count;
    });

    logger.LogInformation(
        "Processed {Count} orders in {ElapsedMs}ms",
        result.Value,
        result.ElapsedMilliseconds
    );
}
```

### Method Profiling

```csharp
public decimal CalculateTotal(Order order)
{
    var result = Stopwatch.Monitor(() =>
    {
        decimal total = 0;
        foreach (var item in order.Items)
        {
            total += item.Price * item.Quantity;
        }
        return total;
    });

    if (result.ElapsedMilliseconds > 100)
    {
        logger.LogWarning(
            "Slow calculation for order {OrderId}: {ElapsedMs}ms",
            order.Id,
            result.ElapsedMilliseconds
        );
    }

    return result.Value;
}
```

---

## Benefits

- ✅ **Simple API**: Start/Stop or Monitor pattern
- ✅ **Async Support**: MonitorAsync for async operations
- ✅ **Return Values**: Capture both result and timing
- ✅ **Performance Insights**: Identify slow operations
- ✅ **Logging Integration**: Easy to log execution times

---

## Related Tools

- **[Task Extensions](https://rystem.net/mcp/tools/rystem-task-extensions.md)** - Task utilities including NoContext() and TaskManager
- **[Background Jobs](https://rystem.net/mcp/resources/background-jobs.md)** - Monitor background job execution times
- **[Repository Pattern](https://rystem.net/mcp/tools/repository-setup.md)** - Monitor repository operations

---

## References

- **NuGet Package**: [Rystem](https://www.nuget.org/packages/Rystem) v9.1.3
- **Documentation**: https://rystem.net
- **GitHub**: https://github.com/KeyserDSoze/Rystem

---

## Task Extensions

> Task utilities including NoContext() for ConfigureAwait(false), ToResult() for synchronous execution, and TaskManager for concurrent task execution with WhenAll() and WhenAtLeast()

---
title: Task Extensions
description: Task utilities including NoContext() for ConfigureAwait(false), ToResult() for synchronous execution, and TaskManager for concurrent task execution with WhenAll() and WhenAtLeast()
---

# Task Extensions

Task utilities to simplify **async/await patterns** and **concurrent task execution**.

---

## Installation

```bash
dotnet add package Rystem --version 9.1.3
```

---

## NoContext() - ConfigureAwait(false)

Tired of writing `.ConfigureAwait(false)` everywhere? Use **`NoContext()`** instead!

### Why ConfigureAwait(false)?

[Microsoft's ConfigureAwait FAQ](https://devblogs.microsoft.com/dotnet/configureawait-faq/)

**TL;DR**: In library code, use `ConfigureAwait(false)` to avoid capturing the synchronization context, improving performance and avoiding deadlocks.

### Before

```csharp
var result = await SomeMethodAsync().ConfigureAwait(false);
var data = await GetDataAsync().ConfigureAwait(false);
```

### After (With Rystem)

```csharp
using Rystem;

var result = await SomeMethodAsync().NoContext();
var data = await GetDataAsync().NoContext();
```

**Example:**

```csharp
public async Task<User> GetUserAsync(Guid userId)
{
    var response = await httpClient.GetAsync($"/api/users/{userId}").NoContext();
    var json = await response.Content.ReadAsStringAsync().NoContext();
    
    return json.FromJson<User>();
}
```

---

## ToResult() - Synchronous Execution

Execute an async task **synchronously** with `ConfigureAwait(false)`:

```csharp
var result = GetDataAsync().ToResult();
```

**Equivalent to:**

```csharp
var result = GetDataAsync().ConfigureAwait(false).GetAwaiter().GetResult();
```

**Example:**

```csharp
public class UserService
{
    public User GetUser(Guid userId)
    {
        // Synchronously execute async method
        return GetUserAsync(userId).ToResult();
    }
    
    public async Task<User> GetUserAsync(Guid userId)
    {
        return await userRepository.GetAsync(userId).NoContext();
    }
}
```

---

## Change Default Behavior

By default, `NoContext()` and `ToResult()` use `ConfigureAwait(false)`. You can change this behavior:

```csharp
// In application startup (Program.cs or Startup.cs)
RystemTask.WaitYourStartingThread = true;
```

**When to use `true`?**
- **Windows Forms** applications
- **WPF** applications
- **WinUI** applications
- Any UI application where you need to return to the **UI thread**

**Example:**

```csharp
// In WPF application
public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
        
        // Set to true for UI applications
        RystemTask.WaitYourStartingThread = true;
    }
    
    private async void Button_Click(object sender, RoutedEventArgs e)
    {
        var data = await LoadDataAsync().NoContext();
        
        // This will execute on UI thread because WaitYourStartingThread = true
        DataGrid.ItemsSource = data;
    }
}
```

---

## TaskManager - Concurrent Execution

Execute **multiple tasks concurrently** with control over concurrency levels.

### WhenAll - Execute with Concurrency Limit

Run multiple tasks with a **maximum concurrency limit** and **run as soon as a slot is free**:

```csharp
var bag = new ConcurrentBag<int>();
int times = 8;
int concurrentTasks = 3;
bool runEverytimeASlotIsFree = true;

await TaskManager.WhenAll(ExecuteAsync, times, concurrentTasks, runEverytimeASlotIsFree).NoContext();

Assert.Equal(times, bag.Count);

async Task ExecuteAsync(int i, CancellationToken cancellationToken)
{
    await Task.Delay(i * 20, cancellationToken).NoContext();
    bag.Add(i);
}
```

**How it works:**
1. Starts first **3 tasks** (concurrentTasks = 3)
2. As soon as one finishes, starts the **4th task**
3. As soon as another finishes, starts the **5th task**
4. Continues until all **8 tasks** (times = 8) are executed

**Visualization:**

```
Time 0ms:    [Task 0] [Task 1] [Task 2] - 3 running
Time 20ms:   [Done 0] [Task 1] [Task 2] [Task 3] - Slot freed, Task 3 starts
Time 40ms:   [Done 0] [Done 1] [Task 2] [Task 3] [Task 4] - Slot freed, Task 4 starts
...
```

### WhenAtLeast - Execute Until Minimum Complete

Run tasks until **at least X tasks** complete, then stop waiting for the rest:

```csharp
var bag = new ConcurrentBag<int>();
int times = 10;
int atLeast = 5;
int concurrentTasks = 3;

await TaskManager.WhenAtLeast(ExecuteAsync, times, atLeast, concurrentTasks).NoContext();

Assert.True(bag.Count < times);        // Not all tasks completed
Assert.True(bag.Count >= atLeast);     // At least 5 completed

async Task ExecuteAsync(int i, CancellationToken cancellationToken)
{
    await Task.Delay(i * 20, cancellationToken).NoContext();
    bag.Add(i);
}
```

**Use Cases:**
- **Load balancing**: Call 10 servers, return as soon as 5 respond
- **Redundancy**: Send to 5 services, return when 3 succeed
- **Sampling**: Process 100 items, stop after 20 succeed

---

## Real-World Examples

### Parallel API Calls with Concurrency Limit

```csharp
public async Task<List<OrderDetails>> GetOrderDetailsAsync(List<Guid> orderIds)
{
    var results = new ConcurrentBag<OrderDetails>();
    
    await TaskManager.WhenAll(
        async (index, cancellationToken) =>
        {
            var orderId = orderIds[index];
            var details = await httpClient.GetFromJsonAsync<OrderDetails>(
                $"/api/orders/{orderId}",
                cancellationToken
            ).NoContext();
            
            results.Add(details);
        },
        times: orderIds.Count,
        concurrentTasks: 5, // Max 5 concurrent API calls
        runEverytimeASlotIsFree: true
    ).NoContext();
    
    return results.ToList();
}
```

### Batch Processing with Early Exit

```csharp
public async Task<List<Product>> FindAvailableProductsAsync(List<string> skus)
{
    var availableProducts = new ConcurrentBag<Product>();
    
    // Stop as soon as we find 10 available products
    await TaskManager.WhenAtLeast(
        async (index, cancellationToken) =>
        {
            var sku = skus[index];
            var product = await productRepository.GetBySkuAsync(sku, cancellationToken).NoContext();
            
            if (product?.IsAvailable == true)
            {
                availableProducts.Add(product);
            }
        },
        times: skus.Count,
        atLeast: 10, // Stop after finding 10 available
        concurrentTasks: 5
    ).NoContext();
    
    return availableProducts.Take(10).ToList();
}
```

### Background Processing

```csharp
public async Task ProcessPendingOrdersAsync()
{
    var orders = await orderRepository.QueryAsync(x => x.Status == OrderStatus.Pending).NoContext();
    
    var processed = new ConcurrentBag<Order>();
    
    await TaskManager.WhenAll(
        async (index, cancellationToken) =>
        {
            var order = orders[index];
            
            try
            {
                await ProcessOrderAsync(order, cancellationToken).NoContext();
                processed.Add(order);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Error processing order {OrderId}", order.Id);
            }
        },
        times: orders.Count,
        concurrentTasks: 10, // Process 10 orders concurrently
        runEverytimeASlotIsFree: true
    ).NoContext();
    
    logger.LogInformation("Processed {Count} orders", processed.Count);
}
```

### Load Balancer

```csharp
public async Task<ApiResponse> CallWithRedundancyAsync(string endpoint)
{
    var servers = new[] { "server1", "server2", "server3", "server4", "server5" };
    var responses = new ConcurrentBag<ApiResponse>();
    
    // Call 5 servers, return as soon as 2 respond successfully
    await TaskManager.WhenAtLeast(
        async (index, cancellationToken) =>
        {
            try
            {
                var response = await httpClient.GetFromJsonAsync<ApiResponse>(
                    $"https://{servers[index]}/{endpoint}",
                    cancellationToken
                ).NoContext();
                
                responses.Add(response);
            }
            catch (Exception ex)
            {
                logger.LogWarning(ex, "Server {Server} failed", servers[index]);
            }
        },
        times: servers.Length,
        atLeast: 2, // Stop after 2 successful responses
        concurrentTasks: 5
    ).NoContext();
    
    // Return first successful response
    return responses.FirstOrDefault();
}
```

### Retry with Multiple Attempts

```csharp
public async Task<bool> TryExecuteWithRetriesAsync(Func<Task> operation, int maxRetries)
{
    var success = new ConcurrentBag<bool>();
    
    await TaskManager.WhenAtLeast(
        async (index, cancellationToken) =>
        {
            try
            {
                await operation().NoContext();
                success.Add(true);
            }
            catch (Exception ex)
            {
                logger.LogWarning(ex, "Attempt {Attempt} failed", index + 1);
            }
        },
        times: maxRetries,
        atLeast: 1, // Stop after first success
        concurrentTasks: 1 // One at a time (sequential retries)
    ).NoContext();
    
    return success.Any();
}
```

---

## Benefits

- ✅ **NoContext()**: Cleaner than `ConfigureAwait(false)`
- ✅ **ToResult()**: Safe synchronous execution
- ✅ **TaskManager.WhenAll()**: Controlled concurrency
- ✅ **TaskManager.WhenAtLeast()**: Early exit when minimum met
- ✅ **Performance**: Efficient task scheduling
- ✅ **Flexibility**: Customizable behavior

---

## Related Tools

- **[Stopwatch](https://rystem.net/mcp/tools/rystem-stopwatch.md)** - Monitor task execution time
- **[Background Jobs](https://rystem.net/mcp/resources/background-jobs.md)** - Scheduled background processing
- **[Concurrency](https://rystem.net/mcp/resources/concurrency.md)** - Distributed locks

---

## References

- **NuGet Package**: [Rystem](https://www.nuget.org/packages/Rystem) v9.1.3
- **Documentation**: https://rystem.net
- **GitHub**: https://github.com/KeyserDSoze/Rystem
- **ConfigureAwait FAQ**: https://devblogs.microsoft.com/dotnet/configureawait-faq/

---

## Rystem.Test.XUnit - XUnit Integration Testing Framework

> Complete guide to Rystem.Test.XUnit with Dependency Injection and ASP.NET Core Test Host support for integration testing

---
title: "Rystem.Test.XUnit - XUnit Integration Testing Framework"
description: "Complete guide to Rystem.Test.XUnit with Dependency Injection and ASP.NET Core Test Host support for integration testing"
category: "Testing"
tags: ["xunit", "testing", "dependency-injection", "integration-testing", "test-host"]
---

# Rystem.Test.XUnit

**Advanced XUnit integration testing framework** with built-in Dependency Injection and ASP.NET Core Test Host support. Perfect for testing APIs, services, and complex application architectures.

## 📦 Installation

```bash
dotnet add package Rystem.Test.XUnit
```

### ⚠️ IMPORTANT: XUnit v3 Requirements

**Rystem.Test.XUnit requires XUnit v3**. Recent XUnit updates introduced breaking changes. Ensure correct package versions.

**Complete test project setup:**

```xml
<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup>
    <TargetFramework>net9.0</TargetFramework>
    <ImplicitUsings>enable</ImplicitUsings>
    <Nullable>enable</Nullable>
    <IsPackable>false</IsPackable>
    <IsTestProject>true</IsTestProject>
  </PropertyGroup>

  <ItemGroup>
    <!-- Rystem Test Framework -->
    <PackageReference Include="Rystem.Test.XUnit" Version="9.1.3" />
    
    <!-- XUnit v3 (NOT xunit v2!) -->
    <PackageReference Include="xunit.v3" Version="3.0.1" />
    
    <!-- Test SDK and Runners -->
    <PackageReference Include="Microsoft.NET.Test.Sdk" Version="17.14.1" />
    <PackageReference Include="xunit.runner.visualstudio" Version="3.1.4">
      <IncludeAssets>runtime; build; native; contentfiles; analyzers; buildtransitive</IncludeAssets>
      <PrivateAssets>all</PrivateAssets>
    </PackageReference>
    
    <!-- Code Coverage -->
    <PackageReference Include="coverlet.collector" Version="6.0.4">
      <IncludeAssets>runtime; build; native; contentfiles; analyzers; buildtransitive</IncludeAssets>
      <PrivateAssets>all</PrivateAssets>
    </PackageReference>
  </ItemGroup>
</Project>
```

**Quick CLI Setup:**

```bash
# 1. Create test project
dotnet new xunit -n MyApp.Tests
cd MyApp.Tests

# 2. Remove old xunit package (if present)
dotnet remove package xunit

# 3. Add XUnit v3 and Rystem
dotnet add package xunit.v3 --version 3.0.1
dotnet add package xunit.runner.visualstudio --version 3.1.4
dotnet add package Rystem.Test.XUnit --version 9.1.3
dotnet add package Microsoft.NET.Test.Sdk --version 17.14.1
```

**Common Mistakes to Avoid:**

| ❌ Wrong | ✅ Correct |
|---------|-----------|
| `<PackageReference Include="xunit" />` | `<PackageReference Include="xunit.v3" />` |
| `xunit.runner.visualstudio` v2.x | `xunit.runner.visualstudio` v3.1.4+ |
| Missing `IsTestProject` property | `<IsTestProject>true</IsTestProject>` |

**XUnit v2 vs v3 Key Differences:**

- ✅ Constructor injection: **Same** (no changes)
- ✅ `[Fact]`, `[Theory]`, `[InlineData]`: **Same** (no changes)
- ⚠️ Assertion APIs: **Some changes** (see [migration guide](https://xunit.net/docs/getting-started/v3/migration))
- ⚠️ Test collection behavior: **Enhanced** (better parallelization)

---

## 🎯 Key Features

- ✅ **Built-in Dependency Injection** - Constructor injection in XUnit test classes
- ✅ **ASP.NET Core Test Server** - Full middleware pipeline with real HTTP requests
- ✅ **Automatic Controller Discovery** - Auto-maps all controllers/endpoints from specified assembly
- ✅ **User Secrets Integration** - Load secrets from Visual Studio Secret Manager
- ✅ **Health Check Support** - Automatic `/healthz` endpoint validation
- ✅ **HTTPS/HTTP Configuration** - Flexible protocol configuration
- ✅ **HttpClient Factory** - Automatic HTTP client setup for API testing

---

## 🚀 Quick Start

### Scenario 1: Testing Business Logic (No HTTP Server)

Perfect for testing services, repositories, and business logic without API layer.

```csharp
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Rystem.Test.XUnit;

namespace MyApp.Tests
{
    public class Startup : StartupHelper
    {
        protected override string? AppSettingsFileName => "appsettings.json";
        protected override bool HasTestHost => false; // ❌ No HTTP server needed
        protected override Type? TypeToChooseTheRightAssemblyToRetrieveSecretsForConfiguration => typeof(Startup);
        protected override Type? TypeToChooseTheRightAssemblyWithControllersToMap => null;
        
        protected override IServiceCollection ConfigureClientServices(IServiceCollection services, IConfiguration configuration)
        {
            // Add your services for testing
            services.AddMyBusinessLogic();
            services.AddMyRepositories();
            
            return services;
        }
    }
}
```

**Write tests with constructor injection:**

```csharp
public class BusinessLogicTest
{
    private readonly IBookManager _bookManager;

    public BusinessLogicTest(IBookManager bookManager)
    {
        _bookManager = bookManager; // Injected automatically! 🎉
    }

    [Fact]
    public async Task CreateBook_ShouldReturnValidBook()
    {
        var bookId = Guid.NewGuid();
        var book = await _bookManager.CreateBookAsync(bookId);
        
        Assert.NotNull(book);
        Assert.Equal(bookId, book.Id);
    }
}
```

---

### Scenario 2: Testing APIs (With HTTP Server)

Full integration testing with real HTTP requests to your ASP.NET Core API.

```csharp
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Rystem.Test.XUnit;

namespace MyApp.Api.Tests
{
    public class Startup : StartupHelper
    {
        protected override string? AppSettingsFileName => "appsettings.test.json";
        protected override bool HasTestHost => true; // ✅ Enable test server
        protected override bool WithHttps => true;
        protected override bool AddHealthCheck => true;
        
        // Use your API's Program class or any controller
        protected override Type? TypeToChooseTheRightAssemblyWithControllersToMap => typeof(Program);
        
        // Use test project's Startup for User Secrets
        protected override Type? TypeToChooseTheRightAssemblyToRetrieveSecretsForConfiguration => typeof(Startup);
        
        // Configure TEST CLIENT services (HTTP consumers)
        protected override IServiceCollection ConfigureClientServices(IServiceCollection services, IConfiguration configuration)
        {
            services.AddHttpClient<IMyApiClient, MyApiClient>(client =>
            {
                client.BaseAddress = new Uri("https://localhost");
            });
            
            return services;
        }
        
        // Configure TEST SERVER services (API dependencies)
        protected override async ValueTask ConfigureServerServicesAsync(IServiceCollection services, IConfiguration configuration)
        {
            services.AddControllers();
            services.AddMyApiServices();
            services.AddMyRepositories();
            
            return;
        }
        
        // Configure TEST SERVER middleware
        protected override async ValueTask ConfigureServerMiddlewareAsync(IApplicationBuilder app, IServiceProvider serviceProvider)
        {
            app.UseRouting();
            app.UseAuthentication();
            app.UseAuthorization();
            app.UseEndpoints(endpoints => endpoints.MapControllers());
            
            return;
        }
    }
}
```

**Write API tests:**

```csharp
public class ApiIntegrationTest
{
    private readonly IMyApiClient _apiClient;

    public ApiIntegrationTest(IMyApiClient apiClient)
    {
        _apiClient = apiClient;
    }

    [Theory]
    [InlineData("user@example.com")]
    public async Task Login_ShouldReturnUser(string email)
    {
        var user = await _apiClient.LoginAsync(email); // Real HTTP call!
        
        Assert.NotNull(user);
        Assert.Equal(email, user.Email);
    }

    [Fact]
    public async Task GetBooks_ThenCreateNew_ShouldWork()
    {
        await _apiClient.LoginAsync("user@example.com");
        
        var books = await _apiClient.GetBooksAsync();
        Assert.NotEmpty(books);
        
        var newBook = await _apiClient.CreateBookAsync(new CreateBookRequest
        {
            Title = "Test Book",
            Author = "Test Author"
        });
        
        Assert.NotNull(newBook);
    }
}
```

---

## 📖 Configuration Reference

### Required Properties

#### `AppSettingsFileName`
Path to appsettings file for test configuration.

```csharp
protected override string? AppSettingsFileName => "appsettings.test.json";
```

**Best Practice**: Use separate `appsettings.test.json` for test-specific configuration.

---

#### `HasTestHost`
Enable/disable ASP.NET Core Test Server.

```csharp
protected override bool HasTestHost => true;  // Enable for API testing
protected override bool HasTestHost => false; // Disable for business logic testing
```

**When to enable:**
- ✅ Testing REST APIs, gRPC, SignalR
- ✅ Testing middleware pipeline
- ✅ Testing authentication/authorization
- ✅ Integration tests with HTTP

**When to disable:**
- ❌ Testing business logic only
- ❌ Repository pattern tests
- ❌ Service layer unit tests

---

#### `TypeToChooseTheRightAssemblyWithControllersToMap`
Specifies assembly containing API controllers/endpoints.

```csharp
// Option 1: Use API's Program class
protected override Type? TypeToChooseTheRightAssemblyWithControllersToMap => typeof(Program);

// Option 2: Use any controller from API project
protected override Type? TypeToChooseTheRightAssemblyWithControllersToMap => typeof(BooksController);

// Option 3: Null if HasTestHost = false
protected override Type? TypeToChooseTheRightAssemblyWithControllersToMap => null;
```

**Purpose**: Framework automatically discovers and maps all controllers/endpoints in that assembly.

---

#### `TypeToChooseTheRightAssemblyToRetrieveSecretsForConfiguration`
Specifies assembly to load User Secrets from.

```csharp
// Usually your TEST project's Startup class
protected override Type? TypeToChooseTheRightAssemblyToRetrieveSecretsForConfiguration => typeof(Startup);
```

**Why**: Test projects typically have their own User Secrets for:
- Database connection strings
- API keys for external services
- Test-specific configuration

**Manage secrets:**
```bash
# Visual Studio: Right-click test project → Manage User Secrets
# Or CLI:
dotnet user-secrets set "ConnectionStrings:TestDb" "Server=localhost;..."
dotnet user-secrets set "ExternalApi:ApiKey" "test-key-123"
```

---

#### `ConfigureClientServices`
Configure DI for **test consumers** (your test classes).

```csharp
protected override IServiceCollection ConfigureClientServices(IServiceCollection services, IConfiguration configuration)
{
    // Add services used by test classes
    services.AddHttpClient<IMyApiClient, MyApiClient>(client =>
    {
        client.BaseAddress = new Uri("https://localhost");
    });
    
    services.AddSingleton<ITestDataGenerator, TestDataGenerator>();
    
    return services;
}
```

**Injected into test class constructors:**
```csharp
public MyTest(IMyApiClient apiClient, ITestDataGenerator generator)
{
    // Both injected automatically
}
```

---

### Optional Properties

#### `WithHttps` (default: `true`)
Enable HTTPS for test server.

```csharp
protected override bool WithHttps => true;  // https://localhost:443
protected override bool WithHttps => false; // http://localhost
```

---

#### `PreserveExecutionContext` (default: `false`)
Preserve execution context across async operations.

```csharp
protected override bool PreserveExecutionContext => true;
```

**When to enable:**
- Testing code using `AsyncLocal<T>`
- Testing authentication contexts flowing across async calls

---

#### `AddHealthCheck` (default: `true`)
Add automatic `/healthz` endpoint.

```csharp
protected override bool AddHealthCheck => true;
```

**Validation**: Framework automatically calls `/healthz` after server startup to ensure health.

---

### Virtual Methods (Override if `HasTestHost = true`)

#### `ConfigureServerServicesAsync`
Configure DI for **test server** (API dependencies).

```csharp
protected override async ValueTask ConfigureServerServicesAsync(IServiceCollection services, IConfiguration configuration)
{
    services.AddControllers();
    services.AddMyBusinessLogic();
    services.AddMyRepositories();
    
    // In-memory database for testing
    services.AddDbContext<MyDbContext>(options =>
        options.UseInMemoryDatabase("TestDb"));
    
    return;
}
```

---

#### `ConfigureServerMiddlewareAsync`
Configure middleware pipeline for **test server**.

```csharp
protected override async ValueTask ConfigureServerMiddlewareAsync(IApplicationBuilder app, IServiceProvider serviceProvider)
{
    app.UseRouting();
    app.UseAuthentication();
    app.UseAuthorization();
    app.UseCors("AllowAll");
    
    app.UseEndpoints(endpoints =>
    {
        endpoints.MapControllers();
    });
    
    return;
}
```

---

## 🏗️ Architecture Diagram

```
┌───────────────────────────────────────────────────────────┐
│              XUnit Test Runner                             │
└──────────────────────┬────────────────────────────────────┘
                       │
                       ▼
┌───────────────────────────────────────────────────────────┐
│           StartupHelper (Abstract Base)                    │
│  • Loads appsettings.json                                  │
│  • Loads User Secrets                                      │
│  • Configures Host Builder                                 │
└──────────────────────┬────────────────────────────────────┘
                       │
         ┌─────────────┴─────────────┐
         ▼                           ▼
┌──────────────────────┐   ┌───────────────────────────────┐
│ ConfigureClientServices│   │ ConfigureServerServicesAsync │
│ (Test DI Container)   │   │ (API DI Container)           │
│ • HTTP Clients        │   │ • Controllers                │
│ • Test Helpers        │   │ • Business Logic             │
│ • Mocks               │   │ • Repositories               │
└─────────┬────────────┘   └──────────┬───────────────────┘
          │                           │
          │               ┌───────────┴──────────────┐
          │               ▼                          │
          │    ┌──────────────────────────┐          │
          │    │ ASP.NET Core Test Server │          │
          │    │ • Middleware Pipeline    │          │
          │    │ • Endpoint Routing       │          │
          │    │ • Authentication         │          │
          │    └──────────┬───────────────┘          │
          │               │                          │
          ▼               ▼                          ▼
┌──────────────────────────────────────────────────────────┐
│       Constructor Injection in Test Classes               │
│  public MyTest(IService service, IHttpClientFactory http) │
└──────────────────────────────────────────────────────────┘
```

---

## 🧪 Real-World Example: Complete API Testing

```csharp
// Startup.cs
public class Startup : StartupHelper
{
    protected override string? AppSettingsFileName => "appsettings.test.json";
    protected override bool HasTestHost => true;
    protected override Type? TypeToChooseTheRightAssemblyWithControllersToMap => typeof(Program);
    protected override Type? TypeToChooseTheRightAssemblyToRetrieveSecretsForConfiguration => typeof(Startup);
    
    protected override IServiceCollection ConfigureClientServices(IServiceCollection services, IConfiguration configuration)
    {
        services.AddHttpClient<IBridgeInspectionApi, BridgeInspectionApi>(client =>
        {
            client.BaseAddress = new Uri("https://localhost");
        });
        return services;
    }
    
    protected override async ValueTask ConfigureServerServicesAsync(IServiceCollection services, IConfiguration configuration)
    {
        services.AddControllers();
        services.AddAuthentication("TestScheme")
            .AddScheme<TestAuthOptions, TestAuthHandler>("TestScheme", options => { });
        services.AddMyApiServices();
        return;
    }
    
    protected override async ValueTask ConfigureServerMiddlewareAsync(IApplicationBuilder app, IServiceProvider serviceProvider)
    {
        app.UseRouting();
        app.UseAuthentication();
        app.UseAuthorization();
        app.UseEndpoints(endpoints => endpoints.MapControllers());
        return;
    }
}

// InspectionTest.cs
public class InspectionTest
{
    private readonly IBridgeInspectionApi _api;

    public InspectionTest(IBridgeInspectionApi api)
    {
        _api = api;
    }

    [Theory]
    [InlineData("user@example.com")]
    [InlineData("admin@example.com")]
    public async Task GetBridgesAndInspections_WithDifferentUsers_ShouldWork(string email)
    {
        // Arrange & Act - Login
        var user = await _api.LoginAsAsync(email);
        
        // Assert - User authenticated
        Assert.NotNull(user);
        Assert.Equal(email, user.Email);
        
        // Act - Get bridges
        var bridges = await _api.BridgeApi.ListAsync();
        
        // Assert - Has bridges
        Assert.NotEmpty(bridges);
        
        // Act - Get inspections for first bridge
        var bridge = bridges.First();
        var inspections = await _api.InspectionApi.ListAsync(bridge.Id);
        
        // Assert - Has inspections
        Assert.NotEmpty(inspections);
    }

    [Fact]
    public async Task DownloadInspectionFiles_ShouldReturnZipData()
    {
        // Arrange
        await _api.LoginAsAsync("admin@example.com");
        var bridges = await _api.BridgeApi.ListAsync();
        var bridge = bridges.First();
        var inspections = await _api.InspectionApi.ListAsync(bridge.Id);
        var inspection = inspections.First();
        
        // Act
        var zipBytes = await _api.InspectionApi.DownloadInspectionsFile(bridge.Id, inspection.Id);
        
        // Assert
        Assert.NotEmpty(zipBytes);
        Assert.True(zipBytes.Length > 0);
    }

    [Fact]
    public async Task GetInspectionFiles_ShouldReturnFileList()
    {
        // Arrange
        await _api.LoginAsAsync("user@example.com");
        var bridges = await _api.BridgeApi.ListAsync();
        var bridge = bridges.First();
        var inspections = await _api.InspectionApi.ListAsync(bridge.Id);
        
        // Act
        var files = await _api.InspectionApi.GetAsync(bridge.Id, inspections.First().Id);
        
        // Assert
        Assert.NotEmpty(files);
    }
}
```

---

## 🔧 Advanced Patterns

### In-Memory Database for Tests

```csharp
protected override async ValueTask ConfigureServerServicesAsync(IServiceCollection services, IConfiguration configuration)
{
    // Each test run gets unique database
    services.AddDbContext<MyDbContext>(options =>
        options.UseInMemoryDatabase($"TestDb_{Guid.NewGuid()}"));
    
    return;
}
```

---

### Mock External Dependencies

```csharp
protected override IServiceCollection ConfigureClientServices(IServiceCollection services, IConfiguration configuration)
{
    // Replace real external API with mock
    services.AddSingleton<IExternalApiClient, MockExternalApiClient>();
    
    // Or use Moq
    var mockClient = new Mock<IExternalApiClient>();
    mockClient.Setup(x => x.GetDataAsync()).ReturnsAsync(new Data());
    services.AddSingleton(mockClient.Object);
    
    return services;
}
```

---

### Custom HTTP Headers

```csharp
services.AddHttpClient<IMyClient, MyClient>((serviceProvider, client) =>
{
    client.BaseAddress = new Uri("https://localhost");
    client.DefaultRequestHeaders.Add("X-Test-Environment", "true");
    client.DefaultRequestHeaders.Add("X-Api-Key", "test-api-key");
    client.Timeout = TimeSpan.FromSeconds(30);
});
```

---

### Test Data Seeding

```csharp
protected override async ValueTask ConfigureServerMiddlewareAsync(IApplicationBuilder app, IServiceProvider serviceProvider)
{
    app.UseRouting();
    app.UseEndpoints(endpoints => endpoints.MapControllers());
    
    // Seed test data
    using var scope = serviceProvider.CreateScope();
    var dbContext = scope.ServiceProvider.GetRequiredService<MyDbContext>();
    await dbContext.SeedTestDataAsync();
    
    return;
}
```

---

## 📊 Comparison: Business Logic vs API Testing

| Feature | Business Logic Only | With API Test Host |
|---------|-------------------|-------------------|
| `HasTestHost` | `false` | `true` |
| HTTP Server | ❌ No | ✅ Yes |
| Real HTTP Calls | ❌ No | ✅ Yes |
| Middleware Pipeline | ❌ No | ✅ Yes |
| Controller Discovery | ❌ No | ✅ Auto |
| Use Case | Services, Repositories | REST APIs, gRPC |
| Performance | ⚡ Fast | 🐢 Slower (HTTP overhead) |
| Complexity | 📦 Simple | 🏗️ Complex |

---

## 🎯 Best Practices

### ✅ DO

- **Use separate `appsettings.test.json`** for test configuration
- **Enable `HasTestHost`** only when testing HTTP layer
- **Use In-Memory Database** for isolated tests
- **Mock external dependencies** to avoid flaky tests
- **Use `Theory` with `InlineData`** for parameterized tests
- **Test happy path AND edge cases**
- **Use descriptive test names** like `CreateBook_WithValidData_ShouldSucceed`

### ❌ DON'T

- **Don't use real databases** in tests (use in-memory or testcontainers)
- **Don't enable `HasTestHost`** if not testing HTTP layer (performance overhead)
- **Don't share test data** between tests (use isolated databases)
- **Don't hardcode URLs** (use `IConfiguration` or constants)
- **Don't ignore cleanup** (dispose resources properly)

---

## 🚨 Troubleshooting

### Test Server Not Starting

**Problem**: `TestHttpClientFactory.Instance.Host` is null

**Solution**: Check that `HasTestHost = true` and `ConfigureServerServicesAsync`/`ConfigureServerMiddlewareAsync` are implemented.

---

### Controllers Not Found

**Problem**: 404 errors when calling API endpoints

**Solution**: Verify `TypeToChooseTheRightAssemblyWithControllersToMap` points to correct assembly containing controllers.

```csharp
// Make sure this points to your API project
protected override Type? TypeToChooseTheRightAssemblyWithControllersToMap => typeof(Program);
```

---

### User Secrets Not Loading

**Problem**: Configuration values from User Secrets are null

**Solution**: 
1. Verify `TypeToChooseTheRightAssemblyToRetrieveSecretsForConfiguration => typeof(Startup)`
2. Check User Secrets are set:
   ```bash
   dotnet user-secrets list
   ```
3. Ensure `UserSecretsId` in `.csproj`:
   ```xml
   <PropertyGroup>
     <UserSecretsId>your-guid-here</UserSecretsId>
   </PropertyGroup>
   ```

---

### XUnit v3 Package Errors

**Problem**: Build errors like "The type or namespace name 'Fact' could not be found"

**Solution**: Ensure you're using `xunit.v3` package, **NOT** `xunit`:

```bash
# Remove old package
dotnet remove package xunit

# Add XUnit v3
dotnet add package xunit.v3 --version 3.0.1
```

**Check your `.csproj`:**
```xml
<!-- ❌ WRONG -->
<PackageReference Include="xunit" Version="2.x.x" />

<!-- ✅ CORRECT -->
<PackageReference Include="xunit.v3" Version="3.0.1" />
```

---

### Test Runner Not Discovering Tests

**Problem**: Tests don't appear in Visual Studio Test Explorer or `dotnet test` finds no tests

**Solution**: 
1. Ensure `xunit.runner.visualstudio` version 3.1.4+:
   ```xml
   <PackageReference Include="xunit.runner.visualstudio" Version="3.1.4">
     <IncludeAssets>runtime; build; native; contentfiles; analyzers; buildtransitive</IncludeAssets>
     <PrivateAssets>all</PrivateAssets>
   </PackageReference>
   ```

2. Ensure `IsTestProject` is set:
   ```xml
   <PropertyGroup>
     <IsTestProject>true</IsTestProject>
   </PropertyGroup>
   ```

3. Rebuild solution:
   ```bash
   dotnet clean
   dotnet build
   ```

---

### Constructor Injection Not Working

**Problem**: Test constructor parameters not being resolved

**Solution**: 
1. Verify `Startup` class inherits from `StartupHelper`
2. Ensure services are registered in `ConfigureClientServices`:
   ```csharp
   protected override IServiceCollection ConfigureClientServices(IServiceCollection services, IConfiguration configuration)
   {
       services.AddMyServices(); // Make sure all dependencies are registered!
       return services;
   }
   ```

3. Check test project references `Rystem.Test.XUnit`:
   ```bash
   dotnet list package | Select-String "Rystem.Test.XUnit"
   ```

---

### Health Check Fails

**Problem**: Test server fails health check validation

**Solution**: 
1. Set `AddHealthCheck = false` if you don't need health checks
2. Or ensure all dependencies are properly configured:
   ```csharp
   protected override async ValueTask ConfigureServerServicesAsync(IServiceCollection services, IConfiguration configuration)
   {
       services.AddHealthChecks()
           .AddCheck("database", () => HealthCheckResult.Healthy())
           .AddCheck("external-api", () => HealthCheckResult.Healthy());
       return;
   }
   ```

---

## 📚 Resources

- **📖 Complete Documentation**: [https://rystem.net](https://rystem.net)
- **🤖 MCP Server for AI**: [https://rystem.cloud/mcp](https://rystem.cloud/mcp)
- **💬 Discord Community**: [https://discord.gg/tkWvy4WPjt](https://discord.gg/tkWvy4WPjt)
- **☕ Support the Project**: [https://www.buymeacoffee.com/keyserdsoze](https://www.buymeacoffee.com/keyserdsoze)
- **🔧 NuGet Package**: [Rystem.Test.XUnit](https://www.nuget.org/packages/Rystem.Test.XUnit)

---

## Text Extensions

> Fast text and stream utilities - includes ToByteArray(), ToStream(), ReadLinesAsync(), ToUpperCaseFirst(), ContainsAtLeast() for efficient string/byte/stream conversions

---
title: Text Extensions
description: Fast text and stream utilities - includes ToByteArray(), ToStream(), ReadLinesAsync(), ToUpperCaseFirst(), ContainsAtLeast() for efficient string/byte/stream conversions
---

# Text Extensions

Fast **text and stream utilities** for efficient conversions between strings, byte arrays, and streams.

---

## Installation

```bash
dotnet add package Rystem --version 9.1.3
```

---

## String ↔ Byte Array

### String to Byte Array

```csharp
using Rystem;

string text = "Hello, World!";
byte[] bytes = text.ToByteArray();
```

### Byte Array to String

```csharp
byte[] bytes = new byte[] { 72, 101, 108, 108, 111 };
string text = bytes.ConvertToString();

Console.WriteLine(text); // Outputs: "Hello"
```

**Complete Example:**

```csharp
string original = "daskemnlandxioasndslam dasmdpoasmdnasndaslkdmlasmv asmdsa";
var bytes = original.ToByteArray();
string restored = bytes.ConvertToString();

Assert.Equal(original, restored);
```

---

## String ↔ Stream

### String to Stream

```csharp
string text = "Hello, World!";
Stream stream = text.ToStream();
```

### Stream to String

```csharp
Stream stream = GetStreamFromSomewhere();
string text = stream.ConvertToString();
```

**Complete Example:**

```csharp
string original = "daskemnlandxioasndslam dasmdpoasmdnasndaslkdmlasmv asmdsa";
var stream = original.ToStream();
string restored = stream.ConvertToString();

Assert.Equal(original, restored);
```

---

## Read Lines Asynchronously

Read a string with **line breaks** as an `IAsyncEnumerable<string>`:

```csharp
string text = "Line 1\nLine 2\nLine 3";
var stream = text.ToStream();

var lines = new List<string>();
await foreach (var line in stream.ReadLinesAsync())
{
    lines.Add(line);
    Console.WriteLine(line);
}

// Output:
// Line 1
// Line 2
// Line 3
```

**With File Stream:**

```csharp
using var fileStream = File.OpenRead("largefile.txt");

await foreach (var line in fileStream.ReadLinesAsync())
{
    // Process each line without loading entire file into memory
    ProcessLine(line);
}
```

---

## Uppercase First Character

Make the **first character uppercase**:

```csharp
string text = "hello world";
string capitalized = text.ToUpperCaseFirst();

Console.WriteLine(capitalized); // Outputs: "Hello world"
```

**Example:**

```csharp
string dasda = "dasda";
string result = dasda.ToUpperCaseFirst();

Assert.Equal("Dasda", result);
```

---

## Contains At Least X Times

Check if a **character appears at least X times**:

```csharp
string value = "abcderfa";

bool containsAtLeastTwoA = value.ContainsAtLeast(2, 'a');
Console.WriteLine(containsAtLeastTwoA); // Outputs: True

bool containsAtLeastThreeA = value.ContainsAtLeast(3, 'a');
Console.WriteLine(containsAtLeastThreeA); // Outputs: False
```

**Use Cases:**

```csharp
// Password validation: at least 2 special characters
string password = "P@ssw0rd!";
bool isValid = password.ContainsAtLeast(2, '@', '!', '#', '$', '%');

// Email validation: exactly one @
string email = "user@example.com";
bool hasOneAt = email.ContainsAtLeast(1, '@') && !email.ContainsAtLeast(2, '@');
```

---

## Real-World Examples

### File Upload Processing

```csharp
public async Task<string> ProcessUploadAsync(Stream fileStream)
{
    // Convert stream to string
    string content = fileStream.ConvertToString();
    
    // Process content
    var lines = new List<string>();
    await foreach (var line in content.ToStream().ReadLinesAsync())
    {
        if (!string.IsNullOrWhiteSpace(line))
        {
            lines.Add(line.ToUpperCaseFirst());
        }
    }
    
    return string.Join("\n", lines);
}
```

### API Response Handling

```csharp
public async Task<ApiResponse> CallExternalApiAsync()
{
    var response = await httpClient.GetAsync("/api/endpoint");
    var stream = await response.Content.ReadAsStreamAsync();
    
    // Convert stream to string
    string jsonResponse = stream.ConvertToString();
    
    return jsonResponse.FromJson<ApiResponse>();
}
```

### Log File Analysis

```csharp
public async Task<Dictionary<string, int>> AnalyzeLogFileAsync(string filePath)
{
    var errorCounts = new Dictionary<string, int>();
    
    using var fileStream = File.OpenRead(filePath);
    
    await foreach (var line in fileStream.ReadLinesAsync())
    {
        if (line.ContainsAtLeast(1, "ERROR", "WARN"))
        {
            var errorType = line.Contains("ERROR") ? "ERROR" : "WARN";
            errorCounts[errorType] = errorCounts.GetValueOrDefault(errorType) + 1;
        }
    }
    
    return errorCounts;
}
```

### CSV Processing

```csharp
public async Task<List<Product>> ParseCsvAsync(Stream csvStream)
{
    var products = new List<Product>();
    
    await foreach (var line in csvStream.ReadLinesAsync())
    {
        var parts = line.Split(',');
        if (parts.Length >= 3)
        {
            products.Add(new Product
            {
                Name = parts[0].ToUpperCaseFirst(),
                Price = decimal.Parse(parts[1]),
                Category = parts[2]
            });
        }
    }
    
    return products;
}
```

### Password Validation

```csharp
public class PasswordValidator
{
    public bool IsValid(string password)
    {
        if (password.Length < 8)
            return false;
        
        // At least 2 uppercase letters
        if (!password.ContainsAtLeast(2, "ABCDEFGHIJKLMNOPQRSTUVWXYZ".ToCharArray()))
            return false;
        
        // At least 2 digits
        if (!password.ContainsAtLeast(2, "0123456789".ToCharArray()))
            return false;
        
        // At least 1 special character
        if (!password.ContainsAtLeast(1, '@', '!', '#', '$', '%', '&', '*'))
            return false;
        
        return true;
    }
}
```

---

## Benefits

- ✅ **Performance**: Fast conversions without allocations
- ✅ **Memory Efficient**: Stream-based line reading
- ✅ **Convenience**: Simple extension methods
- ✅ **Async Support**: ReadLinesAsync for large files
- ✅ **No Dependencies**: Built-in utilities

---

## Related Tools

- **[CSV Serialization](https://rystem.net/mcp/tools/rystem-csv.md)** - CSV utilities using text extensions
- **[JSON Extensions](https://rystem.net/mcp/tools/rystem-json-extensions.md)** - JSON serialization
- **[Content Repository](https://rystem.net/mcp/resources/content-repo.md)** - File upload/download with streams

---

## References

- **NuGet Package**: [Rystem](https://www.nuget.org/packages/Rystem) v9.1.3
- **Documentation**: https://rystem.net
- **GitHub**: https://github.com/KeyserDSoze/Rystem
