---
name: Rystem - Get Rystem Docs / Api
description: Rystem Framework docs: Rystem.Api.Client.Authentication.BlazorServer, Rystem.Api.Client.Authentication.BlazorWasm, Rystem.Api, Rystem.Api.Client and 1 more. Use for api questions in Rystem.
---

# Rystem - Get Rystem Docs / Api

> Auto-generated from Rystem MCP manifest (tool: `get-rystem-docs`, category: `api`)

---

## Rystem.Api.Client.Authentication.BlazorServer

> Rystem.Api.Client.Authentication.BlazorServer adds token-based request enhancers for Rystem.Api.Client in Blazor Server applications.

# Rystem.Api.Client.Authentication.BlazorServer

`Rystem.Api.Client.Authentication.BlazorServer` adds token-based request enhancers for `Rystem.Api.Client` in Blazor Server applications.

It does not register generated API clients for you and it does not configure ASP.NET Core authentication middleware for you. Its job is narrower: attach authorization headers to the HTTP requests created by `Rystem.Api.Client`.

## Installation

```bash
dotnet add package Rystem.Api.Client.Authentication.BlazorServer
```

## What this package adds

The package exposes four extension methods:

| Method | Scope | Token source |
| --- | --- | --- |
| `AddAuthenticationForAllEndpoints(settings)` | all generated clients | `Microsoft.Identity.Web` |
| `AddAuthenticationForEndpoint<T>(settings)` | one generated client | `Microsoft.Identity.Web` |
| `AddSocialAuthenticationForAllEndpoints(settings)` | all generated clients | `Rystem.Authentication.Social.Blazor` |
| `AddSocialAuthenticationForEndpoint<T>(settings)` | one generated client | `Rystem.Authentication.Social.Blazor` |

`AuthorizationSettings` currently exposes only:

- `Scopes`

## Typical Blazor Server setup

This follows the sample client app in `src/Api/Test/Rystem.Api.TestClient/Program.cs`.

```csharp
var scopes = new[] { builder.Configuration["AzureAd:Scopes"]! };

builder.Services
    .AddAuthentication(OpenIdConnectDefaults.AuthenticationScheme)
    .AddMicrosoftIdentityWebApp(builder.Configuration.GetSection("AzureAd"))
    .EnableTokenAcquisitionToCallDownstreamApi(scopes)
    .AddInMemoryTokenCaches();

builder.Services.AddControllersWithViews()
    .AddMicrosoftIdentityUI();

builder.Services.AddMicrosoftIdentityConsentHandler();

builder.Services.AddBusiness();

builder.Services.AddClientsForAllEndpointsApi(http =>
{
    http.ConfigurationHttpClientForApi(client =>
    {
        client.BaseAddress = new Uri("https://localhost:7117");
    });
});

builder.Services.AddAuthenticationForAllEndpoints(settings =>
{
    settings.Scopes = scopes;
});
```

## Microsoft Identity flow

The `AddAuthenticationForAllEndpoints(...)` and `AddAuthenticationForEndpoint<T>(...)` methods:

1. create named `AuthorizationSettings`
2. register them as singleton factory options
3. add a request enhancer (`TokenManager` / `TokenManager<T>`)

At request time, that enhancer calls:

```csharp
IAuthorizationHeaderProvider.CreateAuthorizationHeaderForUserAsync(scopes)
```

and applies the returned `Authorization` header to the outgoing request.

For endpoint-specific registration, the generic `TokenManager<T>` uses the named settings key for that interface.

## Social flow

The social variants use `SocialLoginManager` from `Rystem.Authentication.Social.Blazor` and try to attach a bearer token fetched from the current social session.

If a social token cannot be fetched, the enhancer logs the user out and refreshes the navigation state.

## Important caveats

### This package is only an enhancer layer

You still need:

- `Rystem.Api.Client`
- endpoint/client registrations such as `AddClientsForAllEndpointsApi(...)`
- your own Blazor Server auth setup

### The social path is rough in the current implementation

Source-backed caveats:

- the `settings` callback for the social registration methods is currently not stored anywhere meaningful
- `SocialTokenManager` currently builds the `Authorization` header from the wrapper result object instead of the fetched token string

So the Microsoft Identity path is the better-documented and more reliable path today. Treat the social helpers as limited/experimental until they are cleaned up.

### Enhancer ordering still comes from `Rystem.Api.Client`

If you register both global enhancers and endpoint-specific enhancers, all-endpoint enhancers run first, then endpoint-specific enhancers.

## Grounded by sample files

- `src/Api/Test/Rystem.Api.TestClient/Program.cs`
- `src/Api/Client/Rystem.Api.Client.Authentication.BlazorServer/DefaultInterceptor/ServiceCollectionExtensionsForAuthenticator.cs`
- `src/Api/Client/Rystem.Api.Client.Authentication.BlazorServer/Authorization/TokenManager.cs`
- `src/Api/Client/Rystem.Api.Client.Authentication.BlazorServer/Authorization/SocialTokenManager.cs`

Use this package when you already have Blazor Server authentication in place and you want generated `Rystem.Api.Client` calls to carry bearer tokens automatically.

---

## Rystem.Api.Client.Authentication.BlazorWasm

> Rystem.Api.Client.Authentication.BlazorWasm adds bearer-token request enhancers for generated Rystem.Api.Client proxies in Blazor WebAssembly applications.

# Rystem.Api.Client.Authentication.BlazorWasm

`Rystem.Api.Client.Authentication.BlazorWasm` adds bearer-token request enhancers for generated `Rystem.Api.Client` proxies in Blazor WebAssembly applications.

Like the Blazor Server package, it is an enhancer layer, not a full auth/client registration package.

## Installation

```bash
dotnet add package Rystem.Api.Client.Authentication.BlazorWasm
```

## What this package adds

The package exposes:

| Method | Scope |
| --- | --- |
| `AddAuthenticationForAllEndpoints(settings)` | all generated clients |
| `AddAuthenticationForEndpoint<T>(settings)` | one generated client |

`AuthorizationSettings` currently exposes only:

- `Scopes`

There are no social-auth variants in this package.

## Typical Blazor WASM setup

```csharp
var scopes = new[] { builder.Configuration["AzureAd:Scopes"]! };

builder.Services.AddMsalAuthentication(options =>
{
    builder.Configuration.Bind("AzureAd", options.ProviderOptions.Authentication);
    options.ProviderOptions.DefaultAccessTokenScopes.Add(scopes[0]);
});

builder.Services.AddBusiness();

builder.Services.AddClientsForAllEndpointsApi(http =>
{
    http.ConfigurationHttpClientForApi(client =>
    {
        client.BaseAddress = new Uri("https://api.myapp.io");
    });
});

builder.Services.AddAuthenticationForAllEndpoints(settings =>
{
    settings.Scopes = scopes;
});
```

## Token flow

The package registers a request enhancer (`TokenManager` / `TokenManager<T>`) that:

1. asks `IAccessTokenProvider` for an access token
2. caches the last token in memory
3. refreshes it when it is missing or within five minutes of expiry
4. attaches it as `Bearer <token>` to the outgoing request

If `Scopes` is configured, token acquisition uses those scopes. Otherwise it requests the default token.

## Important caveats

### This package does not register clients

You still need:

- `Rystem.Api.Client`
- shared endpoint registrations
- generated client registration with `AddClientsForAllEndpointsApi(...)` or `AddClientForEndpointApi<T>(...)`

### Endpoint-specific settings are weaker than they look

The package exposes `AddAuthenticationForEndpoint<T>(...)`, but the base token manager currently resolves `AuthorizationSettings` without using the named client key.

So per-endpoint auth settings are not as isolated as the API shape suggests.

### Failed acquisition handling is rough

When token acquisition fails, the current implementation can produce an empty token string rather than a cleaner null-or-challenge flow.

So treat this package as a lightweight enhancer, not as a replacement for the richer `AuthorizationMessageHandler` patterns in custom Blazor WASM code.

### No social helpers here

If you need the separate social-login helpers from this repo, they are not part of the WASM auth package.

## Grounded by source files

- `src/Api/Client/Rystem.Api.Client.Authentication.BlazorWasm/DefaultInterceptor/ServiceCollectionExtensionsForAuthenticator.cs`
- `src/Api/Client/Rystem.Api.Client.Authentication.BlazorWasm/Authorization/TokenManager.cs`
- `src/Api/Test/Rystem.Api.Test.Domain/ServiceCollectionExtensions.cs`

Use this package when you already have Blazor WebAssembly MSAL auth configured and you want generated `Rystem.Api.Client` calls to pick up bearer tokens automatically.

---

## Rystem.Api

> Rystem.Api is the shared metadata package behind the Api area.

# Rystem.Api

`Rystem.Api` is the shared metadata package behind the Api area.

It does not expose routes by itself and it does not create HTTP clients by itself. Instead, it records endpoint definitions from interfaces so that:

- `Rystem.Api.Server` can map them as minimal APIs
- `Rystem.Api.Client` can create runtime HTTP proxies from the same definitions

## Installation

```bash
dotnet add package Rystem.Api
```

## Package boundaries

| Package | Role |
| --- | --- |
| `Rystem.Api` | shared endpoint metadata, binding attributes, `IHttpFile`, and builder APIs |
| `Rystem.Api.Server` | ASP.NET Core mapping, OpenAPI, Swagger, Scalar |
| `Rystem.Api.Client` | runtime `DispatchProxy` HTTP clients |
| `Rystem.Api.Client.Authentication.BlazorServer` | request enhancers for Blazor Server token flows |
| `Rystem.Api.Client.Authentication.BlazorWasm` | request enhancers for Blazor WebAssembly token flows |

## Architecture

The core flow is:

1. register your interface implementation in DI on the server
2. call `ConfigureEndpoints(...)` once to set shared defaults
3. call `AddEndpoint<T>(...)` or `AddEndpointWithFactory<T>(...)` to record API metadata
4. let `Rystem.Api.Server` map those endpoints with `UseEndpointApi()`
5. let `Rystem.Api.Client` build proxies from the same endpoint registrations

Internally, endpoint definitions are stored in a singleton `EndpointsManager`.

Because of that, shared configuration should be done before or together with endpoint registration. In practice, treat `ConfigureEndpoints(...)` as startup configuration, not something to call later.

## Minimal shared registration

This pattern is what the sample domain project does in `src/Api/Test/Rystem.Api.Test.Domain/ServiceCollectionExtensions.cs`.

```csharp
services
    .ConfigureEndpoints(options =>
    {
        options.BasePath = "rapi/";
    })
    .AddEndpoint<ISalubry>(endpoint =>
    {
        endpoint.SetEndpointName("Salubriend");
        endpoint.AddAuthorizationForAll("policy");
    });
```

That registration is shared metadata. You still need:

- a real DI implementation on the server
- `UseEndpointApi()` from `Rystem.Api.Server`
- `AddClientsForAllEndpointsApi(...)` or `AddClientForEndpointApi<T>(...)` from `Rystem.Api.Client`

## Defaults and route shape

`EndpointsManager` defaults are:

| Setting | Default |
| --- | --- |
| `BasePath` | `api/` |
| `RemoveAsyncSuffix` | `true` |

`EndpointValue` defaults are:

- endpoint name = interface name without the leading `I`
- method name = CLR method name, optionally without `Async`

So this interface:

```csharp
public interface IProductService
{
    Task<Product?> GetAsync(string id);
}
```

becomes this route shape by default:

```text
api/ProductService/Get?id=...
```

If a method has path-bound parameters, the placeholders are appended after the method segment.

## Registration APIs

| Method | Purpose |
| --- | --- |
| `ConfigureEndpoints(Action<EndpointsManager>)` | configure shared defaults like `BasePath` and async-suffix trimming |
| `AddEndpoint<T>(Action<ApiEndpointBuilder<T>>, name?)` | register one interface as one endpoint set |
| `AddEndpointWithFactory<T>(Action<ApiEndpointBuilder<T>>?)` | declare a factory-backed endpoint set to be expanded server-side |

The optional `name` on `AddEndpoint<T>(..., name)` targets a specific named factory instance.

On the server, that means the endpoint is resolved through `IFactory<T>`. On the client, the matching named proxy is also a factory-backed registration rather than a plain default interface registration.

## `ApiEndpointBuilder<T>`

The actual public builder surface is:

| Method | Purpose |
| --- | --- |
| `SetEndpointName(name)` | override the endpoint segment |
| `SetMethodName(expr, name)` | rename a method by expression |
| `SetMethodName(methodInfo, name)` | rename a method by `MethodInfo` |
| `Remove(methodInfo)` | exclude a method |
| `Remove(methodName)` | exclude a method by stored key |
| `AddAuthorization(expr)` | require authenticated access on one method |
| `AddAuthorization(expr, params policies)` | require named policies on one method |
| `AddAuthorizationForAll()` | require authentication on all methods |
| `AddAuthorizationForAll(params policies)` | require named policies on all methods |
| `SetupParameter(expr, parameterName, setup)` | override parameter metadata by expression |
| `SetupParameter(methodInfo, parameterName, setup)` | override parameter metadata by `MethodInfo` |

### Recommendation for async methods

The expression-based lookup methods are less reliable when `RemoveAsyncSuffix = true`, because route names and expression names can diverge.

For async methods, prefer the `MethodInfo` overloads when you need precise customization.

Example:

```csharp
var getMethod = typeof(ISalubry).GetMethod(nameof(ISalubry.GetAsync))!;

services.AddEndpoint<ISalubry>(endpoint =>
{
    endpoint.SetEndpointName("Salubriend");
    endpoint.SetMethodName(getMethod, "Gimme");
    endpoint.SetupParameter(getMethod, "id", parameter =>
    {
        parameter.Location = ApiParameterLocation.Body;
        parameter.Example = 56;
    });
});
```

## Parameter binding attributes

These attributes are the shared binding contract for both server and client packages.

| Attribute | Meaning |
| --- | --- |
| `[Query]` | bind from query string |
| `[Path(Index = n)]` | bind from path segments |
| `[Header]` | bind from request headers |
| `[Cookie]` | bind from cookies |
| `[Body]` | bind from request body |
| `[Form]` | bind from multipart form-data |

Properties on these attributes include:

- `Name` for query/header/cookie/form overrides
- `IsRequired` on all binding attributes
- `Index` on `[Path]`

## Default parameter behavior

Without an attribute:

- primitive values default to query binding
- non-primitive values default to body binding
- `CancellationToken` is recognized specially
- `Stream`, `IFormFile`, and `IHttpFile` are treated as streamed body values

`POST` and multipart behavior are inferred later from this metadata by the server and client packages.

## `IHttpFile`

`Rystem.Api` also defines `IHttpFile`, a lightweight file abstraction used by the generated API pipeline.

Use it when you want an interface-level file type that is not tied directly to ASP.NET Core's `IFormFile`.

## Important caveats

### All interface methods are discovered

Registration currently uses `typeof(T).GetMethods()`.

That means property getters are also exposed unless you remove them. The sample `ITeamCalculator` in `src/Api/Test/Rystem.Api.Test.Domain/ITeamCalculator.cs` would expose getter methods such as `get_IsLive` if left untouched.

### Overloads are auto-suffixed

If an interface contains overloaded methods, the builder keeps them unique by renaming later ones to `_2`, `_3`, and so on.

### Factory expansion is a server concern

`AddEndpointWithFactory<T>()` records the intent to expand named factory endpoints, but the actual fan-out happens in `Rystem.Api.Server` during `UseEndpointApi()`.

The client package does not currently perform the same automatic expansion from factory names.

## Grounded by sample files

- `src/Api/Test/Rystem.Api.Test.Domain/ServiceCollectionExtensions.cs`
- `src/Api/Test/Rystem.Api.Test.Domain/IColam.cs`
- `src/Api/Test/Rystem.Api.Test.Domain/ISalubry.cs`
- `src/Api/Test/Rystem.Api.Test.Domain/ITeamCalculator.cs`
- `src/Api/Test/Rystem.Api.Test.Domain/IEmbeddingService.cs`

Use this package when you want to define the shared API contract once and let the server and client packages interpret it consistently.

---

## Rystem.Api.Client

> Rystem.Api.Client is the runtime client layer for Rystem.Api.

# Rystem.Api.Client

`Rystem.Api.Client` is the runtime client layer for `Rystem.Api`.

It does not generate source files. Instead, it builds runtime `DispatchProxy` implementations for your interfaces and sends HTTP requests based on the shared endpoint metadata.

## Installation

```bash
dotnet add package Rystem.Api.Client
```

## Architecture

The client package expects the same endpoint registrations that the server uses.

In practice, both sides should call a shared method, like the sample `AddBusiness()` in `src/Api/Test/Rystem.Api.Test.Domain/ServiceCollectionExtensions.cs`.

The flow is:

1. share `ConfigureEndpoints(...)` and `AddEndpoint...(...)` registrations between client and server
2. register clients with `AddClientsForAllEndpointsApi(...)` or `AddClientForEndpointApi<T>(...)`
3. optionally add `IRequestEnhancer` implementations
4. inject the interface directly and call it like a normal service

Each generated client is a transient factory-backed proxy that uses a named `HttpClient` internally.

## Minimal setup

This follows the sample app in `src/Api/Test/Rystem.Api.TestClient/Program.cs`.

```csharp
builder.Services.AddBusiness();

builder.Services.AddClientsForAllEndpointsApi(http =>
{
    http.ConfigurationHttpClientForApi(client =>
    {
        client.BaseAddress = new Uri("https://localhost:7117");
    });
});
```

After that, you can inject the interface directly:

```csharp
public sealed class ProductPage
{
    private readonly ISalubry _service;

    public ProductPage(ISalubry service)
        => _service = service;

    public Task<bool> RunAsync(int id, Stream stream)
        => _service.GetAsync(id, stream);
}
```

## Registration APIs

| Method | Purpose |
| --- | --- |
| `AddClientsForAllEndpointsApi(Action<HttpClientBuilder>)` | register proxies for every endpoint currently known to `EndpointsManager` |
| `AddClientForEndpointApi<T>(Action<HttpClientBuilder>, factoryName?)` | register a proxy for one endpoint type, optionally targeting a named instance |

Generated proxies are registered through the same factory system used elsewhere in the repo and currently use `ServiceLifetime.Transient`.

When you target a named endpoint instance, resolve that proxy through `IFactory<T>` rather than relying on plain interface injection.

## `HttpClientBuilder`

`HttpClientBuilder` exposes:

| Method | Purpose |
| --- | --- |
| `ConfigurationHttpClientForApi(Action<HttpClient>)` | default `HttpClient` configuration for all endpoint proxies |
| `ConfigurationHttpClientForEndpointApi<T>(Action<HttpClient>)` | `HttpClient` configuration only for interface `T` |

Precedence is:

1. endpoint-specific `ConfigurationHttpClientForEndpointApi<T>(...)`
2. shared `ConfigurationHttpClientForApi(...)`
3. default `AddHttpClient(...)` with no extra configuration

## Request enhancers

`IRequestEnhancer` is the client-side interception hook.

```csharp
public sealed class CorrelationEnhancer : IRequestEnhancer
{
    public ValueTask EnhanceAsync(HttpRequestMessage request, CancellationToken cancellationToken)
    {
        request.Headers.Add("X-Correlation-Id", Guid.NewGuid().ToString());
        return ValueTask.CompletedTask;
    }
}
```

Register enhancers with:

| Method | Scope |
| --- | --- |
| `AddEnhancerForAllEndpoints<TEnhancer>()` | all generated clients |
| `AddEnhancerForEndpoint<TEnhancer, T>()` | only the client for interface `T` |

Enhancer execution order is:

1. all-endpoint enhancers
2. endpoint-specific enhancers

The sample client registers both kinds in `src/Api/Test/Rystem.Api.TestClient/Program.cs`.

## Request building behavior

The client proxy uses the endpoint metadata from `Rystem.Api` to build requests.

- query parameters are appended to the URI
- path parameters are appended as URI segments
- cookies are written into the `cookie` header
- headers are copied into request headers
- body parameters become either plain content or multipart form-data
- `IAsyncEnumerable<T>` results are read as streamed JSON
- `Stream`, `IHttpFile`, and `IFormFile` response shapes are supported

The route pattern mirrors the server-side metadata:

```text
{BasePath}{EndpointName}/{FactoryName?}{MethodName}
```

## Important caveats

### The client depends on shared registrations

If the client and server do not share the same `ConfigureEndpoints(...)` and `AddEndpoint...(...)` definitions, route generation drifts and calls fail.

### Factory auto-expansion is not mirrored client-side

`AddEndpointWithFactory<T>()` is expanded automatically on the server during `UseEndpointApi()`, but the client package does not do the same factory-name fan-out automatically.

If you need named factory-backed clients, use explicit named registrations or `AddClientForEndpointApi<T>(..., factoryName)` for the specific named endpoint you want.

### URI composition is intentionally simple

Query, path, header, and cookie values are composed very directly.

The current implementation does not provide polished URL encoding or rich handling for non-primitive query/header/cookie payloads, so keep those cases simple.

### This is runtime proxy generation

There is no compile-time client code generation here. Debugging behavior is closer to a dynamic proxy than to a handwritten typed `HttpClient`.

## Grounded by sample files

- `src/Api/Test/Rystem.Api.Test.Domain/ServiceCollectionExtensions.cs`
- `src/Api/Test/Rystem.Api.TestClient/Program.cs`
- `src/Api/Test/Rystem.Api.TestClient/Services/Enhancer.cs`
- `src/Api/Test/Rystem.Api.Test.Domain/IColam.cs`
- `src/Api/Test/Rystem.Api.Test.Domain/IEmbeddingService.cs`

Use this package when you want to call `Rystem.Api.Server` endpoints through the same interface contracts instead of writing manual HTTP code.

---

## Rystem.Api.Server

> Rystem.Api.Server is the ASP.NET Core runtime layer for Rystem.Api.

# Rystem.Api.Server

`Rystem.Api.Server` is the ASP.NET Core runtime layer for `Rystem.Api`.

It takes the endpoint metadata recorded by `AddEndpoint<T>(...)` / `AddEndpointWithFactory<T>(...)` and turns it into minimal API routes.

## Installation

```bash
dotnet add package Rystem.Api.Server
```

## What this package adds

The server package provides two main entry points:

- `AddServerIntegrationForRystemApi(...)`
- `UseEndpointApi()`

It also adds:

- OpenAPI document setup
- optional Swagger UI
- optional Scalar UI
- optional model-export endpoint via `UseEndpointApiModels()`

## Typical setup

This follows the structure used in `src/Api/Test/Rystem.Api.TestServer/Program.cs`.

```csharp
var builder = WebApplication.CreateBuilder(args);

builder.Services.AddTransient<IColam, Comad>();
builder.Services.AddFactory<ISalubry, Salubry>();
builder.Services.AddFactory<ISalubry, Salubry2>("Doma");

builder.Services.AddBusiness();

builder.Services.AddAuthorization(options =>
{
    options.AddPolicy("policy", policy =>
    {
        policy.RequireClaim("name");
    });
});

builder.Services.AddServerIntegrationForRystemApi(options =>
{
    options.HasScalar = true;
    options.HasSwagger = true;
});

var app = builder.Build();

app.UseHttpsRedirection();
app.UseAuthentication();
app.UseAuthorization();

app.UseEndpointApi();
app.UseEndpointApiModels();

app.Run();
```

## `AddServerIntegrationForRystemApi(...)`

`AddServerIntegrationForRystemApi(...)` currently does three things:

1. registers `EndpointOptions` as a singleton
2. adds OpenAPI with a custom document transformer
3. adds Swagger generation only when `HasSwagger = true`

`EndpointOptions` exposes:

| Property | Default | Meaning |
| --- | --- | --- |
| `HasSwagger` | `false` | enable Swagger UI |
| `HasScalar` | `false` | enable Scalar API reference |

## `UseEndpointApi()`

`UseEndpointApi()` is the real mapping step.

At runtime it:

1. reads `EndpointOptions`
2. maps raw OpenAPI JSON
3. optionally maps Scalar and Swagger UI
4. expands `AddEndpointWithFactory<T>()` registrations into one endpoint set per factory name
5. maps every endpoint method as `MapGet` or `MapPost`

Without `UseEndpointApi()`, the metadata registered in `Rystem.Api` never becomes HTTP routes.

## Route pattern

The effective route pattern is:

```text
{BasePath}{EndpointName}/{FactoryName?}{MethodName}/{PathParams...}
```

Examples from the sample domain registrations:

- `rapi/Salubriend/Get`
- `rapi/E/Doma/Get`
- `rapi/EmbeddingService/First/Search`
- `rapi/EmbeddingService/Second/Search`

Path-bound parameters are appended after the method segment.

## HTTP verb selection

The server uses only `GET` and `POST`.

| Condition | Verb |
| --- | --- |
| no body-bound parameters | `GET` |
| at least one body-bound parameter | `POST` |

Multipart handling is inferred separately:

| Condition | Request shape |
| --- | --- |
| more than one body parameter | `multipart/form-data` |
| any `Stream`, `IFormFile`, or `IHttpFile` parameter | `multipart/form-data` |
| single non-stream body parameter | plain request body |

## Binding behavior

`UseEndpointApi()` honors the shared binding metadata from `Rystem.Api`:

- query parameters come from `Request.Query`
- cookie parameters come from `Request.Cookies`
- header parameters come from `Request.Headers`
- path parameters come from route segments
- body parameters come either from the raw request body or from multipart form fields/files

It also handles:

- `CancellationToken` injection
- `IFormFile` input
- `IHttpFile` input
- `Stream` input and output
- `IAsyncEnumerable<T>` output

## Authorization behavior

Authorization is driven by the metadata attached in `ApiEndpointBuilder<T>`.

At mapping time the server applies these rules:

- `Policies == null` -> `AllowAnonymous()`
- `Policies.Length == 0` -> `RequireAuthorization()`
- named policies -> `RequireAuthorization(policies)`

That means:

- no authorization metadata leaves the route anonymous
- `AddAuthorizationForAll()` means authenticated users only
- `AddAuthorizationForAll("policy")` means authenticated users that satisfy that policy

## Factory-backed endpoints

`AddEndpointWithFactory<T>()` is expanded on the server by resolving `IFactoryNames<T>`.

For each factory name, `UseEndpointApi()` creates a concrete endpoint set with the factory segment baked into the route.

So this pattern:

```csharp
builder.Services.AddFactory<IEmbeddingService, EmbeddingService1>(EmbeddingType.First);
builder.Services.AddFactory<IEmbeddingService, EmbeddingService2>(EmbeddingType.Second);

builder.Services.AddEndpointWithFactory<IEmbeddingService>();
```

becomes routes such as:

- `rapi/EmbeddingService/First/Search`
- `rapi/EmbeddingService/Second/Search`

## `UseEndpointApiModels()`

`UseEndpointApiModels()` adds a model-export endpoint for the currently hardcoded language list.

Right now that means:

- `GET /Business/Models/Typescript`

It inspects endpoint method return types and parameter types, filters out primitives and infrastructure types, and returns generated model text.

This endpoint does not use `BasePath`.

## Important caveats

### Property getters can become routes

If the shared `Rystem.Api` registration includes interface properties, the server will map them unless you removed those methods earlier.

### Factory expansion happens here, not in the core package

If you rely on `AddEndpointWithFactory<T>()`, remember that the real fan-out happens only when the server maps endpoints.

### OpenAPI raw JSON is always mapped

`UseEndpointApi()` always maps the raw OpenAPI document. Swagger UI and Scalar are the optional parts.

## Grounded by sample files

- `src/Api/Test/Rystem.Api.TestServer/Program.cs`
- `src/Api/Test/Rystem.Api.Test.Domain/ServiceCollectionExtensions.cs`
- `src/Api/Test/Rystem.Api.Test.Domain/IColam.cs`
- `src/Api/Test/Rystem.Api.Test.Domain/IEmbeddingService.cs`

Use this package when you want the interface metadata from `Rystem.Api` to become real ASP.NET Core endpoints.
