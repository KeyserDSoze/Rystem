---
name: Rystem - Get Rystem Docs / Api
description: Rystem Framework docs: api/api-client-authentication-blazorserver, api/api-client-authentication-blazorwasm, api/api, api/api-client and 1 more. Use for api questions in Rystem.
---

# Rystem - Get Rystem Docs / Api

> Auto-generated from Rystem MCP manifest (tool: `get-rystem-docs`, category: `api`)

---

## api/api-client-authentication-blazorserver

> You can add a client for a specific url

### [What is Rystem?](https://github.com/KeyserDSoze/Rystem)

## Services extensions

### HttpClient to use your API (example)
You can add a client for a specific url

    builder.Services.AddRepository<User, string>(builder =>
    {
        builder
            .WithApiClient()
            .WithHttpClient("localhost:7058");
    });

### Default interceptor for Authentication with JWT
You may use the default interceptor to deal with the identity manager in .Net DI.

    builder.Services.AddDefaultAuthorizationInterceptorForApiHttpClient();

This line of code inject an interceptor that works with ITokenAcquisition, injected by the framework during OpenId integration (for example AAD integration).
Automatically it adds the token to each request.

You may use the default identity interceptor not on all repositories, you can specificy them with

    builder.Services.AddRepository(builder => {
        builder
            .WithApiClient()
            .WithHttpClient("localhost:7058")
            .AddDefaultAuthorizationInterceptorForApiHttpClient<T, TKey>();
    });

Remember to add

    builder.Services.AddAuthentication(OpenIdConnectDefaults.AuthenticationScheme)
    .AddMicrosoftIdentityWebApp(builder.Configuration.GetSection("AzureAdB2C or AzureAd"))
     .EnableTokenAcquisitionToCallDownstreamApi(new string[] { "your_scope/access_as_user" })
     .AddInMemoryTokenCaches();

    builder.Services.AddServerSideBlazor()
    .AddMicrosoftIdentityConsentHandler();

    builder.Services.AddControllersWithViews()
    .AddMicrosoftIdentityUI();

---

## api/api-client-authentication-blazorwasm

> You can add a client for a specific url

### [What is Rystem?](https://github.com/KeyserDSoze/Rystem)

## Services extensions

### HttpClient to use your API (example)
You can add a client for a specific url

    builder.Services.AddRepository<User, string>(builder =>
    {
        builder
            .WithApiClient()
            .WithHttpClient("localhost:7058");
    });

### Default interceptor for Authentication with JWT
You may use the default interceptor to deal with the identity manager in .Net DI.

    builder.Services.AddDefaultAuthorizationInterceptorForApiHttpClient();

This line of code inject an interceptor that works with ITokenAcquisition, injected by the framework during OpenId integration (for example AAD integration).
Automatically it adds the token to each request.

You may use the default identity interceptor not on all repositories, you can specificy them with

    builder.Services.AddRepository(builder => {
        builder
            .WithApiClient()
            .WithHttpClient("localhost:7058")
            .AddDefaultAuthorizationInterceptorForApiHttpClient<T, TKey>();
    });

---

## api/api

> This project would be a super project to help the api creator to have fast api behind business interfaces and services dispatched through dependency injection.

### [What is Rystem?](https://github.com/KeyserDSoze/Rystem)

## Rystem.Api
This project would be a super project to help the api creator to have fast api behind business interfaces and services dispatched through dependency injection.

## How to use it

---

## api/api-client

### [What is Rystem?](https://github.com/KeyserDSoze/Rystem)

---

## api/api-server

### [What is Rystem?](https://github.com/KeyserDSoze/Rystem)
