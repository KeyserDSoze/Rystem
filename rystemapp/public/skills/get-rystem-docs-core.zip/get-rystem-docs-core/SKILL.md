---
name: Rystem - Get Rystem Docs / Core
description: Rystem Framework docs: Table of Contents, core/dependencyinjection, core/dependencyinjection-web. Use for core questions in Rystem.
---

# Rystem - Get Rystem Docs / Core

> Auto-generated from Rystem MCP manifest (tool: `get-rystem-docs`, category: `core`)

---

## Table of Contents

> - 📖 Complete Documentation: https://rystem.net(https://rystem.net)

### [What is Rystem?](https://github.com/KeyserDSoze/Rystem)

## 📚 Resources

- **📖 Complete Documentation**: [https://rystem.net](https://rystem.net)
- **🤖 MCP Server for AI**: [https://rystem.cloud/mcp](https://rystem.cloud/mcp)
- **💬 Discord Community**: [https://discord.gg/tkWvy4WPjt](https://discord.gg/tkWvy4WPjt)
- **☕ Support the Project**: [https://www.buymeacoffee.com/keyserdsoze](https://www.buymeacoffee.com/keyserdsoze)

---
# Table of Contents

- [What is Rystem?](#what-is-rystem)
- [Discriminated Union in C#](#discriminated-union-in-c)
  - [What is a Discriminated Union?](#what-is-a-discriminated-union)
  - [AnyOf Classes](#anyof-classes)
  - [JSON Integration](#json-integration)
  - [Matching and Switching](#matching-and-switching)
  - [Usage Examples](#usage-examples)
    - [Defining Unions](#defining-unions)
    - [Serializing and Deserializing JSON](#serializing-and-deserializing-json)
    - [Advanced Matching and Switching](#advanced-matching-and-switching)
    - [Deserialization with Attributes](#deserialization-with-attributes)
- [Extension Methods](#extension-methods)
  - [Stopwatch](#stopwatch)
  - [LINQ Expression Serializer](#linq-expression-serializer)
  - [Reflection Helper](#reflection-helper)
    - [Name of Calling Class](#name-of-calling-class)
    - [Extensions for Type Class](#extensions-for-type-class)
    - [Mock a Type](#mock-a-type)
    - [Check Nullability for Properties, Fields, and Parameters](#check-nullability-for-properties-fields-and-parameters)
  - [Text Extensions](#text-extensions)
  - [Character Separated-Value (CSV)](#character-separated-value-csv)
  - [Minimization of a Model](#minimization-of-a-model)
  - [Extensions for JSON](#extensions-for-json)
  - [Extensions for Task](#extensions-for-task)
  - [TaskManager](#taskmanager)
- [Concurrency](#concurrency)
  - [ConcurrentList](#concurrentlist)

---

## Discriminated Union in C#

This library introduces a `AnyOf<T0, T1, ...>` class that implements discriminated unions in C#. Discriminated unions are a powerful type system feature that allows variables to store one of several predefined types, enabling type-safe and concise programming. 

**This library also includes integration with JSON serialization and deserialization.**

### What is a Discriminated Union?

A discriminated union is a type that can hold one of several predefined types at a time. It provides a way to represent and operate on data that may take different forms, ensuring type safety and improving code readability.

For example, a union can represent a value that is either an integer, a string, or a boolean:

```csharp
AnyOf<int, string, bool> value;
```

The `value` can hold an integer, a string, or a boolean, but never more than one type at a time.

---

### AnyOf Classes

The `AnyOf` class provides the ability to define a discriminated union of up to 8 types.

- `AnyOf<T0, T1>`
- `AnyOf<T0, T1, T2>`
- ...
- `AnyOf<T0, T1, ..., T7>`

Each class supports the following features:

1. **Implicit Conversion**: Allows seamless assignment of any supported type to the union.
```csharp
public AnyOf<int, string> GetSomething(bool check)
{
    if (check)
        return 42;
    else
        return "Hello";
}
```
2. **Type Checking and Casting**: Methods to check and retrieve the stored type.
3. **Serialization Support**: Built-in JSON serialization and deserialization integration.
4. **Matching and Switching**: Methods to process the stored value using delegates or lambdas.

---

### JSON Integration

This library supports seamless JSON serialization and deserialization for discriminated unions. It uses a mechanism called **"Signature"** to identify the correct class during deserialization. The "Signature" is constructed based on the names of all properties that define each class in the union.

#### Serialization and Deserialization

The `AnyOf` class integrates with JSON serialization and deserialization. The integration supports:

1. **Implicit Serialization**: The active value in the union is serialized to JSON directly.
2. **Signature-Based Deserialization**: Uses property names ("signatures") to determine the correct type during deserialization.

#### How "Signature" Works

1. During deserialization, the library analyzes the properties present in the JSON.
2. The "Signature" matches the property names in the JSON to a predefined signature for each class in the union.
3. Once a match is found, the correct class is instantiated and populated with the data.

---

## Matching and Switching

The `AnyOf` class includes methods to simplify processing the stored value:

### Match Method

The `Match` method allows you to provide delegates for each possible type, returning a value based on the stored type.

#### Example:

```csharp
var union = new AnyOf<int, string>(42);
var result = union.Match(
    i => $"Integer: {i}",
    s => $"String: {s}"
);
Console.WriteLine(result); // Outputs: "Integer: 42"
```

### Switch Method

The `Switch` method allows you to perform different actions based on the stored type without returning a value.

#### Example:

```csharp
var union = new AnyOf<int, string>("Hello");
union.Switch(
    i => Console.WriteLine($"Integer: {i}"),
    s => Console.WriteLine($"String: {s}")
);
```

### Async Matching and Switching

Async versions of `Match` and `Switch` are also available for asynchronous operations.

#### Async Match Example:

```csharp
var union = new AnyOf<int, string>("Hello");
var result = await union.MatchAsync(
    async i => await Task.FromResult($"Integer: {i}"),
    async s => await Task.FromResult($"String: {s}")
);
Console.WriteLine(result); // Outputs: "String: Hello"
```

#### Async Switch Example:

```csharp
await union.SwitchAsync(
    async i => { await Task.Delay(100); Console.WriteLine($"Integer: {i}"); },
    async s => { await Task.Delay(100); Console.WriteLine($"String: {s}"); }
);
```

---

### Usage Examples

#### Defining Unions

Here’s how to define and use a discriminated union:

```csharp
var testClass = new CurrentTestClass
{
    OneClass_String = new FirstClass { FirstProperty = "OneClass_String.FirstProperty", SecondProperty = "OneClass_String.SecondProperty" },
    SecondClass_OneClass = new SecondClass
    {
        FirstProperty = "SecondClass_OneClass.FirstProperty",
        SecondProperty = "SecondClass_OneClass.SecondProperty"
    },
    OneClass_string__2 = "ExampleString",
    Bool_Int = 3,
    Decimal_Bool = true,
    OneCLass_SecondClass_Int = 42,
    FirstClass_SecondClass_Int_ThirdClass = new ThirdClass
    {
        Stringable = "StringContent",
        SecondClass = new SecondClass { FirstProperty = "Nested.FirstProperty", SecondProperty = "Nested.SecondProperty" }
    }
};
```

#### Serializing and Deserializing JSON

##### Example:

```csharp
var json = testClass.ToJson();
var deserialized = json.FromJson<CurrentTestClass>();
Console.WriteLine(deserialized.OneClass_String.AsT0.FirstProperty); // Outputs: OneClass_String.FirstProperty
```

---

#### Deserialization with Attributes

Attributes allow more control over deserialization, specifying how the correct type is chosen:

##### Example:

```csharp

public sealed class ChosenClass
{
    public AnyOf<TheFirstChoice, TheSecondChoice>? FirstProperty { get; set; }
    public string? SecondProperty { get; set; }
}

public sealed class TheFirstChoice
{
    [AnyOfJsonSelector("first")]
    public string Type { get; init; }
    public int Flexy { get; set; }
}
public sealed class TheSecondChoice
{
    [AnyOfJsonSelector("third", "second")]
    public string Type { get; init; }
    public int Flexy { get; set; }
}

var testClass = new ChosenClass
{
    FirstProperty = new TheSecondChoice
    {
        Type = "first",
        Flexy = 1,
    }
};
var json = testClass.ToJson();
var deserialized = json.FromJson<ChosenClass>();
Assert.True(deserialized.FirstProperty.Is<TheFirstChoice>());
```

I want to use this example that you find in the unit test to explain the attribute AnyOfJsonSelector. 
In this example FirstProperty of ChosenClass has a value for TheSecondChoice with a value in Type equal to "first".
The attribute AnyOfJsonSelector is used to define the correct class to use during deserialization, therefore when the deserialization happens
the library will use the class TheFirstChoice because the value of Type is "first". Both classes have the same properties and so the signatures are equals.
Follow the next example to understand completely.

```csharp
public sealed class ChosenClass
{
    public AnyOf<TheFirstChoice, TheSecondChoice>? FirstProperty { get; set; }
    public string? SecondProperty { get; set; }
}

public sealed class TheFirstChoice
{
    [AnyOfJsonSelector("first")]
    public string Type { get; init; }
    public int Flexy { get; set; }
}
public sealed class TheSecondChoice
{
    [AnyOfJsonSelector("third", "second")]
    public string Type { get; init; }
    public int Flexy { get; set; }
}

var testClass = new ChosenClass
{
    FirstProperty = new TheSecondChoice
    {
        Type = "third",
        Flexy = 1,
    }
};
var json = testClass.ToJson();
var deserialized = json.FromJson<ChosenClass>();
Assert.True(deserialized.FirstProperty.Is<TheSecondChoice>());
```

In this second example the property has a value of "third" and so the library will use the class TheSecondChoice.

#### Further attributes

Set a class as default class for AnyOf

```csharp
 [AnyOfJsonDefault]
public sealed class RunResult : ApiBaseResponse
{
}
```

Use regex as selector

```csharp
public sealed class FifthGetClass
{
    [AnyOfJsonRegexSelector("fift[^.]*.")]
    public string? FirstProperty { get; set; }
    public string? SecondProperty { get; set; }
}
```

Use over a class and not only over a property, like a value or like a regex.

```csharp
[AnyOfJsonClassSelector(nameof(FirstProperty), "first.F")]
public sealed class FirstGetClass
{
    public string? FirstProperty { get; set; }
    public string? SecondProperty { get; set; }
}
[AnyOfJsonRegexClassSelector(nameof(FirstProperty), "secon[^.]*.[^.]*")]
public sealed class SecondGetClass
{
    public string? FirstProperty { get; set; }
    public string? SecondProperty { get; set; }
}
```

---

#### Benefits of Using It

1. **Type Safety**: Ensures only predefined types are used.
2. **JSON Support**: Automatically identifies and deserializes the correct type using "Signature".
3. **Code Clarity**: Reduces boilerplate code for type management and error handling.


# Extension methods

## Stopwatch
You can monitor the time spent on an action, task or in a method.
Some examples from Unit test.

	var started = Stopwatch.Start();
    //do something
    await Task.Delay(2000);
    var result = started.Stop();

or

    var result = await Stopwatch.MonitorAsync(async () =>
    {
        await Task.Delay(2000);
    });

or with a return value

     var result = await Stopwatch.MonitorAsync(async () =>
    {
        await Task.Delay(2000);
        return 3;
    });

## Linq expression serializer
Usually a linq expression is not serializable as string. With this method you can serialize your expression with some limits. Only primitives are allowed in the expression body.
An example from Unit test.

    Expression<Func<MakeIt, bool>> expression = ƒ => ƒ.X == q && ƒ.Samules.Any(x => x == k) && ƒ.Sol && (ƒ.X.Contains(q) || ƒ.Sol.Equals(IsOk)) && (ƒ.E == id | ƒ.Id == V) && (ƒ.Type == MakeType.Yes || ƒ.Type == qq);
    var serialized = expression.Serialize();

with result

    "ƒ => ((((((ƒ.X == \"dasda\") AndAlso ƒ.Samules.Any(x => (x == \"ccccde\"))) AndAlso ƒ.Sol) AndAlso (ƒ.X.Contains(\"dasda\") OrElse ƒ.Sol.Equals(True))) AndAlso ((ƒ.E == Guid.Parse(\"bf46510b-b7e6-4ba2-88da-cef208aa81f2\")) Or (ƒ.Id == 32))) AndAlso ((ƒ.Type == 1) OrElse (ƒ.Type == 2)))"

with deserialization

    var newExpression = expressionAsString.Deserialize<MakeIt, bool>();

and usage, for instance, with Linq

    var result = makes.Where(newExpression.Compile()).ToList();

you can deserialize and compile at the same time with

    var newExpression = expressionAsString.DeserializeAndCompile<MakeIt, bool>();

you can deserialize as dynamic and use the linq dynamic methods

    Expression<Func<MakeIt, int>> expression = x => x.Id;
    string value = expression.Serialize();
    LambdaExpression newLambda = value.DeserializeAsDynamic<MakeIt>();
    var got = makes.AsQueryable();
    var cut = got.OrderByDescending(newLambda).ThenByDescending(newLambda).ToList();

please see the unit test [here](https://github.com/KeyserDSoze/RystemV3/blob/master/src/Rystem.Test/Rystem.Test.UnitTest/System.Linq/SystemLinq.cs) to understand better how it works
You may deal with return type of your lambda expression:

     LambdaExpression newLambda = value.DeserializeAsDynamic<MakeIt>();
     newLambda =  newLambda.ChangeReturnType<bool>();

or

     newLambda =  newLambda.ChangeReturnType(typeof(bool));


## Reflection helper

### Name of calling class
You can find the name of the calling class from your method, with deep = 1 the calling class of your method, with deep = 2 the calling class that calls the class that calls your method, and so on, with fullName set to true you obtain the complete name of the discovered class.

    ReflectionHelper.NameOfCallingClass(deep, fullName);

### Extensions for Type class
You can get the properties, fields and constructors for your class (and singleton them to save time during new requests)

    Type.FetchProperties();
    Type.FecthConstructors();
    Type.FetchFields();

You can check if a Type is a son or a father or both of other type (in the example Zalo and Folli are Sulo).
You may find more information in unit test [here](https://github.com/KeyserDSoze/RystemV3/blob/master/src/Rystem.Test/Rystem.Test.UnitTest/System.Reflection/ReflectionTest.cs)
    
    Zalo zalo = new();
    Zalo zalo2 = new();
    Folli folli = new();
    Sulo sulo = new();
    object quo = new();
    int x = 2;
    decimal y = 3;
    Assert.True(zalo.IsTheSameTypeOrASon(sulo));
    Assert.True(folli.IsTheSameTypeOrASon(sulo));
    Assert.True(zalo.IsTheSameTypeOrASon(zalo2));
    Assert.True(zalo.IsTheSameTypeOrASon(quo));
    Assert.False(sulo.IsTheSameTypeOrASon(zalo));
    Assert.True(sulo.IsTheSameTypeOrAParent(zalo));
    Assert.False(y.IsTheSameTypeOrAParent(x));

### Mock a Type
If you need to create a type over an abstract class or interface you may use the mocking system of Rystem.
For example, if you have an abstract class like this one down below.

    public abstract class Alzio
    {
        private protected string X { get; }
        public string O => X;
        public string A { get; set; }
        public Alzio(string x)
        {
            X = x;
        }
    }

you can create an instace of it or simply mock it with

    var mocked = typeof(Alzio).CreateInstance("AAA") as Alzio;
    mocked.A = "rrrr";

and you can use the class like a real class. You also may do it with

    Alzio alzio = null!;
    var mocked = alzio.CreateInstance("AAA");
    mocked.A = "rrrr";

or

    Mocking.CreateInstance<Alzio>("AAA");

you may see "AAA" as argument for your constructor in abstract class.

## Check nullability for properties, fields and parameters.
Following an example from unit test.

    private sealed class InModel
    {
        public string? A { get; set; }
        public string B { get; set; }
        public string? C;
        public string D;
        public InModel(string? b, string c)
        {
            A = b;
            B = c;
        }
        public void SetSomething(string? b, string c)
        {
            A = b;
            B = c;
        }
    }
    [Fact]
    public void Test1()
    {
        var type = typeof(InModel);
        var constructorParameters = type.GetConstructors().First().GetParameters().ToList();
        Assert.True(constructorParameters[0].IsNullable());
        Assert.False(constructorParameters[1].IsNullable());
        var methodParameters = type.GetMethod(nameof(InModel.SetSomething)).GetParameters().ToList();
        Assert.True(methodParameters[0].IsNullable());
        Assert.False(methodParameters[1].IsNullable());
        var properties = type.GetProperties().ToList();
        Assert.True(properties[0].IsNullable());
        Assert.False(properties[1].IsNullable());
        var fields = type.GetFields().ToList();
        Assert.True(fields[0].IsNullable());
        Assert.False(fields[1].IsNullable());
    }

## Text extensions
You may convert as fast as possible byte[] to string or stream to byte[] or byte[] to stream or stream to string or string to stream.
For example, string to byte array and viceversa.

    string olfa = "daskemnlandxioasndslam dasmdpoasmdnasndaslkdmlasmv asmdsa";
    var bytes = olfa.ToByteArray();
    string value = bytes.ConvertToString();

For example, string to stream and viceversa.

    string olfa = "daskemnlandxioasndslam dasmdpoasmdnasndaslkdmlasmv asmdsa";
    var stream = olfa.ToStream();
    string value = stream.ConvertToString();

You may read a string with break lines as an enumerable of string

    string olfa = "daskemnlandxioasndslam\ndasmdpoasmdnasndaslkdmlasmv\nasmdsa";
    var stream = olfa.ToStream();
    var strings = new List<string>();
    await foreach (var x in stream.ReadLinesAsync())
    {
        strings.Add(x);
    }

A simple method to make uppercase the first character.

    string olfa = "dasda";
    var olfa2 = olfa.ToUpperCaseFirst();

A simple method to check if a char is contained at least X times.

    string value = "abcderfa";
    bool containsAtLeastTwoAChar = value.ContainsAtLeast(2, 'a');

## Character separated-value (CSV)
Transform any kind of IEnumerable data in a CSV string.

    string value = _models.ToCsv();


## Minimization of a model (based on CSV concept)
It's a brand new idea to serialize any kind of objects (with lesser occupied space of json), the idea comes from Command separated-value standard.
To serialize

    string value = _models.ToMinimize();

To deserialize (for instance in a List of a class named CsvModel)

    value.FromMinimization<List<CsvModel>>();

## Extensions for json
I don't know if you are fed up to write JsonSerializer.Serialize, I do, and so, you may use the extension method to serialize faster.
To serialize

    var text = value.ToJson();

To deserialize in a class (for instance a class named User)

    var value = text.FromJson<User>();

## Extensions for Task
I don't know if you still are fed up to write .ConfigureAwait(false) to eliminate the context waiting for a task. I do.
[Why should I set the configure await to false?](https://devblogs.microsoft.com/dotnet/configureawait-faq/)
To set configure await to false

    await {your async task}.NoContext();

Instead, to get the result as synchronous result but with a configure await set to false.

    {your async task}.ToResult();

You may change the behavior of your NoContext() or ToResult(), setting (in the bootstrap of your application for example)

    RystemTask.WaitYourStartingThread = true;

When do I need a true? In windows application for example you have to return after a button clicked to the same thread that started the request.

## TaskManager
When you need to run a list of tasks concurrently you may use this static method.

In the next example with TaskManager.WhenAll you may run a method ExecuteAsync {times} times with {concurrentTasks} times in concurrency, and running them when a time slot is free.
For example if you run this function with 8 times and 3 concurrentsTasks and true in runEverytimeASlotIsFree
You will have this behavior: first 3 tasks starts and since the fourth the implementation waits the end of one of the 3 started before. As soon as one of the 3 started is finished the implementation starts to run the fourth.

    var bag = new ConcurrentBag<int>();
    await TaskManager.WhenAll(ExecuteAsync, times, concurrentTasks, runEverytimeASlotIsFree).NoContext();

    Assert.Equal(times, bag.Count);

    async Task ExecuteAsync(int i, CancellationToken cancellationToken)
    {
        await Task.Delay(i * 20, cancellationToken).NoContext();
        bag.Add(i);
    }

You may run a {atLeast} times of tasks and stopping to wait the remaining tasks with TaskManager.WhenAtLeast

    var bag = new ConcurrentBag<int>();
    await TaskManager.WhenAtLeast(ExecuteAsync, times, atLeast, concurrentTasks).NoContext();

    Assert.True(bag.Count < times);
    Assert.True(bag.Count >= atLeast);

    async Task ExecuteAsync(int i, CancellationToken cancellationToken)
    {
        await Task.Delay(i * 20, cancellationToken).NoContext();
        bag.Add(i);
    }

## Concurrency

### ConcurrentList
You can use the ConcurrentList implementation to have the List behavior with lock operations.

    var items = new ConcurrentList<ItemClass>();

---

## core/dependencyinjection

> - 📖 Complete Documentation: https://rystem.net(https://rystem.net)

### [What is Rystem?](https://github.com/KeyserDSoze/Rystem)

## 📚 Resources

- **📖 Complete Documentation**: [https://rystem.net](https://rystem.net)
- **🤖 MCP Server for AI**: [https://rystem.cloud/mcp](https://rystem.cloud/mcp)
- **💬 Discord Community**: [https://discord.gg/tkWvy4WPjt](https://discord.gg/tkWvy4WPjt)
- **☕ Support the Project**: [https://www.buymeacoffee.com/keyserdsoze](https://www.buymeacoffee.com/keyserdsoze)

## Get Started

## Dependency injection extensions

### Warm up
When you use the DI pattern in your .Net application you could need a warm up after the build of your services. And with Rystem you can simply do it.

	builder.Services.AddWarmUp(() => somethingToDo());

and after the build use the warm up

	var app = builder.Build();
	await app.Services.WarmUpAsync();


## Population service
You can use the population service to create a list of random value of a specific Type.
An example from unit test explains how to use the service.

    IServiceCollection services = new ServiceCollection();
    services.AddPopulationService();
    var serviceProvider = services.BuildServiceProvider().CreateScope().ServiceProvider;
    var populatedModel = serviceProvider.GetService<IPopulation<PopulationModelTest>>();
    IPopulation<PopulationModelTest> allPrepopulation = populatedModel!
        .Setup()
        .WithPattern(x => x.J!.First().A, "[a-z]{4,5}")
            .WithPattern(x => x.Y!.First().Value.A, "[a-z]{4,5}")
            .WithImplementation(x => x.I, typeof(MyInnerInterfaceImplementation))
            .WithPattern(x => x.I!.A!, "[a-z]{4,5}")
            .WithPattern(x => x.II!.A!, "[a-z]{4,5}")
            .WithImplementation<IInnerInterface, MyInnerInterfaceImplementation>(x => x.I!);
    var all = allPrepopulation.Populate();

## Abstract factory
You can use this abstract factory solution when you need to setup more than one service of the same kind
and you need to distinguish them by a name.

I have an interface 

    public interface IMyService
    {
        string GetName();
    }

Some options for every service

    public class SingletonOption
    {
        public string ServiceName { get; set; }
    }
    public class TransientOption
    {
        public string ServiceName { get; set; }
    }
    public class ScopedOption
    {
        public string ServiceName { get; set; }
    }

with built options which is a IServiceOptions, a options class that ends up with another class. Used for example when you have to add a settings like a connection string but you want to use a service like a client that uses that connection string. 

    public class BuiltScopedOptions : IServiceOptions<ScopedOption>
    {
        public string ServiceName { get; set; }

        public Task<Func<ScopedOption>> BuildAsync()
        {
            return Task.FromResult(() => new ScopedOption
            {
                ServiceName = ServiceName
            });
        }
    }

And six different services

    public class SingletonService : IMyService, IServiceWithOptions<SingletonOption>
    {
        public SingletonOption Options { get; set; }
        public string Id { get; } = Guid.NewGuid().ToString();
        public string GetName()
        {
            return $"{Options.ServiceName} with id {Id}";
        }
    }
    public class TransientService : IMyService, IServiceWithOptions<TransientOption>
    {
        public TransientOption Options { get; set; }
        public string Id { get; } = Guid.NewGuid().ToString();
        public string GetName()
        {
            return $"{Options.ServiceName} with id {Id}";
        }
    }
    public class ScopedService : IMyService, IServiceWithOptions<ScopedOption>
    {
        public ScopedOption Options { get; set; }
        public string Id { get; } = Guid.NewGuid().ToString();
        public string GetName()
        {
            return $"{Options.ServiceName} with id {Id}";
        }
    }
    public class ScopedService2 : IMyService, IServiceWithOptions<ScopedOption>
    {
        public ScopedOption Options { get; set; }
        public string Id { get; } = Guid.NewGuid().ToString();

        public string GetName()
        {
            return $"{Options.ServiceName} with id {Id}";
        }
    }
    public class ScopedService3 : IMyService, IServiceWithOptions<ScopedOption>
    {
        public ScopedOption Options { get; set; }
        public string Id { get; } = Guid.NewGuid().ToString();

        public string GetName()
        {
            return $"{Options.ServiceName} with id {Id}";
        }
    }
    public class ScopedService4 : IMyService, IServiceWithOptions<ScopedOption>
    {
        public ScopedOption Options { get; set; }
        public string Id { get; } = Guid.NewGuid().ToString();

        public string GetName()
        {
            return $"{Options.ServiceName} with id {Id}";
        }
    }

I can setup them in this way

    var services = new ServiceCollection();
    services.AddFactory<IMyService, SingletonService, SingletonOption>(x =>
    {
        x.ServiceName = "singleton";
    },
    "singleton",
    ServiceLifetime.Singleton);

    services.AddFactory<IMyService, TransientService, TransientOption>(x =>
    {
        x.ServiceName = "transient";
    },
    "transient",
    ServiceLifetime.Transient);

    services.AddFactory<IMyService, ScopedService, ScopedOption>(x =>
    {
        x.ServiceName = "scoped";
    },
    "scoped",
    ServiceLifetime.Scoped);

    services.AddFactory<IMyService, ScopedService2, ScopedOption>(x =>
    {
        x.ServiceName = "scoped2";
    },
    "scoped2",
    ServiceLifetime.Scoped);

    await services.AddFactoryAsync<IMyService, ScopedService3, BuiltScopedOptions, ScopedOption>(
        x =>
        {
            x.ServiceName = "scoped3";
        },
        "scoped3"
    );

    await services.AddFactoryAsync<IMyService, ScopedService3, BuiltScopedOptions, ScopedOption>(
        x =>
        {
            x.ServiceName = "scoped3_2";
        },
        "scoped3_2"
    );

    await services.AddFactoryAsync<IMyService, ScopedService4, BuiltScopedOptions, ScopedOption>(
        x =>
        {
            x.ServiceName = "scoped4";
        },
        "scoped4"
    );

and use them in this way

    var serviceProvider = services.BuildServiceProvider().CreateScope().ServiceProvider;
    var factory = serviceProvider.GetService<IFactory<IMyService>>()!;
    var factory2 = serviceProvider.GetService<IFactory<IMyService>>()!;

    var singletonFromFactory = factory.Create("singleton").Id;
    var singletonFromFactory2 = factory2.Create("singleton").Id;
    var transientFromFactory = factory.Create("transient").Id;
    var transientFromFactory2 = factory2.Create("transient").Id;
    var scopedFromFactory = factory.Create("scoped").Id;
    var scopedFromFactory2 = factory2.Create("scoped").Id;
    var scoped2FromFactory = factory.Create("scoped2").Id;
    var scoped2FromFactory2 = factory2.Create("scoped2").Id;
    var scoped3FromFactory = factory.Create("scoped3").Id;
    var scoped3FromFactory2 = factory2.Create("scoped3").Id;
    var scoped3_2FromFactory = factory.Create("scoped3_2").Id;
    var scoped3_2FromFactory2 = factory2.Create("scoped3_2").Id;
    var scoped4FromFactory = factory.Create("scoped4").Id;
    var scoped4FromFactory2 = factory2.Create("scoped4").Id;

    Assert.Equal(singletonFromFactory, singletonFromFactory2);
    Assert.NotEqual(transientFromFactory, transientFromFactory2);
    Assert.Equal(scopedFromFactory, scopedFromFactory2);
    Assert.Equal(scoped2FromFactory, scoped2FromFactory2);
    Assert.NotEqual(scoped3FromFactory, scoped3FromFactory2);
    Assert.NotEqual(scoped3_2FromFactory, scoped3_2FromFactory2);
    Assert.NotEqual(scoped4FromFactory, scoped4FromFactory2);

## Decorator
You may add a decoration for your services, based on the abstract factory integration.
The decorator service replaces the previous version and receives it during the injection.

Setup

    services
        .AddService<ITestWithoutFactoryService, TestWithoutFactoryService>(lifetime);
    services
        .AddDecoration<ITestWithoutFactoryService, TestWithoutFactoryServiceDecorator>(null, lifetime);

Usage

    var decorator = provider.GetRequiredService<ITestWithoutFactoryService>();
    var previousService = provider.GetRequiredService<IDecoratedService<ITestWithoutFactoryService>>();

In decorator you may find the previousService in the method SetDecoratedService which runs in injection

    public class TestWithoutFactoryServiceDecorator : ITestWithoutFactoryService, IDecoratorService<ITestWithoutFactoryService>
    {
        public string Id { get; } = Guid.NewGuid().ToString();
        public ITestWithoutFactoryService Test { get; private set; }
        public void SetDecoratedService(ITestWithoutFactoryService service)
        {
            Test = service;
        }

        public void SetFactoryName(string name)
        {
            return;
        }
    }

### Decorator with Abstract Factory integration
You may add a decoration only for one service of your factory integration.

Setup

    services.AddFactory<ITestService, TestService, TestOptions>(x =>
    {
        x.ClassicName = classicName;
    },
    factoryName,
    lifetime);
    services
        .AddDecoration<ITestService, DecoratorTestService>(factoryName, lifetime);

Usage

    var decoratorFactory = provider.GetRequiredService<IFactory<ITestService>>();
    var decorator = decoratorFactory.Create(factoryName);
    var previousService = decoratorFactory.CreateWithoutDecoration(factoryName);

## Factory Fallback
You may add a fallback for your factory integration. The fallback service is called when the factory service key is not found.

```csharp
services.AddFactoryFallback<TService, TFactoryFallback>();
```

where TFactoryFallback is class and an IFactoryFallback<TService>

You may add a fallback with an action fallback too.
    
```csharp
services.AddActionAsFallbackWithServiceProvider<TService>(Func<FallbackBuilderForServiceProvider, TService> fallbackBuilder);
```

## Scan dependency injection
You may scan your assemblies in search of types you need to add to dependency injection.
For instance I have an interface IAnything and I need to add all classes which implements it.

    public interface IAnything
    {
    }
    internal class ScanModels : IAnything
    {
    }

and in service collection I can add it.

    serviceCollection
        .Scan<IAnything>(ServiceLifetime.Scoped, typeof(IAnything).Assembly);

I can add to my class the interface IScannable of T to scan automatically. 
For instance.

    public interface IAnything
    {
    }
    internal class ScanModels : IAnything, IScannable<IAnything>
    {
    }

and in service collection I could add it in this way

    serviceCollection
        .Scan(ServiceLifetime.Scoped, typeof(IAnything).Assembly);

Furthermore with ISingletonScannable, IScopedScannable and ITransientScannable I can override the service lifetime.
For instance.

    public interface IAnything
    {
    }
    internal class ScanModels : IAnything, IScannable<IAnything>, ISingletonScannable
    {
    }

    serviceCollection
        .Scan(ServiceLifetime.Scoped, typeof(IAnything).Assembly);

ScanModels will be installed as a Singleton service, overwriting the service lifetime from Scan method.

You also automatically use different assembly sources.

    serviceCollection
        .ScanDependencyContext(ServiceLifetime.Scoped);

or

    serviceCollection
        .ScanCallingAssembly(ServiceLifetime.Scoped);

or

    serviceCollection
        .ScanCurrentDomain(ServiceLifetime.Scoped);

or

    serviceCollection
        .ScanEntryAssembly(ServiceLifetime.Scoped);

or

    serviceCollection
        .ScanExecutingAssembly(ServiceLifetime.Scoped);

or

    serviceCollection
        .ScanFromType<T>(ServiceLifetime.Scoped);

or

    serviceCollection
        .ScanFromTypes<T1, T2>(ServiceLifetime.Scoped);

Finally with ScanWithReferences you may call all the assemblies you want plus all referenced assemblies by them.

---

## core/dependencyinjection-web

> builder.Services.AddRuntimeServiceProvider();

### [What is Rystem?](https://github.com/KeyserDSoze/Rystem)

## Get Started with Runtime Dependency Injection

## Adding runtime provider

	 builder.Services.AddRuntimeServiceProvider();

and after the build use the runtime provider

	var app = builder.Build();
	app.UseRuntimeServiceProvider();


## Add service at runtime

```csharp
await RuntimeServiceProvider.GetServiceCollection()
       .AddSingleton<Service2>()
       .RebuildAsync();
```

## Add service at runtime with lock

```csharp
 await RuntimeServiceProvider
    .AddServicesToServiceCollectionWithLock(configureFurtherServices =>
    {
        configureFurtherServices.AddSingleton(service);
    })
.RebuildAsync();
```

## Add fallback for Factory and automatic rebuild of service collection
In this example Factorized is a simple class with a few parameters.

```csharp
services.AddFactory<Factorized>("1");
services.AddActionAsFallbackWithServiceCollectionRebuilding<Factorized>(async x =>
{
    //example of retrievieng something
    await Task.Delay(1); 
    //example of ServiceProvider usage during new service addition
    var singletonService = x.ServiceProvider.GetService<SingletonService>();
    if (singletonService != null)
    {
        //example of adding a new service as factory to the service collection. You need to pass a delegate.
        x.ServiceColletionBuilder = (serviceCollection => serviceCollection.AddFactory<Factorized>(x.Name));
    }
});
```
