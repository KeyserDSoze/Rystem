---
name: Rystem - Get Rystem Docs / Core
description: Rystem Framework docs: core/rystem, core/dependencyinjection, core/dependencyinjection-web. Use for core questions in Rystem.
---

# Rystem - Get Rystem Docs / Core

> Auto-generated from Rystem MCP manifest (tool: `get-rystem-docs`, category: `core`)

---

## core/rystem

> Rystem is the core utilities package of the Rystem ecosystem.

### [What is Rystem?](https://github.com/KeyserDSoze/Rystem)

## Rystem

`Rystem` is the core utilities package of the Rystem ecosystem.

It extends familiar BCL namespaces such as `System`, `System.Linq`, `System.Linq.Expressions`, `System.Reflection`, `System.Text`, and `System.Threading.Tasks` with pragmatic helpers for:

- discriminated unions in C#
- expression serialization and dynamic LINQ/queryable composition
- reflection, mocking, runtime model generation, and IL inspection
- JSON, CSV, minimization, hashing, and encoding helpers
- task orchestration and small concurrent collections

Most examples below are adapted from the repository test suite so the README stays aligned with real usage.
For brevity, short snippets sometimes use obvious sample types such as `User`, `Order`, `MyType`, or `MyDto`.

## Resources

- Complete Documentation: [https://rystem.net](https://rystem.net)
- MCP Server for AI: [https://rystem.cloud/mcp](https://rystem.cloud/mcp)
- Discord Community: [https://discord.gg/tkWvy4WPjt](https://discord.gg/tkWvy4WPjt)
- Support the Project: [https://www.buymeacoffee.com/keyserdsoze](https://www.buymeacoffee.com/keyserdsoze)

## Installation

```bash
dotnet add package Rystem
```

The current `10.x` package targets `net11.0`.

After installation, most APIs are available through standard `using` directives that match the namespace they extend. The main exception is `ReflectionHelper`, which lives in `Rystem.Reflection`.

If you move deeper into the ecosystem, [`Rystem.DependencyInjection`](https://github.com/KeyserDSoze/Rystem/blob/master/src/Core/Rystem.DependencyInjection/README.md) builds DI modules on top of this package, and [`Rystem.DependencyInjection.Web`](https://github.com/KeyserDSoze/Rystem/blob/master/src/Core/Rystem.DependencyInjection.Web/README.md) adds ASP.NET Core runtime rebuilding on top of the DI layer.

## Table of Contents

- [Package Architecture](#package-architecture)
- [Discriminated Unions in C#](#discriminated-unions-in-c)
  - [Define a union](#define-a-union)
  - [Match, Switch, and TryGet](#match-switch-and-tryget)
  - [JSON serialization and deserialization](#json-serialization-and-deserialization)
  - [Resolving ambiguous JSON with selectors](#resolving-ambiguous-json-with-selectors)
  - [Class-level selectors, regex selectors, and default types](#class-level-selectors-regex-selectors-and-default-types)
- [Core Utilities](#core-utilities)
- [Stopwatch](#stopwatch)
- [Try / Retry](#try--retry)
- [Cast extensions](#cast-extensions)
- [Copy extensions](#copy-extensions)
- [Enum extensions](#enum-extensions)
- [Text extensions](#text-extensions)
- [Encoding: Base64 and Base45](#encoding-base64-and-base45)
  - [Base64](#base64)
  - [Base45](#base45)
- [Cryptography (Hashing)](#cryptography-hashing)
- [JSON extensions](#json-extensions)
- [CSV and Minimization](#csv-and-minimization)
- [CSV](#csv)
- [Minimization](#minimization)
- [LINQ and Expression Utilities](#linq-and-expression-utilities)
- [Serialize and deserialize lambda expressions](#serialize-and-deserialize-lambda-expressions)
- [Dynamic lambda utilities](#dynamic-lambda-utilities)
- [Dynamic IQueryable helpers](#dynamic-iqueryable-helpers)
- [RemoveWhere](#removewhere)
- [AllAsync and AnyAsync](#allasync-and-anyasync)
- [Non-generic IEnumerable helpers](#non-generic-ienumerable-helpers)
- [Reflection and Runtime Tools](#reflection-and-runtime-tools)
- [Name of the calling class](#name-of-the-calling-class)
- [Cached reflection helpers](#cached-reflection-helpers)
- [Type relationship helpers](#type-relationship-helpers)
- [Create default instances](#create-default-instances)
- [Mock abstract classes and interfaces](#mock-abstract-classes-and-interfaces)
- [Construct with the best dynamic fit](#construct-with-the-best-dynamic-fit)
- [Nullability inspection](#nullability-inspection)
- [Property showcase](#property-showcase)
- [IL inspection and method signatures](#il-inspection-and-method-signatures)
- [Runtime model builder](#runtime-model-builder)
- [Generic method invocation](#generic-method-invocation)
- [Tasks and Collections](#tasks-and-collections)
- [NoContext and ToResult](#nocontext-and-toresult)
- [ToListAsync](#tolistasync)
- [TaskManager](#taskmanager)
  - [WhenAll](#whenall)
  - [WhenAtLeast](#whenatleast)
- [ConcurrentList](#concurrentlist)
- [Utilities](#utilities)
- [AsyncEnumerable.Empty](#asyncenumerableempty)
- [Programming language conversion](#programming-language-conversion)
- [Repository Examples](#repository-examples)

---

## Package Architecture

| Area                   | Main APIs                                                                                                                                                       |
| ---------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Discriminated unions   | `AnyOf<T0, ...>`, `Match`, `MatchAsync`, `Switch`, `SwitchAsync`, `TryGetTn`, JSON selectors and defaults                                                       |
| Core helpers           | `Stopwatch`, `Try`, `Cast<T>`, `ToDeepCopy`, `CopyPropertiesFrom`, enum and string helpers                                                                      |
| Text and data          | `ToByteArray`, `ToStream`, `ReadLinesAsync`, `ToJson`, `ToHash`, `ToBase64`, `ToBase45`, `ToCsv`, `ToMinimize`                                                  |
| LINQ and expressions   | `Serialize`, `Deserialize`, `DeserializeAsDynamic`, `ChangeReturnType`, `InvokeAsync`, `Where(LambdaExpression)`, `Select(LambdaExpression)`, `CallMethodAsync` |
| Reflection and runtime | `FetchProperties`, `CreateWithDefault`, `CreateInstance`, `ConstructWithBestDynamicFit`, `ToShowcase`, `GetBodyAsString`, `Model.Create(...)`                   |
| Tasks and collections  | `NoContext`, `ToResult`, `ToListAsync`, `TaskManager`, `ConcurrentList<T>`, `AsyncEnumerable<T>.Empty`                                                          |
| Conversion             | `ConvertAs(ProgrammingLanguageType.Typescript)`                                                                                                                 |

If you want a single package with a broad set of low-level .NET utilities, this is the entry point of the Rystem ecosystem.

---

## Discriminated Unions in C#

`AnyOf<T0, T1, ...>` brings discriminated unions to C# with built-in `System.Text.Json` integration.

The package ships `AnyOf` variants from 2 to 10 generic arguments.

### Define a union

```csharp
AnyOf<int, string, bool> value = "hello";

Console.WriteLine(value.Index); // 1
Console.WriteLine(value.IsT1);  // true
Console.WriteLine(value.AsT1);  // hello

value = 42;
int number = value.CastT0;
```

Useful members include:

- `Index`
- `IsT0`, `IsT1`, ...
- `AsT0`, `AsT1`, ...
- `CastT0`, `CastT1`, ...
- `Is<T>()`
- `TryGetT0(out value)`, `TryGetT1(out value)`, ...

### Match, Switch, and TryGet

```csharp
AnyOf<int, string, bool> value = "hello";

string description = value.Match(
    number => $"int: {number}",
    text => $"string: {text}",
    flag => $"bool: {flag}")!;

value.Switch(
    number => Console.WriteLine(number),
    text => Console.WriteLine(text),
    flag => Console.WriteLine(flag));

string? asyncDescription = await value.MatchAsync(
    async number => await Task.FromResult($"int: {number}"),
    async text => await Task.FromResult($"string: {text}"),
    async flag => await Task.FromResult($"bool: {flag}"));

await value.SwitchAsync(
    number => { Console.WriteLine(number); return ValueTask.CompletedTask; },
    text => { Console.WriteLine(text); return ValueTask.CompletedTask; },
    flag => { Console.WriteLine(flag); return ValueTask.CompletedTask; });

if (value.TryGetT1(out var textValue))
    Console.WriteLine(textValue);
```

Notes:

- `MatchAsync` delegates return `Task<TResult?>`
- `SwitchAsync` delegates return `ValueTask`
- `TryGetTn` is the safest way to branch without exceptions

### JSON serialization and deserialization

The active value is serialized directly, and deserialization automatically chooses the correct target type.

```csharp
public sealed class Wrapper
{
    public AnyOf<FirstClass, string>? Data { get; set; }
}

public sealed class FirstClass
{
    public string? FirstProperty { get; set; }
    public string? SecondProperty { get; set; }
}

var wrapper = new Wrapper
{
    Data = new FirstClass
    {
        FirstProperty = "alpha",
        SecondProperty = "beta"
    }
};

string json = wrapper.ToJson();
Wrapper copy = json.FromJson<Wrapper>();

Console.WriteLine(copy.Data!.AsT0!.FirstProperty); // alpha
```

By default, union deserialization uses the JSON payload signature, meaning the set of available property names is used to find the best candidate.

```csharp
public sealed class SignatureTestClass
{
    public AnyOf<SignatureClassOne, SignatureClassTwo>? Test { get; set; }
}

public sealed class SignatureClassOne
{
    public string? FirstProperty { get; set; }
    public string? SecondProperty { get; set; }
}

public sealed class SignatureClassTwo
{
    public string? FirstProperty { get; set; }
    public string? SecondProperty { get; set; }
}

var payload = new SignatureTestClass
{
    Test = new SignatureClassTwo
    {
        FirstProperty = "FirstProperty",
        SecondProperty = "SecondProperty"
    }
};

var copy = payload.ToJson().FromJson<SignatureTestClass>();

// Both candidate types have the same signature,
// so the first matching type wins.
Console.WriteLine(copy.Test!.Is<SignatureClassOne>()); // true
```

If no candidate can be matched, the union property is deserialized as `null`.

### Resolving ambiguous JSON with selectors

When multiple candidate types share the same shape, add selectors to tell the deserializer how to choose.

`AnyOfJsonSelector` works with both strings and non-string values.

```csharp
public sealed class ChosenClass
{
    public AnyOf<TheFirstChoice, TheSecondChoice>? Value { get; set; }
}

public sealed class TheFirstChoice
{
    [AnyOfJsonSelector("first")]
    public string Type { get; init; } = null!;

    [AnyOfJsonSelector(2, 3, 4)]
    public int Flexy { get; set; }
}

public sealed class TheSecondChoice
{
    [AnyOfJsonSelector("first", "second")]
    public string Type { get; init; } = null!;

    [AnyOfJsonSelector(1)]
    public int Flexy { get; set; }
}

var payload = new ChosenClass
{
    Value = new TheSecondChoice
    {
        Type = "first",
        Flexy = 1
    }
};

var copy = payload.ToJson().FromJson<ChosenClass>();
Console.WriteLine(copy.Value!.Is<TheSecondChoice>()); // true

payload = new ChosenClass
{
    Value = new TheSecondChoice
    {
        Type = "first",
        Flexy = 2
    }
};

copy = payload.ToJson().FromJson<ChosenClass>();
Console.WriteLine(copy.Value!.Is<TheFirstChoice>()); // true
```

In the second case, the raw object was originally `TheSecondChoice`, but the selector values identify `TheFirstChoice` as the correct deserialization target.

### Class-level selectors, regex selectors, and default types

You can apply selectors to a whole class instead of a single property.

```csharp
[AnyOfJsonClassSelector(nameof(FirstProperty), "first.F")]
public sealed class FirstGetClass
{
    public string? FirstProperty { get; set; }
    public string? SecondProperty { get; set; }
}

[AnyOfJsonRegexClassSelector(nameof(FirstProperty), "secon[^.]*.[^.]*")]
public sealed class SecondGetClass
{
    public string? FirstProperty { get; set; }
    public string? SecondProperty { get; set; }
}

public sealed class FourthGetClass
{
    [AnyOfJsonSelector("fourth.F")]
    public string? FirstProperty { get; set; }
    public string? SecondProperty { get; set; }
}

public sealed class FifthGetClass
{
    [AnyOfJsonRegexSelector("fift[^.]*.")]
    public string? FirstProperty { get; set; }
    public string? SecondProperty { get; set; }
}

[AnyOfJsonDefault]
public sealed class SixthGetClass
{
    public string? FirstProperty { get; set; }
    public string? SecondProperty { get; set; }
}
```

This lets you combine:

- exact value selectors
- regex selectors
- class-level selectors
- a default fallback type when no other selector matches

---

## Core Utilities

## Stopwatch

Measure actions, tasks, or task-returning functions.

```csharp
var started = Stopwatch.Start();
await Task.Delay(2000);
var result = started.Stop();

Console.WriteLine(result.Span.TotalMilliseconds);
```

```csharp
var result = await Stopwatch.MonitorAsync(async () =>
{
    await Task.Delay(2000);
});

Console.WriteLine(result.Span.TotalMilliseconds);
```

```csharp
var result = await Stopwatch.MonitorAsync(async () =>
{
    await Task.Delay(2000);
    return 3;
});

Console.WriteLine(result.Result);            // 3
Console.WriteLine(result.Stopwatch.Span);    // elapsed time
```

There is also a synchronous overload:

```csharp
var result = Stopwatch.Monitor(() => DoWork());
```

## Try / Retry

`Try` wraps synchronous, `Task`, and `ValueTask` execution and returns the value plus any exception.

```csharp
var success = Try.WithDefaultOnCatch(() => 42);
int value = success;

Console.WriteLine(value);                    // 42
Console.WriteLine(success.Exception == null); // true
```

```csharp
var failed = Try.WithDefaultOnCatch(() => int.Parse("abc"));

Console.WriteLine((int)failed);              // 0
Console.WriteLine(failed.Exception != null); // true
```

```csharp
var asyncFailed = await Try.WithDefaultOnCatchAsync(async () =>
{
    await Task.Delay(10);
    return int.Parse("abc");
});

Console.WriteLine(asyncFailed.Exception != null); // true
```

```csharp
var valueTaskResult = await Try.WithDefaultOnCatchValueTaskAsync(async () =>
{
    await Task.Delay(10);
    return 12;
});
```

You can also configure retry behavior.

```csharp
var response = await Try.WithDefaultOnCatchAsync(
    async () => await FlakyServiceAsync(),
    behavior =>
    {
        behavior.MaxRetry = 3;
        behavior.WaitBetweenRetry = 200;
        behavior.RetryUntil = exception => exception is HttpRequestException;
    });
```

Prefer checking `response.Exception` to detect failures. That is the most explicit and reliable success signal.

## Cast extensions

Use `Cast<T>()` for safe conversions across numeric values, strings, runtime types, and inheritance hierarchies.

```csharp
int x = 2;
decimal result = x.Cast<decimal>();

int? nullable = null;
decimal result2 = nullable.Cast<decimal>();   // 0
decimal? result3 = nullable.Cast<decimal?>(); // null

string guid = Guid.NewGuid().ToString();
Guid parsed = guid.Cast<Guid>();
```

```csharp
object entity = new User();
Type targetType = typeof(UserDto);
object converted = entity.Cast(targetType)!;
```

## Copy extensions

Use `ToDeepCopy()` to create a detached clone, or `CopyPropertiesFrom(...)` to copy property values onto an existing instance.

```csharp
var original = new User { Id = 3 };
var copy = original.ToDeepCopy();

Console.WriteLine(ReferenceEquals(original, copy)); // false
Console.WriteLine(copy.Id);                         // 3
```

```csharp
var source = new User { Id = 10 };
var target = new User();

target.CopyPropertiesFrom(source);
Console.WriteLine(target.Id); // 10
```

## Enum extensions

Convert strings or other enum values into a target enum and read `[Display]` names.

```csharp
enum Color
{
    Red,
    Green,
    Blue
}

Color c1 = "green".ToEnum<Color>();
Color c2 = ConsoleColor.Green.ToEnum<Color>();
```

```csharp
public enum Status
{
    [Display(Name = "In Progress")]
    Working
}

string label = Status.Working.GetDisplayName(); // In Progress
```

## Text extensions

Convert between strings, byte arrays, and streams with minimal ceremony.

```csharp
string text = "daskemnlandxioasndslam dasmdpoasmdnasndaslkdmlasmv asmdsa";

byte[] bytes = text.ToByteArray();
string restored = bytes.ConvertToString();
```

```csharp
string text = "daskemnlandxioasndslam dasmdpoasmdnasndaslkdmlasmv asmdsa";

Stream stream = text.ToStream();
string restored = stream.ConvertToString();
```

`ReadLinesAsync()` turns a stream into `IAsyncEnumerable<string>`.

```csharp
string text = "line 1\nline 2\nline 3";
Stream stream = text.ToStream();

await foreach (var line in stream.ReadLinesAsync())
{
    Console.WriteLine(line);
}
```

Other small helpers:

```csharp
string title = "dasda".ToUpperCaseFirst();          // Dasda
bool hasTwoAs = "abcderfa".ContainsAtLeast(2, 'a');
string replaced = "aaa".Replace("a", "b", 2);    // bba
```

## Encoding: Base64 and Base45

### Base64

```csharp
string encoded = "Hello World".ToBase64();
string decoded = encoded.FromBase64();

var payload = new User { Id = 7, Name = "Ada" };
string encodedObject = payload.ToBase64();
User decodedObject = encodedObject.FromBase64<User>();
```

### Base45

Base45 is handy when you want a compact, QR-code-friendly character set.

```csharp
string encoded = "Hello World".ToBase45();
string decoded = encoded.FromBase45();

var payload = new User { Id = 7, Name = "Ada" };
string encodedObject = payload.ToBase45();
User decodedObject = encodedObject.FromBase45<User>();
```

Both object overloads serialize through JSON first.

## Cryptography (Hashing)

`ToHash()` creates a deterministic SHA-512 hexadecimal hash from a string or any serializable object.

```csharp
string hash = "my secret".ToHash();

var foo = new Foo
{
    Values = new[] { "aa", "bb", "cc" },
    X = true
};

string hash2 = foo.ToHash();
Console.WriteLine(foo.ToHash() == hash2); // true
```

```csharp
Guid id = Guid.Parse("41e2c840-8ba1-4c0b-8a9b-781747a5de0c");
string hash = id.ToHash();
```

## JSON extensions

The JSON helpers are intentionally tiny wrappers over `System.Text.Json`.

```csharp
var users = new List<User>
{
    new User { Id = 1, Name = "Ada" },
    new User { Id = 2, Name = "Grace" }
};

string json = users.ToJson();
List<User> copy = json.FromJson<List<User>>();
```

```csharp
object? dynamicCopy = json.FromJson(typeof(List<User>));
```

```csharp
await using var stream = json.ToStream();
List<User> fromStream = await stream.FromJsonAsync<List<User>>();
```

---

## CSV and Minimization

## CSV

`ToCsv()` flattens objects, nested objects, and enumerable members into a tabular representation.

```csharp
string csv = models.ToCsv();
```

You can configure headers, delimiters, Excel-friendly quoting, and excluded properties.

```csharp
string csv = users.ToCsv(configuration =>
{
    configuration.ForExcel = true;
    configuration.UseExtendedName = false;
    configuration.ConfigureHeader(x => x.Id, "Identifier");
    configuration.ConfigureHeader(x => x.Groups.First().Name, "GroupName");
    configuration.AvoidProperty(x => x.Password);
    configuration.Delimiter = ";";
});
```

Configuration options include:

- `UseHeader`
- `Delimiter`
- `ForExcel`
- `UseExtendedName`
- `ConfigureHeader(...)`
- `AvoidProperty(...)`

## Minimization

`ToMinimize()` is a compact serializer designed to occupy less space than JSON for many object graphs.

```csharp
string minimized = models.ToMinimize();
List<CsvModel> restored = minimized.FromMinimization<List<CsvModel>>();
```

You can also choose the starting separator explicitly.

```csharp
string minimized = models.ToMinimize('&');
List<CsvModel> restored = minimized.FromMinimization<List<CsvModel>>('&');
```

Use `MinimizationPropertyAttribute` when you want deterministic property ordering.

```csharp
public sealed class CompactUser
{
    [MinimizationProperty(0)]
    public int Id { get; set; }

    [MinimizationProperty(1)]
    public string? Name { get; set; }
}
```

---

## LINQ and Expression Utilities

## Serialize and deserialize lambda expressions

Rystem can serialize expression trees to strings and build them back into executable expressions.

```csharp
var q = "dasda";
var id = Guid.Parse("bf46510b-b7e6-4ba2-88da-cef208aa81f2");

Expression<Func<MakeIt, bool>> expression =
    x => x.X == q &&
         x.Samules!.Any(y => y == "ccccde") &&
         x.Sol &&
         (x.X.Contains(q) || x.Sol.Equals(true)) &&
         (x.E == id | x.Id == 32);

string serialized = expression.Serialize();
Func<MakeIt, bool> compiled = serialized.DeserializeAndCompile<MakeIt, bool>();

List<MakeIt> filtered = makes.Where(compiled).ToList();
```

The test suite covers scenarios such as:

- `Contains(...)`
- `Any(...)`
- enum comparisons
- `DateTime` comparisons
- `TimeSpan` comparisons
- unary `!`
- nested member access

## Dynamic lambda utilities

You can deserialize to `LambdaExpression`, inspect the inferred result type, convert the return type, and cast back to typed expressions.

```csharp
Expression<Func<User, int>> selector = x => x.Id;
string text = selector.Serialize();

LambdaExpression dynamicSelector = text.DeserializeAsDynamic<User>();
Expression<Func<User, int>> asInt = dynamicSelector.AsExpression<User, int>();
Expression<Func<User, decimal>> asDecimal = dynamicSelector.AsExpression<User, decimal>();

decimal average = new List<User> { new User { Id = 13 } }.Average(asDecimal.Compile());
```

```csharp
var inferred = "x => x.Id == 25".DeserializeAsDynamicAndRetrieveType<User>();

Console.WriteLine(inferred.Type); // System.Boolean
```

```csharp
Expression<Func<User, ValueTask<int>>> expression = x => GetUserIdAsync(x);
LambdaExpression lambda = expression;

decimal id = await lambda.InvokeAsync<decimal>(new User { Id = 13 });
```

`InvokeAndTransform(...)` is also available when you want a converted return type from a compiled expression.

```csharp
Expression<Func<User, int>> expression = x => x.Id;
decimal result = expression.InvokeAndTransform<User, int, decimal>(new User { Id = 13 })!;
```

You can also extract a property directly from an expression.

```csharp
PropertyInfo? property = ((Expression<Func<User, int>>)(x => x.Id)).GetPropertyFromExpression();
```

## Dynamic IQueryable helpers

The package exposes dynamic `IQueryable` operators that accept `LambdaExpression` instead of strongly typed selectors.

Supported helpers include:

- `Average`
- `Count`
- `DistinctBy`
- `GroupBy`
- `LongCount`
- `Max`
- `Min`
- `OrderBy`
- `OrderByDescending`
- `Select`
- `Sum`
- `ThenBy`
- `ThenByDescending`
- `Where`

```csharp
Expression<Func<MakeIt, int>> orderExpression = x => x.Id;
Expression<Func<MakeIt, bool>> predicateExpression = x => x.Id >= 10;

LambdaExpression orderBy = orderExpression.Serialize().DeserializeAsDynamic<MakeIt>();
LambdaExpression predicate = predicateExpression.Serialize().DeserializeAsDynamic<MakeIt>();

var query = makes.AsQueryable();

var ordered = query.OrderByDescending(orderBy).ThenBy(orderBy).ToList();
var filtered = query.Where(predicate).ToList();
var grouped = query.GroupBy(orderBy).ToList();
var projected = query.Select<MakeIt, decimal>(orderBy).ToList();

var average = query.Average(orderBy);
var sum = query.Sum(orderBy);
var count = query.Count(predicate);
```

`CallMethodAsync(...)` lets you invoke custom async query operators dynamically.

```csharp
public static class QueryableExtensions
{
    public static async Task<IQueryable<T>> GetAsync<T>(
        this IQueryable<T> queryable,
        Expression<Func<T, bool>> expression,
        CancellationToken cancellationToken = default)
    {
        await Task.Delay(0);
        return queryable.Where(expression);
    }
}

var result = await query.CallMethodAsync<MakeIt, IQueryable<MakeIt>>(
    "GetAsync",
    predicate,
    typeof(QueryableExtensions));
```

This is especially useful when you need to bridge runtime-generated selectors with LINQ providers such as Entity Framework.

## RemoveWhere

`RemoveWhere(...)` works on arrays, `ICollection<T>`, and plain `IEnumerable<T>`.

```csharp
int[] numbers = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
numbers = numbers.RemoveWhere(x => x == 8 || x == 9);
```

```csharp
var filtered = myEnumerable.RemoveWhere(x => x.IsExpired);
```

```csharp
List<Order> orders = GetOrders();
int removed = orders.RemoveWhere(x => x.Status == OrderStatus.Cancelled);
```

## AllAsync and AnyAsync

Use async predicates over a synchronous `IEnumerable<T>`.

```csharp
bool allValid = await items.AllAsync(x => ValueTask.FromResult(x.Id >= 0));
bool anyZero = await items.AnyAsync(x => Task.FromResult(x.Id == 0));
```

Both `Task<bool>` and `ValueTask<bool>` predicates are supported.

## Non-generic IEnumerable helpers

The non-generic helpers are useful when you receive `IEnumerable` at runtime and still need indexed operations.

```csharp
IEnumerable items = GetItems();

object? value = items.ElementAt(10);
items.SetElementAt(10, newValue);

bool removed = items.RemoveElementAt(10, out IEnumerable newItems, out object? removedValue);
```

They work with both `Array` and `IList` implementations.

---

## Reflection and Runtime Tools

## Name of the calling class

`ReflectionHelper` lives in `Rystem.Reflection`.

```csharp
using Rystem.Reflection;

string name = ReflectionHelper.NameOfCallingClass(deep: 1);
string fullName = ReflectionHelper.NameOfCallingClass(deep: 1, full: true);
```

Increase `deep` when you want to walk further up the call stack.

## Cached reflection helpers

The package caches repeated reflection lookups for better reuse.

```csharp
PropertyInfo[] properties = typeof(MyType).FetchProperties();
ConstructorInfo[] constructors = typeof(MyType).FecthConstructors();
FieldInfo[] fields = typeof(MyType).FetchFields();
MethodInfo[] methods = typeof(MyType).FetchMethods();
MethodInfo[] staticMethods = typeof(MyType).FetchStaticMethods();
```

`FetchProperties(...)` can ignore properties decorated with specific attributes.

```csharp
PropertyInfo[] visibleProperties = typeof(MyType).FetchProperties(typeof(JsonIgnoreAttribute));
```

## Type relationship helpers

```csharp
bool sameOrSon = typeof(Folli).IsTheSameTypeOrASon(typeof(Sulo));
bool sameOrParent = typeof(Sulo).IsTheSameTypeOrAParent(typeof(Folli));
bool hasInterface = typeof(MyService).HasInterface<IDisposable>();
```

Instance overloads are available too.

```csharp
Zalo zalo = new();
Sulo sulo = new();

Console.WriteLine(zalo.IsTheSameTypeOrASon(sulo));
Console.WriteLine(sulo.IsTheSameTypeOrAParent(zalo));
```

## Create default instances

`CreateWithDefault()` builds an instance by recursively creating default constructor arguments and common collection implementations.

```csharp
public sealed class Foo
{
    public IEnumerable<string> Values { get; }
    public Foo(IEnumerable<string> values) => Values = values;
}

Foo foo = typeof(Foo).CreateWithDefault<Foo>()!;
(foo.Values as List<string>)!.Add("aaa");
```

`CreateWithDefaultConstructorPropertiesAndField()` goes further and populates settable properties and fields as well.

```csharp
Foo2 foo = typeof(Foo2).CreateWithDefaultConstructorPropertiesAndField<Foo2>()!;

foo.Complex.Add("x", "y");
(foo.Tiny.Values as List<string>)!.Add("aaa");
```

## Mock abstract classes and interfaces

Rystem can generate runtime implementations for abstract classes and interfaces.

```csharp
public abstract class Alzio
{
    private protected string X { get; }
    public string O => X;
    public string A { get; set; }

    protected Alzio(string x) => X = x;
}

var mocked = typeof(Alzio).CreateInstance("AAA") as Alzio;
mocked!.A = "rrrr";

Console.WriteLine(mocked.O); // AAA
Console.WriteLine(mocked.A); // rrrr
```

You can also configure the generated type.

```csharp
Alzio alzio = null!;

var configured = alzio.CreateInstance(configuration =>
{
    configuration.IsSealed = false;
    configuration.CreateNewOneIfExists = true;
}, "AAA");
```

## Construct with the best dynamic fit

`ConstructWithBestDynamicFit(...)` matches runtime arguments first against constructor parameters and then against settable properties.

```csharp
var entity = (MySuperClass)typeof(MySuperClass).ConstructWithBestDynamicFit(3, 4, 5, 6)!;
var entity2 = Constructor.InvokeWithBestDynamicFit<MySuperClass>(5, 6, 7, 8);
var interfaceInstance = Constructor.InvokeWithBestDynamicFit<IMogalo>(9, 10, 11, 21);
```

This is useful when the values are only known at runtime and you still want a best-effort, exact-type match.

## Nullability inspection

`IsNullable()` works on properties, fields, and parameters.

```csharp
var type = typeof(InModel);

var constructorParameters = type.GetConstructors().First().GetParameters();
var methodParameters = type.GetMethod(nameof(InModel.SetSomething))!.GetParameters();
var properties = type.GetProperties();
var fields = type.GetFields();

Console.WriteLine(constructorParameters[0].IsNullable());
Console.WriteLine(methodParameters[0].IsNullable());
Console.WriteLine(properties[0].IsNullable());
Console.WriteLine(fields[0].IsNullable());
```

## Property showcase

`ToShowcase()` builds a structured description of a type and can attach extra computed metadata to each flattened property.

```csharp
var showcase = typeof(Something).ToShowcase(
    IFurtherParameter.Create("Bootstrap", x => new BootstrapProperty(x)),
    IFurtherParameter.Create("Title", x => x.NavigationPath));

var first = showcase.FlatProperties.First();
string title = first.GetProperty<string>("Title");
BootstrapProperty bootstrap = first.GetProperty<BootstrapProperty>("Bootstrap");
```

This is handy for metadata-driven UI generation, forms, and schema exploration.

## IL inspection and method signatures

Inspect the body of a method as text or as decoded IL instructions.

```csharp
MethodInfo method = typeof(Sulo).GetMethod(nameof(Sulo.Something), BindingFlags.Public | BindingFlags.Instance)!;

string body = method.GetBodyAsString();
List<ILInstruction> instructions = method.GetInstructions();
string signature = method.ToSignature();
```

This is useful for diagnostics, analysis tools, or advanced runtime inspection.

## Runtime model builder

Create types dynamically at runtime.

```csharp
var modelName = "MyBestModel";

Type modelType = Model
    .Create(modelName)
    .AddProperty("Primary", typeof(int))
    .AddProperty("Secondary", typeof(bool))
    .AddProperty("Name", typeof(string))
    .AddProperty("Id", typeof(Guid))
    .AddProperty("InModel", typeof(InModel))
    .AddParent<SomethingNew>()
    .Build();

dynamic instance = Model.Construct(modelName);
instance.Primary = 45;
instance.B = "Aloa";
```

This gives you a runtime-generated type plus a strongly discoverable builder API.

## Generic method invocation

`Generics.With(...)` and `Generics.WithStatic(...)` let you bind generic methods by runtime type and invoke them later.

```csharp
var staticResult = await Generics
    .WithStatic<SystemReflection>(nameof(StaticCreateAsync), typeof(int))
    .InvokeAsync(3);

var host = new SystemReflection();

var instanceResult = await Generics
    .With<SystemReflection>(nameof(CreateAsync), typeof(int))
    .InvokeAsync(host, 3);
```

```csharp
int value = Generics
    .WithStatic<SystemReflection>(nameof(StaticCreate), typeof(int))
    .Invoke<int>(3)!;
```

---

## Tasks and Collections

## NoContext and ToResult

`NoContext()` is a small convenience wrapper around `ConfigureAwait(...)`, controlled by `RystemTask.WaitYourStartingThread`.

```csharp
await DoSomethingAsync().NoContext();
int result = GetValueAsync().ToResult();
```

If you need to preserve the original synchronization context, set:

```csharp
RystemTask.WaitYourStartingThread = true;
```

## ToListAsync

The package adds a small `IAsyncEnumerable<T>` helper.

```csharp
await using var stream = "line 1\nline 2\nline 3".ToStream();
List<string> lines = await stream.ReadLinesAsync().ToListAsync();
```

## TaskManager

`TaskManager` helps you run a bounded number of tasks concurrently.

### WhenAll

```csharp
var bag = new ConcurrentBag<int>();

await TaskManager.WhenAll(ExecuteAsync, times: 45, concurrentTasks: 12, runEverytimeASlotIsFree: true).NoContext();

async Task ExecuteAsync(int i, CancellationToken cancellationToken)
{
    await Task.Delay(i * 20, cancellationToken).NoContext();
    bag.Add(i);
}
```

It also works with collections of objects.

```csharp
await TaskManager.WhenAll(ProcessAsync, orders, concurrentTasks: 5).NoContext();

async Task ProcessAsync(Order order, CancellationToken cancellationToken)
{
    await SaveAsync(order, cancellationToken).NoContext();
}
```

### WhenAtLeast

`WhenAtLeast(...)` stops waiting as soon as the requested number of tasks has completed.

```csharp
var bag = new ConcurrentBag<int>();

await TaskManager.WhenAtLeast(ExecuteAsync, times: 45, atLeast: 16, concurrentTasks: 12).NoContext();

async Task ExecuteAsync(int i, CancellationToken cancellationToken)
{
    await Task.Delay(i * 20, cancellationToken).NoContext();
    bag.Add(i);
}
```

## ConcurrentList

`ConcurrentList<T>` is a small thread-safe wrapper around `List<T>` for common list operations.

```csharp
var items = new ConcurrentList<MyClass>();

items.Add(new MyClass());
items.Insert(0, new MyClass());
items.RemoveAt(0);

Console.WriteLine(items.Count);
```

Use it when you want a simple `IList<T>` implementation with locking around the common mutating APIs.

---

## Utilities

## AsyncEnumerable.Empty

`AsyncEnumerable<T>.Empty` gives you a typed empty `IAsyncEnumerable<T>`.

```csharp
using System.Collection.Generics;

IAsyncEnumerable<MyClass> empty = AsyncEnumerable<MyClass>.Empty;

await foreach (var item in empty)
{
    // never reached
}
```

## Programming language conversion

The package can convert CLR types into other language representations. Right now it supports TypeScript.

```csharp
using System.ProgrammingLanguage;

ProgrammingLanguangeResponse ts = typeof(MyDto)
    .ConvertAs(ProgrammingLanguageType.Typescript);

Console.WriteLine(ts.Text);
Console.WriteLine(ts.MimeType);
```

```csharp
ProgrammingLanguangeResponse ts = new[] { typeof(OrderDto), typeof(ProductDto) }
    .ConvertAs(ProgrammingLanguageType.Typescript);
```

```csharp
ProgrammingLanguangeResponse renamed = typeof(MyInternalClass)
    .ConvertAs(ProgrammingLanguageType.Typescript, "PublicDto");
```

The generated output understands common primitives, arrays, enumerables, dictionaries, enums, and nested types. It also respects `JsonPropertyNameAttribute` when present.

---

## Repository Examples

If you want to see more real-world examples, the best references are the repository tests:

- Discriminated unions: [src/Core/Test/Rystem.Test.UnitTest/System/DiscriminatedUnionTests.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Core/Test/Rystem.Test.UnitTest/System/DiscriminatedUnionTests.cs)
- LINQ and dynamic queryable helpers: [src/Core/Test/Rystem.Test.UnitTest/System.Linq/SystemLinq.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Core/Test/Rystem.Test.UnitTest/System.Linq/SystemLinq.cs)
- Expression serialization and dynamic lambdas: [src/Core/Test/Rystem.Test.UnitTest/System.Linq.Expression/SystemLinqExpressions.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Core/Test/Rystem.Test.UnitTest/System.Linq.Expression/SystemLinqExpressions.cs)
- Reflection helpers: [src/Core/Test/Rystem.Test.UnitTest/System.Reflection/ReflectionTest.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Core/Test/Rystem.Test.UnitTest/System.Reflection/ReflectionTest.cs)
- Generic reflection and constructor fitting: [src/Core/Test/Rystem.Test.UnitTest/System.Reflection/SystemReflection.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Core/Test/Rystem.Test.UnitTest/System.Reflection/SystemReflection.cs)
- Property showcase: [src/Core/Test/Rystem.Test.UnitTest/System.Reflection/PropertyHandlerTest.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Core/Test/Rystem.Test.UnitTest/System.Reflection/PropertyHandlerTest.cs)
- Runtime model builder: [src/Core/Test/Rystem.Test.UnitTest/System.Reflection/ModelTest.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Core/Test/Rystem.Test.UnitTest/System.Reflection/ModelTest.cs)
- IL reader: [src/Core/Test/Rystem.Test.UnitTest/System.Reflection/IlReaderTest.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Core/Test/Rystem.Test.UnitTest/System.Reflection/IlReaderTest.cs)
- CSV: [src/Core/Test/Rystem.Test.UnitTest/System.Text.Csv/CsvTest.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Core/Test/Rystem.Test.UnitTest/System.Text.Csv/CsvTest.cs)
- Minimization: [src/Core/Test/Rystem.Test.UnitTest/System.Text.Minimization/MinimizationTest.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Core/Test/Rystem.Test.UnitTest/System.Text.Minimization/MinimizationTest.cs)
- Task helpers: [src/Core/Test/Rystem.Test.UnitTest/System.Threading.Tasks/TasksTest.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Core/Test/Rystem.Test.UnitTest/System.Threading.Tasks/TasksTest.cs)

The current README is intentionally long because this package covers a lot of independent utilities.

---

## core/dependencyinjection

> Rystem.DependencyInjection extends Microsoft.Extensions.DependencyInjection with a set of practical modules built around the default .NET container.

### [What is Rystem?](https://github.com/KeyserDSoze/Rystem)

## Rystem.DependencyInjection

`Rystem.DependencyInjection` extends `Microsoft.Extensions.DependencyInjection` with a set of practical modules built around the default .NET container.

The package is not a replacement container. It stays on top of `IServiceCollection`, `IServiceProvider`, keyed services, and standard lifetimes, then adds higher-level building blocks for:

- warm-up logic after the service provider is built
- temporary provider execution during registration time
- service registration helpers for runtime lifetimes
- keyed service helpers with the same ergonomics
- named abstract factories with per-name options
- decorators that also work with named factories
- assembly scanning with marker interfaces and lifetime overrides
- random object population for tests and seed data

Most examples below are based on the current source code and repository tests. Short snippets use small sample types such as `MyService`, `MyOptions`, or `Order` when the exact test models would add too much noise.

## Resources

- Complete Documentation: [https://rystem.net](https://rystem.net)
- MCP Server for AI: [https://rystem.cloud/mcp](https://rystem.cloud/mcp)
- Discord Community: [https://discord.gg/tkWvy4WPjt](https://discord.gg/tkWvy4WPjt)
- Support the Project: [https://www.buymeacoffee.com/keyserdsoze](https://www.buymeacoffee.com/keyserdsoze)

## Installation

```bash
dotnet add package Rystem.DependencyInjection
```

The current `10.x` package targets `net11.0` and builds on top of:

- `Microsoft.Extensions.DependencyInjection`
- `Microsoft.Extensions.DependencyInjection.Abstractions`
- `Microsoft.Extensions.DependencyModel`
- `Rystem`

If you only need the underlying utility layer, start with [`Rystem`](https://github.com/KeyserDSoze/Rystem/blob/master/src/Core/Rystem/README.md). If you need runtime ASP.NET Core container rebuilding on top of these DI helpers, continue with [`Rystem.DependencyInjection.Web`](https://github.com/KeyserDSoze/Rystem/blob/master/src/Core/Rystem.DependencyInjection.Web/README.md).

## Package Architecture

The package is organized in independent modules, each mapped to a folder in the source tree.

| Module | Purpose |
|---|---|
| `Warmup` | Register actions to run after provider build, each executed inside its own scope |
| `ExecuteServicesBeforeStart` | Build a temporary provider and execute code immediately during setup |
| `ServiceHelper` | Add, query, remove, override, and try-add services with runtime `ServiceLifetime` |
| `KeyedServiceHelper` | Same idea for keyed services |
| `AbstractFactory` | Named registrations, per-name options, fallback, and name discovery |
| `Decorator` | Service decoration for both plain registrations and named factories |
| `Scanner` | Assembly scanning with explicit interfaces or marker interfaces |
| `System.Population.Random` | Random object generation and population customization |
| `ProxyService` | Low-level runtime proxy registration API |
| `System.Threading.Tasks` | Small helper to align `NoContext()` behavior with the starting thread |

Conceptually, the most important relationship is this:

- service helpers and keyed helpers are the low-level registration layer
- abstract factory is built on top of keyed registrations
- decorators can be applied to both plain services and factory registrations
- scanning and population are separate productivity modules on top of the same DI container

## Table of Contents

- [Package Architecture](#package-architecture)
- [Warm-up and Pre-build Execution](#warm-up-and-pre-build-execution)
  - [Warm Up](#warm-up)
  - [Execute Until Now](#execute-until-now)
- [Service Helpers](#service-helpers)
  - [AddService](#addservice)
  - [HasService](#hasservice)
  - [RemoveService](#removeservice)
  - [AddOrOverrideService](#addoroverrideservice)
  - [TryAddService](#tryaddservice)
  - [TryAddSingletonAndGetService and GetSingletonService](#tryaddsingletonandgetservice-and-getsingletonservice)
- [Keyed Service Helpers](#keyed-service-helpers)
  - [AddKeyedService](#addkeyedservice)
  - [HasKeyedService](#haskeyedservice)
  - [RemoveKeyedService](#removekeyedservice)
  - [AddOrOverrideKeyedService](#addoroverridekeyedservice)
  - [TryAddKeyedService](#tryaddkeyedservice)
  - [TryAddKeyedSingletonAndGetService and GetSingletonKeyedService](#tryaddkeyedsingletonandgetservice-and-getsingletonkeyedservice)
- [Abstract Factory](#abstract-factory)
  - [Why use it](#why-use-it)
  - [Core contracts](#core-contracts)
  - [Registration](#registration)
  - [Options-aware registrations](#options-aware-registrations)
  - [Synchronous options builders](#synchronous-options-builders)
  - [Asynchronous options builders](#asynchronous-options-builders)
  - [Usage](#usage)
  - [HasFactory](#hasfactory)
  - [IFactoryNames](#ifactorynames)
  - [Factory fallback](#factory-fallback)
  - [Registration families](#registration-families)
- [Decorator](#decorator)
  - [Plain service decoration](#plain-service-decoration)
  - [Decorator with abstract factory](#decorator-with-abstract-factory)
- [Assembly Scanning](#assembly-scanning)
  - [Manual scan with an explicit interface](#manual-scan-with-an-explicit-interface)
  - [Marker interfaces](#marker-interfaces)
  - [Override lifetime per class](#override-lifetime-per-class)
  - [Assembly source helpers](#assembly-source-helpers)
  - [ScanResult](#scanresult)
- [Population Service](#population-service)
  - [Basic usage](#basic-usage)
  - [Reusable settings at registration time](#reusable-settings-at-registration-time)
  - [Common builder methods](#common-builder-methods)
  - [Extending the population engine](#extending-the-population-engine)
- [Other Utilities in this Package](#other-utilities-in-this-package)
  - [Keep NoContext on the original thread](#keep-nocontext-on-the-original-thread)
  - [Dynamic proxy registration](#dynamic-proxy-registration)
- [Repository Examples](#repository-examples)

---

## Warm-up and Pre-build Execution

## Warm Up

Use warm-up actions when some initialization should happen only after the provider is built.

There are two overloads:

- `AddWarmUp(Action<IServiceProvider>)`
- `AddWarmUp(Func<IServiceProvider, Task>)`

```csharp
builder.Services.AddWarmUp(serviceProvider =>
{
    var foo = serviceProvider.GetRequiredService<Foo>();
    var foo2 = serviceProvider.GetRequiredService<Foo2>();

    Console.WriteLine(foo.Hello() + foo2.Hello());
});

builder.Services.AddWarmUp(async serviceProvider =>
{
    await serviceProvider.GetRequiredService<MyService>().InitAsync();
});
```

After the app or provider is built, execute all registered warm-up actions:

```csharp
var app = builder.Build();
await app.Services.WarmUpAsync();
```

`WarmUpAsync()` returns the same provider instance, so it can be chained.

Implementation detail that matters in practice: each warm-up action runs inside a fresh scope.

## Execute Until Now

`ExecuteUntilNowAsync(...)` is useful when you want to build a temporary provider, resolve a service, execute some logic immediately, and dispose the temporary scope.

```csharp
string result = await services.ExecuteUntilNowAsync((Foo foo) =>
{
    return Task.FromResult(foo.Hello());
});
```

You can also resolve from `IServiceProvider` directly.

```csharp
string result = await services.ExecuteUntilNowAsync(serviceProvider =>
{
    var foo = serviceProvider.GetRequiredService<Foo>();
    var foo2 = serviceProvider.GetRequiredService<Foo2>();
    return Task.FromResult(foo.Hello() + foo2.Hello());
});
```

If you want warm-up to run before the callback, use the dedicated variant:

```csharp
string result = await services.ExecuteUntilNowWithWarmUpAsync((Foo foo) =>
{
    return Task.FromResult(foo.Hello());
});
```

This is especially handy in:

- test setup code
- one-off migrations or bootstrap steps
- validating DI registrations before host startup

---

## Service Helpers

The service helper extensions wrap the standard `AddTransient`, `AddScoped`, and `AddSingleton` methods behind a runtime `ServiceLifetime` parameter.

## AddService

```csharp
services.AddService<MyService>(ServiceLifetime.Singleton);
services.AddService<IMyService, MyService>(ServiceLifetime.Scoped);
services.AddService(typeof(IMyService), typeof(MyService), ServiceLifetime.Transient);
```

There are also factory-based overloads.

```csharp
services.AddService<IMyService>(
    serviceProvider => new MyService(serviceProvider.GetRequiredService<IDependency>()),
    ServiceLifetime.Transient);
```

Use these helpers when lifetime is only known at runtime and you do not want to branch manually on `ServiceLifetime`.

## HasService

Check whether a non-keyed registration already exists.

```csharp
bool exists = services.HasService<IMyService>(out ServiceDescriptor? descriptor);
bool exact = services.HasService<IMyService, MyService>(out ServiceDescriptor? exactDescriptor);
```

This is useful for defensive registration code or package bootstrappers.

## RemoveService

Remove every non-keyed registration for a given service type.

```csharp
services.RemoveService<IMyService>();
services.RemoveService(typeof(IMyService));
```

## AddOrOverrideService

Replace an existing non-keyed service registration with a new one.

```csharp
services.AddOrOverrideService<IMyService, MyServiceV2>(ServiceLifetime.Scoped);
services.AddOrOverrideSingleton<IMyService>(new MyServiceV2());
services.AddOrOverrideSingleton<IMyService, MyServiceV2>(new MyServiceV2());
```

Use this when your package or module must become the effective registration for a given service type.

## TryAddService

Register only if the service type is still absent.

```csharp
services.TryAddService<IMyService, MyService>(ServiceLifetime.Scoped);
services.TryAddService<MyService>(ServiceLifetime.Singleton);
```

There are additional overloads for:

- implementation instances
- runtime `Type`
- factory-based registrations

## TryAddSingletonAndGetService and GetSingletonService

These helpers are useful while you are still configuring `IServiceCollection` and want to keep one shared singleton instance around.

```csharp
MySettings settings = services.TryAddSingletonAndGetService(new MySettings
{
    Environment = "test"
});
```

```csharp
MySettings settings = services.TryAddSingletonAndGetService<MySettings>();
IMySettings typed = services.TryAddSingletonAndGetService<IMySettings, MySettings>(new MySettings());
```

```csharp
MySettings? existing = services.GetSingletonService<MySettings>();
```

This pattern is handy for package-level maps, registries, or shared configuration objects that are built directly during registration. `GetSingletonService(...)` is most useful for singleton instances that were added directly to `IServiceCollection`, especially through these same helpers.

---

## Keyed Service Helpers

The keyed helpers provide the same ergonomics for .NET keyed DI registrations.

They are especially useful when you want one service contract with multiple named or keyed implementations, but you do not need the higher-level abstract factory API.

## AddKeyedService

```csharp
services.AddKeyedService<MyService>("default", ServiceLifetime.Singleton);
services.AddKeyedService<IMyService, MyService>("west", ServiceLifetime.Scoped);
services.AddKeyedService(typeof(IMyService), "east", typeof(MyService), ServiceLifetime.Transient);
```

Factory-based keyed registration is also supported.

```csharp
services.AddKeyedService<IMyService>(
    "west",
    (serviceProvider, key) => new MyService(key?.ToString() ?? "unknown"),
    ServiceLifetime.Transient);
```

## HasKeyedService

```csharp
bool exists = services.HasKeyedService<IMyService>("west", out ServiceDescriptor? descriptor);
bool exact = services.HasKeyedService<IMyService, MyService>("west", out _);
bool raw = services.HasKeyedService(typeof(IMyService), "west", out _);
```

## RemoveKeyedService

```csharp
services.RemoveKeyedService<IMyService>("west");
services.RemoveKeyedService(typeof(IMyService), "west");
```

## AddOrOverrideKeyedService

Replace the registration associated with a specific key.

```csharp
services.AddOrOverrideKeyedService<MyWorker>("main", ServiceLifetime.Singleton);
services.AddOrOverrideKeyedService(typeof(MyWorker), "backup", ServiceLifetime.Scoped);
services.AddOrOverrideKeyedSingleton<IMySettings>("tenant-a", new MySettings());
```

## TryAddKeyedService

```csharp
services.TryAddKeyedService<IMyService, MyService>("west", ServiceLifetime.Scoped);
services.TryAddKeyedService<MyService>("default", ServiceLifetime.Singleton);
```

As with the non-keyed helper family, there are also overloads for runtime types and keyed implementation factories.

## TryAddKeyedSingletonAndGetService and GetSingletonKeyedService

```csharp
MySettings settings = services.TryAddKeyedSingletonAndGetService(new MySettings(), "tenant-a");
MySettings autoCreated = services.TryAddKeyedSingletonAndGetService<MySettings>("tenant-b");
```

```csharp
MySettings? existing = services.GetSingletonKeyedService<MySettings>("tenant-a");
```

This is the keyed equivalent of the singleton-get helper from the non-keyed service module and is mainly intended for keyed singleton instances stored directly in the collection.

---

## Abstract Factory

## Why use it

Use the abstract factory module when you need multiple named registrations of the same service contract, each with its own lifetime and optional per-name options.

This is the most important high-level feature in the package.

Factory names can be either:

- `string`
- `Enum`

Internally, names are normalized through `AnyOf<string?, Enum>`. When you use an enum, its display name is used if a `[Display(Name = ...)]` attribute exists.

## Core contracts

The public contracts are:

```csharp
public interface IFactory<out TService>
    where TService : class
{
    TService? Create(AnyOf<string?, Enum>? name = null);
    TService? CreateWithoutDecoration(AnyOf<string?, Enum>? name = null);
    IEnumerable<TService> CreateAll(AnyOf<string?, Enum>? name = null);
    IEnumerable<TService> CreateAllWithoutDecoration(AnyOf<string?, Enum>? name = null);
    bool Exists(AnyOf<string?, Enum>? name = null);
}
```

```csharp
public interface IServiceForFactory
{
    void SetFactoryName(string name);
    bool FactoryNameAlreadySetup { get; set; }
}

public interface IServiceWithFactoryWithOptions : IServiceForFactory
{
    bool OptionsAlreadySetup { get; set; }
}

public interface IServiceWithFactoryWithOptions<in TOptions> : IServiceWithFactoryWithOptions
    where TOptions : class, IFactoryOptions
{
    void SetOptions(TOptions options);
}
```

If a factory-created service implements `IServiceForFactory`, the factory name is injected automatically during creation.

If it also implements `IServiceWithFactoryWithOptions<TOptions>`, the per-name options are injected automatically too.

## Registration

Here is the simplest options-aware registration flow, adapted from the tests.

```csharp
public interface ITestService
{
    string Id { get; }
    string FactoryName { get; }
}

public sealed class TestOptions : IFactoryOptions
{
    public string ClassicName { get; set; } = string.Empty;
}

public sealed class TestService : ITestService, IServiceWithFactoryWithOptions<TestOptions>
{
    public string Id => Options.ClassicName;
    public string FactoryName { get; private set; } = string.Empty;
    public TestOptions Options { get; private set; } = null!;

    public bool FactoryNameAlreadySetup { get; set; }
    public bool OptionsAlreadySetup { get; set; }

    public void SetFactoryName(string name) => FactoryName = name;
    public void SetOptions(TestOptions options) => Options = options;
}

services.AddFactory<ITestService, TestService, TestOptions>(
    options =>
    {
        options.ClassicName = "singleton";
    },
    name: "singleton",
    lifetime: ServiceLifetime.Singleton);

services.AddFactory<ITestService, TestService, TestOptions>(
    options =>
    {
        options.ClassicName = "scoped";
    },
    name: "scoped",
    lifetime: ServiceLifetime.Scoped);

services.AddFactory<ITestService, TestService, TestOptions>(
    options =>
    {
        options.ClassicName = "transient";
    },
    name: "transient",
    lifetime: ServiceLifetime.Transient);
```

The factory supports both string and enum names.

```csharp
public enum TestKind
{
    Singleton,
    Scoped,
    Transient
}

services.AddFactory<ITestService, TestService, TestOptions>(
    options => options.ClassicName = "enum-singleton",
    TestKind.Singleton,
    ServiceLifetime.Singleton);
```

## Options-aware registrations

You only need options when the same service type must behave differently per factory name.

If you do not need custom options, the basic overload is enough.

```csharp
services.AddFactory<ITestService, TestService>("default", ServiceLifetime.Scoped);
```

There are also overload families for:

- self-registered services
- implementation instances
- implementation factories
- runtime `Type` arguments

## Synchronous options builders

If the configuration object must be built through a builder step, implement `IOptionsBuilder<TBuiltOptions>`.

```csharp
public sealed class BuiltOptions : IFactoryOptions
{
    public string ServiceName { get; set; } = string.Empty;
}

public sealed class BuiltOptionsBuilder : IOptionsBuilder<BuiltOptions>
{
    public string Prefix { get; set; } = string.Empty;

    public Func<IServiceProvider, BuiltOptions> Build()
        => _ => new BuiltOptions
        {
            ServiceName = $"{Prefix}-built"
        };
}

public sealed class BuiltService : ITestService, IServiceWithFactoryWithOptions<BuiltOptions>
{
    public string Id => Options.ServiceName;
    public string FactoryName { get; private set; } = string.Empty;
    public BuiltOptions Options { get; private set; } = null!;

    public bool FactoryNameAlreadySetup { get; set; }
    public bool OptionsAlreadySetup { get; set; }

    public void SetFactoryName(string name) => FactoryName = name;
    public void SetOptions(BuiltOptions options) => Options = options;
}

services.AddFactory<ITestService, BuiltService, BuiltOptionsBuilder, BuiltOptions>(
    options => options.Prefix = "sync",
    name: "sync-builder",
    lifetime: ServiceLifetime.Transient);
```

## Asynchronous options builders

If options must be prepared asynchronously, implement `IOptionsBuilderAsync<TBuiltOptions>` and use `AddFactoryAsync(...)`.

```csharp
public sealed class AsyncBuiltOptions : IFactoryOptions
{
    public string ServiceName { get; set; } = string.Empty;
}

public sealed class AsyncBuiltOptionsBuilder : IOptionsBuilderAsync<AsyncBuiltOptions>
{
    public string Prefix { get; set; } = string.Empty;

    public Task<Func<IServiceProvider, AsyncBuiltOptions>> BuildAsync()
    {
        return Task.FromResult<Func<IServiceProvider, AsyncBuiltOptions>>(_ =>
            new AsyncBuiltOptions
            {
                ServiceName = $"{Prefix}-async"
            });
    }
}

public sealed class AsyncBuiltService : ITestService, IServiceWithFactoryWithOptions<AsyncBuiltOptions>
{
    public string Id => Options.ServiceName;
    public string FactoryName { get; private set; } = string.Empty;
    public AsyncBuiltOptions Options { get; private set; } = null!;

    public bool FactoryNameAlreadySetup { get; set; }
    public bool OptionsAlreadySetup { get; set; }

    public void SetFactoryName(string name) => FactoryName = name;
    public void SetOptions(AsyncBuiltOptions options) => Options = options;
}

await services.AddFactoryAsync<ITestService, AsyncBuiltService, AsyncBuiltOptionsBuilder, AsyncBuiltOptions>(
    options => options.Prefix = "async",
    name: "async-builder",
    lifetime: ServiceLifetime.Scoped);
```

## Usage

Resolve the factory from DI and create named services on demand.

```csharp
using var provider = services.BuildServiceProvider();
using var scope = provider.CreateScope();

var factory = scope.ServiceProvider.GetRequiredService<IFactory<ITestService>>();

var singleton = factory.Create("singleton");
var transient = factory.Create("transient");
var scoped = factory.Create("scoped");

bool exists = factory.Exists("singleton");
bool missing = factory.Exists("missing");

IEnumerable<ITestService> all = factory.CreateAll("singleton");
```

Lifetime semantics are still the standard DI ones.

```csharp
var factory = scope.ServiceProvider.GetRequiredService<IFactory<ITestService>>();

string singletonId1 = factory.Create("singleton")!.Id;
string singletonId2 = factory.Create("singleton")!.Id;

string transientId1 = factory.Create("transient")!.Id;
string transientId2 = factory.Create("transient")!.Id;

Console.WriteLine(singletonId1 == singletonId2); // true
Console.WriteLine(transientId1 == transientId2); // false
```

`CreateWithoutDecoration(...)` and `CreateAllWithoutDecoration(...)` are useful when decorators are involved and you explicitly want the undecorated pipeline.

## HasFactory

You can check a registration before the provider is built.

```csharp
bool byString = services.HasFactory<ITestService>("singleton");
bool byEnum = services.HasFactory<ITestService>(TestKind.Singleton);
bool raw = services.HasFactory(typeof(ITestService), "singleton");
```

## IFactoryNames

`IFactoryNames<TService>` exposes the list of registered names for a service contract.

```csharp
var names = provider.GetRequiredService<IFactoryNames<ITestService>>().List();
```

This is useful for discovery scenarios such as settings pages, admin UIs, or dynamic feature selection.

## Factory fallback

Fallbacks are invoked when `Create(name)` is called for a name that has no registration.

```csharp
public sealed class DefaultService : ITestService
{
    public DefaultService(string name)
    {
        Id = name;
        FactoryName = name;
    }

    public string Id { get; }
    public string FactoryName { get; }
}

public sealed class MyFallback : IFactoryFallback<ITestService>
{
    public ITestService Create(AnyOf<string?, Enum>? name = null)
        => new DefaultService(name?.AsString() ?? "default");
}

services.AddFactoryFallback<ITestService, MyFallback>();
```

Or use a delegate that also receives the service provider:

```csharp
services.AddActionAsFallbackWithServiceProvider<ITestService>(builder =>
{
    var resolvedName = builder.Name?.AsString() ?? "default";
    return new DefaultService(resolvedName);
});
```

## Registration families

In addition to `AddFactory(...)`, the package also exposes these families:

- `TryAddFactory(...)`
- `AddOrOverrideFactory(...)`
- `AddNewFactory(...)`
- `TryAddFactoryAsync(...)`
- `AddOrOverrideFactoryAsync(...)`
- `AddNewFactoryAsync(...)`

They exist for the same combinations of:

- self-registered services
- service + implementation types
- instance registrations
- implementation factories
- plain registrations
- options-aware registrations
- sync and async options builders

Use:

- `TryAddFactory` when you want a `bool` success signal and no replacement
- `AddOrOverrideFactory` when the latest registration should win
- `AddNewFactory` when you want an explicitly new registration path instead of silently reusing an existing one

---

## Decorator

The decorator module replaces a service registration with a decorator and keeps the original service accessible through `IDecoratedService<TService>`.

The correct interface is:

```csharp
public interface IDecoratorService<in TService> : IServiceForFactory
    where TService : class
{
    void SetDecoratedServices(IEnumerable<TService> services);
}
```

The decorator receives all decorated services as an enumerable so it can support multiple layers.

## Plain service decoration

```csharp
public interface ITestWithoutFactoryService
{
    string Id { get; }
}

public sealed class TestWithoutFactoryService : ITestWithoutFactoryService
{
    public string Id { get; } = Guid.NewGuid().ToString();
}

public sealed class TestWithoutFactoryServiceDecorator :
    ITestWithoutFactoryService,
    IDecoratorService<ITestWithoutFactoryService>
{
    public string Id { get; } = Guid.NewGuid().ToString();
    public ITestWithoutFactoryService Inner { get; private set; } = null!;

    public bool FactoryNameAlreadySetup { get; set; }
    public void SetFactoryName(string name) { }

    public void SetDecoratedServices(IEnumerable<ITestWithoutFactoryService> services)
        => Inner = services.First();
}

services.AddService<ITestWithoutFactoryService, TestWithoutFactoryService>(ServiceLifetime.Scoped);
services.AddDecoration<ITestWithoutFactoryService, TestWithoutFactoryServiceDecorator>(
    name: null,
    lifetime: ServiceLifetime.Scoped);
```

Usage:

```csharp
var decorated = provider.GetRequiredService<ITestWithoutFactoryService>();
var raw = provider.GetRequiredService<IDecoratedService<ITestWithoutFactoryService>>().Service;
```

`decorated` is the decorator. `raw` is the original pre-decoration service.

## Decorator with abstract factory

Decorators also work with named factory registrations.

```csharp
services.AddFactory<ITestService, TestService, TestOptions>(
    options => options.ClassicName = "special",
    name: "special",
    lifetime: ServiceLifetime.Scoped);

services.AddDecoration<ITestService, DecoratorTestService>(
    name: "special",
    lifetime: ServiceLifetime.Scoped);
```

```csharp
var factory = provider.GetRequiredService<IFactory<ITestService>>();

var decorated = factory.Create("special");
var raw = factory.CreateWithoutDecoration("special");
```

This is one of the strongest combinations in the package:

- `IFactory<TService>` chooses the named implementation
- `IDecoratorService<TService>` layers cross-cutting behavior on top
- `CreateWithoutDecoration(...)` lets you bypass the decorator when needed

---

## Assembly Scanning

The scanning module can register implementations explicitly by interface or implicitly through marker interfaces.

It also tracks previously scanned type pairs to avoid duplicate registrations for the same service and implementation.

## Manual scan with an explicit interface

```csharp
public interface IAnything { }
internal sealed class ScanModels : IAnything { }

ScanResult result = services.Scan<IAnything>(
    ServiceLifetime.Scoped,
    typeof(IAnything).Assembly);
```

Equivalent non-generic overloads exist too.

## Marker interfaces

If the implementation class declares `IScannable<TService>`, you can use the untyped scan overload.

```csharp
public interface IAnything { }

internal sealed class ScanModels : IAnything, IScannable<IAnything>
{
}

services.Scan(ServiceLifetime.Scoped, typeof(IAnything).Assembly);
```

That is useful when the service-to-implementation relationship should stay close to the implementation itself.

## Override lifetime per class

You can override the scan lifetime with one of these marker interfaces:

- `ISingletonScannable`
- `IScopedScannable`
- `ITransientScannable`

```csharp
internal sealed class ScanModels :
    IAnything,
    IScannable<IAnything>,
    ISingletonScannable
{
}

services.Scan(ServiceLifetime.Scoped, typeof(IAnything).Assembly);
```

In this example the default scan lifetime is `Scoped`, but `ScanModels` is registered as `Singleton`.

## Assembly source helpers

The package includes several helpers to decide where assemblies come from.

```csharp
services.ScanDependencyContext(ServiceLifetime.Scoped);
services.ScanCallingAssembly(ServiceLifetime.Scoped);
services.ScanCurrentDomain(ServiceLifetime.Scoped);
services.ScanEntryAssembly(ServiceLifetime.Scoped);
services.ScanExecutingAssembly(ServiceLifetime.Scoped);
services.ScanFromType<MyMarker>(ServiceLifetime.Scoped);
services.ScanFromTypes<MyMarker1, MyMarker2>(ServiceLifetime.Scoped);
```

`ScanDependencyContext(...)` also supports an optional assembly predicate.

```csharp
services.ScanDependencyContext(
    ServiceLifetime.Scoped,
    assembly => assembly.GetName().Name!.StartsWith("MyCompany."));
```

If you want transitive references too, use `ScanWithReferences(...)`.

```csharp
services.ScanWithReferences(ServiceLifetime.Scoped, typeof(MyMarker).Assembly);
```

## ScanResult

Every scan method returns a `ScanResult`.

```csharp
ScanResult result = services.Scan(ServiceLifetime.Scoped, typeof(MyMarker).Assembly);

Console.WriteLine(result.Count);
foreach (var type in result.Implementations)
{
    Console.WriteLine(type.FullName);
}
```

This is convenient for diagnostics or registration reports.

---

## Population Service

The population module generates random object graphs and lets you override the generated values with patterns, delegates, implementations, and shared random queues.

It is especially useful for:

- integration tests
- seed/demo data
- random-but-valid object generation
- stress-testing APIs with large model graphs

## Basic usage

Register the service once:

```csharp
IServiceCollection services = new ServiceCollection();
services.AddPopulationService();
```

Resolve `IPopulation<T>` and either populate immediately or create a reusable builder with `Setup()`.

```csharp
using var provider = services.BuildServiceProvider();
using var scope = provider.CreateScope();

var population = scope.ServiceProvider.GetRequiredService<IPopulation<PopulationModelTest>>();

List<PopulationModelTest> items = population.Populate();
IPopulationBuilder<PopulationModelTest> setup = population.Setup();
```

From the tests, a more realistic setup looks like this:

```csharp
var population = scope.ServiceProvider.GetRequiredService<IPopulation<PopulationModelTest>>();

var setup = population
    .Setup()
    .WithPattern(x => x.J!.First().A, "[a-z]{4,5}")
    .WithPattern(x => x.Y!.First().Value.A, "[a-z]{4,5}")
    .WithImplementation(x => x.I, typeof(MyInnerInterfaceImplementation))
    .WithPattern(x => x.I!.A!, "[a-z]{4,5}")
    .WithPattern(x => x.II!.A!, "[a-z]{4,5}")
    .WithImplementation<IInnerInterface, MyInnerInterfaceImplementation>(x => x.I!);

List<PopulationModelTest> items = setup.Populate();
```

`Populate(...)` accepts:

- `numberOfElements` - how many root objects to create
- `numberOfElementsWhenEnumerableIsFound` - how many elements to generate inside collections by default

```csharp
List<PopulationModelTest> items = setup.Populate(50, 4);
```

## Reusable settings at registration time

If a configuration should apply every time `IPopulation<T>` is resolved, register it during DI setup with `AddPopulationSettings<T>()`.

```csharp
services
    .AddPopulationSettings<PopulationModelTest>()
    .WithAutoIncrement(x => x.A, 1);
```

That configuration becomes the default for `IPopulation<PopulationModelTest>`.

The tests also show wrapper models using settings during registration time.

```csharp
services
    .AddPopulationSettings<Entity<PopulationModelTest, int>>()
    .WithAutoIncrement(x => x.Value.A, 1)
    .WithAutoIncrement(x => x.Key, 1)
    .WithPattern(x => x.Value.J!.First().A, "[a-z]{4,5}")
    .WithImplementation(x => x.Value.I, typeof(MyInnerInterfaceImplementation));
```

## Common builder methods

`IPopulationBuilder<T>` exposes a rich customization surface.

### WithPattern

Generate values matching one or more regex patterns.

```csharp
population.Setup()
    .WithPattern(x => x.Name, "[a-z]{4,10}")
    .WithPattern(x => x.Code, "[A-Z]{3}[0-9]{2}");
```

### WithAutoIncrement

Useful for deterministic ids across repeated generations.

```csharp
population.Setup()
    .WithAutoIncrement(x => x.Id, 1);
```

### WithValue

Set values explicitly using a local function or an async service-based resolver.

```csharp
population.Setup()
    .WithValue(x => x.Environment, () => "test");
```

```csharp
population.Setup()
    .WithValue(x => x.UserName, async serviceProvider =>
    {
        var source = serviceProvider.GetRequiredService<IUserNameSource>();
        return await source.NextAsync();
    });
```

### WithRandomValue

Provide a pool of allowed values and let the population engine choose randomly.

```csharp
services
    .AddPopulationSettings<MyEntity>()
    .WithRandomValue(x => x.Groups, async serviceProvider =>
    {
        return new List<Group>
        {
            new Group { Id = "2", Name = "admin" },
            new Group { Id = "3", Name = "user" }
        };
    });
```

There are overloads both for scalar properties and enumerable properties.

### WithSpecificNumberOfElements

Override the default number of generated items for a specific collection property.

```csharp
population.Setup()
    .WithSpecificNumberOfElements(x => x.Tags, 3);
```

### WithImplementation

Choose the concrete type used for interface or abstract properties.

```csharp
population.Setup()
    .WithImplementation(x => x.I, typeof(MyInnerInterfaceImplementation))
    .WithImplementation<IInnerInterface, MyInnerInterfaceImplementation>(x => x.I!);
```

### WithRandomValueFromRystem

Share values through the Rystem random queues.

```csharp
population.Setup()
    .WithRandomValueFromRystem(x => x.CountryCode, useTheSameRandomValuesForTheSameType: true)
    .WithRandomValueFromRystemWithSpecificQueue(x => x.RegionCode, "shared-region-queue");
```

This is useful when related properties across many generated entities should reuse the same random pool instead of being fully independent.

## Extending the population engine

The module is extensible through DI.

```csharp
services.AddPopulationService();
services.AddPopulationService<MyPopulationService>();
services.AddPopulationService<MyEntity, MyPopulationForEntity>();
services.AddPopulationStrategyService<MyEntity, MyPopulationStrategy>();
services.AddRegexService<MyRegexService>();
services.AddRandomPopulationService<MyCustomRandomPopulationService>();
```

This lets you override:

- the global population service
- the strategy for a specific `T`
- the regex generator
- any low-level random population provider by priority

---

## Other Utilities in this Package

## Keep NoContext on the original thread

The package includes a tiny bridge to the core `RystemTask.WaitYourStartingThread` switch.

```csharp
services.AddWaitingTheSameThreadThatStartedTheTaskWhenUseNoContext();
```

This simply sets `RystemTask.WaitYourStartingThread = true` so `NoContext()` returns to the starting thread when that behavior is needed.

This is useful in UI-style environments where resuming on the original thread matters.

## Dynamic proxy registration

There is also a low-level runtime proxy API:

```csharp
(Type proxyInterface, Type proxyImplementation) = services.AddProxy(
    interfaceType: typeof(IMyService),
    implementationType: typeof(MyService),
    interfaceName: "IMyServiceProxy",
    className: "MyServiceProxy",
    lifetime: ServiceLifetime.Scoped);
```

`AddProxy(...)` dynamically emits a new interface and implementation type and registers that proxy interface in DI.

This is an advanced API and is not covered by the repository tests as thoroughly as the modules above, so treat it as a source-level power feature rather than the mainline package entry point.

---

## Repository Examples

The best example sources for this package are:

- Warm-up and ExecuteUntilNow: [src/Core/Test/Rystem.Test.UnitTest/Microsoft.Extensions.DependencyInjection/DependencyInjectionTest.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Core/Test/Rystem.Test.UnitTest/Microsoft.Extensions.DependencyInjection/DependencyInjectionTest.cs)
- Abstract factory: [src/Core/Test/Rystem.Test.UnitTest/Microsoft.Extensions.DependencyInjection/AbstractFactoryTests.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Core/Test/Rystem.Test.UnitTest/Microsoft.Extensions.DependencyInjection/AbstractFactoryTests.cs)
- Factory + decorator together: [src/Core/Test/Rystem.Test.UnitTest/Microsoft.Extensions.DependencyInjection/DecoratorFactoryTests.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Core/Test/Rystem.Test.UnitTest/Microsoft.Extensions.DependencyInjection/DecoratorFactoryTests.cs)
- Decorator support models: [src/Core/Test/Rystem.Test.UnitTest/Microsoft.Extensions.DependencyInjection/Decoration/Decoration.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Core/Test/Rystem.Test.UnitTest/Microsoft.Extensions.DependencyInjection/Decoration/Decoration.cs)
- Scanning: [src/Core/Test/Rystem.Test.UnitTest/Microsoft.Extensions.DependencyInjection/ScanTest.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Core/Test/Rystem.Test.UnitTest/Microsoft.Extensions.DependencyInjection/ScanTest.cs)
- Population service: [src/Core/Test/Rystem.Test.UnitTest/System.Population.Random/PopulationTest.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Core/Test/Rystem.Test.UnitTest/System.Population.Random/PopulationTest.cs)

This README is intentionally long because `Rystem.DependencyInjection` is not a single feature. It is a set of composable DI modules that can be adopted independently or together.

---

## core/dependencyinjection-web

> Rystem.DependencyInjection.Web adds a runtime-rebuild layer on top of Rystem.DependencyInjection for ASP.NET Core applications.

### [What is Rystem?](https://github.com/KeyserDSoze/Rystem)

## Rystem.DependencyInjection.Web

`Rystem.DependencyInjection.Web` adds a runtime-rebuild layer on top of `Rystem.DependencyInjection` for ASP.NET Core applications.

The package is built for scenarios where the application must keep serving requests while the underlying `IServiceCollection` changes at runtime. Instead of treating the container as immutable after startup, it keeps track of the current service collection, rebuilds a fresh provider when needed, and routes later requests through that latest provider.

This is a specialized package. It is most useful for:

- dynamic feature activation
- runtime factory expansion
- test/demo environments that register services on demand
- multi-tenant or plug-in style setups where registrations are not fully known at startup

Most examples below come from the current source and from the runtime integration tests in `src/Core/Test/Rystem.Test.UnitTest/RuntimeServiceProvider/RuntimeServiceProviderTest.cs` plus the sample API used by those tests in `src/Extensions/Tests/Test/Rystem.Test.TestApi`.

## Resources

- Complete Documentation: [https://rystem.net](https://rystem.net)
- MCP Server for AI: [https://rystem.cloud/mcp](https://rystem.cloud/mcp)
- Discord Community: [https://discord.gg/tkWvy4WPjt](https://discord.gg/tkWvy4WPjt)
- Support the Project: [https://www.buymeacoffee.com/keyserdsoze](https://www.buymeacoffee.com/keyserdsoze)

## Installation

```bash
dotnet add package Rystem.DependencyInjection.Web
```

The current `10.x` package targets `net11.0` and references:

- `Microsoft.AspNetCore.App`
- `Rystem.DependencyInjection`

This package assumes the abstractions from [`Rystem.DependencyInjection`](https://github.com/KeyserDSoze/Rystem/blob/master/src/Core/Rystem.DependencyInjection/README.md), which in turn builds on the lower-level utility package [`Rystem`](https://github.com/KeyserDSoze/Rystem/blob/master/src/Core/Rystem/README.md).

## Package Architecture

The package is intentionally small and is organized around two modules.

| Module | Purpose |
|---|---|
| `RuntimeServiceProvider` | Tracks the current `IServiceCollection`, current built `IServiceProvider`, request-time swapping, and rebuild operations |
| `Fallback` | Integrates with `IFactory<T>` so missing factory names can register new services and rebuild automatically |

At a high level, the flow is:

- call `AddRuntimeServiceProvider()` during service registration
- call `UseRuntimeServiceProvider()` after the app is built
- mutate the tracked `IServiceCollection` later
- call `RebuildAsync()` to build the next provider
- future resolutions and future HTTP requests use the newest provider

## Table of Contents

- [Package Architecture](#package-architecture)
- [Setup](#setup)
- [How Runtime Rebuilding Works](#how-runtime-rebuilding-works)
- [Read the Current Collection and Provider](#read-the-current-collection-and-provider)
- [Add Services at Runtime](#add-services-at-runtime)
- [Thread-safe Runtime Registration](#thread-safe-runtime-registration)
- [RebuildAsync](#rebuildasync)
  - [Preserve existing singleton instances](#preserve-existing-singleton-instances)
  - [Concurrent rebuild behavior](#concurrent-rebuild-behavior)
- [Factory Fallback with Auto-Rebuild](#factory-fallback-with-auto-rebuild)
  - [Generic fallback registration](#generic-fallback-registration)
  - [Runtime type fallback registration](#runtime-type-fallback-registration)
  - [FallbackBuilderForServiceCollection](#fallbackbuilderforservicecollection)
- [Practical Notes](#practical-notes)
- [Repository Examples](#repository-examples)

---

## Setup

Register runtime rebuilding during startup:

```csharp
builder.Services.AddRuntimeServiceProvider();

var app = builder.Build();
app.UseRuntimeServiceProvider();
```

This does two important things:

- stores the application `IServiceCollection` so it can be mutated later
- inserts middleware that replaces `HttpContext.RequestServices` with a scope created from the latest rebuilt provider

You can also choose not to dispose the previous request service provider when the middleware swaps it out:

```csharp
app.UseRuntimeServiceProvider(disposeOldServiceProvider: false);
```

That flag matters only if you need to keep the previous request-scoped provider alive longer than the default handoff behavior.

## How Runtime Rebuilding Works

The package keeps global static references to:

- the tracked `IServiceCollection`
- the latest built `IServiceProvider`
- the `IApplicationBuilder` used to patch the host-level `Services` property

When `RebuildAsync()` runs, it:

1. reads the tracked service collection
2. optionally migrates singleton instances from the old provider into matching singleton descriptors
3. builds a new provider
4. swaps the global current provider if that rebuild still represents the newest service count
5. runs `WarmUpAsync()` on the rebuilt provider

This design means the package is best suited to application-level dynamic composition, not to isolated per-module container ownership.

## Read the Current Collection and Provider

After setup, you can read either the mutable collection or the latest provider.

```csharp
IServiceCollection services = RuntimeServiceProvider.GetServiceCollection();
IServiceProvider provider = RuntimeServiceProvider.GetServiceProvider();
```

`GetServiceCollection()` also clears the internal read-only flag on the collection before returning it, so later `Add...` calls can keep modifying the same collection instance.

`GetServiceProvider()` throws until the runtime provider has been initialized through `UseRuntimeServiceProvider()`.

---

## Add Services at Runtime

The simplest runtime update flow is:

```csharp
await RuntimeServiceProvider
    .GetServiceCollection()
    .AddSingleton<MyNewService>()
    .RebuildAsync();
```

That pattern comes directly from the test API used by `RuntimeServiceProviderTest`.

For example, the sample controller checks whether `AddedService` exists and, if not, registers it and rebuilds immediately:

```csharp
var value = _serviceProvider.GetService<AddedService>();
if (value == null)
{
    await RuntimeServiceProvider.GetServiceCollection()
         .AddSingleton<AddedService>()
         .RebuildAsync();
}
```

The integration test confirms the effect:

- first request does not see `AddedService`
- second request does see it
- existing singleton instances stay the same by default
- scoped and transient services are recreated as usual

---

## Thread-safe Runtime Registration

If multiple threads may mutate the tracked service collection, use the built-in lock helper:

```csharp
await RuntimeServiceProvider
    .AddServicesToServiceCollectionWithLock(services =>
    {
        services.AddSingleton(myServiceInstance);
    })
    .RebuildAsync();
```

Use this helper when registration can happen concurrently, for example from multiple requests or parallel background tasks.

The runtime tests also exercise this pattern by adding many mocked service types in parallel and rebuilding after each change.

---

## RebuildAsync

You can rebuild either from the tracked collection instance or through the static shortcut:

```csharp
await services.RebuildAsync();
await RuntimeServiceProvider.RebuildAsync();
```

Every rebuild ends by calling `WarmUpAsync()` on the latest provider, so warm-up actions registered through `Rystem.DependencyInjection` still participate in the runtime-rebuild flow.

### Preserve existing singleton instances

By default, rebuild keeps the current singleton instance values when matching singleton descriptors still exist in the new collection.

```csharp
await RuntimeServiceProvider.RebuildAsync(preserveValueForSingletonServices: true);
```

Or disable that behavior:

```csharp
await RuntimeServiceProvider.RebuildAsync(preserveValueForSingletonServices: false);
```

That default preservation is why the runtime test can add `AddedService` while keeping the original ids for already-created singleton services.

### Concurrent rebuild behavior

The implementation tracks the current number of registered services and only promotes the rebuilt provider if that rebuild still represents the largest service collection seen so far.

Practically, this means that when multiple rebuilds race:

- older/smaller rebuilds do not overwrite a newer/larger one
- the provider that wins is the one associated with the latest widest collection snapshot

The tests stress this behavior with repeated sequential and parallel rebuilds.

---

## Factory Fallback with Auto-Rebuild

This package becomes especially powerful when combined with `IFactory<T>` from `Rystem.DependencyInjection`.

You can register a fallback that reacts when `factory.Create(name)` is called for an unknown name. Inside that fallback you dynamically add the missing factory registration, rebuild the service provider, and then return the newly available service.

### Generic fallback registration

```csharp
services.AddFactory<Factorized>("1");

services.AddActionAsFallbackWithServiceCollectionRebuilding<Factorized>(async context =>
{
    await Task.Delay(1);

    var singletonService = context.ServiceProvider.GetService<SingletonService>();
    if (singletonService != null)
    {
        context.ServiceColletionBuilder = serviceCollection =>
            serviceCollection.AddFactory<Factorized>(context.Name);
    }
});
```

That exact pattern is used in `src/Extensions/Tests/Test/Rystem.Test.TestApi/Extensions/ServiceExtensions.cs`.

After this is registered, the first call to an unknown factory name can materialize the missing registration on demand:

```csharp
var factory = serviceProvider.GetRequiredService<IFactory<Factorized>>();
var created = factory.Create("dynamic-name");
```

The runtime tests validate this behavior both for one service and for many services in parallel.

### Runtime type fallback registration

There is also a non-generic overload for runtime service types:

```csharp
RuntimeServiceProvider.AddServicesToServiceCollectionWithLock(sc =>
{
    sc.AddActionAsFallbackWithServiceCollectionRebuilding(serviceType, async context =>
    {
        await Task.Delay(1);
        context.ServiceColletionBuilder = inner => inner.AddFactory(serviceType, context.Name);
    });
});

await RuntimeServiceProvider.RebuildAsync();
```

This is useful when the service contract itself is discovered dynamically.

### FallbackBuilderForServiceCollection

The fallback delegate receives `FallbackBuilderForServiceCollection`:

| Property | Type | Purpose |
|---|---|---|
| `Name` | `AnyOf<string, Enum>?` | The missing factory name that triggered the fallback |
| `ServiceProvider` | `IServiceProvider` | A fresh scope created from the current runtime provider |
| `ServiceColletionBuilder` | `Action<IServiceCollection>` | The action that will mutate the tracked service collection before rebuild |

Note that the public property name is actually `ServiceColletionBuilder` in the source, including the typo. The README keeps that spelling because it is the real API surface.

Internally the flow is:

1. the fallback builds a `FallbackBuilderForServiceCollection`
2. your delegate populates `ServiceColletionBuilder`
3. the package runs that action under `AddServicesToServiceCollectionWithLock(...)`
4. it calls `RebuildAsync()`
5. it resolves the requested service again from the rebuilt `IFactory<T>`

---

## Practical Notes

- This package uses static global state, so it is designed for one active application container per process.
- `UseRuntimeServiceProvider()` relies on reflection to patch internal hosting fields and to unfreeze the service collection.
- Request pipelines only see the updated provider for future requests; already-running requests continue on the scope they already have.
- `RebuildAsync()` returns the current `IServiceProvider`, so you can chain additional startup logic after a rebuild.
- The package is much easier to reason about when paired with the lower-level helpers from `Rystem.DependencyInjection`, especially `AddFactory(...)`, warm-up, and service helper APIs.

---

## Repository Examples

The most useful sources for this package are:

- Runtime integration tests: [src/Core/Test/Rystem.Test.UnitTest/RuntimeServiceProvider/RuntimeServiceProviderTest.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Core/Test/Rystem.Test.UnitTest/RuntimeServiceProvider/RuntimeServiceProviderTest.cs)
- Test API startup wiring: [src/Extensions/Tests/Test/Rystem.Test.TestApi/Extensions/ServiceExtensions.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Extensions/Tests/Test/Rystem.Test.TestApi/Extensions/ServiceExtensions.cs)
- Test API controller scenarios: [src/Extensions/Tests/Test/Rystem.Test.TestApi/Controllers/ServiceController.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Extensions/Tests/Test/Rystem.Test.TestApi/Controllers/ServiceController.cs)
- Runtime provider implementation: [src/Core/Rystem.DependencyInjection.Web/RuntimeServiceProvider/RuntimeServiceProvider.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Core/Rystem.DependencyInjection.Web/RuntimeServiceProvider/RuntimeServiceProvider.cs)
- Auto-rebuild fallback implementation: [src/Core/Rystem.DependencyInjection.Web/Fallback/ServiceCollectionExtensions.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Core/Rystem.DependencyInjection.Web/Fallback/ServiceCollectionExtensions.cs)

This README is intentionally architecture-first because `Rystem.DependencyInjection.Web` is not just one extension method. It is a runtime composition model for ASP.NET Core built on top of the base Rystem DI package.
