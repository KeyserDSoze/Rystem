---
name: Rystem - Get Rystem Docs / Content
description: Rystem Framework docs: Content Repository - Azure Blob Storage, Content Repository - Azure File Storage, Content Repository - In-Memory Storage, Content Repository - SharePoint Online and 6 more. Use…
---

# Rystem - Get Rystem Docs / Content

> Auto-generated from Rystem MCP manifest (tool: `get-rystem-docs`, category: `content`)

---

## Content Repository - Azure Blob Storage

> Store files in Azure Blob Storage with Content Repository - perfect for large files, CDN integration, and public access with metadata and tags support

---
title: Content Repository - Azure Blob Storage
description: Store files in Azure Blob Storage with Content Repository - perfect for large files, CDN integration, and public access with metadata and tags support
---

# Content Repository - Azure Blob Storage Integration

Store files in **Azure Blob Storage** using the unified Content Repository interface.

**Best For:**
- Large files (videos, images, backups)
- CDN integration for public access
- Scalable cloud storage
- Static website hosting

---

## Installation

```bash
dotnet add package Rystem.Content.Infrastructure.Storage.Blob --version 9.1.3
```

---

## Configuration

### Basic Setup

```csharp
await services
    .AddContentRepository()
    .WithBlobStorageIntegrationAsync(x =>
    {
        x.ContainerName = "my-container";
        x.ConnectionString = configuration["ConnectionString:Storage"];
    }, "blobstorage")
    .NoContext();
```

### With Prefix

Add a **prefix** to all file paths (like a virtual folder):

```csharp
await services
    .AddContentRepository()
    .WithBlobStorageIntegrationAsync(x =>
    {
        x.ContainerName = "documents";
        x.Prefix = "uploads/2024/";  // All files will be under this prefix
        x.ConnectionString = configuration["ConnectionString:Storage"];
    }, "blobstorage")
    .NoContext();
```

---

## Usage

### Single Integration

```csharp
public class FileService
{
    private readonly IContentRepository _contentRepository;
    
    public FileService(IContentRepository contentRepository)
    {
        _contentRepository = contentRepository;
    }
    
    public async Task UploadImageAsync(string imageName, byte[] imageData)
    {
        await _contentRepository.UploadAsync(
            $"images/{imageName}",
            imageData,
            new ContentRepositoryOptions
            {
                HttpHeaders = new ContentRepositoryHttpHeaders
                {
                    ContentType = "image/png"
                }
            }
        );
    }
}
```

### Multiple Integrations

```csharp
public class FileService
{
    private readonly IContentRepository _blobStorage;
    
    public FileService(IContentRepositoryFactory factory)
    {
        _blobStorage = factory.Create("blobstorage");
    }
}
```

---

## Complete Example

```csharp
public class BlobStorageTest
{
    private readonly IContentRepositoryFactory _factory;
    
    public BlobStorageTest(IContentRepositoryFactory factory)
    {
        _factory = factory;
    }
    
    public async Task ExecuteAsync()
    {
        var _contentRepository = _factory.Create("blobstorage");
        
        // Read file
        var file = await File.ReadAllBytesAsync("document.pdf");
        var name = "folder/document.pdf";
        var contentType = "application/pdf";
        
        var metadata = new Dictionary<string, string>
        {
            { "uploadedBy", "john.doe" },
            { "department", "sales" }
        };
        
        var tags = new Dictionary<string, string>
        {
            { "version", "1.0" },
            { "status", "published" }
        };
        
        // Check if exists
        var exists = await _contentRepository.ExistAsync(name);
        if (exists)
        {
            await _contentRepository.DeleteAsync(name);
        }
        
        // Upload file
        var uploaded = await _contentRepository.UploadAsync(name, file, new ContentRepositoryOptions
        {
            HttpHeaders = new ContentRepositoryHttpHeaders
            {
                ContentType = contentType
            },
            Metadata = metadata,
            Tags = tags
        }, overwrite: true);
        
        Assert.True(uploaded);
        
        // Verify exists
        exists = await _contentRepository.ExistAsync(name);
        Assert.True(exists);
        
        // Get properties
        var properties = await _contentRepository.GetPropertiesAsync(name, ContentInformationType.All);
        
        Assert.NotNull(properties.Uri);
        Assert.Equal(contentType, properties.Options.HttpHeaders.ContentType);
        
        foreach (var kvp in metadata)
        {
            Assert.Equal(kvp.Value, properties.Options.Metadata[kvp.Key]);
        }
        
        foreach (var kvp in tags)
        {
            Assert.Equal(kvp.Value, properties.Options.Tags[kvp.Key]);
        }
        
        // Update metadata
        metadata.Add("modifiedBy", "jane.smith");
        
        var updated = await _contentRepository.SetPropertiesAsync(name, new ContentRepositoryOptions
        {
            Metadata = metadata
        });
        
        Assert.True(updated);
        
        // Verify update
        properties = await _contentRepository.GetPropertiesAsync(name, ContentInformationType.All);
        Assert.Equal("jane.smith", properties.Options.Metadata["modifiedBy"]);
        
        // Download file
        var downloaded = await _contentRepository.DownloadAsync(name);
        Assert.NotNull(downloaded);
        Assert.Equal(file.Length, downloaded.Data.Length);
        
        // Delete file
        var deleted = await _contentRepository.DeleteAsync(name);
        Assert.True(deleted);
        
        // Verify deleted
        exists = await _contentRepository.ExistAsync(name);
        Assert.False(exists);
    }
}
```

---

## Real-World Examples

### Image Upload API

```csharp
[HttpPost("upload/image")]
public async Task<IActionResult> UploadImage(IFormFile file)
{
    if (!file.ContentType.StartsWith("image/"))
        return BadRequest("Only images allowed");
    
    using var memoryStream = new MemoryStream();
    await file.CopyToAsync(memoryStream);
    
    var fileName = $"images/{Guid.NewGuid()}{Path.GetExtension(file.FileName)}";
    
    var success = await _contentRepository.UploadAsync(
        fileName,
        memoryStream.ToArray(),
        new ContentRepositoryOptions
        {
            HttpHeaders = new ContentRepositoryHttpHeaders
            {
                ContentType = file.ContentType,
                CacheControl = "public, max-age=31536000" // 1 year
            },
            Metadata = new Dictionary<string, string>
            {
                { "originalFileName", file.FileName },
                { "uploadedBy", User.Identity?.Name ?? "anonymous" }
            }
        }
    );
    
    if (!success)
        return StatusCode(500);
    
    var properties = await _contentRepository.GetPropertiesAsync(fileName);
    
    return Ok(new 
    { 
        fileName, 
        url = properties?.Uri?.ToString() 
    });
}
```

### Backup Service

```csharp
public class BackupService
{
    private readonly IContentRepository _blobStorage;
    private readonly ILogger<BackupService> _logger;
    
    public BackupService(IContentRepositoryFactory factory, ILogger<BackupService> logger)
    {
        _blobStorage = factory.Create("backups");
        _logger = logger;
    }
    
    public async Task BackupDatabaseAsync(string databaseName)
    {
        var timestamp = DateTime.UtcNow.ToString("yyyyMMdd-HHmmss");
        var backupPath = $"backups/{databaseName}/{timestamp}.bak";
        
        // Generate backup (pseudo-code)
        byte[] backupData = await GenerateBackupAsync(databaseName);
        
        var success = await _blobStorage.UploadAsync(
            backupPath,
            backupData,
            new ContentRepositoryOptions
            {
                Metadata = new Dictionary<string, string>
                {
                    { "databaseName", databaseName },
                    { "backupDate", timestamp },
                    { "size", backupData.Length.ToString() }
                },
                Tags = new Dictionary<string, string>
                {
                    { "type", "database-backup" },
                    { "retention", "30-days" }
                }
            }
        );
        
        if (success)
            _logger.LogInformation("Backup completed: {Path}", backupPath);
        else
            _logger.LogError("Backup failed: {Path}", backupPath);
    }
}
```

### CDN File Delivery

```csharp
public class CdnService
{
    private readonly IContentRepository _cdn;
    
    public CdnService(IContentRepositoryFactory factory)
    {
        _cdn = factory.Create("cdn");
    }
    
    public async Task<string> PublishAssetAsync(string assetName, byte[] content, string contentType)
    {
        var path = $"assets/{assetName}";
        
        await _cdn.UploadAsync(path, content, new ContentRepositoryOptions
        {
            HttpHeaders = new ContentRepositoryHttpHeaders
            {
                ContentType = contentType,
                CacheControl = "public, max-age=31536000, immutable"
            },
            Tags = new Dictionary<string, string>
            {
                { "environment", "production" },
                { "publishedAt", DateTime.UtcNow.ToString("o") }
            }
        });
        
        var properties = await _cdn.GetPropertiesAsync(path);
        
        return properties?.Uri?.ToString() ?? string.Empty;
    }
}
```

---

## Configuration Options

```csharp
public class BlobStorageOptions
{
    public string ContainerName { get; set; }      // Required: Blob container name
    public string Prefix { get; set; }             // Optional: Path prefix for all files
    public string ConnectionString { get; set; }   // Required: Azure Storage connection string
}
```

---

## Benefits

- ✅ **Scalable**: Handles petabytes of data
- ✅ **CDN Integration**: Built-in Azure CDN support
- ✅ **Cost-Effective**: Pay for what you use
- ✅ **Metadata & Tags**: Rich file properties
- ✅ **Access Tiers**: Hot, Cool, Archive
- ✅ **Public Access**: Optional anonymous access

---

## Related Tools

- **[Content Repository Pattern](https://rystem.net/mcp/tools/content-repository.md)** - Main documentation
- **[Azure File Storage](https://rystem.net/mcp/tools/content-repository-file.md)** - File storage integration
- **[SharePoint](https://rystem.net/mcp/tools/content-repository-sharepoint.md)** - SharePoint integration

---

## References

- **NuGet Package**: [Rystem.Content.Infrastructure.Storage.Blob](https://www.nuget.org/packages/Rystem.Content.Infrastructure.Storage.Blob) v9.1.3
- **Documentation**: https://rystem.net
- **GitHub**: https://github.com/KeyserDSoze/Rystem
- **Azure Docs**: https://learn.microsoft.com/azure/storage/blobs/

---

## Content Repository - Azure File Storage

> Store files in Azure File Storage with Content Repository - perfect for SMB shares, legacy applications, and enterprise file sharing with metadata support

---
title: Content Repository - Azure File Storage
description: Store files in Azure File Storage with Content Repository - perfect for SMB shares, legacy applications, and enterprise file sharing with metadata support
---

# Content Repository - Azure File Storage Integration

Store files in **Azure File Storage** using the unified Content Repository interface.

**Best For:**
- SMB/CIFS file shares
- Legacy application migration
- Enterprise file sharing
- Lift-and-shift scenarios

---

## Installation

```bash
dotnet add package Rystem.Content.Infrastructure.Storage.File --version 9.1.3
```

---

## Configuration

### Basic Setup

```csharp
await services
    .AddContentRepository()
    .WithFileStorageIntegrationAsync(x =>
    {
        x.ShareName = "my-share";
        x.ConnectionString = configuration["ConnectionString:Storage"];
    }, "filestorage")
    .NoContext();
```

### With Prefix

Add a **prefix** to all file paths:

```csharp
await services
    .AddContentRepository()
    .WithFileStorageIntegrationAsync(x =>
    {
        x.ShareName = "company-files";
        x.Prefix = "departments/sales/";
        x.ConnectionString = configuration["ConnectionString:Storage"];
    }, "filestorage")
    .NoContext();
```

---

## Usage

### Single Integration

```csharp
public class DocumentService
{
    private readonly IContentRepository _contentRepository;
    
    public DocumentService(IContentRepository contentRepository)
    {
        _contentRepository = contentRepository;
    }
    
    public async Task SaveDocumentAsync(string documentName, byte[] data)
    {
        await _contentRepository.UploadAsync(
            $"documents/{documentName}",
            data,
            new ContentRepositoryOptions
            {
                HttpHeaders = new ContentRepositoryHttpHeaders
                {
                    ContentType = "application/pdf"
                }
            }
        );
    }
}
```

### Multiple Integrations

```csharp
public class FileService
{
    private readonly IContentRepository _fileStorage;
    
    public FileService(IContentRepositoryFactory factory)
    {
        _fileStorage = factory.Create("filestorage");
    }
}
```

---

## Complete Example

```csharp
public class FileStorageTest
{
    private readonly IContentRepositoryFactory _factory;
    
    public FileStorageTest(IContentRepositoryFactory factory)
    {
        _factory = factory;
    }
    
    public async Task ExecuteAsync()
    {
        var _contentRepository = _factory.Create("filestorage");
        
        // Read file
        var file = await File.ReadAllBytesAsync("report.xlsx");
        var name = "reports/2024/Q1/report.xlsx";
        var contentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
        
        var metadata = new Dictionary<string, string>
        {
            { "department", "finance" },
            { "quarter", "Q1" },
            { "year", "2024" }
        };
        
        var tags = new Dictionary<string, string>
        {
            { "reportType", "quarterly" },
            { "status", "final" }
        };
        
        // Check if exists
        var exists = await _contentRepository.ExistAsync(name);
        if (exists)
        {
            await _contentRepository.DeleteAsync(name);
        }
        
        // Upload file
        var uploaded = await _contentRepository.UploadAsync(name, file, new ContentRepositoryOptions
        {
            HttpHeaders = new ContentRepositoryHttpHeaders
            {
                ContentType = contentType
            },
            Metadata = metadata,
            Tags = tags
        }, overwrite: true);
        
        Assert.True(uploaded);
        
        // Verify exists
        exists = await _contentRepository.ExistAsync(name);
        Assert.True(exists);
        
        // Get properties
        var properties = await _contentRepository.GetPropertiesAsync(name, ContentInformationType.All);
        
        Assert.NotNull(properties.Uri);
        Assert.Equal(contentType, properties.Options.HttpHeaders.ContentType);
        
        foreach (var kvp in metadata)
        {
            Assert.Equal(kvp.Value, properties.Options.Metadata[kvp.Key]);
        }
        
        foreach (var kvp in tags)
        {
            Assert.Equal(kvp.Value, properties.Options.Tags[kvp.Key]);
        }
        
        // Update metadata
        metadata.Add("reviewed", "true");
        
        var updated = await _contentRepository.SetPropertiesAsync(name, new ContentRepositoryOptions
        {
            Metadata = metadata
        });
        
        Assert.True(updated);
        
        // Verify update
        properties = await _contentRepository.GetPropertiesAsync(name, ContentInformationType.All);
        Assert.Equal("true", properties.Options.Metadata["reviewed"]);
        
        // Download file
        var downloaded = await _contentRepository.DownloadAsync(name);
        Assert.NotNull(downloaded);
        Assert.Equal(file.Length, downloaded.Data.Length);
        
        // Delete file
        var deleted = await _contentRepository.DeleteAsync(name);
        Assert.True(deleted);
        
        // Verify deleted
        exists = await _contentRepository.ExistAsync(name);
        Assert.False(exists);
    }
}
```

---

## Real-World Examples

### Department File Sharing

```csharp
public class DepartmentFileService
{
    private readonly IContentRepository _fileShare;
    private readonly ILogger<DepartmentFileService> _logger;
    
    public DepartmentFileService(IContentRepositoryFactory factory, ILogger<DepartmentFileService> logger)
    {
        _fileShare = factory.Create("departments");
        _logger = logger;
    }
    
    public async Task ShareFileWithDepartmentAsync(string department, string fileName, byte[] fileData)
    {
        var path = $"{department}/shared/{fileName}";
        
        var success = await _fileShare.UploadAsync(
            path,
            fileData,
            new ContentRepositoryOptions
            {
                Metadata = new Dictionary<string, string>
                {
                    { "department", department },
                    { "sharedBy", "admin" },
                    { "sharedDate", DateTime.UtcNow.ToString("o") }
                },
                Tags = new Dictionary<string, string>
                {
                    { "access", "department-wide" }
                }
            }
        );
        
        if (success)
            _logger.LogInformation("File shared with {Department}: {FileName}", department, fileName);
    }
    
    public async Task<List<string>> ListDepartmentFilesAsync(string department)
    {
        var files = new List<string>();
        
        await foreach (var file in _fileShare.ListAsync(
            prefix: $"{department}/",
            downloadContent: false
        ))
        {
            files.Add(file.Path);
        }
        
        return files;
    }
}
```

### Legacy Application Migration

```csharp
public class LegacyFileService
{
    private readonly IContentRepository _fileStorage;
    
    public LegacyFileService(IContentRepositoryFactory factory)
    {
        _fileStorage = factory.Create("legacy-files");
    }
    
    public async Task MigrateLegacyFileAsync(string sourcePath)
    {
        // Read from local file system (legacy)
        var fileData = await File.ReadAllBytesAsync(sourcePath);
        var fileName = Path.GetFileName(sourcePath);
        
        // Upload to Azure File Storage
        var cloudPath = $"migrated/{fileName}";
        
        await _fileStorage.UploadAsync(
            cloudPath,
            fileData,
            new ContentRepositoryOptions
            {
                Metadata = new Dictionary<string, string>
                {
                    { "sourcePath", sourcePath },
                    { "migratedAt", DateTime.UtcNow.ToString("o") },
                    { "originalSize", fileData.Length.ToString() }
                },
                Tags = new Dictionary<string, string>
                {
                    { "migration", "legacy-to-cloud" }
                }
            }
        );
    }
}
```

### Report Archive

```csharp
public class ReportArchiveService
{
    private readonly IContentRepository _archive;
    
    public ReportArchiveService(IContentRepositoryFactory factory)
    {
        _archive = factory.Create("report-archive");
    }
    
    public async Task ArchiveReportAsync(string reportType, int year, int month, byte[] reportData)
    {
        var path = $"{reportType}/{year}/{month:D2}/report.pdf";
        
        await _archive.UploadAsync(
            path,
            reportData,
            new ContentRepositoryOptions
            {
                HttpHeaders = new ContentRepositoryHttpHeaders
                {
                    ContentType = "application/pdf"
                },
                Metadata = new Dictionary<string, string>
                {
                    { "reportType", reportType },
                    { "year", year.ToString() },
                    { "month", month.ToString() },
                    { "archivedAt", DateTime.UtcNow.ToString("o") }
                }
            }
        );
    }
    
    public async Task<byte[]?> RetrieveReportAsync(string reportType, int year, int month)
    {
        var path = $"{reportType}/{year}/{month:D2}/report.pdf";
        
        var result = await _archive.DownloadAsync(path);
        
        return result?.Data;
    }
}
```

---

## Configuration Options

```csharp
public class FileStorageOptions
{
    public string ShareName { get; set; }          // Required: File share name
    public string Prefix { get; set; }             // Optional: Path prefix for all files
    public string ConnectionString { get; set; }   // Required: Azure Storage connection string
}
```

---

## Benefits

- ✅ **SMB Compatible**: Mount as network drive
- ✅ **Enterprise Ready**: AD/LDAP integration
- ✅ **Lift-and-Shift**: Easy migration from on-premises
- ✅ **Metadata Support**: Rich file properties
- ✅ **Hierarchical**: Folder structure support
- ✅ **Cross-Platform**: Windows, Linux, macOS

---

## Related Tools

- **[Content Repository Pattern](https://rystem.net/mcp/tools/content-repository.md)** - Main documentation
- **[Azure Blob Storage](https://rystem.net/mcp/tools/content-repository-blob.md)** - Blob storage integration
- **[SharePoint](https://rystem.net/mcp/tools/content-repository-sharepoint.md)** - SharePoint integration

---

## References

- **NuGet Package**: [Rystem.Content.Infrastructure.Storage.File](https://www.nuget.org/packages/Rystem.Content.Infrastructure.Storage.File) v9.1.3
- **Documentation**: https://rystem.net
- **GitHub**: https://github.com/KeyserDSoze/Rystem
- **Azure Docs**: https://learn.microsoft.com/azure/storage/files/

---

## Content Repository - In-Memory Storage

> Store files in memory with Content Repository - perfect for unit testing, caching, and development without external dependencies

---
title: Content Repository - In-Memory Storage
description: Store files in memory with Content Repository - perfect for unit testing, caching, and development without external dependencies
---

# Content Repository - In-Memory Storage Integration

Store files **in memory** using the unified Content Repository interface.

**Best For:**
- Unit testing
- Development/debugging
- Temporary caching
- CI/CD pipelines
- No external dependencies

---

## Installation

```bash
dotnet add package Rystem.Content.Infrastructure.InMemory --version 9.1.3
```

---

## Configuration

### Basic Setup

```csharp
services
    .AddContentRepository()
    .WithInMemoryIntegration("inmemory");
```

**Note:** No connection string or configuration needed! Files are stored in RAM.

---

## Usage

### Single Integration

```csharp
public class FileService
{
    private readonly IContentRepository _contentRepository;
    
    public FileService(IContentRepository contentRepository)
    {
        _contentRepository = contentRepository;
    }
    
    public async Task CacheFileAsync(string fileName, byte[] data)
    {
        await _contentRepository.UploadAsync(fileName, data);
    }
}
```

### Multiple Integrations

```csharp
public class FileService
{
    private readonly IContentRepository _cache;
    
    public FileService(IContentRepositoryFactory factory)
    {
        _cache = factory.Create("inmemory");
    }
}
```

---

## Complete Example

```csharp
public class InMemoryTest
{
    private readonly IContentRepositoryFactory _factory;
    
    public InMemoryTest(IContentRepositoryFactory factory)
    {
        _factory = factory;
    }
    
    public async Task ExecuteAsync()
    {
        var _contentRepository = _factory.Create("inmemory");
        
        // Create test data
        var file = new byte[] { 1, 2, 3, 4, 5 };
        var name = "test-file.bin";
        var contentType = "application/octet-stream";
        
        var metadata = new Dictionary<string, string>
        {
            { "test", "value" },
            { "created", DateTime.UtcNow.ToString("o") }
        };
        
        var tags = new Dictionary<string, string>
        {
            { "environment", "test" },
            { "temporary", "true" }
        };
        
        // Check if exists (should be false initially)
        var exists = await _contentRepository.ExistAsync(name);
        Assert.False(exists);
        
        // Upload file
        var uploaded = await _contentRepository.UploadAsync(name, file, new ContentRepositoryOptions
        {
            HttpHeaders = new ContentRepositoryHttpHeaders
            {
                ContentType = contentType
            },
            Metadata = metadata,
            Tags = tags
        }, overwrite: true);
        
        Assert.True(uploaded);
        
        // Verify exists
        exists = await _contentRepository.ExistAsync(name);
        Assert.True(exists);
        
        // Get properties
        var properties = await _contentRepository.GetPropertiesAsync(name, ContentInformationType.All);
        
        Assert.NotNull(properties.Uri);
        Assert.Equal(contentType, properties.Options.HttpHeaders.ContentType);
        
        foreach (var kvp in metadata)
        {
            Assert.Equal(kvp.Value, properties.Options.Metadata[kvp.Key]);
        }
        
        foreach (var kvp in tags)
        {
            Assert.Equal(kvp.Value, properties.Options.Tags[kvp.Key]);
        }
        
        // Update metadata
        metadata.Add("updated", "true");
        
        var updated = await _contentRepository.SetPropertiesAsync(name, new ContentRepositoryOptions
        {
            Metadata = metadata
        });
        
        Assert.True(updated);
        
        // Verify update
        properties = await _contentRepository.GetPropertiesAsync(name, ContentInformationType.All);
        Assert.Equal("true", properties.Options.Metadata["updated"]);
        
        // Download file
        var downloaded = await _contentRepository.DownloadAsync(name);
        Assert.NotNull(downloaded);
        Assert.Equal(file.Length, downloaded.Data.Length);
        
        // Delete file
        var deleted = await _contentRepository.DeleteAsync(name);
        Assert.True(deleted);
        
        // Verify deleted
        exists = await _contentRepository.ExistAsync(name);
        Assert.False(exists);
    }
}
```

---

## Real-World Examples

### Unit Testing

```csharp
public class FileServiceTests
{
    private readonly IContentRepository _contentRepository;
    
    public FileServiceTests()
    {
        var services = new ServiceCollection();
        services
            .AddContentRepository()
            .WithInMemoryIntegration("test");
        
        var provider = services.BuildServiceProvider();
        _contentRepository = provider.GetRequiredService<IContentRepository>();
    }
    
    [Fact]
    public async Task UploadFile_ShouldStoreInMemory()
    {
        // Arrange
        var fileName = "test.txt";
        var fileData = Encoding.UTF8.GetBytes("Hello, World!");
        
        // Act
        var success = await _contentRepository.UploadAsync(fileName, fileData);
        
        // Assert
        Assert.True(success);
        
        var exists = await _contentRepository.ExistAsync(fileName);
        Assert.True(exists);
        
        var downloaded = await _contentRepository.DownloadAsync(fileName);
        Assert.Equal(fileData, downloaded.Data);
    }
    
    [Fact]
    public async Task DeleteFile_ShouldRemoveFromMemory()
    {
        // Arrange
        var fileName = "test.txt";
        var fileData = Encoding.UTF8.GetBytes("Test");
        await _contentRepository.UploadAsync(fileName, fileData);
        
        // Act
        var deleted = await _contentRepository.DeleteAsync(fileName);
        
        // Assert
        Assert.True(deleted);
        
        var exists = await _contentRepository.ExistAsync(fileName);
        Assert.False(exists);
    }
}
```

### Temporary File Cache

```csharp
public class FileCacheService
{
    private readonly IContentRepository _cache;
    private readonly IContentRepository _permanent;
    
    public FileCacheService(IContentRepositoryFactory factory)
    {
        _cache = factory.Create("inmemory");       // Fast in-memory cache
        _permanent = factory.Create("blobstorage"); // Permanent Azure Blob
    }
    
    public async Task<byte[]> GetFileAsync(string fileName)
    {
        // Try cache first
        var cached = await _cache.DownloadAsync(fileName);
        if (cached != null)
        {
            return cached.Data;
        }
        
        // Load from permanent storage
        var permanent = await _permanent.DownloadAsync(fileName);
        if (permanent != null)
        {
            // Cache for next time
            await _cache.UploadAsync(fileName, permanent.Data);
            return permanent.Data;
        }
        
        return Array.Empty<byte>();
    }
    
    public async Task SaveFileAsync(string fileName, byte[] data)
    {
        // Save to permanent storage
        await _permanent.UploadAsync(fileName, data);
        
        // Also cache
        await _cache.UploadAsync(fileName, data);
    }
}
```

### Development Mock

```csharp
public class DevelopmentFileService
{
    private readonly IContentRepository _files;
    
    public DevelopmentFileService(IContentRepositoryFactory factory, IHostEnvironment env)
    {
        // Use in-memory in Development, Azure Blob in Production
        _files = env.IsDevelopment() 
            ? factory.Create("inmemory")
            : factory.Create("production-blob");
    }
    
    public async Task UploadUserAvatarAsync(Guid userId, byte[] imageData)
    {
        await _files.UploadAsync(
            $"avatars/{userId}.jpg",
            imageData,
            new ContentRepositoryOptions
            {
                HttpHeaders = new ContentRepositoryHttpHeaders
                {
                    ContentType = "image/jpeg"
                }
            }
        );
    }
}

// Startup configuration
if (builder.Environment.IsDevelopment())
{
    services
        .AddContentRepository()
        .WithInMemoryIntegration("inmemory");
}
else
{
    await services
        .AddContentRepository()
        .WithBlobStorageIntegrationAsync(x =>
        {
            x.ContainerName = "user-avatars";
            x.ConnectionString = configuration["Azure:Storage"];
        }, "production-blob")
        .NoContext();
}
```

### CI/CD Pipeline Testing

```csharp
public class IntegrationTests : IClassFixture<WebApplicationFactory<Program>>
{
    private readonly WebApplicationFactory<Program> _factory;
    
    public IntegrationTests(WebApplicationFactory<Program> factory)
    {
        _factory = factory.WithWebHostBuilder(builder =>
        {
            builder.ConfigureServices(services =>
            {
                // Replace real storage with in-memory for tests
                services
                    .AddContentRepository()
                    .WithInMemoryIntegration("test-storage");
            });
        });
    }
    
    [Fact]
    public async Task UploadFile_ShouldSucceed()
    {
        var client = _factory.CreateClient();
        
        var content = new MultipartFormDataContent();
        content.Add(new ByteArrayContent(new byte[] { 1, 2, 3 }), "file", "test.bin");
        
        var response = await client.PostAsync("/api/files/upload", content);
        
        response.EnsureSuccessStatusCode();
    }
}
```

### Session Storage

```csharp
public class SessionFileService
{
    private readonly IContentRepository _sessionStorage;
    private readonly IHttpContextAccessor _httpContext;
    
    public SessionFileService(IContentRepositoryFactory factory, IHttpContextAccessor httpContext)
    {
        _sessionStorage = factory.Create("session");
        _httpContext = httpContext;
    }
    
    public async Task SaveSessionFileAsync(string fileName, byte[] data)
    {
        var sessionId = _httpContext.HttpContext?.Session.Id;
        var path = $"{sessionId}/{fileName}";
        
        await _sessionStorage.UploadAsync(
            path,
            data,
            new ContentRepositoryOptions
            {
                Tags = new Dictionary<string, string>
                {
                    { "expiresAt", DateTime.UtcNow.AddHours(1).ToString("o") }
                }
            }
        );
    }
    
    public async Task<byte[]?> GetSessionFileAsync(string fileName)
    {
        var sessionId = _httpContext.HttpContext?.Session.Id;
        var path = $"{sessionId}/{fileName}";
        
        var result = await _sessionStorage.DownloadAsync(path);
        return result?.Data;
    }
}
```

---

## Benefits

- ✅ **No Dependencies**: Works without Azure, AWS, or any external service
- ✅ **Fast**: Files stored in RAM for instant access
- ✅ **Simple Setup**: No configuration needed
- ✅ **Perfect for Tests**: No cleanup, fresh state each test run
- ✅ **Development**: No costs, no credentials
- ✅ **CI/CD**: Works in any environment

---

## Limitations

- ⚠️ **Not Persistent**: Data lost when application restarts
- ⚠️ **Memory Usage**: Large files consume RAM
- ⚠️ **Single Instance**: Not shared across app instances
- ⚠️ **Production**: Not suitable for production use

---

## Related Tools

- **[Content Repository Pattern](https://rystem.net/mcp/tools/content-repository.md)** - Main documentation
- **[Azure Blob Storage](https://rystem.net/mcp/tools/content-repository-blob.md)** - Production storage
- **[Azure File Storage](https://rystem.net/mcp/tools/content-repository-file.md)** - File share storage

---

## References

- **NuGet Package**: [Rystem.Content.Infrastructure.InMemory](https://www.nuget.org/packages/Rystem.Content.Infrastructure.InMemory) v9.1.3
- **Documentation**: https://rystem.net
- **GitHub**: https://github.com/KeyserDSoze/Rystem

---

## Content Repository - SharePoint Online

> Store files in SharePoint Online with Content Repository - perfect for document collaboration, Office 365 integration, and enterprise content management with metadata support

---
title: Content Repository - SharePoint Online
description: Store files in SharePoint Online with Content Repository - perfect for document collaboration, Office 365 integration, and enterprise content management with metadata support
---

# Content Repository - SharePoint Online Integration

Store files in **SharePoint Online** using the unified Content Repository interface.

**Best For:**
- Document collaboration with Office 365
- Enterprise content management
- Team sites and document libraries
- Compliance and governance
- Microsoft ecosystem integration

---

## Installation

```bash
dotnet add package Rystem.Content.Infrastructure.M365.Sharepoint --version 9.1.3
```

---

## Prerequisites

### Azure AD App Registration

1. Go to **Azure Portal** → **Azure Active Directory** → **App registrations**
2. Create new registration
3. Copy **Tenant ID**, **Client ID**
4. Create **Client Secret** (copy the value)
5. Grant API permissions:
   - **Microsoft Graph** → `Sites.ReadWrite.All`
   - Grant admin consent

### Get Site and Library IDs

Get SharePoint site information:

```
https://<tenant>.sharepoint.com/sites/<site-url>/_api/site/id
```

---

## Configuration

### By Site Name and Document Library Name

```csharp
await services
    .AddContentRepository()
    .WithSharepointIntegrationAsync(x =>
    {
        x.TenantId = configuration["Sharepoint:TenantId"];
        x.ClientId = configuration["Sharepoint:ClientId"];
        x.ClientSecret = configuration["Sharepoint:ClientSecret"];
        x.MapWithSiteNameAndDocumentLibraryName("TeamSite", "Documents");
    }, "sharepoint")
    .NoContext();
```

### By Root Site

```csharp
await services
    .AddContentRepository()
    .WithSharepointIntegrationAsync(x =>
    {
        x.TenantId = configuration["Sharepoint:TenantId"];
        x.ClientId = configuration["Sharepoint:ClientId"];
        x.ClientSecret = configuration["Sharepoint:ClientSecret"];
        x.MapWithRootSiteAndDocumentLibraryName("SharedDocuments");
    }, "sharepoint")
    .NoContext();
```

### By Site ID and Library ID

```csharp
await services
    .AddContentRepository()
    .WithSharepointIntegrationAsync(x =>
    {
        x.TenantId = configuration["Sharepoint:TenantId"];
        x.ClientId = configuration["Sharepoint:ClientId"];
        x.ClientSecret = configuration["Sharepoint:ClientSecret"];
        x.MapWithSiteIdAndDocumentLibraryId(
            configuration["Sharepoint:SiteId"],
            configuration["Sharepoint:DocumentLibraryId"]
        );
    }, "sharepoint")
    .NoContext();
```

---

## Usage

### Single Integration

```csharp
public class DocumentService
{
    private readonly IContentRepository _contentRepository;
    
    public DocumentService(IContentRepository contentRepository)
    {
        _contentRepository = contentRepository;
    }
    
    public async Task UploadDocumentAsync(string documentName, byte[] data)
    {
        await _contentRepository.UploadAsync(
            $"contracts/{documentName}",
            data,
            new ContentRepositoryOptions
            {
                HttpHeaders = new ContentRepositoryHttpHeaders
                {
                    ContentType = "application/pdf"
                }
            }
        );
    }
}
```

### Multiple Integrations

```csharp
public class MultiSiteService
{
    private readonly IContentRepository _hrSite;
    private readonly IContentRepository _salesSite;
    
    public MultiSiteService(IContentRepositoryFactory factory)
    {
        _hrSite = factory.Create("hr-sharepoint");
        _salesSite = factory.Create("sales-sharepoint");
    }
}
```

---

## Complete Example

```csharp
public class SharepointTest
{
    private readonly IContentRepositoryFactory _factory;
    
    public SharepointTest(IContentRepositoryFactory factory)
    {
        _factory = factory;
    }
    
    public async Task ExecuteAsync()
    {
        var _contentRepository = _factory.Create("sharepoint");
        
        // Read file
        var file = await File.ReadAllBytesAsync("contract.pdf");
        var name = "legal/contracts/contract-2024.pdf";
        var contentType = "application/pdf";
        
        var metadata = new Dictionary<string, string>
        {
            { "department", "legal" },
            { "contractType", "employment" },
            { "year", "2024" }
        };
        
        var tags = new Dictionary<string, string>
        {
            { "status", "active" },
            { "confidential", "true" }
        };
        
        // Check if exists
        var exists = await _contentRepository.ExistAsync(name);
        if (exists)
        {
            await _contentRepository.DeleteAsync(name);
        }
        
        // Upload file
        var uploaded = await _contentRepository.UploadAsync(name, file, new ContentRepositoryOptions
        {
            HttpHeaders = new ContentRepositoryHttpHeaders
            {
                ContentType = contentType
            },
            Metadata = metadata,
            Tags = tags
        }, overwrite: true);
        
        Assert.True(uploaded);
        
        // Verify exists
        exists = await _contentRepository.ExistAsync(name);
        Assert.True(exists);
        
        // Get properties
        var properties = await _contentRepository.GetPropertiesAsync(name, ContentInformationType.All);
        
        Assert.NotNull(properties.Uri);
        Assert.Equal(contentType, properties.Options.HttpHeaders.ContentType);
        
        foreach (var kvp in metadata)
        {
            Assert.Equal(kvp.Value, properties.Options.Metadata[kvp.Key]);
        }
        
        foreach (var kvp in tags)
        {
            Assert.Equal(kvp.Value, properties.Options.Tags[kvp.Key]);
        }
        
        // Update metadata
        metadata.Add("reviewed", "true");
        metadata.Add("reviewedBy", "legal-team");
        
        var updated = await _contentRepository.SetPropertiesAsync(name, new ContentRepositoryOptions
        {
            Metadata = metadata
        });
        
        Assert.True(updated);
        
        // Verify update
        properties = await _contentRepository.GetPropertiesAsync(name, ContentInformationType.All);
        Assert.Equal("true", properties.Options.Metadata["reviewed"]);
        Assert.Equal("legal-team", properties.Options.Metadata["reviewedBy"]);
        
        // Download file
        var downloaded = await _contentRepository.DownloadAsync(name);
        Assert.NotNull(downloaded);
        Assert.Equal(file.Length, downloaded.Data.Length);
        
        // Delete file
        var deleted = await _contentRepository.DeleteAsync(name);
        Assert.True(deleted);
        
        // Verify deleted
        exists = await _contentRepository.ExistAsync(name);
        Assert.False(exists);
    }
}
```

---

## Real-World Examples

### Contract Management

```csharp
public class ContractService
{
    private readonly IContentRepository _sharepoint;
    private readonly ILogger<ContractService> _logger;
    
    public ContractService(IContentRepositoryFactory factory, ILogger<ContractService> logger)
    {
        _sharepoint = factory.Create("legal-docs");
        _logger = logger;
    }
    
    public async Task UploadContractAsync(string contractName, byte[] pdfData, string contractType)
    {
        var year = DateTime.UtcNow.Year;
        var path = $"Contracts/{year}/{contractType}/{contractName}.pdf";
        
        var success = await _sharepoint.UploadAsync(
            path,
            pdfData,
            new ContentRepositoryOptions
            {
                HttpHeaders = new ContentRepositoryHttpHeaders
                {
                    ContentType = "application/pdf"
                },
                Metadata = new Dictionary<string, string>
                {
                    { "contractType", contractType },
                    { "year", year.ToString() },
                    { "uploadedBy", "contract-system" },
                    { "uploadedDate", DateTime.UtcNow.ToString("o") }
                },
                Tags = new Dictionary<string, string>
                {
                    { "department", "legal" },
                    { "status", "pending-review" }
                }
            }
        );
        
        if (success)
            _logger.LogInformation("Contract uploaded to SharePoint: {Path}", path);
        else
            _logger.LogError("Failed to upload contract: {Path}", path);
    }
    
    public async Task<List<string>> ListActiveContractsAsync()
    {
        var contracts = new List<string>();
        
        await foreach (var file in _sharepoint.ListAsync(
            prefix: "Contracts/",
            downloadContent: false,
            informationRetrieve: ContentInformationType.Tags
        ))
        {
            if (file.Options.Tags.TryGetValue("status", out var status) && status == "active")
            {
                contracts.Add(file.Path);
            }
        }
        
        return contracts;
    }
}
```

### Team Document Collaboration

```csharp
public class TeamDocumentService
{
    private readonly IContentRepository _teamSite;
    
    public TeamDocumentService(IContentRepositoryFactory factory)
    {
        _teamSite = factory.Create("team-site");
    }
    
    public async Task ShareDocumentWithTeamAsync(string teamName, string documentName, byte[] documentData)
    {
        var path = $"Teams/{teamName}/Shared/{documentName}";
        
        await _teamSite.UploadAsync(
            path,
            documentData,
            new ContentRepositoryOptions
            {
                HttpHeaders = new ContentRepositoryHttpHeaders
                {
                    ContentType = GetContentType(documentName)
                },
                Metadata = new Dictionary<string, string>
                {
                    { "team", teamName },
                    { "sharedBy", "document-system" },
                    { "sharedDate", DateTime.UtcNow.ToString("o") }
                },
                Tags = new Dictionary<string, string>
                {
                    { "access", "team-only" },
                    { "collaborative", "true" }
                }
            }
        );
    }
    
    private string GetContentType(string fileName)
    {
        return Path.GetExtension(fileName).ToLower() switch
        {
            ".pdf" => "application/pdf",
            ".docx" => "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            ".xlsx" => "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            ".pptx" => "application/vnd.openxmlformats-officedocument.presentationml.presentation",
            _ => "application/octet-stream"
        };
    }
}
```

### Compliance and Audit Trail

```csharp
public class ComplianceDocumentService
{
    private readonly IContentRepository _compliance;
    private readonly IAuditLogger _auditLogger;
    
    public ComplianceDocumentService(IContentRepositoryFactory factory, IAuditLogger auditLogger)
    {
        _compliance = factory.Create("compliance-docs");
        _auditLogger = auditLogger;
    }
    
    public async Task ArchiveComplianceDocumentAsync(
        string documentName, 
        byte[] data, 
        string department,
        DateTime retentionUntil)
    {
        var path = $"Compliance/{DateTime.UtcNow.Year}/{department}/{documentName}";
        
        var success = await _compliance.UploadAsync(
            path,
            data,
            new ContentRepositoryOptions
            {
                HttpHeaders = new ContentRepositoryHttpHeaders
                {
                    ContentType = "application/pdf"
                },
                Metadata = new Dictionary<string, string>
                {
                    { "department", department },
                    { "archivedDate", DateTime.UtcNow.ToString("o") },
                    { "retentionUntil", retentionUntil.ToString("o") },
                    { "compliance", "true" }
                },
                Tags = new Dictionary<string, string>
                {
                    { "retention-policy", "7-years" },
                    { "confidential", "true" }
                }
            }
        );
        
        if (success)
        {
            await _auditLogger.LogAsync(new AuditEntry
            {
                Action = "Document Archived",
                Resource = path,
                Department = department,
                Timestamp = DateTime.UtcNow
            });
        }
    }
}
```

### Multi-Site Document Distribution

```csharp
public class DocumentDistributionService
{
    private readonly IContentRepositoryFactory _factory;
    
    public DocumentDistributionService(IContentRepositoryFactory factory)
    {
        _factory = factory;
    }
    
    public async Task DistributeToAllSitesAsync(string documentName, byte[] data)
    {
        var sites = new[] { "hr-site", "finance-site", "it-site" };
        
        await TaskManager.WhenAll(
            async (index, cancellationToken) =>
            {
                var siteName = sites[index];
                var repository = _factory.Create(siteName);
                
                await repository.UploadAsync(
                    $"Shared/{documentName}",
                    data,
                    new ContentRepositoryOptions
                    {
                        Metadata = new Dictionary<string, string>
                        {
                            { "distributedTo", siteName },
                            { "distributedDate", DateTime.UtcNow.ToString("o") }
                        }
                    }
                );
            },
            times: sites.Length,
            concurrentTasks: 3,
            runEverytimeASlotIsFree: true
        ).NoContext();
    }
}
```

---

## Configuration Options

```csharp
public class SharepointOptions
{
    public string TenantId { get; set; }           // Required: Azure AD Tenant ID
    public string ClientId { get; set; }           // Required: App Registration Client ID
    public string ClientSecret { get; set; }       // Required: App Registration Secret
    
    // Choose ONE mapping method:
    public void MapWithSiteNameAndDocumentLibraryName(string siteName, string libraryName);
    public void MapWithRootSiteAndDocumentLibraryName(string libraryName);
    public void MapWithSiteIdAndDocumentLibraryId(string siteId, string libraryId);
}
```

---

## Benefits

- ✅ **Office 365 Integration**: Works with Microsoft ecosystem
- ✅ **Collaboration**: Real-time co-authoring with Office Online
- ✅ **Versioning**: Built-in document version control
- ✅ **Compliance**: DLP, retention policies, eDiscovery
- ✅ **Search**: Powerful enterprise search
- ✅ **Permissions**: Granular access control

---

## Related Tools

- **[Content Repository Pattern](https://rystem.net/mcp/tools/content-repository.md)** - Main documentation
- **[Azure Blob Storage](https://rystem.net/mcp/tools/content-repository-blob.md)** - Alternative cloud storage
- **[Content Migration](https://rystem.net/mcp/tools/content-repository.md#migration-tool)** - Migrate from/to SharePoint

---

## References

- **NuGet Package**: [Rystem.Content.Infrastructure.M365.Sharepoint](https://www.nuget.org/packages/Rystem.Content.Infrastructure.M365.Sharepoint) v9.1.3
- **Documentation**: https://rystem.net
- **GitHub**: https://github.com/KeyserDSoze/Rystem
- **SharePoint API**: https://learn.microsoft.com/sharepoint/dev/

---

## Content Repository Pattern

> Unified interface for file storage across multiple providers - upload, download, delete files with metadata and tags support for Azure Blob Storage, Azure File Storage, SharePoint, and In-Memory storage

---
title: Content Repository Pattern
description: Unified interface for file storage across multiple providers - upload, download, delete files with metadata and tags support for Azure Blob Storage, Azure File Storage, SharePoint, and In-Memory storage
---

# Content Repository Pattern

**Unified interface** for managing **file storage** across multiple storage providers (Azure Blob Storage, Azure File Storage, SharePoint, In-Memory).

---

## What is Content Repository?

Content Repository provides a **consistent API** for file operations regardless of the underlying storage provider. Switch between Azure Blob, SharePoint, or local file storage without changing your business logic.

**Key Features:**
- ✅ Upload, download, delete files
- ✅ Metadata and tags support
- ✅ Multiple storage providers
- ✅ Migration tool between providers
- ✅ Factory pattern for multiple integrations

---

## Installation

```bash
# Core package
dotnet add package Rystem.Content.Abstractions --version 9.1.3

# Choose your integration(s)
dotnet add package Rystem.Content.Infrastructure.Storage.Blob --version 9.1.3
dotnet add package Rystem.Content.Infrastructure.Storage.File --version 9.1.3
dotnet add package Rystem.Content.Infrastructure.M365.Sharepoint --version 9.1.3
dotnet add package Rystem.Content.Infrastructure.InMemory --version 9.1.3
```

---

## Quick Start

### 1. Register Single Integration

```csharp
services
    .AddContentRepository()
    .WithInMemoryIntegration("inmemory");
```

### 2. Use in Business Class

```csharp
public class FileService
{
    private readonly IContentRepository _contentRepository;
    
    public FileService(IContentRepository contentRepository)
    {
        _contentRepository = contentRepository;
    }
    
    public async Task UploadFileAsync(string fileName, byte[] data)
    {
        await _contentRepository.UploadAsync(fileName, data);
    }
    
    public async Task<byte[]> DownloadFileAsync(string fileName)
    {
        var result = await _contentRepository.DownloadAsync(fileName);
        return result?.Data ?? Array.Empty<byte>();
    }
}
```

---

## Core Operations

### Upload File

```csharp
var data = File.ReadAllBytes("document.pdf");

var success = await _contentRepository.UploadAsync(
    path: "folder/document.pdf",
    data: data,
    options: new ContentRepositoryOptions
    {
        HttpHeaders = new ContentRepositoryHttpHeaders
        {
            ContentType = "application/pdf"
        },
        Metadata = new Dictionary<string, string>
        {
            { "uploadedBy", "user123" },
            { "department", "sales" }
        },
        Tags = new Dictionary<string, string>
        {
            { "version", "1.0" },
            { "status", "draft" }
        }
    },
    overwrite: true
);
```

### Download File

```csharp
var result = await _contentRepository.DownloadAsync(
    path: "folder/document.pdf",
    informationRetrieve: ContentInformationType.All
);

if (result != null)
{
    byte[] fileData = result.Data;
    string contentType = result.Options.HttpHeaders.ContentType;
    var metadata = result.Options.Metadata;
    var tags = result.Options.Tags;
}
```

### Check if File Exists

```csharp
bool exists = await _contentRepository.ExistAsync("folder/document.pdf");
```

### Get File Properties

```csharp
var properties = await _contentRepository.GetPropertiesAsync(
    path: "folder/document.pdf",
    informationRetrieve: ContentInformationType.All
);

if (properties != null)
{
    Uri fileUri = properties.Uri;
    var metadata = properties.Options.Metadata;
    var tags = properties.Options.Tags;
    string contentType = properties.Options.HttpHeaders.ContentType;
}
```

### Update File Properties

```csharp
var success = await _contentRepository.SetPropertiesAsync(
    path: "folder/document.pdf",
    options: new ContentRepositoryOptions
    {
        Metadata = new Dictionary<string, string>
        {
            { "status", "published" },
            { "publishedDate", DateTime.UtcNow.ToString("o") }
        }
    }
);
```

### Delete File

```csharp
var success = await _contentRepository.DeleteAsync("folder/document.pdf");
```

### List Files

```csharp
await foreach (var file in _contentRepository.ListAsync(
    prefix: "folder/",
    downloadContent: false,
    informationRetrieve: ContentInformationType.All
))
{
    Console.WriteLine($"File: {file.Path}");
    Console.WriteLine($"Size: {file.Data?.Length ?? 0} bytes");
    Console.WriteLine($"Content-Type: {file.Options.HttpHeaders.ContentType}");
}
```

---

## Multiple Integrations (Factory Pattern)

When you need **multiple storage providers** in the same application:

### Registration

```csharp
await services
    .AddContentRepository()
    .WithInMemoryIntegration("inmemory")
    .WithBlobStorageIntegrationAsync(x =>
    {
        x.ContainerName = "documents";
        x.ConnectionString = configuration["ConnectionString:Storage"];
    }, "azure")
    .NoContext();
```

### Usage with Factory

```csharp
public class FileService
{
    private readonly IContentRepository _memoryStorage;
    private readonly IContentRepository _azureStorage;
    
    public FileService(IContentRepositoryFactory factory)
    {
        _memoryStorage = factory.Create("inmemory");
        _azureStorage = factory.Create("azure");
    }
    
    public async Task CacheFileAsync(string fileName, byte[] data)
    {
        // Store in memory for fast access
        await _memoryStorage.UploadAsync(fileName, data);
        
        // Also persist to Azure
        await _azureStorage.UploadAsync(fileName, data);
    }
}
```

---

## Migration Tool

Migrate files **between storage providers** with filtering and path modification:

### Setup Multiple Providers

```csharp
await services
    .AddContentRepository()
    .WithBlobStorageIntegrationAsync(x =>
    {
        x.ContainerName = "old-storage";
        x.ConnectionString = configuration["ConnectionString:OldStorage"];
    }, "source")
    .WithSharepointIntegrationAsync(x =>
    {
        x.TenantId = configuration["Sharepoint:TenantId"];
        x.ClientId = configuration["Sharepoint:ClientId"];
        x.ClientSecret = configuration["Sharepoint:ClientSecret"];
        x.MapWithSiteNameAndDocumentLibraryName("CompanySite", "Documents");
    }, "destination")
    .NoContext();
```

### Migrate Files

```csharp
public class MigrationService
{
    private readonly IContentMigration _contentMigration;
    
    public MigrationService(IContentMigration contentMigration)
    {
        _contentMigration = contentMigration;
    }
    
    public async Task MigrateToSharepointAsync()
    {
        await _contentMigration.MigrateAsync(
            sourceKey: "source",
            destinationKey: "destination",
            settings: config =>
            {
                // Overwrite existing files
                config.OverwriteIfExists = true;
                
                // Only migrate files in specific folder
                config.Prefix = "documents/2024/";
                
                // Filter files
                config.Predicate = file =>
                {
                    // Skip files larger than 10MB
                    return file.Data?.Length < 10 * 1024 * 1024;
                };
                
                // Modify destination path
                config.ModifyDestinationPath = path =>
                {
                    // Rename folder structure
                    return path.Replace("documents/2024/", "archive/2024/");
                };
            }
        );
    }
}
```

---

## ContentInformationType

Control what information is retrieved:

```csharp
public enum ContentInformationType
{
    None,           // No metadata/tags
    Metadata,       // Only metadata
    Tags,           // Only tags
    All             // Metadata + tags
}
```

**Example:**

```csharp
// Get only file data (fastest)
var result = await _contentRepository.DownloadAsync(
    "file.pdf", 
    ContentInformationType.None
);

// Get file data + metadata
var result = await _contentRepository.DownloadAsync(
    "file.pdf", 
    ContentInformationType.Metadata
);

// Get everything
var result = await _contentRepository.DownloadAsync(
    "file.pdf", 
    ContentInformationType.All
);
```

---

## Real-World Examples

### File Upload API

```csharp
[ApiController]
[Route("api/[controller]")]
public class FilesController : ControllerBase
{
    private readonly IContentRepository _contentRepository;
    
    public FilesController(IContentRepository contentRepository)
    {
        _contentRepository = contentRepository;
    }
    
    [HttpPost("upload")]
    public async Task<IActionResult> UploadFile(IFormFile file, [FromForm] string category)
    {
        using var memoryStream = new MemoryStream();
        await file.CopyToAsync(memoryStream);
        
        var fileName = $"{category}/{Guid.NewGuid()}_{file.FileName}";
        
        var success = await _contentRepository.UploadAsync(
            fileName,
            memoryStream.ToArray(),
            new ContentRepositoryOptions
            {
                HttpHeaders = new ContentRepositoryHttpHeaders
                {
                    ContentType = file.ContentType
                },
                Metadata = new Dictionary<string, string>
                {
                    { "originalFileName", file.FileName },
                    { "uploadedBy", User.Identity?.Name ?? "anonymous" },
                    { "uploadedAt", DateTime.UtcNow.ToString("o") }
                }
            }
        );
        
        return success ? Ok(new { fileName }) : StatusCode(500);
    }
    
    [HttpGet("download/{*path}")]
    public async Task<IActionResult> DownloadFile(string path)
    {
        var result = await _contentRepository.DownloadAsync(path, ContentInformationType.All);
        
        if (result == null)
            return NotFound();
        
        return File(result.Data, result.Options.HttpHeaders.ContentType ?? "application/octet-stream");
    }
}
```

### Document Management System

```csharp
public class DocumentService
{
    private readonly IContentRepository _contentRepository;
    private readonly ILogger<DocumentService> _logger;
    
    public DocumentService(IContentRepository contentRepository, ILogger<DocumentService> logger)
    {
        _contentRepository = contentRepository;
        _logger = logger;
    }
    
    public async Task<Guid> CreateDocumentAsync(string category, byte[] content, string fileName)
    {
        var documentId = Guid.NewGuid();
        var path = $"{category}/{documentId}/{fileName}";
        
        var success = await _contentRepository.UploadAsync(path, content, new ContentRepositoryOptions
        {
            Metadata = new Dictionary<string, string>
            {
                { "documentId", documentId.ToString() },
                { "category", category },
                { "originalFileName", fileName },
                { "createdAt", DateTime.UtcNow.ToString("o") }
            },
            Tags = new Dictionary<string, string>
            {
                { "version", "1" },
                { "status", "draft" }
            }
        });
        
        if (!success)
            throw new Exception("Failed to upload document");
        
        _logger.LogInformation("Document {DocumentId} created", documentId);
        
        return documentId;
    }
    
    public async Task<List<DocumentInfo>> ListDocumentsByCategoryAsync(string category)
    {
        var documents = new List<DocumentInfo>();
        
        await foreach (var file in _contentRepository.ListAsync(
            prefix: $"{category}/",
            downloadContent: false,
            informationRetrieve: ContentInformationType.All
        ))
        {
            documents.Add(new DocumentInfo
            {
                DocumentId = Guid.Parse(file.Options.Metadata["documentId"]),
                FileName = file.Options.Metadata["originalFileName"],
                Path = file.Path,
                Status = file.Options.Tags.GetValueOrDefault("status", "unknown"),
                CreatedAt = DateTime.Parse(file.Options.Metadata["createdAt"])
            });
        }
        
        return documents;
    }
}
```

### Multi-Tenant File Storage

```csharp
public class TenantFileService
{
    private readonly IContentRepositoryFactory _factory;
    
    public TenantFileService(IContentRepositoryFactory factory)
    {
        _factory = factory;
    }
    
    public async Task UploadTenantFileAsync(Guid tenantId, string fileName, byte[] data)
    {
        // Each tenant has its own storage
        var repository = _factory.Create($"tenant-{tenantId}");
        
        await repository.UploadAsync(fileName, data, new ContentRepositoryOptions
        {
            Metadata = new Dictionary<string, string>
            {
                { "tenantId", tenantId.ToString() }
            }
        });
    }
}

// Registration
services
    .AddContentRepository()
    .WithBlobStorageIntegrationAsync(x =>
    {
        x.ContainerName = "tenant-a-files";
        x.ConnectionString = configuration["Storage:TenantA"];
    }, "tenant-a")
    .WithBlobStorageIntegrationAsync(x =>
    {
        x.ContainerName = "tenant-b-files";
        x.ConnectionString = configuration["Storage:TenantB"];
    }, "tenant-b");
```

---

## Available Integrations

| Integration | Package | Use Case |
|------------|---------|----------|
| **Azure Blob Storage** | `Rystem.Content.Infrastructure.Storage.Blob` | Large files, CDN, public access |
| **Azure File Storage** | `Rystem.Content.Infrastructure.Storage.File` | SMB shares, legacy apps |
| **SharePoint Online** | `Rystem.Content.Infrastructure.M365.Sharepoint` | Document collaboration, Office 365 |
| **In-Memory** | `Rystem.Content.Infrastructure.InMemory` | Testing, caching |

---

## Benefits

- ✅ **Provider Agnostic**: Switch storage providers without code changes
- ✅ **Unified API**: Same interface for all providers
- ✅ **Metadata & Tags**: Store custom properties
- ✅ **Migration**: Built-in tool for moving files
- ✅ **Factory Pattern**: Multiple providers in one app
- ✅ **Testing**: In-memory provider for unit tests

---

## Related Tools

- **[Azure Blob Storage Integration](https://rystem.net/mcp/tools/content-repository-blob.md)** - Blob storage setup
- **[Azure File Storage Integration](https://rystem.net/mcp/tools/content-repository-file.md)** - File storage setup
- **[SharePoint Integration](https://rystem.net/mcp/tools/content-repository-sharepoint.md)** - SharePoint setup
- **[In-Memory Integration](https://rystem.net/mcp/tools/content-repository-inmemory.md)** - In-memory setup
- **[Text Extensions](https://rystem.net/mcp/tools/rystem-text-extensions.md)** - Stream/byte utilities

---

## References

- **NuGet Packages**: 
  - [Rystem.Content.Abstractions](https://www.nuget.org/packages/Rystem.Content.Abstractions) v9.1.3
  - [Rystem.Content.Infrastructure.*](https://www.nuget.org/packages?q=Rystem.Content.Infrastructure) v9.1.3
- **Documentation**: https://rystem.net
- **GitHub**: https://github.com/KeyserDSoze/Rystem

---

## Rystem.Content.Abstractions

> Rystem.Content.Abstractions contains the shared content API, the registration builder, and the cross-provider migration service.

# Rystem.Content.Abstractions

`Rystem.Content.Abstractions` contains the shared content API, the registration builder, and the cross-provider migration service.

It does not implement storage by itself. Real storage arrives through provider packages such as Blob, File Share, SharePoint, or InMemory.

## Installation

```bash
dotnet add package Rystem.Content.Abstractions
```

## What this package adds

This package defines:

- `IContentRepository`
- `IContentRepositoryBuilder`
- `ContentRepositoryOptions`
- `ContentRepositoryResult`
- `ContentRepositoryDownloadResult`
- `ContentInformationType`
- `IContentMigration`

At DI level, `AddContentRepository()` currently registers:

- `IContentMigration` as `Transient`

Provider registrations are added later through `With...Integration(...)` extension methods.

## Architecture

The core model is intentionally small:

- `IContentRepository` is the only storage contract
- `AddContentRepository()` returns an `IContentRepositoryBuilder`
- providers register named implementations through the shared factory system
- migrations resolve source and destination repositories from `IFactory<IContentRepository>`

In the current source tree and tests, named resolution is done with `IFactory<IContentRepository>`, not an `IContentRepositoryFactory` abstraction.

## Registration API

`IContentRepositoryBuilder` exposes three registration shapes:

| Method | Use when | Default lifetime |
| --- | --- | --- |
| `WithIntegration<TRepository>(name, lifetime)` | repository has no options object | `Transient` |
| `WithIntegration<TRepository, TOptions>(options, name, lifetime)` | repository needs synchronous options wiring | `Transient` |
| `WithIntegrationAsync<TRepository, TOptions, TConnection>(options, name, lifetime)` | repository setup is asynchronous and builds a connection wrapper | `Transient` |

The built-in Blob, File, and SharePoint providers sit on top of `WithIntegrationAsync(...)`. The InMemory provider uses `WithIntegration(...)` and overrides the lifetime to `Singleton`.

The provider-specific `WithBlobStorageIntegration(...)`, `WithFileStorageIntegration(...)`, `WithSharepointIntegration(...)`, and `WithInMemoryIntegration(...)` extensions are defined by the provider packages, not by this package itself.

## Minimal setup

```csharp
var repositories = services.AddContentRepository();

repositories.WithInMemoryIntegration("inmemory");
```

When you need a provider with async setup:

```csharp
var repositories = services.AddContentRepository();

await repositories.WithBlobStorageIntegrationAsync(options =>
{
    options.ContainerName = "supertest";
    options.ConnectionString = configuration["ConnectionString:Storage"];
}, "blobstorage");
```

## Consuming named repositories

The content tests resolve repositories like this:

```csharp
public sealed class ContentService
{
    private readonly IContentRepository _contentRepository;

    public ContentService(IFactory<IContentRepository> factory)
        => _contentRepository = factory.Create("blobstorage");
}
```

## `IContentRepository` contract

| Method | Return type | Purpose |
| --- | --- | --- |
| `ListAsync(prefix, downloadContent, informationRetrieve)` | `IAsyncEnumerable<ContentRepositoryDownloadResult>` | Enumerate files with optional prefix filtering |
| `DownloadAsync(path, informationRetrieve)` | `Task<ContentRepositoryDownloadResult?>` | Download bytes and optional metadata |
| `GetPropertiesAsync(path, informationRetrieve)` | `Task<ContentRepositoryResult?>` | Read metadata without downloading bytes |
| `UploadAsync(path, data, options, overwrite)` | `ValueTask<bool>` | Create or replace a file |
| `SetPropertiesAsync(path, options)` | `ValueTask<bool>` | Update headers, metadata, or tags |
| `DeleteAsync(path)` | `ValueTask<bool>` | Delete a file |
| `ExistAsync(path)` | `ValueTask<bool>` | Check whether a file exists |

Important caveat: `overwrite` is part of the shared interface, but not every provider enforces it the same way.

## Shared models

### `ContentRepositoryOptions`

```csharp
var options = new ContentRepositoryOptions
{
    HttpHeaders = new ContentRepositoryHttpHeaders
    {
        ContentType = "image/png",
        CacheControl = "max-age=3600",
        ContentDisposition = "attachment; filename=image.png"
    },
    Metadata = new Dictionary<string, string>
    {
        ["author"] = "alice"
    },
    Tags = new Dictionary<string, string>
    {
        ["version"] = "1"
    }
};
```

### `ContentInformationType`

| Value | Meaning |
| --- | --- |
| `None` | no extra metadata |
| `HttpHeaders` | include content headers |
| `Metadata` | include metadata dictionary |
| `Tags` | include tags when supported |
| `All` | `HttpHeaders | Metadata | Tags` |

### Result models

| Type | Properties |
| --- | --- |
| `ContentRepositoryResult` | `Path`, `Uri`, `Options` |
| `ContentRepositoryDownloadResult` | everything in `ContentRepositoryResult` plus `Data` |

`Path` and `Uri` are provider-defined. Do not assume they have identical semantics across Blob, File Share, SharePoint, and InMemory.

## Migration service

`IContentMigration` copies content between named providers.

This example matches the usage style in `src/Content/Rystem.Content.Tests/Rystem.Content.UnitTest/Integrations/AllStorageTest.cs`.

```csharp
ContentMigrationResult result = await contentMigration.MigrateAsync(
    sourceName: "inmemory",
    destinationName: "filestorage",
    settings: options =>
    {
        options.Prefix = "Test/Folder1/";
        options.OverwriteIfExists = true;
        options.Predicate = item => item.Path?.Contains("fileName6") != true;
        options.ModifyDestinationPath = path => path.Replace("Folder2", "Folder3");
    });
```

Available settings:

| Property | Default | Meaning |
| --- | --- | --- |
| `Prefix` | `null` | restrict source enumeration |
| `Predicate` | `null` | skip items that do not match |
| `OverwriteIfExists` | `false` | pass overwrite intent to destination upload |
| `OnErrorContinue` | `true` | keep going after per-file errors |
| `ModifyDestinationPath` | `null` | rewrite the output path |

## Migration behavior notes

The current implementation is a straightforward copy loop:

- it resolves both repositories through `IFactory<IContentRepository>`
- it enumerates source items with `ListAsync(..., downloadContent: false, ContentInformationType.None)`
- it downloads each matched item with `ContentInformationType.All`
- it uploads the downloaded bytes plus options to the destination repository

Important caveats from the source:

- `NotMigratedPaths` exists on `ContentMigrationResult`, but the current implementation never fills it
- when an upload returns `false`, the result currently lands in `NotContentPaths`
- there is no provider-native server-side copy or batching logic

## Writing a custom provider

If you want your own backend, implement `IContentRepository` and register it through the builder.

```csharp
internal sealed class MyContentRepository : IContentRepository
{
    public IAsyncEnumerable<ContentRepositoryDownloadResult> ListAsync(
        string? prefix = null,
        bool downloadContent = false,
        ContentInformationType informationRetrieve = ContentInformationType.None,
        CancellationToken cancellationToken = default)
        => throw new NotImplementedException();

    public Task<ContentRepositoryDownloadResult?> DownloadAsync(
        string path,
        ContentInformationType informationRetrieve = ContentInformationType.None,
        CancellationToken cancellationToken = default)
        => throw new NotImplementedException();

    public Task<ContentRepositoryResult?> GetPropertiesAsync(
        string path,
        ContentInformationType informationRetrieve = ContentInformationType.All,
        CancellationToken cancellationToken = default)
        => throw new NotImplementedException();

    public ValueTask<bool> UploadAsync(
        string path,
        byte[] data,
        ContentRepositoryOptions? options = null,
        bool overwrite = true,
        CancellationToken cancellationToken = default)
        => throw new NotImplementedException();

    public ValueTask<bool> SetPropertiesAsync(
        string path,
        ContentRepositoryOptions? options = null,
        CancellationToken cancellationToken = default)
        => throw new NotImplementedException();

    public ValueTask<bool> DeleteAsync(string path, CancellationToken cancellationToken = default)
        => throw new NotImplementedException();

    public ValueTask<bool> ExistAsync(string path, CancellationToken cancellationToken = default)
        => throw new NotImplementedException();
}
```

Then register it:

```csharp
services
    .AddContentRepository()
    .WithIntegration<MyContentRepository>("custom");
```

## Related packages

- `Rystem.Content.Infrastructure.Storage.Blob`
- `Rystem.Content.Infrastructure.Storage.File`
- `Rystem.Content.Infrastructure.M365.Sharepoint`
- `Rystem.Content.Infrastructure.InMemory`

Use this package when you want the contract and migration layer; add a provider package when you want real storage.

---

## Rystem.Content.Infrastructure.Storage.Blob

> This provider adds Azure Blob Storage support to the Content framework.

# Rystem.Content.Infrastructure.Storage.Blob

This provider adds Azure Blob Storage support to the Content framework.

Repo note: the folder name is `Rystem.Content.Infrastructure.Azure.Storage.Blob`, but the current NuGet package id is `Rystem.Content.Infrastructure.Storage.Blob`.

## Installation

```bash
dotnet add package Rystem.Content.Infrastructure.Storage.Blob
```

## Architecture

The provider is a thin wrapper over `BlobContainerClient`.

- registration builds a single container client
- async registration creates the container immediately
- `Prefix` is prepended to every blob name
- `SetPropertiesAsync` maps to blob headers, metadata, and tags

The registration shape is defined in `src/Content/Rystem.Content.Infrastructures/Rystem.Content.Infrastructure.Azure.Storage.Blob/BuilderExtensions/ContentRepositoryBuilderExtensions.cs` and the runtime behavior lives in `BlobStorage/BlobStorageRepository.cs`.

## Registration API

| Method | Default lifetime | Notes |
| --- | --- | --- |
| `WithBlobStorageIntegrationAsync(options, name, serviceLifetime)` | `Transient` | preferred path because setup is async |
| `WithBlobStorageIntegration(options, name, serviceLifetime)` | `Transient` | sync wrapper over the async implementation |

## Example

This matches the unit-test startup in `src/Content/Rystem.Content.Tests/Rystem.Content.UnitTest/Startup.cs`.

```csharp
var repositories = builder.Services.AddContentRepository();

await repositories.WithBlobStorageIntegrationAsync(options =>
{
    options.ContainerName = "supertest";
    options.Prefix = "site/";
    options.ConnectionString = builder.Configuration["ConnectionString:Storage"];
    options.UploadOptions = new BlobUploadOptions
    {
        AccessTier = AccessTier.Cool
    };
}, "blobstorage");
```

Resolve and use it:

```csharp
public sealed class BlobAssetService
{
    private readonly IContentRepository _repository;

    public BlobAssetService(IFactory<IContentRepository> factory)
        => _repository = factory.Create("blobstorage");

    public ValueTask<bool> UploadAsync(string path, byte[] data)
        => _repository.UploadAsync(path, data, new ContentRepositoryOptions
        {
            HttpHeaders = new ContentRepositoryHttpHeaders
            {
                ContentType = "image/png"
            },
            Metadata = new Dictionary<string, string>
            {
                ["source"] = "upload"
            },
            Tags = new Dictionary<string, string>
            {
                ["version"] = "1"
            }
        });
}
```

## Settings

`BlobStorageConnectionSettings` exposes:

| Property | Notes |
| --- | --- |
| `ConnectionString` | used when present |
| `EndpointUri` | used for managed identity mode |
| `ManagedIdentityClientId` | null means `DefaultAzureCredential`; otherwise `ManagedIdentityCredential` |
| `ContainerName` | used in connection-string mode |
| `Prefix` | prepended to every blob path |
| `IsPublic` | when `true`, registration sets public blob access on the container |
| `ClientOptions` | passed to `BlobContainerClient` |
| `UploadOptions` | reused by `UploadAsync(...)` |

## Managed identity note

In managed identity mode, the provider constructs the client as:

```csharp
new BlobContainerClient(settings.EndpointUri, credential, settings.ClientOptions)
```

So `EndpointUri` needs to point to the container itself, not just the storage account. In that path, `ContainerName` is ignored.

## Provider behavior

- `UploadAsync` writes the blob and then calls `SetPropertiesAsync(...)`
- `GetPropertiesAsync` reads blob properties and optionally tags
- `DownloadAsync` downloads content and can also include headers, metadata, and tags
- `ListAsync` can optionally download content for each blob

Native Blob features supported by this provider:

- HTTP headers
- metadata
- blob tags

## Important caveats

### Prefix handling is not fully uniform

- `ListAsync` strips the configured prefix from the returned `Path`
- `DownloadAsync` returns `Path = blobClient.Name`, which still includes the prefix
- `GetPropertiesAsync` does the same

So if you rely on `Path`, be aware that list results and direct point-lookups are not fully normalized.

### `overwrite` is weaker than it looks

`UploadAsync(path, data, options, overwrite)` accepts an `overwrite` flag, but the current implementation always calls `blobClient.UploadAsync(...)` with the configured upload options.

If you need strict create-only semantics when `overwrite == false`, enforce that in your application with `ExistAsync(...)` before uploading.

### `ContentInformationType.None` still returns an options object

For Blob and File providers, `informationRetrieve == None` returns an empty `ContentRepositoryOptions` instance rather than `null`.

## When to use this provider

Use it when you want:

- Azure Blob Storage as the backing store
- native blob metadata and tag support
- optional public container access
- simple path-prefix partitioning inside one container

Avoid assuming that all providers behave exactly like Blob Storage. The Content abstraction keeps the method names aligned, not every detail of path, URI, and overwrite semantics.

---

## Rystem.Content.Infrastructure.Storage.File

> This provider adds Azure File Share support to the Content framework.

# Rystem.Content.Infrastructure.Storage.File

This provider adds Azure File Share support to the Content framework.

Repo note: the folder name is `Rystem.Content.Infrastructure.Azure.Storage.File`, but the current NuGet package id is `Rystem.Content.Infrastructure.Storage.File`.

## Installation

```bash
dotnet add package Rystem.Content.Infrastructure.Storage.File
```

## Architecture

The provider is a thin wrapper over `ShareClient` and `ShareFileClient`.

- async registration creates the share immediately
- if `Prefix` is configured, registration also creates the prefix directories
- uploads create missing intermediate directories on demand
- headers and metadata are mapped to Azure File Share APIs

The public registration extensions live in `BuilderExtensions/ContentRepositoryBuilderExtensions.cs`, while the runtime behavior is in `FileStorage/FileStorageRepository.cs`.

## Registration API

| Method | Default lifetime | Notes |
| --- | --- | --- |
| `WithFileStorageIntegrationAsync(options, name, serviceLifetime)` | `Transient` | preferred path because setup is async |
| `WithFileStorageIntegration(options, name, serviceLifetime)` | `Transient` | sync wrapper over the async implementation |

## Example

This matches the unit-test startup in `src/Content/Rystem.Content.Tests/Rystem.Content.UnitTest/Startup.cs`.

```csharp
var repositories = builder.Services.AddContentRepository();

await repositories.WithFileStorageIntegrationAsync(options =>
{
    options.ShareName = "supertest";
    options.Prefix = "site/";
    options.ConnectionString = builder.Configuration["ConnectionString:Storage"];
}, "filestorage");
```

Resolve and use it:

```csharp
public sealed class FileShareDocumentService
{
    private readonly IContentRepository _repository;

    public FileShareDocumentService(IFactory<IContentRepository> factory)
        => _repository = factory.Create("filestorage");

    public ValueTask<bool> SaveAsync(string path, byte[] data)
        => _repository.UploadAsync(path, data, new ContentRepositoryOptions
        {
            HttpHeaders = new ContentRepositoryHttpHeaders
            {
                ContentType = "application/pdf"
            },
            Metadata = new Dictionary<string, string>
            {
                ["department"] = "legal"
            }
        });
}
```

## Settings

`FileStorageConnectionSettings` exposes:

| Property | Notes |
| --- | --- |
| `ConnectionString` | used when present |
| `EndpointUri` | used for managed identity mode |
| `ManagedIdentityClientId` | null means `DefaultAzureCredential`; otherwise `ManagedIdentityCredential` |
| `ShareName` | used in connection-string mode |
| `Prefix` | prepended to every logical path and pre-created as directories |
| `ClientOptions` | passed to `ShareClient` |
| `ClientCreateOptions` | used when creating the share |
| `Permissions` | passed to `SetAccessPolicyAsync(...)` |
| `Conditions` | passed to `SetAccessPolicyAsync(...)` |
| `IsPublic` | present on the settings type, but not used by the current implementation |

## Managed identity note

In managed identity mode, the provider constructs the client as:

```csharp
new ShareClient(settings.EndpointUri, credential, settings.ClientOptions)
```

So `EndpointUri` needs to point to the share itself. In that path, `ShareName` is ignored.

## Provider behavior

- `UploadAsync` creates intermediate directories if they do not exist
- `SetPropertiesAsync` maps HTTP headers and metadata
- `GetPropertiesAsync` reads headers and metadata
- `Tags` are not supported and stay `null`

Compared with Blob Storage, this provider is more directory-oriented and less metadata-rich.

## Important caveats

### Listing is not recursive

`ListAsync(...)` enumerates a single directory scope and skips directory entries. It does not recursively walk nested folders the way the SharePoint provider does.

### `overwrite` is effectively ignored

If the file already exists, `UploadAsync(...)` resizes it and uploads the new bytes regardless of the `overwrite` parameter.

If you need strict create-only behavior, check `ExistAsync(...)` first.

### Path and URI semantics are inconsistent

The current implementation returns different shapes depending on the method:

- `DownloadAsync` returns `Path = path` and `Uri = path`
- `GetPropertiesAsync` returns `Path = fileClient.Name`
- `ListAsync` returns `Uri = fileClient.Uri.ToString()` and a relative path

So treat `Path` and `Uri` as provider-defined output rather than a normalized contract.

## When to use this provider

Use it when you want:

- Azure File Share as the backing store
- directory-style organization
- native file headers and metadata
- automatic directory creation during upload

It is less appropriate when you need native tag support or Blob-like path semantics.

---

## Rystem.Content.Infrastructure.InMemory

> This provider adds an in-memory content store for tests, local development, and simple non-persistent scenarios.

# Rystem.Content.Infrastructure.InMemory

This provider adds an in-memory content store for tests, local development, and simple non-persistent scenarios.

It is the lightest provider in the Content area: a singleton `ConcurrentDictionary<string, ContentRepositoryDownloadResult>` keyed by path.

## Installation

```bash
dotnet add package Rystem.Content.Infrastructure.InMemory
```

## Registration

```csharp
services
    .AddContentRepository()
    .WithInMemoryIntegration("inmemory");
```

Unlike the other built-in providers, this one registers with `ServiceLifetime.Singleton`.

## Example

```csharp
public sealed class InMemoryContentService
{
    private readonly IContentRepository _repository;

    public InMemoryContentService(IFactory<IContentRepository> factory)
        => _repository = factory.Create("inmemory");

    public async Task RoundTripAsync()
    {
        await _repository.UploadAsync("folder/file.txt", System.Text.Encoding.UTF8.GetBytes("hello"), new ContentRepositoryOptions
        {
            HttpHeaders = new ContentRepositoryHttpHeaders
            {
                ContentType = "text/plain"
            },
            Metadata = new Dictionary<string, string>
            {
                ["author"] = "test"
            },
            Tags = new Dictionary<string, string>
            {
                ["version"] = "1"
            }
        });

        var file = await _repository.DownloadAsync("folder/file.txt", ContentInformationType.All);
        var props = await _repository.GetPropertiesAsync("folder/file.txt", ContentInformationType.All);
        await _repository.DeleteAsync("folder/file.txt");
    }
}
```

## Provider behavior

The runtime is straightforward:

- `UploadAsync` stores `Path`, `Uri`, `Data`, and `Options` directly in memory
- `DeleteAsync` removes the item from the dictionary
- `ExistAsync` checks the dictionary key
- `SetPropertiesAsync` mutates the stored options object

This makes the provider very convenient for tests and also means it is not a fidelity model for remote storage services.

## Important caveats

### `downloadContent` is ignored

`ListAsync(...)` always yields the stored `ContentRepositoryDownloadResult`, so data is already present even when `downloadContent == false`.

### `informationRetrieve` is mostly ignored

`DownloadAsync(...)` and `GetPropertiesAsync(...)` return the stored object or stored options directly. They do not selectively materialize headers, metadata, or tags based on the requested flags.

### `Uri` is just the path

The provider stores:

- `Path = path`
- `Uri = path`

So `Uri` is only a placeholder string, not a real network URL.

### State lives for the process lifetime

Because the provider is a singleton, content persists until you remove it or rebuild the host.

## When to use this provider

Use it when you want:

- fast unit or integration tests
- no external infrastructure
- full round-trip of headers, metadata, and tags in memory

Do not treat it as a perfect simulator for Blob, File Share, or SharePoint behavior.

---

## Rystem.Content.Infrastructure.M365.Sharepoint

> This provider adds SharePoint Online support to the Content framework through Microsoft Graph.

# Rystem.Content.Infrastructure.M365.Sharepoint

This provider adds SharePoint Online support to the Content framework through Microsoft Graph.

It models one SharePoint document library as one `IContentRepository` registration.

## Installation

```bash
dotnet add package Rystem.Content.Infrastructure.M365.Sharepoint
```

## Authentication model

The current implementation uses Microsoft Graph with client credentials.

You need an app registration with application permissions such as:

- `Files.ReadWrite.All`
- or `Sites.ReadWrite.All`

And you need:

- `TenantId`
- `ClientId`
- `ClientSecret`

## Architecture

Async registration does real setup work:

- it creates a `GraphServiceClient`
- resolves the target site and document library ids
- when a site-scoped library name is configured and the library is missing, it creates the document library

The registration extensions live in `BuilderExtensions/ContentRepositoryBuilderExtensions.cs`, the mapping rules in `Options/SharepointConnectionSettings.cs`, and the runtime behavior in `SharepointRepository/SharepointRepository.cs` plus `SharepointServiceClient/SharepointServiceClientFactory.cs`.

## Registration API

| Method | Default lifetime | Notes |
| --- | --- | --- |
| `WithSharepointIntegrationAsync(options, name, serviceLifetime)` | `Transient` | preferred path because setup is async |
| `WithSharepointIntegration(options, name, serviceLifetime)` | `Transient` | sync wrapper over the async implementation |

## Mapping methods

Call exactly one of these on `SharepointConnectionSettings`:

| Method | Meaning |
| --- | --- |
| `MapWithSiteIdAndDocumentLibraryId(siteId, documentLibraryId)` | use exact ids |
| `MapWithSiteIdAndDocumentLibraryName(siteId, documentLibraryName)` | site id plus library name |
| `MapWithSiteNameAndDocumentLibraryName(siteName, documentLibraryName)` | find the site by name, then find or create the library |
| `MapWithRootSiteAndDocumentLibraryName(documentLibraryName)` | use the root site and a library name |
| `MapOnlyDocumentLibraryId(documentLibraryId)` | search by library id only |
| `MapOnlyDocumentLibraryName(documentLibraryName)` | search by library name only |

If your tenant has ambiguous site names, prefer the id-based methods.

## Example

This matches `src/Content/Rystem.Content.Tests/Rystem.Content.UnitTest/Startup.cs`.

```csharp
var repositories = builder.Services.AddContentRepository();

await repositories.WithSharepointIntegrationAsync(options =>
{
    options.TenantId = builder.Configuration["Sharepoint:TenantId"];
    options.ClientId = builder.Configuration["Sharepoint:ClientId"];
    options.ClientSecret = builder.Configuration["Sharepoint:ClientSecret"];
    options.MapWithSiteNameAndDocumentLibraryName(
        builder.Configuration["Sharepoint:SiteName"]!,
        builder.Configuration["Sharepoint:DocumentLibraryName"]!);
}, "sharepoint");
```

Resolve and use it:

```csharp
public sealed class SharepointContentService
{
    private readonly IContentRepository _repository;

    public SharepointContentService(IFactory<IContentRepository> factory)
        => _repository = factory.Create("sharepoint");

    public ValueTask<bool> UploadAsync(string path, byte[] data)
        => _repository.UploadAsync(path, data, new ContentRepositoryOptions
        {
            HttpHeaders = new ContentRepositoryHttpHeaders
            {
                ContentType = "application/pdf"
            },
            Metadata = new Dictionary<string, string>
            {
                ["department"] = "legal"
            },
            Tags = new Dictionary<string, string>
            {
                ["version"] = "1"
            }
        });
}
```

## Provider behavior

- `UploadAsync` writes file content through `ItemWithPath(path).Content.PutAsync(...)`
- `ExistAsync` and `GetPropertiesAsync` query the file through Graph
- `ListAsync` recursively enumerates folders
- `DeleteAsync` returns `true` when the item does not exist

This provider is the most conceptually different from Blob and File Share because it does not map `ContentRepositoryOptions` to native SharePoint storage primitives.

## Important caveats

### Options are stored in `DriveItem.Description`

`SetPropertiesAsync(...)` serializes the whole `ContentRepositoryOptions` object into `DriveItem.Description`.

`GetPropertiesAsync(...)` reads that description back and deserializes it.

Practical consequence:

- headers are not written as real SharePoint HTTP response headers
- metadata is not mapped to list columns by this provider
- tags are not native SharePoint tags

They round-trip because the provider stores its own JSON payload in the description field.

### Site-name lookup is fuzzy

When you use `MapWithSiteNameAndDocumentLibraryName(...)`, the provider searches Graph sites and takes the first match.

If you have multiple similarly named sites, use the id-based mapping methods instead.

### Missing libraries can be created automatically

When a site is known and the requested document library name does not exist, the async setup path creates a document library for you.

### Listing is recursive

Unlike the File Share provider, `ListAsync(...)` descends into child folders.

## When to use this provider

Use it when you want:

- SharePoint document libraries behind the shared content API
- Microsoft 365 app-registration authentication
- recursive listing over folder structures
- convenient cross-provider migration targets

Be careful if you need native SharePoint field or header semantics, because this provider currently stores repository options in the item description instead.
