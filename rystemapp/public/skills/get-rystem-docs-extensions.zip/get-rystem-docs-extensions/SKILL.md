---
name: Rystem - Get Rystem Docs / Extensions
description: Rystem Framework docs: extensions/backgroundjob, extensions/concurrency, extensions/concurrency-redis, extensions/localization-multiple and 2 more. Use for extensions questions in Rystem.
---

# Rystem - Get Rystem Docs / Extensions

> Auto-generated from Rystem MCP manifest (tool: `get-rystem-docs`, category: `extensions`)

---

## extensions/backgroundjob

> Rystem.BackgroundJob adds CRON-based recurring jobs on top of the Rystem DI stack.

### [What is Rystem?](https://github.com/KeyserDSoze/Rystem)

## Rystem.BackgroundJob

`Rystem.BackgroundJob` adds CRON-based recurring jobs on top of the Rystem DI stack.

The package is designed for applications that want small recurring jobs without introducing a heavier external scheduler. Jobs are registered through dependency injection, started during DI warm-up, and executed according to standard 5-field or 6-field CRON expressions through `Cronos`.

It is most useful for:

- recurring maintenance jobs
- polling and synchronization tasks
- cleanup or archival work
- lightweight scheduled automation inside ASP.NET Core or generic host applications

The best source-backed examples for this package are the package implementation itself plus the sample web app in `src/Extensions/BackgroundJob/Test/Rystem.BackgroundJob.WebApp`.

## Resources

- Complete Documentation: [https://rystem.net](https://rystem.net)
- MCP Server for AI: [https://rystem.cloud/mcp](https://rystem.cloud/mcp)
- Discord Community: [https://discord.gg/tkWvy4WPjt](https://discord.gg/tkWvy4WPjt)
- Support the Project: [https://www.buymeacoffee.com/keyserdsoze](https://www.buymeacoffee.com/keyserdsoze)

## Installation

```bash
dotnet add package Rystem.BackgroundJob
```

The current `10.x` package targets `net11.0` and builds on top of:

- `Cronos`
- `Rystem.Concurrency`
- the warm-up flow from [`Rystem.DependencyInjection`](https://github.com/KeyserDSoze/Rystem/blob/master/src/Core/Rystem.DependencyInjection/README.md)

## Package Architecture

The package is intentionally compact and revolves around four pieces.

| Piece | Purpose |
|---|---|
| `IBackgroundJob` | Contract implemented by each scheduled job |
| `BackgroundJobOptions` | CRON, startup behavior, and logical key |
| `IBackgroundJobManager` | Scheduler abstraction responsible for running jobs |
| `AddBackgroundJob<TJob>` | DI entry point that registers the job and wires startup through warm-up |

At a high level, the flow is:

- register a job with `AddBackgroundJob<TJob>(...)`
- the package adds the job as a transient service
- warm-up starts the schedule after the provider is built
- the manager computes the next CRON occurrence and arms a timer
- each tick executes the job and schedules the next one

## Table of Contents

- [Package Architecture](#package-architecture)
- [Implement a Job](#implement-a-job)
  - [IBackgroundJob contract](#ibackgroundjob-contract)
  - [Dependency injection behavior](#dependency-injection-behavior)
- [Register a Job](#register-a-job)
- [BackgroundJobOptions](#backgroundjoboptions)
- [Scheduling and Warm-up](#scheduling-and-warm-up)
  - [Warm-up starts the scheduler](#warm-up-starts-the-scheduler)
  - [RunImmediately](#runimmediately)
  - [CRON format](#cron-format)
- [Multiple Registrations of the Same Job Type](#multiple-registrations-of-the-same-job-type)
- [Custom Job Manager](#custom-job-manager)
- [Repository Examples](#repository-examples)

---

## Implement a Job

Jobs implement `IBackgroundJob`.

The public job types live in the `System.Timers` namespace, so the usual starting point is:

```csharp
using System.Timers;
```

Then implement the job itself:

```csharp
using System.Timers;

public sealed class ReportJob : IBackgroundJob
{
    private readonly ILogger<ReportJob> _logger;

    public ReportJob(ILogger<ReportJob> logger)
    {
        _logger = logger;
    }

    public async Task ActionToDoAsync(CancellationToken cancellationToken = default)
    {
        _logger.LogInformation("Report job running at {Time}", DateTime.UtcNow);
        await Task.Delay(10, cancellationToken);
    }

    public Task OnException(Exception exception)
    {
        _logger.LogError(exception, "Report job failed");
        return Task.CompletedTask;
    }
}
```

### IBackgroundJob contract

The interface is intentionally small:

```csharp
public interface IBackgroundJob
{
    Task ActionToDoAsync(CancellationToken cancellationToken = default);
    Task OnException(Exception exception);
}
```

- `ActionToDoAsync(...)` contains the recurring work
- `OnException(...)` is called when `ActionToDoAsync(...)` throws

If you want the scheduler loop to keep going, `OnException(...)` should usually log or handle the exception rather than rethrow it.

### Dependency injection behavior

`AddBackgroundJob<TJob>(...)` registers the job as `Transient`.

The sample app in `src/Extensions/BackgroundJob/Test/Rystem.BackgroundJob.WebApp/BackgroundJob.cs` shows the intended lifetime behavior clearly:

- singleton dependencies stay stable across executions
- scoped dependencies are shared inside one execution but change across later executions
- transient dependencies are recreated even inside the same execution when resolved twice

That makes constructor injection work the same way it does in the rest of the application.

---

## Register a Job

Register the job during service setup:

```csharp
builder.Services.AddBackgroundJob<ReportJob>(options =>
{
    options.Cron = "*/5 * * * *";
    options.RunImmediately = true;
});
```

What `AddBackgroundJob<TJob>(...)` does internally:

- registers the default `IBackgroundJobManager` with `TryAddSingleton(...)`
- enables the Rystem lock service with `AddLock()`
- registers `TJob` as transient
- creates effective options
- schedules startup through `AddWarmUp(...)`

So this package depends on the same warm-up lifecycle documented in [`src/Core/Rystem.DependencyInjection/README.md`](https://github.com/KeyserDSoze/Rystem/blob/master/src/Core/Rystem.DependencyInjection/README.md).

---

## BackgroundJobOptions

`BackgroundJobOptions` contains the scheduling settings:

```csharp
public sealed class BackgroundJobOptions
{
    public string? Key { get; set; }
    public bool RunImmediately { get; set; }
    public string Cron { get; set; } = "* * * * *";
}
```

In practice, `AddBackgroundJob<TJob>(...)` starts from these effective defaults before your configuration delegate runs:

| Property | Effective default in `AddBackgroundJob(...)` | Purpose |
|---|---|---|
| `Key` | random GUID | Distinguishes one registration from another |
| `RunImmediately` | `false` | Executes once during warm-up before the timer begins |
| `Cron` | `"0 1 * * *"` | Schedules the job daily at 01:00 UTC |

That distinction matters because the raw `BackgroundJobOptions` class initializes `Cron` to `"* * * * *"`, while `AddBackgroundJob(...)` overwrites the starting default to `"0 1 * * *"` unless you set a different value.

---

## Scheduling and Warm-up

### Warm-up starts the scheduler

Jobs do not start automatically just because they were registered. They start when warm-up runs.

```csharp
var app = builder.Build();
await app.Services.WarmUpAsync();
app.Run();
```

Without `WarmUpAsync()`, the recurring timers are never started.

### RunImmediately

If `RunImmediately` is `true`, the manager executes `ActionToDoAsync(...)` once during warm-up before creating the first scheduled timer.

```csharp
builder.Services.AddBackgroundJob<ReportJob>(options =>
{
    options.Cron = "0 */2 * * *";
    options.RunImmediately = true;
});
```

This is useful when the first execution should happen during startup instead of waiting for the first future CRON occurrence.

### CRON format

The package uses `Cronos` and supports both standard and second-based expressions. The manager detects the format by counting space-separated fields.

```text
*/1 * * * *
```

- 5 fields -> standard CRON format
- 6 fields -> CRON format with seconds

Examples:

```text
*/1 * * * *
0 */2 * * *
0 9 * * 1-5
*/30 * * * * *
0 0 9 * * 1-5
```

For quick validation, [crontab.guru](https://crontab.guru/) is still a convenient companion for the 5-field form.

---

## Multiple Registrations of the Same Job Type

You can register the same job type more than once.

```csharp
builder.Services.AddBackgroundJob<ReportJob>(options =>
{
    options.Key = "daily";
    options.Cron = "0 8 * * *";
});

builder.Services.AddBackgroundJob<ReportJob>(options =>
{
    options.Key = "weekly";
    options.Cron = "0 8 * * 1";
});
```

The built-in manager uses a key shaped like:

```text
BackgroundWork_{options.Key}_{jobTypeFullName}
```

So multiple registrations stay independent as long as they do not collide on both job type and key.

If you do not set `Key`, the package generates a GUID automatically, which already keeps separate registrations distinct.

---

## Custom Job Manager

If you need different scheduling or execution semantics, replace the default manager.

```csharp
builder.Services.AddBackgroundJobManager<MyCustomJobManager>();
```

Your implementation must satisfy:

```csharp
public interface IBackgroundJobManager
{
    Task RunAsync(
        IBackgroundJob job,
        BackgroundJobOptions options,
        Func<IBackgroundJob>? factory = null,
        CancellationToken cancellationToken = default);
}
```

The optional `factory` parameter is the hook the default manager uses to recreate jobs for later scheduled executions.

Important: call `AddBackgroundJobManager<TJobManager>()` before any `AddBackgroundJob(...)` registration, because the built-in manager is registered with `TryAddSingleton(...)`.

The built-in `BackgroundJobManager` also uses the Rystem lock service to prevent concurrent timer updates for the same logical job key.

---

## Repository Examples

The most useful references for this package are:

- Package registration entry point: [src/Extensions/BackgroundJob/Rystem.BackgroundJob/ServiceCollectionExtensions/ServiceCollectionExtensions.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Extensions/BackgroundJob/Rystem.BackgroundJob/ServiceCollectionExtensions/ServiceCollectionExtensions.cs)
- Built-in scheduler manager: [src/Extensions/BackgroundJob/Rystem.BackgroundJob/BackgroundJob/BackgroundJobManager.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Extensions/BackgroundJob/Rystem.BackgroundJob/BackgroundJob/BackgroundJobManager.cs)
- Background job contract: [src/Extensions/BackgroundJob/Rystem.BackgroundJob/Interfaces/IBackgroundJob.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Extensions/BackgroundJob/Rystem.BackgroundJob/Interfaces/IBackgroundJob.cs)
- Sample application startup: [src/Extensions/BackgroundJob/Test/Rystem.BackgroundJob.WebApp/Program.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Extensions/BackgroundJob/Test/Rystem.BackgroundJob.WebApp/Program.cs)
- Sample job showing DI lifetime behavior: [src/Extensions/BackgroundJob/Test/Rystem.BackgroundJob.WebApp/BackgroundJob.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Extensions/BackgroundJob/Test/Rystem.BackgroundJob.WebApp/BackgroundJob.cs)

This README stays focused because `Rystem.BackgroundJob` is a narrow package: one job contract, one manager abstraction, one DI registration path, and a CRON-driven execution loop.

---

## extensions/concurrency

> Rystem.Concurrency adds two small async concurrency primitives on top of the Rystem DI stack:

### [What is Rystem?](https://github.com/KeyserDSoze/Rystem)

## Rystem.Concurrency

`Rystem.Concurrency` adds two small async concurrency primitives on top of the Rystem DI stack:

- `ILock` for serialized async execution
- `IRaceCodition` for deduplicating concurrent calls within a time window

Both abstractions are built on `ILockable`, which defaults to an in-memory implementation and can be swapped for another backend such as Redis.

The package is most useful for:

- guarding critical async sections
- de-duplicating cache refreshes and polling work
- coordinating lightweight background tasks
- keeping the same API while switching from local memory to distributed locking

The public types live in `System.Threading.Concurrent`, so that is the namespace you usually import when consuming the package.

## Resources

- Complete Documentation: [https://rystem.net](https://rystem.net)
- MCP Server for AI: [https://rystem.cloud/mcp](https://rystem.cloud/mcp)
- Discord Community: [https://discord.gg/tkWvy4WPjt](https://discord.gg/tkWvy4WPjt)
- Support the Project: [https://www.buymeacoffee.com/keyserdsoze](https://www.buymeacoffee.com/keyserdsoze)

## Installation

```bash
dotnet add package Rystem.Concurrency
```

Optional distributed backend:

```bash
dotnet add package Rystem.Concurrency.Redis
```

The current `10.x` package targets `net11.0` and builds on top of [`Rystem.DependencyInjection`](https://github.com/KeyserDSoze/Rystem/blob/master/src/Core/Rystem.DependencyInjection/README.md).

## Package Architecture

The package is organized in three layers.

| Layer | Purpose |
|---|---|
| `ILockable` | Lowest-level acquire / inspect / release abstraction |
| `ILock` | Serialized execution of async work for a key |
| `IRaceCodition` | First-wins execution with a configurable deduplication window |

The DI registrations mirror that layering:

- `AddInMemoryLockable()` registers only the in-memory `ILockable`
- `AddLockExecutor()` registers only the `ILock` executor
- `AddLock()` wires both together for the default lock setup
- `AddRaceConditionExecutor()` registers only the `IRaceCodition` executor
- `AddRaceCondition()` wires the full in-memory race-condition stack

That split is important when you want to plug in a custom or distributed backend without changing the calling code.

## Table of Contents

- [Package Architecture](#package-architecture)
- [Async Lock](#async-lock)
  - [Setup](#setup)
  - [ILock contract](#ilock-contract)
  - [Behavior](#behavior)
  - [LockResponse](#lockresponse)
- [Race Condition Guard](#race-condition-guard)
  - [Setup](#setup-1)
  - [IRaceCodition contract](#iracecodition-contract)
  - [Behavior](#behavior-1)
  - [RaceConditionResponse](#raceconditionresponse)
- [ILockable and Custom Backends](#ilockable-and-custom-backends)
  - [ILockable contract](#ilockable-contract)
  - [Built-in in-memory backend](#built-in-in-memory-backend)
  - [Custom executor registration](#custom-executor-registration)
- [Distributed Locking with Redis](#distributed-locking-with-redis)
- [Repository Examples](#repository-examples)

---

## Async Lock

`ILock` is the async equivalent of a critical section keyed by a string.

Use it when all callers for the same key must execute one after another instead of overlapping.

### Setup

```csharp
services.AddLock();
```

This registers:

- `ILock` -> `LockExecutor`
- `ILockable` -> `MemoryLock`

### ILock contract

```csharp
public interface ILock
{
    Task<LockResponse> ExecuteAsync(Func<Task> action, string? key = null);
}
```

Typical usage:

```csharp
using System.Threading.Concurrent;

public sealed class InventoryService
{
    private readonly ILock _lock;

    public InventoryService(ILock @lock)
    {
        _lock = @lock;
    }

    public async Task UpdateAsync()
    {
        LockResponse response = await _lock.ExecuteAsync(
            async () =>
            {
                await Task.Delay(15);
                await SaveAsync();
            },
            key: "inventory");

        if (response.InException)
            throw response.Exceptions!;
    }

    private Task SaveAsync() => Task.CompletedTask;
}
```

### Behavior

The repository test in `src/Extensions/Concurrency/Test/Rystem.Concurrency.UnitTest/LockTest.cs` is the clearest example of the intended behavior.

It starts 100 concurrent calls against the same lock:

```csharp
var locking = provider.CreateScope().ServiceProvider.GetService<ILock>();

for (int i = 0; i < 100; i++)
    tasks.Add(locking!.ExecuteAsync(() => CountAsync(2)));
```

Because all calls share the same keyless default lock, they are serialized and the final counter is deterministic:

```csharp
Assert.Equal(100 * 2, counter);
```

Important details from the implementation:

- `key: null` becomes `string.Empty`, so omitted keys all share one common lock
- different keys can run in parallel
- `ExecutionTime` includes both waiting time and action time because timing starts before acquisition
- exceptions are captured in the response instead of being rethrown directly

### LockResponse

```csharp
public sealed class LockResponse
{
    public TimeSpan ExecutionTime { get; }
    public AggregateException? Exceptions { get; }
    public bool InException => this.Exceptions != default;
}
```

Use `InException` as the quick status check and `Exceptions` when you want the captured failure details.

---

## Race Condition Guard

`IRaceCodition` is a first-wins guard for async work.

When multiple callers hit the same key inside the guarded window:

- the first caller executes the action
- the later callers wait until the guard is released
- those later callers return without executing the action

The interface name is intentionally documented as `IRaceCodition` because that is the current public API surface in the package.

### Setup

```csharp
services.AddRaceCondition();
```

This wires:

- `ILockable` -> `MemoryLock`
- `ILock` -> `LockExecutor`
- `IRaceCodition` -> `RaceConditionExecutor`

### IRaceCodition contract

```csharp
public interface IRaceCodition
{
    Task<RaceConditionResponse> ExecuteAsync(
        Func<Task> action,
        string? key = null,
        TimeSpan? timeWindow = null);
}
```

Typical usage:

```csharp
using System.Threading.Concurrent;

public sealed class PriceCacheService
{
    private readonly IRaceCodition _raceCondition;

    public PriceCacheService(IRaceCodition raceCondition)
    {
        _raceCondition = raceCondition;
    }

    public async Task RefreshAsync(string productId)
    {
        var response = await _raceCondition.ExecuteAsync(
            async () =>
            {
                await Task.Delay(15);
                await RefreshCoreAsync(productId);
            },
            key: productId,
            timeWindow: TimeSpan.FromSeconds(10));

        if (response.InException)
            throw response.Exceptions!;

        if (response.IsExecuted)
        {
            // this caller won and executed the action
        }
    }

    private Task RefreshCoreAsync(string productId) => Task.CompletedTask;
}
```

### Behavior

The repository test in `src/Extensions/Concurrency/Test/Rystem.Concurrency.UnitTest/RaceConditionTest.cs` runs 100 concurrent calls but alternates between only two keys:

```csharp
for (int i = 0; i < 100; i++)
    tasks.Add(raceCondition!.ExecuteAsync(
        () => CountAsync(2),
        (i % 2).ToString(),
        TimeSpan.FromSeconds(2)));
```

Only the first call for key `0` and the first call for key `1` execute, so the final result is:

```csharp
Assert.Equal(4, counter);
```

Important details from the implementation:

- default `timeWindow` is `TimeSpan.FromMinutes(1)`
- omitted keys also collapse to `string.Empty`
- the winner keeps the lock until the action finishes and the time window has elapsed, whichever is later in the in-memory flow
- non-winning callers wait for release, then return `IsExecuted = false`

### RaceConditionResponse

```csharp
public sealed class RaceConditionResponse
{
    public bool IsExecuted { get; }
    public AggregateException? Exceptions { get; }
    public bool InException => this.Exceptions != default;
}
```

- `IsExecuted = true` only for the winning caller
- `InException` and `Exceptions` reflect failures from the winning execution

---

## ILockable and Custom Backends

`ILock` and `IRaceCodition` both delegate the actual locking primitive to `ILockable`.

### ILockable contract

```csharp
public interface ILockable
{
    Task<bool> AcquireAsync(string key, TimeSpan? maxWindow = null);
    Task<bool> IsAcquiredAsync(string key);
    Task<bool> ReleaseAsync(string key);
}
```

`maxWindow` matters mostly for backends that can encode expiration directly, such as Redis.

### Built-in in-memory backend

The built-in implementation is `MemoryLock`, registered through:

```csharp
services.AddInMemoryLockable();
```

If you only want the low-level backend and plan to wire your own executors, this is the smallest registration unit.

To replace the backend entirely:

```csharp
services.AddLockableIntegration<MyDistributedLockable>();
```

### Custom executor registration

If you want to keep the lockable but swap the higher-level behavior:

```csharp
services.AddLockExecutor<MyCustomLock>();
services.AddRaceConditionExecutor<MyCustomRaceCondition>();
```

There are also non-generic registrations for the default executors only:

```csharp
services.AddLockExecutor();
services.AddRaceConditionExecutor();
```

Those methods register the executors but do not automatically add a lockable backend, so pair them with `AddInMemoryLockable()`, `AddLockableIntegration<T>()`, or the Redis package.

---

## Distributed Locking with Redis

For multi-process or multi-host coordination, use [`Rystem.Concurrency.Redis`](https://github.com/KeyserDSoze/Rystem/blob/master/src/Extensions/Concurrency/Rystem.Concurrency.Redis/README.md).

That companion package exposes:

- `AddRedisLock(...)`
- `AddRaceConditionWithRedis(...)`
- `AddRedisLockable(...)`

Example:

```csharp
services.AddRedisLock(options =>
{
    options.ConnectionString = configuration["ConnectionString:Redis"]!;
});
```

The Redis-backed lock test in `src/Extensions/Concurrency/Test/Rystem.Concurrency.UnitTest/RedisLockTest.cs` uses the same `ILock` API as the in-memory version, which is exactly the point of the `ILockable` abstraction.

---

## Repository Examples

The most useful sources for this package are:

- Lock registration and executor: [src/Extensions/Concurrency/Rystem.Concurrency/Lock/ServiceCollectionExtensions.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Extensions/Concurrency/Rystem.Concurrency/Lock/ServiceCollectionExtensions.cs)
- Lock implementation: [src/Extensions/Concurrency/Rystem.Concurrency/Lock/LockExecutor.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Extensions/Concurrency/Rystem.Concurrency/Lock/LockExecutor.cs)
- Race condition registration and executor: [src/Extensions/Concurrency/Rystem.Concurrency/RaceCondition/ServiceCollectionExtensions.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Extensions/Concurrency/Rystem.Concurrency/RaceCondition/ServiceCollectionExtensions.cs)
- Race condition implementation: [src/Extensions/Concurrency/Rystem.Concurrency/RaceCondition/RaceConditionExecutor.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Extensions/Concurrency/Rystem.Concurrency/RaceCondition/RaceConditionExecutor.cs)
- In-memory backend: [src/Extensions/Concurrency/Rystem.Concurrency/Lockable/MemoryLock.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Extensions/Concurrency/Rystem.Concurrency/Lockable/MemoryLock.cs)
- In-memory lock test: [src/Extensions/Concurrency/Test/Rystem.Concurrency.UnitTest/LockTest.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Extensions/Concurrency/Test/Rystem.Concurrency.UnitTest/LockTest.cs)
- Race-condition test: [src/Extensions/Concurrency/Test/Rystem.Concurrency.UnitTest/RaceConditionTest.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Extensions/Concurrency/Test/Rystem.Concurrency.UnitTest/RaceConditionTest.cs)
- Redis lock test: [src/Extensions/Concurrency/Test/Rystem.Concurrency.UnitTest/RedisLockTest.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Extensions/Concurrency/Test/Rystem.Concurrency.UnitTest/RedisLockTest.cs)

This README stays intentionally focused because `Rystem.Concurrency` is a small package with a layered design: one low-level lockable abstraction and two higher-level execution patterns built on top of it.

---

## extensions/concurrency-redis

> Rystem.Concurrency.Redis swaps the default in-memory ILockable from Rystem.Concurrency with a Redis-backed distributed implementation.

### [What is Rystem?](https://github.com/KeyserDSoze/Rystem)

## Rystem.Concurrency.Redis

`Rystem.Concurrency.Redis` swaps the default in-memory `ILockable` from `Rystem.Concurrency` with a Redis-backed distributed implementation.

Use it when lock and race-condition state must be shared across:

- multiple application instances
- multiple worker processes
- multiple machines or containers

The package keeps the same higher-level APIs from `Rystem.Concurrency`:

- `ILock`
- `IRaceCodition`
- `ILockable`

Only the storage backend changes.

## Resources

- Complete Documentation: [https://rystem.net](https://rystem.net)
- MCP Server for AI: [https://rystem.cloud/mcp](https://rystem.cloud/mcp)
- Discord Community: [https://discord.gg/tkWvy4WPjt](https://discord.gg/tkWvy4WPjt)
- Support the Project: [https://www.buymeacoffee.com/keyserdsoze](https://www.buymeacoffee.com/keyserdsoze)

## Installation

```bash
dotnet add package Rystem.Concurrency.Redis
```

The current `10.x` package targets `net11.0` and builds on top of:

- `StackExchange.Redis`
- [`Rystem.Concurrency`](https://github.com/KeyserDSoze/Rystem/blob/master/src/Extensions/Concurrency/Rystem.Concurrency/README.md)

## Package Architecture

The package is intentionally small and only adds the Redis-specific pieces.

| Piece | Purpose |
|---|---|
| `RedisConfiguration` | Holds the Redis connection string |
| `RedisLock` | Implements `ILockable` on top of `StackExchange.Redis` |
| `AddRedisLock(...)` | Registers `ILock` plus the Redis lockable |
| `AddRaceConditionWithRedis(...)` | Registers `IRaceCodition` plus the Redis lock stack |
| `AddRedisLockable(...)` | Registers only the Redis `ILockable` backend |

Conceptually, this package does not replace the concurrency model. It only replaces the backend used by that model.

## Table of Contents

- [Package Architecture](#package-architecture)
- [Distributed Async Lock](#distributed-async-lock)
- [Distributed Race Condition](#distributed-race-condition)
- [Redis Lockable Only](#redis-lockable-only)
- [Redis Backend Behavior](#redis-backend-behavior)
- [Configuration and Registration Notes](#configuration-and-registration-notes)
- [Repository Examples](#repository-examples)

---

## Distributed Async Lock

Register a distributed `ILock` with Redis as the backing store:

```csharp
services.AddRedisLock(options =>
{
    options.ConnectionString = configuration["ConnectionString:Redis"]!;
});
```

Internally this does two things:

- registers the standard `ILock` executor
- registers `RedisLock` as the active `ILockable`

Usage stays identical to the in-memory version from `Rystem.Concurrency`:

```csharp
using System.Threading.Concurrent;

LockResponse response = await distributedLock.ExecuteAsync(
    async () =>
    {
        await Task.Delay(15);
        await SaveAsync();
    },
    key: "inventory");

if (response.InException)
    throw response.Exceptions!;
```

The repository test in `src/Extensions/Concurrency/Test/Rystem.Concurrency.UnitTest/RedisLockTest.cs` uses this registration and starts 100 concurrent lock executions. The final counter still ends at `200`, confirming that the distributed backend preserves the same serialized behavior as the in-memory version.

---

## Distributed Race Condition

Register the race-condition guard with Redis:

```csharp
services.AddRaceConditionWithRedis(options =>
{
    options.ConnectionString = configuration["ConnectionString:Redis"]!;
});
```

This composes:

- `AddRedisLock(...)`
- `AddRaceConditionExecutor()`

So the high-level race-condition logic remains the same as the base package, but the lock state is now shared through Redis.

Usage also stays the same:

```csharp
using System.Threading.Concurrent;

RaceConditionResponse response = await raceCondition.ExecuteAsync(
    async () =>
    {
        await Task.Delay(15);
        await RefreshCacheAsync();
    },
    key: "cache-refresh",
    timeWindow: TimeSpan.FromSeconds(30));

if (response.IsExecuted)
{
    // this instance won and executed the action
}
```

There is no separate Redis-specific race-condition test in the repository at the moment, so this section is source-backed rather than test-backed. The important implementation detail is that the Redis package reuses the same `RaceConditionExecutor` from the base concurrency package.

---

## Redis Lockable Only

If you want Redis as the backend but your own higher-level executor, register only `ILockable`:

```csharp
services.AddRedisLockable(options =>
{
    options.ConnectionString = configuration["ConnectionString:Redis"]!;
});
```

Then add your own executor on top:

```csharp
services.AddLockExecutor<MyCustomLock>();
services.AddRaceConditionExecutor<MyCustomRaceCondition>();
```

This is the lowest-level integration point exposed by the package.

---

## Redis Backend Behavior

`RedisLock` implements `ILockable` like this:

- `AcquireAsync(key, maxWindow)` uses `StringSetAsync(..., When.NotExists)`
- `IsAcquiredAsync(key)` checks whether the key currently exists
- `ReleaseAsync(key)` uses a Lua script so the key is deleted only when the stored value matches the expected key value

That gives you two useful properties:

- acquisition is atomic across all Redis-connected processes
- release is guarded, so one caller does not accidentally delete another caller's lock entry

The optional `maxWindow` parameter is important for race-condition scenarios because it becomes the Redis key expiration window.

---

## Configuration and Registration Notes

`RedisConfiguration` is intentionally minimal:

```csharp
public sealed class RedisConfiguration
{
    public string? ConnectionString { get; set; }
}
```

The package creates the `IConnectionMultiplexer` immediately during registration:

```csharp
services.AddSingleton<IConnectionMultiplexer>(
    ConnectionMultiplexer.Connect(redisConfiguration.ConnectionString));
```

So connection issues can surface as soon as the service collection is being built.

Also note the registration order behavior:

- `AddRedisLockable(...)` uses `TryAddSingleton<ILockable, RedisLock>()`
- `AddRedisLock(...)` and `AddRaceConditionWithRedis(...)` rely on that registration

That means if another `ILockable` has already been registered earlier, Redis will not override it automatically. In practice, use the Redis registration path as the primary setup for the service collection instead of mixing it with `AddLock()` or `AddRaceCondition()` first.

---

## Repository Examples

The most useful references for this package are:

- Redis lock registration: [src/Extensions/Concurrency/Rystem.Concurrency.Redis/Lock/ServiceCollectionExtensions.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Extensions/Concurrency/Rystem.Concurrency.Redis/Lock/ServiceCollectionExtensions.cs)
- Redis race-condition registration: [src/Extensions/Concurrency/Rystem.Concurrency.Redis/RaceCondition/ServiceCollectionExtensions.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Extensions/Concurrency/Rystem.Concurrency.Redis/RaceCondition/ServiceCollectionExtensions.cs)
- Redis lockable registration: [src/Extensions/Concurrency/Rystem.Concurrency.Redis/Lockable/ServiceCollectionExtensions.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Extensions/Concurrency/Rystem.Concurrency.Redis/Lockable/ServiceCollectionExtensions.cs)
- Redis backend implementation: [src/Extensions/Concurrency/Rystem.Concurrency.Redis/Lockable/RedisLock.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Extensions/Concurrency/Rystem.Concurrency.Redis/Lockable/RedisLock.cs)
- Redis configuration model: [src/Extensions/Concurrency/Rystem.Concurrency.Redis/Configurations/RedisConfiguration.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Extensions/Concurrency/Rystem.Concurrency.Redis/Configurations/RedisConfiguration.cs)
- Distributed lock test: [src/Extensions/Concurrency/Test/Rystem.Concurrency.UnitTest/RedisLockTest.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Extensions/Concurrency/Test/Rystem.Concurrency.UnitTest/RedisLockTest.cs)

This README stays focused because `Rystem.Concurrency.Redis` is a backend package, not a separate concurrency model. The API shape comes from `Rystem.Concurrency`; Redis only supplies the shared lock state.

---

## extensions/localization-multiple

> Rystem.Localization.Multiple extends the default ASP.NET Core localization model so multiple assemblies can participate as independent resource sources at the s

### [What is Rystem?](https://github.com/KeyserDSoze/Rystem)

## Rystem.Localization.Multiple

`Rystem.Localization.Multiple` extends the default ASP.NET Core localization model so multiple assemblies can participate as independent resource sources at the same time.

The package is useful when:

- the host application has its own `.resx` files
- one or more class libraries also ship their own `.resx` files
- you still want to inject the normal `IStringLocalizer<T>` API
- each `T` should resolve against the resources of its own assembly

This package does not replace `IStringLocalizer<T>`. It replaces the factory behind it so localization can be resolved per registered assembly instead of being tied to a single localization setup.

The best source-backed examples come from the sample app in `src/Extensions/Localization/Test/LocalizationApp` and the companion Razor library in `src/Extensions/Localization/Test/Localization.RazorLibrary`.

## Resources

- Complete Documentation: [https://rystem.net](https://rystem.net)
- MCP Server for AI: [https://rystem.cloud/mcp](https://rystem.cloud/mcp)
- Discord Community: [https://discord.gg/tkWvy4WPjt](https://discord.gg/tkWvy4WPjt)
- Support the Project: [https://www.buymeacoffee.com/keyserdsoze](https://www.buymeacoffee.com/keyserdsoze)

## Installation

Use the current package id from the project metadata:

```bash
dotnet add package Rystem.Extensions.Localization.Multiple
```

The current package metadata in `src/Extensions/Localization/Rystem.Localization.Multiple/Rystem.Localization.Multiple.csproj` is:

- package id: `Rystem.Extensions.Localization.Multiple`
- version: `7.0.0`
- target framework: `net11.0`

The package builds on top of:

- `Microsoft.Extensions.Localization`
- `Microsoft.Extensions.Localization.Abstractions`

## Package Architecture

The package is small and built around four pieces.

| Piece | Purpose |
|---|---|
| `AddMultipleLocalization<T>(...)` | Registers one assembly as a localization source |
| `MultipleLocalizationOptions` | Stores `ResourcesPath` plus the registered assembly name |
| `IMultipleStringLocalizerFactory` | Selects the right `IStringLocalizerFactory` for a requested type |
| `MultipleStringLocalizer<T>` | Transparent `IStringLocalizer<T>` implementation that delegates to the selected factory |

At a high level, the flow is:

- call `AddMultipleLocalization<T>(...)` once for each assembly you want to expose
- the package stores one `MultipleLocalizationOptions` instance per registration
- `IStringLocalizer<TResource>` resolves to `MultipleStringLocalizer<TResource>`
- that wrapper asks `IMultipleStringLocalizerFactory` for the factory matching `TResource.Assembly`
- the selected factory uses the right resource path and assembly when resolving `.resx` entries

## Table of Contents

- [Package Architecture](#package-architecture)
- [The Problem it Solves](#the-problem-it-solves)
- [Registration](#registration)
  - [Register one assembly](#register-one-assembly)
  - [Register multiple assemblies](#register-multiple-assemblies)
  - [ResourcesPath behavior](#resourcespath-behavior)
- [Usage with IStringLocalizer](#usage-with-istringlocalizer)
- [How Resolution Works](#how-resolution-works)
- [Fallback Behavior](#fallback-behavior)
- [Repository Examples](#repository-examples)

---

## The Problem it Solves

The standard localization setup is easy when one application owns all resources.

It becomes awkward when resources are split across assemblies. For example:

- the app has `LocalizationApp.Resources.Shared2.resx`
- a Razor class library has `Localization.RazorLibrary.Resources.Shared.resx`

The sample app demonstrates exactly that setup.

In `src/Extensions/Localization/Test/LocalizationApp/Pages/Index.razor`, both localizers are injected side by side:

```razor
@using Microsoft.Extensions.Localization;
@using Localization.RazorLibrary.Resources;
@inject IStringLocalizer<Shared> Localization
@inject IStringLocalizer<Shared2> Localization2

<h2>@Localization["Ale"]</h2>
<h2>@Localization2["Lisa"]</h2>
```

And the resources really do come from different assemblies:

- `src/Extensions/Localization/Test/Localization.RazorLibrary/Resources/Shared.resx` contains `Ale -> Yes I am`
- `src/Extensions/Localization/Test/LocalizationApp/Resources/Shared2.resx` contains `Lisa -> Yes I am in app`

That is the main capability this package adds.

---

## Registration

### Register one assembly

Register an assembly by passing any anchor type from that assembly.

```csharp
services.AddMultipleLocalization<Shared2>(options =>
{
    options.ResourcesPath = "Resources";
});
```

Internally the package captures:

- `ResourcesPath`
- `typeof(T).Assembly.GetName().Name()` as `FullNameAssembly`

You can also use the parameterless overload:

```csharp
services.AddMultipleLocalization<Shared2>();
```

That overload sets `ResourcesPath` to `string.Empty`.

### Register multiple assemblies

Call the method once per participating assembly.

The sample app does exactly that through two extension methods:

```csharp
builder.Services.AddInAppLocalization();
builder.Services.AddLibraryLocalization();
```

Those map to these registrations:

```csharp
services.AddMultipleLocalization<Shared2>(x =>
{
    x.ResourcesPath = "Resources";
});

services.AddMultipleLocalization<Shared>(x =>
{
    x.ResourcesPath = string.Empty;
});
```

`AddMultipleLocalization<T>(...)` can therefore be repeated safely for different assemblies. The shared singleton factory receives all registered `MultipleLocalizationOptions` instances through `IEnumerable<MultipleLocalizationOptions>`.

### ResourcesPath behavior

`ResourcesPath` works the same way it does in standard ASP.NET Core localization: it points to the folder that contains the `.resx` files inside the registered assembly.

From the current sample:

- the app registers `Shared2` with `ResourcesPath = "Resources"`
- the Razor library registers `Shared` with `ResourcesPath = string.Empty`

The internal resource manager factory converts the path to dotted notation when building the resource prefix.

---

## Usage with IStringLocalizer

After registration, usage remains standard ASP.NET Core localization.

```csharp
using Microsoft.Extensions.Localization;

public sealed class MyService
{
    private readonly IStringLocalizer<Shared2> _localizer;

    public MyService(IStringLocalizer<Shared2> localizer)
    {
        _localizer = localizer;
    }

    public string GetValue() => _localizer["Lisa"];
}
```

Or with multiple assemblies in the same component or service:

```csharp
public sealed class DashboardService
{
    private readonly IStringLocalizer<Shared> _libraryLocalizer;
    private readonly IStringLocalizer<Shared2> _appLocalizer;

    public DashboardService(
        IStringLocalizer<Shared> libraryLocalizer,
        IStringLocalizer<Shared2> appLocalizer)
    {
        _libraryLocalizer = libraryLocalizer;
        _appLocalizer = appLocalizer;
    }

    public string[] GetTexts() =>
    [
        _libraryLocalizer["Ale"],
        _appLocalizer["Lisa"]
    ];
}
```

No custom consumer API is needed. That is the main design goal of the package.

---

## How Resolution Works

`AddMultipleLocalization<T>(...)` registers:

- `IStringLocalizer<>` -> `MultipleStringLocalizer<>` as transient
- `IMultipleStringLocalizerFactory` -> `MultipleStringLocalizerFactory` as singleton
- one singleton `MultipleLocalizationOptions` instance for the registered assembly

`MultipleStringLocalizer<TResourceSource>` inherits from `StringLocalizer<TResourceSource>` and simply passes in the factory selected for `TResourceSource`.

The singleton `MultipleStringLocalizerFactory` builds a dictionary keyed by assembly name:

```csharp
_localizers.Add(options.FullNameAssembly,
    new ResourceManagerStringLocalizerFactory(new MultipleOptions(options), loggerFactory));
```

Then, at resolution time:

```csharp
var assemblyName = type.Assembly.GetName().Name;
if (_localizers.ContainsKey(assemblyName!))
    return _localizers[assemblyName!];
```

So the localizer used for `IStringLocalizer<Shared>` and `IStringLocalizer<Shared2>` is selected according to the assembly of `Shared` and `Shared2`.

---

## Fallback Behavior

There is one important implementation detail to know.

If a type is requested from an assembly that was not explicitly registered, the factory falls back to the first registered localizer factory:

```csharp
return _localizers.First().Value;
```

That means:

- registered assemblies resolve deterministically to their own factory
- unregistered assemblies do not fail immediately
- instead, they reuse the first configured localization source

So in practice, you should register every assembly that you expect to localize explicitly.

---

## Repository Examples

The most useful references for this package are:

- Registration extensions: [src/Extensions/Localization/Rystem.Localization.Multiple/LocalizationServiceCollectionExtensions.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Extensions/Localization/Rystem.Localization.Multiple/LocalizationServiceCollectionExtensions.cs)
- Options model: [src/Extensions/Localization/Rystem.Localization.Multiple/MultipleLocalizationOptions.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Extensions/Localization/Rystem.Localization.Multiple/MultipleLocalizationOptions.cs)
- Factory selector: [src/Extensions/Localization/Rystem.Localization.Multiple/MultipleStringLocalizerFactoryOfT.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Extensions/Localization/Rystem.Localization.Multiple/MultipleStringLocalizerFactoryOfT.cs)
- Localizer wrapper: [src/Extensions/Localization/Rystem.Localization.Multiple/MultipleStringLocalizerOfT.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Extensions/Localization/Rystem.Localization.Multiple/MultipleStringLocalizerOfT.cs)
- Sample app registration: [src/Extensions/Localization/Test/LocalizationApp/ServiceCollectionExtensions.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Extensions/Localization/Test/LocalizationApp/ServiceCollectionExtensions.cs)
- Sample library registration: [src/Extensions/Localization/Test/Localization.RazorLibrary/ServiceCollectionExtensions.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Extensions/Localization/Test/Localization.RazorLibrary/ServiceCollectionExtensions.cs)
- Sample app usage: [src/Extensions/Localization/Test/LocalizationApp/Pages/Index.razor](https://github.com/KeyserDSoze/Rystem/blob/master/src/Extensions/Localization/Test/LocalizationApp/Pages/Index.razor)
- App resource file: [src/Extensions/Localization/Test/LocalizationApp/Resources/Shared2.resx](https://github.com/KeyserDSoze/Rystem/blob/master/src/Extensions/Localization/Test/LocalizationApp/Resources/Shared2.resx)
- Library resource file: [src/Extensions/Localization/Test/Localization.RazorLibrary/Resources/Shared.resx](https://github.com/KeyserDSoze/Rystem/blob/master/src/Extensions/Localization/Test/Localization.RazorLibrary/Resources/Shared.resx)

This README stays focused because `Rystem.Localization.Multiple` is a narrow infrastructure package. Its whole purpose is to keep the normal `IStringLocalizer<T>` developer experience while selecting the correct resource factory per assembly.

---

## extensions/queue

> Rystem.Queue is a batching queue library built on top of Rystem.BackgroundJob.

### [What is Rystem?](https://github.com/KeyserDSoze/Rystem)

## Rystem.Queue

`Rystem.Queue` is a batching queue library built on top of `Rystem.BackgroundJob`.

Items are stored in an `IQueue<T>` implementation and periodically flushed to an `IQueueManager<T>` implementation. The package includes in-memory FIFO and LIFO backends, plus an integration hook for custom queue providers.

It is most useful for:

- batching writes to external systems
- lightweight buffered ingestion
- collecting events before periodic processing
- swapping queue backends while keeping the same enqueue and flush contracts

The best real examples for this package come from the source itself and the unit test in `src/Extensions/Queue/Test/Rystem.Queue.UnitTest/QueueTest.cs`.

## Resources

- Complete Documentation: [https://rystem.net](https://rystem.net)
- MCP Server for AI: [https://rystem.cloud/mcp](https://rystem.cloud/mcp)
- Discord Community: [https://discord.gg/tkWvy4WPjt](https://discord.gg/tkWvy4WPjt)
- Support the Project: [https://www.buymeacoffee.com/keyserdsoze](https://www.buymeacoffee.com/keyserdsoze)

## Installation

```bash
dotnet add package Rystem.Queue
```

The current `10.x` package targets `net11.0` and builds on top of [`Rystem.BackgroundJob`](https://github.com/KeyserDSoze/Rystem/blob/master/src/Extensions/BackgroundJob/Rystem.BackgroundJob/README.md).

## Package Architecture

The package is centered around five pieces.

| Piece | Purpose |
|---|---|
| `IQueue<T>` | Storage abstraction for queued items |
| `IQueueManager<T>` | Batch processor invoked when a flush happens |
| `QueueProperty<T>` | Per-queue settings for thresholds and schedules |
| `QueueJobManager<T>` | Internal background job that decides when to flush |
| `AddQueueIntegration(...)` | DI entry point that wires queue, manager, settings, and background job |

The two built-in queue backends are:

- `MemoryQueue<T>` for FIFO behavior
- `MemoryStackQueue<T>` for LIFO behavior

At a high level, the flow is:

- register a queue and a queue manager
- enqueue items through `IQueue<T>`
- run `WarmUpAsync()` so the background job starts
- the queue job checks size and schedule conditions
- when a flush occurs, it dequeues items and passes them to `IQueueManager<T>.ManageAsync(...)`

## Table of Contents

- [Package Architecture](#package-architecture)
- [Implement a Queue Manager](#implement-a-queue-manager)
  - [IQueueManager contract](#iqueuemanager-contract)
  - [Dependency injection behavior](#dependency-injection-behavior)
- [Register a Queue](#register-a-queue)
  - [In-memory FIFO queue](#in-memory-fifo-queue)
  - [In-memory LIFO stack queue](#in-memory-lifo-stack-queue)
  - [Generic queue integration](#generic-queue-integration)
- [QueueProperty](#queueproperty)
- [Flush Behavior and Warm-up](#flush-behavior-and-warm-up)
  - [Warm-up starts the queue worker](#warm-up-starts-the-queue-worker)
  - [Buffer threshold](#buffer-threshold)
  - [Retention and polling cadence](#retention-and-polling-cadence)
- [Using IQueue](#using-iqueue)
  - [IQueue contract](#iqueue-contract)
  - [Memory queue semantics](#memory-queue-semantics)
- [Custom Queue Backends](#custom-queue-backends)
- [Repository Examples](#repository-examples)

---

## Implement a Queue Manager

`IQueueManager<T>` is the consumer that receives a flushed batch.

```csharp
using Rystem.Queue;

public sealed class SampleQueueManager : IQueueManager<Sample>
{
    private readonly ILogger<SampleQueueManager> _logger;

    public SampleQueueManager(ILogger<SampleQueueManager> logger)
    {
        _logger = logger;
    }

    public Task ManageAsync(IEnumerable<Sample> items)
    {
        _logger.LogInformation("Processing {Count} items", items.Count());
        return Task.CompletedTask;
    }
}
```

### IQueueManager contract

```csharp
public interface IQueueManager<in T>
{
    Task ManageAsync(IEnumerable<T> items);
}
```

The manager should be able to process the whole batch in one call.

### Dependency injection behavior

`AddQueueIntegration(...)` registers `IQueueManager<T>` as `Transient`.

When a flush happens, `QueueJobManager<T>` resolves the manager from a fresh DI scope:

```csharp
var service = _serviceProvider.CreateScope().ServiceProvider.GetService<IQueueManager<T>>();
```

That means scoped dependencies behave per flush, not for the lifetime of the application. The unit test manager in `src/Extensions/Queue/Test/Rystem.Queue.UnitTest/QueueTest.cs` demonstrates this by resolving singleton, scoped, and transient dependencies inside the manager.

---

## Register a Queue

### In-memory FIFO queue

Register the built-in FIFO queue with `AddMemoryQueue<T, TQueueManager>()`:

```csharp
services.AddMemoryQueue<Sample, SampleQueueManager>(options =>
{
    options.MaximumBuffer = 1000;
    options.MaximumRetentionCronFormat = "*/3 * * * * *";
    options.BackgroundJobCronFormat = "*/1 * * * * *";
});
```

This uses `MemoryQueue<T>`, which is backed by `ConcurrentQueue<T>`.

### In-memory LIFO stack queue

If you want stack-like behavior instead, use `AddMemoryStackQueue<T, TQueueManager>()`:

```csharp
services.AddMemoryStackQueue<Sample, SampleQueueManager>(options =>
{
    options.MaximumBuffer = 1000;
    options.MaximumRetentionCronFormat = "*/3 * * * * *";
    options.BackgroundJobCronFormat = "*/1 * * * * *";
});
```

This uses `MemoryStackQueue<T>`, which is backed by `ConcurrentStack<T>`.

### Generic queue integration

The common registration path is:

```csharp
services.AddQueueIntegration<T, TQueueManager, TQueue>(options =>
{
    // configure QueueProperty<T>
});
```

Internally it registers:

- `QueueProperty<T>` as singleton
- `IQueue<T>` as singleton
- `IQueueManager<T>` as transient
- `QueueJobManager<T>` through `AddBackgroundJob(...)`

The background queue worker is configured with:

```csharp
x.Cron = settings.BackgroundJobCronFormat;
x.RunImmediately = false;
```

So queue processing always depends on the `Rystem.BackgroundJob` scheduler and does not run immediately at startup unless the first scheduled tick occurs.

---

## QueueProperty

`QueueProperty<T>` contains the queue settings:

```csharp
public sealed class QueueProperty<T>
{
    public int MaximumBuffer { get; set; } = 5000;
    public string MaximumRetentionCronFormat { get; set; } = "*/1 * * * *";
    public string BackgroundJobCronFormat { get; set; } = "*/1 * * * *";
}
```

| Property | Default | Purpose |
|---|---|---|
| `MaximumBuffer` | `5000` | Flush when the queued item count goes above this value |
| `MaximumRetentionCronFormat` | `"*/1 * * * *"` | Retention schedule used by `QueueJobManager<T>` when computing flush timing |
| `BackgroundJobCronFormat` | `"*/1 * * * *"` | How often the background worker checks the queue |

`QueueProperty<T>` is generic only so it can be registered separately per queue type.

---

## Flush Behavior and Warm-up

### Warm-up starts the queue worker

Because the queue worker is implemented as a background job, it starts only after warm-up runs:

```csharp
var app = builder.Build();
await app.Services.WarmUpAsync();
app.Run();
```

The unit test does the same with:

```csharp
serviceProvider.WarmUpAsync().ToResult();
```

Without warm-up, the scheduled queue flushes never begin.

### Buffer threshold

The internal queue worker flushes when:

```csharp
await _queue.CountAsync() > _property.MaximumBuffer
```

Note the comparison is `>` rather than `>=`.

That is why the test uses `1001` items when `MaximumBuffer = 1000`:

```csharp
for (int i = 0; i < 1001; i++)
    await queue.AddAsync(new Sample { Id = i.ToString() });
```

After a short wait, the queue is empty again:

```csharp
Assert.Equal(0, await queue.CountAsync());
```

### Retention and polling cadence

The queue worker runs on `BackgroundJobCronFormat`, and that scheduled execution is the outer polling loop for flushes.

Inside the worker, `MaximumRetentionCronFormat` is parsed with `Cronos` to compute the next retention occurrence when flush logic runs. In practice, the background job cadence is what determines how often the queue can be inspected, so keep `BackgroundJobCronFormat` at or below the level of responsiveness you want.

The test-backed example configures:

```csharp
options.MaximumRetentionCronFormat = "*/3 * * * * *";
options.BackgroundJobCronFormat = "*/1 * * * * *";
```

With that setup, the queue is checked every second and flushed during the scheduled processing loop.

---

## Using IQueue

Inject `IQueue<T>` wherever items should be buffered.

```csharp
using Rystem.Queue;

public sealed class OrderService
{
    private readonly IQueue<Sample> _queue;

    public OrderService(IQueue<Sample> queue)
    {
        _queue = queue;
    }

    public async Task EnqueueAsync()
    {
        for (int i = 0; i < 100; i++)
            await _queue.AddAsync(new Sample { Id = i.ToString() });
    }
}
```

### IQueue contract

```csharp
public interface IQueue<T>
{
    Task AddAsync(T entity);
    Task<IEnumerable<T>> DequeueAsync(int? top = null);
    Task<IEnumerable<T>> ReadAsync(int? top = null);
    Task<int> CountAsync();
}
```

Typical usage:

```csharp
await queue.AddAsync(new Sample { Id = "1" });

IEnumerable<Sample> preview = await queue.ReadAsync(top: 10);
IEnumerable<Sample> batch = await queue.DequeueAsync(top: 50);
int count = await queue.CountAsync();
```

### Memory queue semantics

The built-in in-memory implementations behave like this:

- `MemoryQueue<T>` is FIFO
- `MemoryStackQueue<T>` is LIFO
- both implementations are singleton-backed, so queued items live for the application lifetime unless dequeued

---

## Custom Queue Backends

To plug in your own queue storage, implement `IQueue<T>` and register it through `AddQueueIntegration(...)`.

```csharp
using Rystem.Queue;

public sealed class ServiceBusQueue<T> : IQueue<T>
{
    public Task AddAsync(T entity) => Task.CompletedTask;
    public Task<IEnumerable<T>> ReadAsync(int? top = null) => Task.FromResult(Enumerable.Empty<T>());
    public Task<IEnumerable<T>> DequeueAsync(int? top = null) => Task.FromResult(Enumerable.Empty<T>());
    public Task<int> CountAsync() => Task.FromResult(0);
}
```

```csharp
services.AddQueueIntegration<Sample, SampleQueueManager, ServiceBusQueue<Sample>>(options =>
{
    options.MaximumBuffer = 1000;
    options.MaximumRetentionCronFormat = "*/3 * * * * *";
    options.BackgroundJobCronFormat = "*/1 * * * * *";
});
```

When writing a custom backend, keep these semantics aligned with the queue worker:

- `CountAsync()` should reflect the current queued count as accurately as possible
- `DequeueAsync()` should remove the returned items
- `ReadAsync()` should not remove items

---

## Repository Examples

The most useful references for this package are:

- Queue registration entry point: [src/Extensions/Queue/Rystem.Queue/ServiceCollectionExtensions/ServiceCollectionExtensions.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Extensions/Queue/Rystem.Queue/ServiceCollectionExtensions/ServiceCollectionExtensions.cs)
- Queue settings model: [src/Extensions/Queue/Rystem.Queue/Models/QueueProperty.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Extensions/Queue/Rystem.Queue/Models/QueueProperty.cs)
- Queue worker background job: [src/Extensions/Queue/Rystem.Queue/BackgroundJob/QueueJobManager.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Extensions/Queue/Rystem.Queue/BackgroundJob/QueueJobManager.cs)
- Queue contract: [src/Extensions/Queue/Rystem.Queue/Interfaces/IQueue.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Extensions/Queue/Rystem.Queue/Interfaces/IQueue.cs)
- Queue manager contract: [src/Extensions/Queue/Rystem.Queue/Interfaces/IQueueManager.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Extensions/Queue/Rystem.Queue/Interfaces/IQueueManager.cs)
- FIFO in-memory backend: [src/Extensions/Queue/Rystem.Queue/InMemory/MemoryQueue.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Extensions/Queue/Rystem.Queue/InMemory/MemoryQueue.cs)
- LIFO in-memory backend: [src/Extensions/Queue/Rystem.Queue/InMemory/MemoryStackQueue.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Extensions/Queue/Rystem.Queue/InMemory/MemoryStackQueue.cs)
- Unit test: [src/Extensions/Queue/Test/Rystem.Queue.UnitTest/QueueTest.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Extensions/Queue/Test/Rystem.Queue.UnitTest/QueueTest.cs)

This README is intentionally architecture-first because `Rystem.Queue` is more than just an in-memory queue. It is a small batching pipeline built from a queue abstraction, a batch manager abstraction, and a scheduled worker from `Rystem.BackgroundJob`.

---

## extensions/web-components

> Rystem.Web.Components is a Blazor component library centered on Bootstrap-flavored layout helpers, a fluent CSS-class builder, a small set of UI services, and s

### [What is Rystem?](https://github.com/KeyserDSoze/Rystem)

## Rystem.Web.Components

`Rystem.Web.Components` is a Blazor component library centered on Bootstrap-flavored layout helpers, a fluent CSS-class builder, a small set of UI services, and static assets for styles and Material Symbols.

The package is still clearly work-in-progress from the current source layout, so the most useful way to document it is to stay very close to the public code that actually exists today.

It is most useful for:

- lightweight Bootstrap-style Blazor layouts
- reusable button and icon components
- fluent CSS class composition in C#
- clipboard and loader services for interactive UI flows

The strongest example source is the sample app in `src/Extensions/Web/Test/Rystem.Web.Components.Test`.

## Resources

- Complete Documentation: [https://rystem.net](https://rystem.net)
- MCP Server for AI: [https://rystem.cloud/mcp](https://rystem.cloud/mcp)
- Discord Community: [https://discord.gg/tkWvy4WPjt](https://discord.gg/tkWvy4WPjt)
- Support the Project: [https://www.buymeacoffee.com/keyserdsoze](https://www.buymeacoffee.com/keyserdsoze)

## Installation

```bash
dotnet add package Rystem.Web.Components
```

The current package metadata in `src/Extensions/Web/Rystem.Web.Components/Rystem.Web.Components.csproj` is:

- package id: `Rystem.Web.Components`
- version: `3.1.33`
- target framework: `net11.0`

The package builds on top of:

- `Microsoft.AspNetCore.App`
- `Microsoft.AspNetCore.Components.Web`
- `Rystem`
- `Rystem.Extensions.Localization.Multiple`

## Package Architecture

The current package surface is organized around five areas.

| Area | Purpose |
|---|---|
| `AddRystemWeb()` / `RystemWebBuilder` | DI entry point and service registration builder |
| Layout components | `Container`, `Row`, `Col`, `Wrapper` |
| UI components | `Button`, `Icon` |
| Styling helpers | `Bootstrap` and the related builder types |
| Services and assets | `ILoaderService`, `ICopyService`, plus packaged CSS/JS partials |

There are also table-related support models under `Contents/DataTable`, but in the current public source tree those models are present without a completed public table component.

## Table of Contents

- [Package Architecture](#package-architecture)
- [Setup](#setup)
  - [Service registration](#service-registration)
  - [Imports and static assets](#imports-and-static-assets)
- [Layout Components](#layout-components)
  - [Container](#container)
  - [Row](#row)
  - [Col](#col)
  - [Wrapper](#wrapper)
- [UI Components](#ui-components)
  - [Button](#button)
  - [Icon](#icon)
- [Bootstrap Class Builder](#bootstrap-class-builder)
- [Built-in Services](#built-in-services)
  - [ILoaderService](#iloaderservice)
  - [ICopyService](#icopyservice)
  - [IDialogService](#idialogservice)
- [Table-related Models](#table-related-models)
- [Repository Examples](#repository-examples)

---

## Setup

### Service registration

The DI entry point is:

```csharp
builder.Services.AddRystemWeb();
```

This currently does one thing in the source:

```csharp
services.AddRazorPages();
```

It then returns a `RystemWebBuilder`, which exposes the available service registrations.

Current builder methods are:

```csharp
builder.Services
    .AddRystemWeb()
    .WithLoaderService()
    .WithCopyService();
```

Or all currently implemented services at once:

```csharp
builder.Services
    .AddRystemWeb()
    .WithAllServices();
```

From the current implementation, `WithAllServices()` only includes:

- `WithLoaderService()`
- `WithCopyService()`

### Imports and static assets

The sample project imports the component namespace in `_Imports.razor`:

```razor
@using Rystem.Web.Components
@using Rystem.Web.Components.Customization
```

The package also ships two partials for assets:

- `RystemStyle`
- `RystemScript`

The sample host page includes them like this:

```cshtml
<partial name="RystemStyle" />
...
<partial name="RystemScript" />
```

Those partials add:

- Google Material Symbols font stylesheets
- `_content/Rystem.Web.Components/rystem.css`
- Bootstrap bundle JS from CDN
- `_content/Rystem.Web.Components/rystem.js`

---

## Layout Components

### Container

`Container` renders a `<div>` and combines a Bootstrap container class with an optional custom builder.

```razor
<Container Breakpoint="BreakpointType.Small">
    <Row>
        <Col>content</Col>
    </Row>
</Container>
```

Current public parameters:

- `ChildContent`
- `Class` as `Bootstrap`
- `Breakpoint` as `BreakpointType`

The CSS class is built as:

```csharp
$"{Breakpoint.ToBoostrapBreakpoint("container{0}")} {Class?.ToString()}"
```

### Row

`Row` renders a Bootstrap row container.

```razor
<Row RowBuilder="RowBuilder.Style.Default.S1.Large.S2">
    <Col>left</Col>
    <Col>right</Col>
</Row>
```

Current public parameters:

- `ChildContent`
- `Class` as plain string
- `RowBuilder` as `RowBuilder`

### Col

`Col` renders a Bootstrap column container.

```razor
<Col ColumnBuilder="ColumnBuilder.Style.ExtraExtraLarge.S11.ExtraLarge.S9">
    content
</Col>
```

Current public parameters:

- `ChildContent`
- `Class` as plain string
- `ColumnBuilder` as `ColumnBuilder`

### Wrapper

`Wrapper` is a generic `<div>` wrapper that accepts the top-level `Bootstrap` builder.

```razor
<Wrapper Bootstrap="Bootstrap.Style.Container.Large.And().Column.Small.S7.Build()">
    <div>content</div>
</Wrapper>
```

Unlike the name suggests, the current implementation prefixes the wrapper with `row` as part of `GetCssClass()`.

---

## UI Components

### Button

`Button` renders a Bootstrap-style button with optional body content, text, and icon.

```razor
<Button Message="Search"
        Size="SizeType.Large"
        Icon="IconType.Search"
        IconStyle="StyleType.Rounded"
        IconSize="SizeType.Large"
        Click="@Clicking">
    <Body>
        Search
    </Body>
</Button>
```

Current public parameters:

- `Click` as `Func<ValueTask>?`
- `Color` as `ColorType`
- `Size` as `SizeType`
- `Outline` as `bool`
- `Body` as `RenderFragment?`
- `Message` as `string?`
- `Icon` as `IconType`
- `IconStyle` as `StyleType`
- `IconSize` as `SizeType`
- `Disabled` as `bool`

Two important source-level details:

- `Body` does not replace `Message`; if both are set, both are rendered
- the click callback is invoked and discarded with `_ = Click?.Invoke()`, so the component itself does not await it

### Icon

`Icon` renders a Material Symbol icon inside a `<span>`.

```razor
<Icon Value="IconType.Search" Style="StyleType.Rounded" Size="SizeType.Large" />
```

The visible text is derived from the enum name:

```csharp
@Value.ToString().Trim('_').ToLower()
```

So enum members such as `Expand_More` become the lower-case Material Symbol name used by the font.

The package currently exposes a very large `IconType` enum covering many Material Symbol names.

---

## Bootstrap Class Builder

The `Bootstrap` builder is the package's fluent CSS composition entry point.

```csharp
string css = Bootstrap.Style
    .Container
    .Fluid
    .ToString();
```

Or for row and justify content:

```csharp
string rowCss = Bootstrap.Style.Row.ToString();
string justifyCss = Bootstrap.Style.JustifyContent.Default.End.Build();
```

The sample page shows the builder in real use:

```razor
<Wrapper Bootstrap="Bootstrap.Style.Container.Large.And().Column.Small.S7.And().JustifyContent.Small.End.Build()">
    <div class="@Bootstrap.Style.JustifyContent.Default.End.Build()">ciao</div>
</Wrapper>
```

This builder area is one of the stronger parts of the current package because it is actually exercised by the sample UI.

---

## Built-in Services

### ILoaderService

`ILoaderService` is fully implemented and registered through `WithLoaderService()`.

```csharp
public interface ILoaderService
{
    bool IsVisible { get; }
    void Show();
    void Hide();
    event Action? OnChange;
}
```

Current implementation details:

- the backing service is scoped
- `IsVisible` starts as `true`
- `Show()` and `Hide()` both raise `OnChange`

### ICopyService

`ICopyService` is fully implemented and registered through `WithCopyService()`.

```csharp
public interface ICopyService
{
    ValueTask CopyAsync(string value);
}
```

The current implementation uses:

```csharp
await _jsInterop.InvokeVoidAsync("navigator.clipboard.writeText", value)
```

So it depends on browser clipboard support and Blazor JS interop.

### IDialogService

`IDialogService` exists in the public interfaces:

```csharp
public interface IDialogService
{
    void Show(string title, Func<ValueTask> ok, string? message = null);
    void Cancel();
}
```

But in the current source tree there is no concrete implementation and no `RystemWebBuilder` method that registers it.

So it should be treated as a not-yet-wired public contract rather than a ready-to-use built-in service.

---

## Table-related Models

The package currently exposes table-support models under `Contents/DataTable`, including:

- `DataTableSettings<T, TKey>`
- `PaginationState`
- `FilterWrapper<T>`
- `SearchWrapper<T>`
- `OrderWrapper<T>`

`DataTableSettings<T, TKey>` currently exposes:

```csharp
public sealed class DataTableSettings<T, TKey>
    where TKey : notnull
{
    public string CssClass { get; set; } = string.Empty;
    public Dictionary<TKey, T>? Items { get; set; }
    public Func<PaginationState, FilterWrapper<T>, Task<(Dictionary<TKey, T> Items, int Count)>>? ItemsSelector { get; set; }
    public ColorType Color { get; set; }
    public SizeType Size { get; set; }
    public bool Striped { get; set; }
    public bool Sticky { get; set; }
    public BorderType Bordered { get; set; }
    public BreakpointType Responsive { get; set; }
    public bool Hover { get; set; }
}
```

However, the current public source tree does not include a matching completed table component. So these APIs are best understood as groundwork for a table feature rather than a finished top-level component surface.

---

## Repository Examples

The most useful references for this package are:

- Service registration entry point: [src/Extensions/Web/Rystem.Web.Components/ServiceCollectionExtensions.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Extensions/Web/Rystem.Web.Components/ServiceCollectionExtensions.cs)
- Builder registrations: [src/Extensions/Web/Rystem.Web.Components/Builder/RystemWebBuilder.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Extensions/Web/Rystem.Web.Components/Builder/RystemWebBuilder.cs)
- `Container`: [src/Extensions/Web/Rystem.Web.Components/Components/Container.razor](https://github.com/KeyserDSoze/Rystem/blob/master/src/Extensions/Web/Rystem.Web.Components/Components/Container.razor)
- `Row`: [src/Extensions/Web/Rystem.Web.Components/Components/Row.razor](https://github.com/KeyserDSoze/Rystem/blob/master/src/Extensions/Web/Rystem.Web.Components/Components/Row.razor)
- `Col`: [src/Extensions/Web/Rystem.Web.Components/Components/Col.razor](https://github.com/KeyserDSoze/Rystem/blob/master/src/Extensions/Web/Rystem.Web.Components/Components/Col.razor)
- `Button`: [src/Extensions/Web/Rystem.Web.Components/Components/Button.razor](https://github.com/KeyserDSoze/Rystem/blob/master/src/Extensions/Web/Rystem.Web.Components/Components/Button.razor)
- `Icon`: [src/Extensions/Web/Rystem.Web.Components/Components/Icon.razor](https://github.com/KeyserDSoze/Rystem/blob/master/src/Extensions/Web/Rystem.Web.Components/Components/Icon.razor)
- CSS builder entry point: [src/Extensions/Web/Rystem.Web.Components/Customization/Builder/Bootstrap.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Extensions/Web/Rystem.Web.Components/Customization/Builder/Bootstrap.cs)
- Asset partials: [src/Extensions/Web/Rystem.Web.Components/Pages/Shared/RystemStyle.cshtml](https://github.com/KeyserDSoze/Rystem/blob/master/src/Extensions/Web/Rystem.Web.Components/Pages/Shared/RystemStyle.cshtml) and [src/Extensions/Web/Rystem.Web.Components/Pages/Shared/RystemScript.cshtml](https://github.com/KeyserDSoze/Rystem/blob/master/src/Extensions/Web/Rystem.Web.Components/Pages/Shared/RystemScript.cshtml)
- Sample app startup: [src/Extensions/Web/Test/Rystem.Web.Components.Test/Program.cs](https://github.com/KeyserDSoze/Rystem/blob/master/src/Extensions/Web/Test/Rystem.Web.Components.Test/Program.cs)
- Sample page usage: [src/Extensions/Web/Test/Rystem.Web.Components.Test/Pages/Index.razor](https://github.com/KeyserDSoze/Rystem/blob/master/src/Extensions/Web/Test/Rystem.Web.Components.Test/Pages/Index.razor)
- Sample host page: [src/Extensions/Web/Test/Rystem.Web.Components.Test/Pages/_Host.cshtml](https://github.com/KeyserDSoze/Rystem/blob/master/src/Extensions/Web/Test/Rystem.Web.Components.Test/Pages/_Host.cshtml)

This README stays intentionally conservative because the package is still evolving. It documents the component and service surface that is visibly present in the current source tree, rather than promising a broader UI framework than the current implementation actually provides.
