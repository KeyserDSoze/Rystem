---
name: Rystem - Get Rystem Docs / Extensions
description: Rystem Framework docs: extensions/backgroundjob, extensions/concurrency, extensions/concurrency-redis, extensions/localization-multiple and 2 more. Use for extensions questions in Rystem.
---

# Rystem - Get Rystem Docs / Extensions

> Auto-generated from Rystem MCP manifest (tool: `get-rystem-docs`, category: `extensions`)

---

## extensions/backgroundjob

> Background job is a library that helps to create a background thread in your application (webapp or similar).

## Background job
Background job is a library that helps to create a background thread in your application (webapp or similar).
With the dependency injection pattern, you may set che CRON value (when your job has to run), [link to create CRON](https://crontab.guru/).
You may set to true the RunImmediately if you want to run one time during your bootstrap.
You may set the Key to allow the possibility to have more than one job with the same class on the same instance.

	builder.Services.AddBackgroundJob<BackgroundJob>(
        x =>
        {
            x.Cron = "*/1 * * * *";
            x.RunImmediately = true;
            x.Key = "alzo";
        });

Your class BackgroundJob has to extend IBackgrounJob and you may warm up it during the bootstrap.

    var app = builder.Build();
    await app.Services.WarmUpAsync();

In IBackgroundJob you have ActionToDoAsync, it's the main method, called when the cron is fired; and OnException to catch the possibile exception during the main method run.

---

## extensions/concurrency

> A lock keyword is used in C# to lock a memory address to have a sort of execution queue. But, unfortunately, you cannot use async methods in the lock statement.

### [What is Rystem?](https://github.com/KeyserDSoze/Rystem)

## Concurrency

### Async Lock
A lock keyword is used in C# to lock a memory address to have a sort of execution queue. But, unfortunately, you cannot use async methods in the lock statement.
With async lock you also may have the lock behavior for your async methods.
In DI you have to add the lock service

	services.AddLock();

Inject ILock and use it

	ILock locking = _serviceProvider.CreateScope().ServiceProvider.GetService<ILock>();
	await locking!.ExecuteAsync(() => CountAsync(2), "SampleKey");

You have the method to execute, a key for more than one concurrent lock.

### Race condition
First of all, you have to understand the race condition [here](https://en.wikipedia.org/wiki/Race_condition)
In DI you have to add the lock service

	services.AddRaceCondition();
	
Inject IRaceCodition and use it

	 var raceCondition = _serviceProvider.CreateScope().ServiceProvider.GetService<IRaceCodition>();
	 raceCondition!.ExecuteAsync(() => CountAsync(2), (i % 2).ToString(), TimeSpan.FromSeconds(2));

You have the method to execute, a key for more than one concurrent race, and a time span for time window, if you put 2 seconds, you block the execution of further methods for 2 seconds from when first method started.

### ILockable
You can inject the ILockable interface for your purpose, like a distributed lock with Blob storage, or redis cache for instance.

	services.AddLockableIntegration<BlobLockIntegration>();

---

## extensions/concurrency-redis

> A lock keyword is used in C# to lock a memory address to have a sort of execution queue. But, unfortunately, you cannot use async methods in the lock statement.

### [What is Rystem?](https://github.com/KeyserDSoze/Rystem)

## Concurrency

### Async Lock
A lock keyword is used in C# to lock a memory address to have a sort of execution queue. But, unfortunately, you cannot use async methods in the lock statement.
With async lock you also may have the lock behavior for your async methods.
In DI you have to add the lock service

	services.AddRedisLock(x =>
                {
                    x.ConnectionString = configuration["ConnectionString:Redis"]!;
                });

Inject ILock and use it

	ILock locking = _serviceProvider.CreateScope().ServiceProvider.GetService<ILock>();
	await locking!.ExecuteAsync(() => CountAsync(2), "SampleKey");

You have the method to execute, a key for more than one concurrent lock.

### Race condition
First of all, you have to understand the race condition [here](https://en.wikipedia.org/wiki/Race_condition)
In DI you have to add the lock service

	services.AddRaceConditionWithRedis(x =>
                {
                    x.ConnectionString = configuration["ConnectionString:Redis"]!;
                });
	
Inject IRaceCodition and use it

	 var raceCondition = _serviceProvider.CreateScope().ServiceProvider.GetService<IRaceCodition>();
	 raceCondition!.ExecuteAsync(() => CountAsync(2), (i % 2).ToString(), TimeSpan.FromSeconds(2));

You have the method to execute, a key for more than one concurrent race, and a time span for time window, if you put 2 seconds, you block the execution of further methods for 2 seconds from when first method started.

---

## extensions/localization-multiple

> You have to add a service for localization with Multiple word.

### [What is Rystem?](https://github.com/KeyserDSoze/Rystem)

## Add to service collection the multiple localization from different sources/libraries

You have to add a service for localization with Multiple word.
From library 1 for example

    services.AddMultipleLocalization<Shared1>(x =>
        {
            x.ResourcesPath = "Resources";
        });

and for library 2

    services.AddMultipleLocalization<Shared2>(x =>
        {
            x.ResourcesPath = "Resources";
        });

When you use the IStringLocalizer<T> the model T will find the correct assembly resources, choosing between assembly 1 (from Shared1) or assembly 2 (from Shared2).

Inject a model from library 1 to access to resources from library 1, and the same for library 2.

    IStringLocalizer<SameClassInShared1Library1>
    IStringLocalizer<SameClassInShared1Library2>

---

## extensions/queue

> You have to configure it in DI

## Queue
You have to configure it in DI
BackgroundJobCronFormat is the CRON for background job that checks if Maximum buffer is exceeded or has a retention expired, usually is lesser than or equal of MaximumRetentionCronFormat.
MaximumRetentionCronFormat is the CRON for maximum time before to empty the queue and call the IQueueManager<T>.
MaximumBuffer is the maximum queue length before to empty the queue and call the IQueueManager<T>.

	services.AddMemoryQueue<Sample, SampleQueueManager>(x =>
        {
            x.MaximumBuffer = 1000;
            x.MaximumRetentionCronFormat = "*/3 * * * * *";
            x.BackgroundJobCronFormat = "*/1 * * * * *";
        });

    public class SampleQueueManager : IQueueManager<Sample> 
    {
        public Task ManageAsync(IEnumerable<Sample> items)
        {
            return Task.CompletedTask;
        }
    }

For instance, in the example above you have a maximum queue length of 1000, a background job thatc checks every 1 second if there are 1000 or more items or maximum retention period of 3 seconds is expired.
after the build you have to warm up

    var app = builder.Build();
	await app.Services.WarmUpAsync();

and inject to use it
    
    var queue = _serviceProvider.GetService<IQueue<Sample>>()!;
    for (int i = 0; i < 100; i++)
        await queue.AddAsync(new Sample() { Id = i.ToString() });

In this example, after 1000 elements or 3 seconds the configured actions will be fired and the queue will be emptied.

### Stack (Last In First Out)

    services.AddMemoryStackQueue<Sample, SampleQueueManager>(x =>
        {
            x.MaximumBuffer = 1000;
            x.MaximumRetentionCronFormat = "*/3 * * * * *";
            x.BackgroundJobCronFormat = "*/1 * * * * *";
        });

### Custom integration
If you want to use a distributed queue like storage queue, or event hub or service bus or event grid, you can write your own integration and configure it.

    services.AddQueueIntegration<Sample, SampleQueueManager, YourQueueIntegration>(x =>
        {
            x.MaximumBuffer = 1000;
            x.MaximumRetentionCronFormat = "*/3 * * * * *";
            x.BackgroundJobCronFormat = "*/1 * * * * *";
        });

---

## extensions/web-components

### [What is Rystem?](https://github.com/KeyserDSoze/Rystem)
