---
name: Rystem - Get Rystem Docs / Repository
description: Rystem Framework docs: Repository API Client - .NET, Repository API Client - TypeScript, Repository API Server, Repository Pattern Setup and 17 more. Use for repository questions in Rystem.
---

# Rystem - Get Rystem Docs / Repository

> Auto-generated from Rystem MCP manifest (tool: `get-rystem-docs`, category: `repository`)

---

## Repository API Client - .NET

> Consume Repository APIs from .NET/C# apps using same IRepository interface as backend - supports Blazor Server, Blazor WASM, MAUI, WPF, and Console apps

---
title: Repository API Client - .NET
description: Consume Repository APIs from .NET/C# apps using same IRepository interface as backend - supports Blazor Server, Blazor WASM, MAUI, WPF, and Console apps
---

# Repository API Client - .NET/C#

**Purpose**: This tool explains how to **consume auto-generated Repository APIs** from .NET/C# applications (Blazor Server, Blazor WASM, MAUI, WPF, Console apps). The client provides the same `IRepository<T, TKey>` interface you use on the server, making it seamless to work with remote data.

---

## 🎯 What is Rystem Repository API Client?

The **Rystem.RepositoryFramework.Api.Client** package provides:
- ✅ **Same interface as server** - use `IRepository<T, TKey>` everywhere
- ✅ **Automatic HttpClient configuration** with Polly retry policies
- ✅ **Built-in authentication** interceptors for JWT tokens
- ✅ **Factory pattern support** for multiple endpoints
- ✅ **CQRS support** with `ICommand` and `IQuery`
- ✅ **Works everywhere**: Blazor Server, Blazor WASM, MAUI, WPF, Console

**Key Benefit**: Write once, use the same repository interface on server and client!

---

## 📦 Installation

```bash
# Core API Client
dotnet add package Rystem.RepositoryFramework.Api.Client --version 9.1.3

# For Blazor Server with JWT authentication
dotnet add package Rystem.RepositoryFramework.Api.Client.Authentication.BlazorServer --version 9.1.3

# For Blazor WASM with JWT authentication
dotnet add package Rystem.RepositoryFramework.Api.Client.Authentication.BlazorWasm --version 9.1.3
```

---

## 🚀 Quick Start - Simple Repository

### Step 1: Register Repository Client

```csharp
// Program.cs (Blazor Server, MAUI, WPF, Console)
using Rystem;

var builder = WebApplication.CreateBuilder(args);

// Register repository client
builder.Services.AddRepository<Order, Guid>(repositoryBuilder =>
{
    repositoryBuilder
        .WithApiClient()
        .WithHttpClient("https://api.myapp.com/api/");
});

var app = builder.Build();
app.Run();
```

### Step 2: Use in Your Service

```csharp
// Services/OrderService.cs
public class OrderService
{
    private readonly IRepository<Order, Guid> _orderRepository;
    
    public OrderService(IRepository<Order, Guid> orderRepository)
    {
        _orderRepository = orderRepository;
    }
    
    public async Task<Order?> GetOrderAsync(Guid orderId)
    {
        return await _orderRepository.GetAsync(orderId);
    }
    
    public async Task<State<Order, Guid>> CreateOrderAsync(Order order)
    {
        return await _orderRepository.InsertAsync(order.Id, order);
    }
    
    public async Task<List<Order>> GetPendingOrdersAsync()
    {
        var results = await _orderRepository
            .Where(x => x.Status == OrderStatus.Pending)
            .ToListAsync();
        
        return results.Select(x => x.Value!).ToList();
    }
}
```

**That's it!** The same interface works on client and server.

---

## 🔄 Advanced Setup - Multiple Repositories

### Extension Method Pattern

```csharp
// Extensions/ServiceCollectionExtensions.cs
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddApiRepositories(
        this IServiceCollection services, 
        IConfiguration configuration)
    {
        var apiUri = configuration["Api:Uri"] ?? "https://api.myapp.com/api/";
        
        // Order Repository
        services.AddHttpClientIntegration<Order, Guid>(apiUri);
        
        // Customer Repository
        services.AddHttpClientIntegration<Customer, Guid>(apiUri);
        
        // Product Repository
        services.AddHttpClientIntegration<Product, int>(apiUri);
        
        // Complex key example
        services.AddHttpClientIntegration<OrderItem, OrderItemKey>(apiUri);
        
        return services;
    }
    
    // Helper method for consistent configuration
    private static IServiceCollection AddHttpClientIntegration<T, TKey>(
        this IServiceCollection services,
        string apiUri,
        string? factoryName = null)
        where TKey : notnull
    {
        return services.AddRepository<T, TKey>(builder =>
        {
            builder.WithApiClient(apiBuilder =>
            {
                apiBuilder
                    .WithHttpClient(apiUri)
                    .WithDefaultRetryPolicy();
                
                if (factoryName != null)
                    apiBuilder.WithServerFactoryName(factoryName);
            }, factoryName, ServiceLifetime.Transient);
        });
    }
}
```

### Usage in Program.cs

```csharp
// Program.cs
var builder = WebApplication.CreateBuilder(args);

// Add all API repositories
builder.Services.AddApiRepositories(builder.Configuration);

var app = builder.Build();
app.Run();
```

---

## 🔐 Authentication with JWT

### Blazor Server

```csharp
// Program.cs (Blazor Server)
using Rystem;

var builder = WebApplication.CreateBuilder(args);

// Add authentication services
builder.Services.AddAuthentication(/* your auth config */);
builder.Services.AddAuthorization();

// Add default JWT interceptor
builder.Services.AddDefaultAuthorizationInterceptorForApiHttpClient();

// Register repositories
builder.Services.AddRepository<Order, Guid>(repositoryBuilder =>
{
    repositoryBuilder
        .WithApiClient()
        .WithHttpClient("https://api.myapp.com/api/");
});

var app = builder.Build();

app.UseAuthentication();
app.UseAuthorization();

app.Run();
```

**Package required**: `Rystem.RepositoryFramework.Api.Client.Authentication.BlazorServer`

### Blazor WASM

```csharp
// Program.cs (Blazor WASM)
using Microsoft.AspNetCore.Components.WebAssembly.Hosting;
using Rystem;

var builder = WebAssemblyHostBuilder.CreateDefault(args);

// Add authentication services
builder.Services.AddAuthorizationCore();

// Add default JWT interceptor for WASM
builder.Services.AddDefaultAuthorizationInterceptorForApiHttpClient();

// Register repositories
builder.Services.AddRepository<Order, Guid>(repositoryBuilder =>
{
    repositoryBuilder
        .WithApiClient()
        .WithHttpClient("https://api.myapp.com/api/");
});

await builder.Build().RunAsync();
```

**Package required**: `Rystem.RepositoryFramework.Api.Client.Authentication.BlazorWasm`

---

## 🔧 Polly Retry Policies

Add resilience with Polly retry policies:

```csharp
using Polly;
using Polly.Extensions.Http;
using Polly.Timeout;

var builder = WebApplication.CreateBuilder(args);

// Define retry policy
var retryPolicy = HttpPolicyExtensions
    .HandleTransientHttpError()
    .Or<TimeoutRejectedException>()
    .WaitAndRetryAsync(3, retryAttempt => 
        TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)));

// Register repository with policy
builder.Services.AddRepository<Order, Guid>(repositoryBuilder =>
{
    repositoryBuilder
        .WithApiClient()
        .WithHttpClient("https://api.myapp.com/api/")
            .ClientBuilder  // Access underlying HttpClientBuilder
        .AddPolicyHandler(retryPolicy);
});
```

### Advanced Polly Configuration

```csharp
// Retry with exponential backoff
var retryPolicy = HttpPolicyExtensions
    .HandleTransientHttpError()
    .WaitAndRetryAsync(
        retryCount: 3,
        sleepDurationProvider: retryAttempt => 
            TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)),
        onRetry: (outcome, timespan, retryCount, context) =>
        {
            Console.WriteLine($"Retry {retryCount} after {timespan.TotalSeconds}s");
        });

// Circuit breaker
var circuitBreakerPolicy = HttpPolicyExtensions
    .HandleTransientHttpError()
    .CircuitBreakerAsync(
        handledEventsAllowedBeforeBreaking: 5,
        durationOfBreak: TimeSpan.FromSeconds(30));

// Timeout
var timeoutPolicy = Policy.TimeoutAsync<HttpResponseMessage>(
    TimeSpan.FromSeconds(10));

// Register with multiple policies
builder.Services.AddRepository<Order, Guid>(repositoryBuilder =>
{
    repositoryBuilder
        .WithApiClient()
        .WithHttpClient("https://api.myapp.com/api/")
            .ClientBuilder
        .AddPolicyHandler(retryPolicy)
        .AddPolicyHandler(circuitBreakerPolicy)
        .AddPolicyHandler(timeoutPolicy);
});
```

---

## 🏭 Factory Pattern - Multiple Endpoints

Use multiple API endpoints for the same entity:

```csharp
// Setup multiple repositories with factory names
builder.Services.AddRepository<Order, Guid>(repositoryBuilder =>
{
    repositoryBuilder.WithApiClient(apiBuilder =>
    {
        apiBuilder
            .WithHttpClient("https://api-primary.myapp.com/api/")
            .WithDefaultRetryPolicy();
        apiBuilder.WithServerFactoryName("primary");
    }, "primary");
});

builder.Services.AddRepository<Order, Guid>(repositoryBuilder =>
{
    repositoryBuilder.WithApiClient(apiBuilder =>
    {
        apiBuilder
            .WithHttpClient("https://api-backup.myapp.com/api/")
            .WithDefaultRetryPolicy();
        apiBuilder.WithServerFactoryName("backup");
    }, "backup");
});

// Usage with Factory
public class OrderService
{
    private readonly IFactory<IRepository<Order, Guid>> _repositoryFactory;
    
    public OrderService(IFactory<IRepository<Order, Guid>> repositoryFactory)
    {
        _repositoryFactory = repositoryFactory;
    }
    
    public async Task<Order?> GetOrderAsync(Guid orderId)
    {
        // Try primary first
        var primaryRepo = _repositoryFactory.Create("primary");
        var order = await primaryRepo.GetAsync(orderId);
        
        if (order != null)
            return order;
        
        // Fallback to backup
        var backupRepo = _repositoryFactory.Create("backup");
        return await backupRepo.GetAsync(orderId);
    }
}
```

---

## 📊 CQRS Pattern

Separate read and write operations with different endpoints:

### Setup

```csharp
// Command (write) to primary API
builder.Services.AddCommand<Order, Guid>(commandBuilder =>
{
    commandBuilder
        .WithApiClient()
        .WithHttpClient("https://api-write.myapp.com/api/");
});

// Query (read) from read replica API
builder.Services.AddQuery<Order, Guid>(queryBuilder =>
{
    queryBuilder
        .WithApiClient()
        .WithHttpClient("https://api-read.myapp.com/api/");
});
```

### Usage

```csharp
public class OrderService
{
    private readonly ICommand<Order, Guid> _orderCommand;
    private readonly IQuery<Order, Guid> _orderQuery;
    
    public OrderService(
        ICommand<Order, Guid> orderCommand,
        IQuery<Order, Guid> orderQuery)
    {
        _orderCommand = orderCommand;
        _orderQuery = orderQuery;
    }
    
    // Write operations use Command
    public async Task<State<Order, Guid>> CreateOrderAsync(Order order)
    {
        return await _orderCommand.InsertAsync(order.Id, order);
    }
    
    public async Task<State<Order, Guid>> UpdateOrderAsync(Order order)
    {
        return await _orderCommand.UpdateAsync(order.Id, order);
    }
    
    // Read operations use Query
    public async Task<Order?> GetOrderAsync(Guid orderId)
    {
        return await _orderQuery.GetAsync(orderId);
    }
    
    public async Task<List<Order>> GetPendingOrdersAsync()
    {
        var results = await _orderQuery
            .Where(x => x.Status == OrderStatus.Pending)
            .ToListAsync();
        
        return results.Select(x => x.Value!).ToList();
    }
}
```

**⚠️ Important**: Always inject `ICommand`, `IQuery`, `IRepository` - NOT `ICommandPattern`, `IQueryPattern`, `IRepositoryPattern`!

---

## 🎭 Custom Interceptors

Add custom logic before/after every HTTP request:

### Create Interceptor

```csharp
// Interceptors/CustomHeaderInterceptor.cs
using Rystem.RepositoryFramework.Api.Client;

public class CustomHeaderInterceptor : IRepositoryClientInterceptor
{
    private readonly IHttpContextAccessor _httpContextAccessor;
    
    public CustomHeaderInterceptor(IHttpContextAccessor httpContextAccessor)
    {
        _httpContextAccessor = httpContextAccessor;
    }
    
    public async ValueTask<HttpClient> EnrichAsync(
        HttpClient client,
        RepositoryMethod method,
        CancellationToken cancellationToken = default)
    {
        // Add custom headers
        var userId = _httpContextAccessor.HttpContext?.User.FindFirst("sub")?.Value;
        if (userId != null)
        {
            client.DefaultRequestHeaders.Add("X-User-Id", userId);
        }
        
        // Add correlation ID
        client.DefaultRequestHeaders.Add("X-Correlation-Id", Guid.NewGuid().ToString());
        
        // Add tenant ID for multi-tenancy
        var tenantId = await GetTenantIdAsync();
        if (tenantId != null)
        {
            client.DefaultRequestHeaders.Add("X-Tenant-Id", tenantId);
        }
        
        return client;
    }
    
    private async Task<string?> GetTenantIdAsync()
    {
        // Your tenant resolution logic
        return "tenant-123";
    }
}
```

### Register Interceptor

#### Global Interceptor (for all repositories)

```csharp
builder.Services.AddApiClientInterceptor<CustomHeaderInterceptor>(ServiceLifetime.Scoped);
```

#### Specific Interceptor (for one repository)

```csharp
builder.Services.AddRepository<Order, Guid>(repositoryBuilder =>
{
    repositoryBuilder
        .WithApiClient()
        .WithHttpClient("https://api.myapp.com/api/")
        .AddApiClientSpecificInterceptor<Order, Guid, CustomHeaderInterceptor>(ServiceLifetime.Scoped);
});
```

### Built-in JWT Interceptor

For standard JWT authentication:

```csharp
// For Blazor Server
builder.Services.AddDefaultAuthorizationInterceptorForApiHttpClient();

// For Blazor WASM
builder.Services.AddDefaultAuthorizationInterceptorForApiHttpClient();
```

This automatically adds the JWT token from the current user's authentication context.

---

## 🌐 Real-World Example - Complete Setup

```csharp
// Program.cs (Blazor Server)
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Polly;
using Polly.Extensions.Http;
using Rystem;

var builder = WebApplication.CreateBuilder(args);

// Add Blazor services
builder.Services.AddRazorPages();
builder.Services.AddServerSideBlazor();

// Add authentication
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.Authority = builder.Configuration["Auth:Authority"];
        options.Audience = builder.Configuration["Auth:Audience"];
    });

builder.Services.AddAuthorization();

// Add HttpContextAccessor for interceptors
builder.Services.AddHttpContextAccessor();

// Add default JWT interceptor
builder.Services.AddDefaultAuthorizationInterceptorForApiHttpClient();

// Add custom interceptor
builder.Services.AddApiClientInterceptor<CustomHeaderInterceptor>(ServiceLifetime.Scoped);

// Add API repositories
builder.Services.AddApiRepositories(builder.Configuration);

var app = builder.Build();

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

app.MapBlazorHub();
app.MapFallbackToPage("/_Host");

app.Run();
```

```csharp
// Extensions/ServiceCollectionExtensions.cs
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Polly;
using Polly.Extensions.Http;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddApiRepositories(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        var apiUri = configuration["Api:Uri"];
        if (!string.IsNullOrEmpty(apiUri) && !apiUri.StartsWith("http"))
            apiUri = $"https://{apiUri}";
        
        // Orders
        services.AddHttpClientIntegration<Order, Guid>(apiUri);
        
        // Customers
        services.AddHttpClientIntegration<Customer, Guid>(apiUri);
        
        // Products
        services.AddHttpClientIntegration<Product, int>(apiUri);
        
        // Shipments with factory name
        services.AddHttpClientIntegration<Shipment, Guid>(apiUri, "primary");
        
        // Live data with different endpoint
        services.AddRepository<LiveData, string>(builder =>
        {
            builder.WithApiClient(apiBuilder =>
            {
                apiBuilder
                    .WithHttpClient($"{apiUri}/live")
                    .WithDefaultRetryPolicy();
                apiBuilder.WithServerFactoryName("live");
            }, "live");
        });
        
        return services;
    }
    
    private static IServiceCollection AddHttpClientIntegration<T, TKey>(
        this IServiceCollection services,
        string apiUri,
        string? factoryName = null)
        where TKey : notnull
    {
        return services.AddRepository<T, TKey>(builder =>
        {
            builder.WithApiClient(apiBuilder =>
            {
                apiBuilder
                    .WithHttpClient(apiUri)
                    .WithDefaultRetryPolicy();
                
                if (factoryName != null)
                    apiBuilder.WithServerFactoryName(factoryName);
            }, factoryName, ServiceLifetime.Transient);
        });
    }
}
```

---

## 📱 Platform-Specific Examples

### Blazor Server

```csharp
// Program.cs
var builder = WebApplication.CreateBuilder(args);

builder.Services.AddRazorPages();
builder.Services.AddServerSideBlazor();

builder.Services.AddDefaultAuthorizationInterceptorForApiHttpClient();
builder.Services.AddApiRepositories(builder.Configuration);

var app = builder.Build();
app.UseAuthentication();
app.UseAuthorization();
app.MapBlazorHub();
app.Run();
```

### Blazor WASM

```csharp
// Program.cs
using Microsoft.AspNetCore.Components.WebAssembly.Hosting;

var builder = WebAssemblyHostBuilder.CreateDefault(args);

builder.Services.AddAuthorizationCore();
builder.Services.AddDefaultAuthorizationInterceptorForApiHttpClient();
builder.Services.AddApiRepositories(builder.Configuration);

await builder.Build().RunAsync();
```

### MAUI

```csharp
// MauiProgram.cs
using Microsoft.Extensions.Configuration;
using Microsoft.Maui.Hosting;

public static class MauiProgram
{
    public static MauiApp CreateMauiApp()
    {
        var builder = MauiApp.CreateBuilder();
        
        builder
            .UseMauiApp<App>()
            .ConfigureFonts(fonts =>
            {
                fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
            });
        
        // Add configuration
        var configuration = new ConfigurationBuilder()
            .AddJsonFile("appsettings.json")
            .Build();
        
        builder.Services.AddSingleton<IConfiguration>(configuration);
        
        // Add API repositories
        builder.Services.AddApiRepositories(configuration);
        
        return builder.Build();
    }
}
```

### WPF

```csharp
// App.xaml.cs
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

public partial class App : Application
{
    private readonly IHost _host;
    
    public App()
    {
        _host = Host.CreateDefaultBuilder()
            .ConfigureServices((context, services) =>
            {
                // Add API repositories
                services.AddApiRepositories(context.Configuration);
                
                // Add views
                services.AddSingleton<MainWindow>();
            })
            .Build();
    }
    
    protected override async void OnStartup(StartupEventArgs e)
    {
        await _host.StartAsync();
        
        var mainWindow = _host.Services.GetRequiredService<MainWindow>();
        mainWindow.Show();
        
        base.OnStartup(e);
    }
}
```

### Console App

```csharp
// Program.cs
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

var host = Host.CreateDefaultBuilder(args)
    .ConfigureServices((context, services) =>
    {
        services.AddApiRepositories(context.Configuration);
    })
    .Build();

// Use repository
var orderRepository = host.Services.GetRequiredService<IRepository<Order, Guid>>();
var order = await orderRepository.GetAsync(Guid.Parse("..."));

await host.RunAsync();
```

---

## 🎯 Best Practices

### 1. Use Extension Methods for Configuration

```csharp
// ✅ GOOD - Centralized configuration
public static IServiceCollection AddApiRepositories(this IServiceCollection services, IConfiguration configuration)
{
    services.AddHttpClientIntegration<Order, Guid>(configuration["Api:Uri"]);
    services.AddHttpClientIntegration<Customer, Guid>(configuration["Api:Uri"]);
    return services;
}

// ❌ BAD - Scattered configuration
builder.Services.AddRepository<Order, Guid>(...);
builder.Services.AddRepository<Customer, Guid>(...);
```

### 2. Always Add Retry Policies

```csharp
// ✅ GOOD - Resilient with retry
apiBuilder
    .WithHttpClient(apiUri)
    .WithDefaultRetryPolicy();

// ❌ BAD - No retry policy
apiBuilder.WithHttpClient(apiUri);
```

### 3. Use Proper Lifetime for Interceptors

```csharp
// ✅ GOOD - Scoped for user context
services.AddApiClientInterceptor<CustomHeaderInterceptor>(ServiceLifetime.Scoped);

// ❌ BAD - Singleton with user-specific data
services.AddApiClientInterceptor<CustomHeaderInterceptor>(ServiceLifetime.Singleton);
```

### 4. Inject IRepository, Not IRepositoryPattern

```csharp
// ✅ GOOD
public OrderService(IRepository<Order, Guid> repository)

// ❌ BAD
public OrderService(IRepositoryPattern<Order, Guid> repository)
```

### 5. Use Factory for Multiple Endpoints

```csharp
// ✅ GOOD - Factory for multiple endpoints
public OrderService(IFactory<IRepository<Order, Guid>> factory)
{
    var primary = factory.Create("primary");
    var backup = factory.Create("backup");
}

// ❌ BAD - Multiple injections
public OrderService(
    IRepository<Order, Guid> repo1,
    IRepository<Order, Guid> repo2) // Won't work!
```

---

## ⚠️ Important Notes

1. **Package version**: Use `9.1.3` for all Rystem packages
2. **Authentication packages**:
   - Blazor Server: `Rystem.RepositoryFramework.Api.Client.Authentication.BlazorServer`
   - Blazor WASM: `Rystem.RepositoryFramework.Api.Client.Authentication.BlazorWasm`
3. **Inject interfaces**: Use `IRepository`, `ICommand`, `IQuery` (NOT Pattern versions)
4. **Polly is optional**: But highly recommended for production
5. **Interceptors run in order**: Global first, then specific
6. **Factory names must match**: Client factory name must match server factory name
7. **HttpClient base address**: Should end with `/` for proper URL joining

---

## 🔗 Related Resources

- **repository-setup**: How to configure repositories on backend
- **repository-api-server**: How to expose repositories as REST APIs
- **repository-api-client-typescript**: Client for TypeScript/JavaScript apps
- **auth-flow**: Setting up authentication with Rystem.Authentication.Social

---

## 📖 Further Reading

- [Rystem.RepositoryFramework.Api.Client GitHub](https://github.com/KeyserDSoze/RepositoryFramework/tree/master/src/RepositoryFramework.Api.Client)
- [Authentication Integration](https://github.com/KeyserDSoze/RepositoryFramework/tree/master/src/RepositoryFramework.Api.Client.Authentication.BlazorServer)
- [Polly Documentation](https://github.com/App-vNext/Polly)

---

## ✅ Summary

**Rystem.RepositoryFramework.Api.Client** provides:
- ✅ Same `IRepository<T, TKey>` interface as server
- ✅ Automatic HttpClient configuration
- ✅ Built-in JWT authentication interceptors
- ✅ Polly retry policies support
- ✅ Custom interceptors for headers/logging
- ✅ Factory pattern for multiple endpoints
- ✅ CQRS with `ICommand` and `IQuery`
- ✅ Works on Blazor Server, Blazor WASM, MAUI, WPF, Console

**Use this tool to build .NET/C# clients that consume your Repository APIs seamlessly!** 🚀

---

## Repository API Client - TypeScript

> Consume Repository APIs from TypeScript/JavaScript apps with type-safe access, automatic authentication, and retry logic for React, Next.js, and Node.js

---
title: Repository API Client - TypeScript
description: Consume Repository APIs from TypeScript/JavaScript apps with type-safe access, automatic authentication, and retry logic for React, Next.js, and Node.js
---

# Repository API Client - TypeScript/JavaScript

**Purpose**: This tool explains how to **consume auto-generated Repository APIs** from TypeScript/JavaScript applications (React, React Native, Next.js, Node.js). The client provides type-safe access to your backend repositories with automatic authentication, error handling, and retry logic.

---

## 🎯 What is Rystem Repository Client?

The **rystem.repository.client** npm package provides:
- ✅ **Type-safe repository access** with TypeScript generics
- ✅ **Automatic authentication** with token refresh
- ✅ **Custom error handlers** with retry logic
- ✅ **CQRS support** (Command/Query separation)
- ✅ **LINQ-style queries** from client-side
- ✅ **Batch operations** support
- ✅ **Works everywhere**: React, React Native, Next.js, Node.js

**Key Benefit**: Configure once, use type-safe repositories throughout your app!

---

## 📦 Installation

```bash
npm install rystem.repository.client
# or
yarn add rystem.repository.client
# or
pnpm add rystem.repository.client
```

---

## 🚀 Quick Start

### Step 1: Define Your Types

Create TypeScript interfaces matching your C# entities:

```typescript
// types/order.ts

// Raw interface (matching C# JsonPropertyName attributes)
export interface OrderRaw {
  i: string;      // Id
  n: string;      // OrderNumber
  c: string;      // CustomerId
  s: number;      // Status (enum as number)
  a: number;      // TotalAmount
  d: string;      // CreatedAt (ISO string)
}

// Clean interface (readable property names)
export interface Order {
  id: string;
  orderNumber: string;
  customerId: string;
  status: OrderStatus;
  totalAmount: number;
  createdAt: Date;
}

export enum OrderStatus {
  Pending = 0,
  Confirmed = 1,
  Shipped = 2,
  Delivered = 3,
  Cancelled = 4
}

// Mapping functions
export function mapRawToOrder(raw: OrderRaw): Order {
  return {
    id: raw.i,
    orderNumber: raw.n,
    customerId: raw.c,
    status: raw.s as OrderStatus,
    totalAmount: raw.a,
    createdAt: new Date(raw.d)
  };
}

export function mapOrderToRaw(order: Order): OrderRaw {
  return {
    i: order.id,
    n: order.orderNumber,
    c: order.customerId,
    s: order.status,
    a: order.totalAmount,
    d: order.createdAt.toISOString()
  };
}
```

### Step 2: Configure Repository Services

```typescript
// config/repositoryConfig.ts
import { RepositoryServices } from "rystem.repository.client";
import { OrderRaw } from "../types/order";
import { CustomerRaw } from "../types/customer";
import { tokenService } from "../services/tokenService";
import { authService } from "../services/authService";

export const setupRepositoryServices = () => {
  const baseUrl = process.env.NEXT_PUBLIC_API_URL || "https://api.myapp.com/api/";

  RepositoryServices
    .Create(baseUrl)
    // Order Repository
    .addRepository<OrderRaw, string>(x => {
      x.name = "Order";
      x.path = "Order";
      x.addHeadersEnricher(() => getAuthHeaders());
      x.addErrorHandler(handleAuthError);
    })
    // Customer Repository
    .addRepository<CustomerRaw, string>(x => {
      x.name = "Customer";
      x.path = "Customer";
      x.addHeadersEnricher(() => getAuthHeaders());
      x.addErrorHandler(handleAuthError);
    });
};

// Helper: Add authorization header
const getAuthHeaders = async (): Promise<HeadersInit> => {
  const accessToken = await tokenService.getValidToken();
  
  return accessToken ? {
    "Authorization": `Bearer ${accessToken}`,
    "Content-Type": "application/json"
  } : {
    "Content-Type": "application/json"
  };
};

// Helper: Handle 401 errors with automatic retry
const handleAuthError = async (
  endpoint: any,
  uri: string,
  method: string,
  headers: any,
  body: any,
  err: any
) => {
  if (err.status === 401) {
    console.log('🔐 401 Unauthorized - attempting token refresh...');
    try {
      const refreshToken = await tokenService.getRefreshToken();
      if (refreshToken) {
        const newTokenData = await authService.refreshToken(refreshToken);
        await tokenService.saveToken(newTokenData);
        console.log('✅ Token refreshed successfully');
        return true; // Retry the request
      }
    } catch (error) {
      console.error('❌ Token refresh failed:', error);
      await handleAuthenticationFailure();
    }
  }
  return false; // Don't retry
};

// Helper: Clear tokens and redirect to login
const handleAuthenticationFailure = async () => {
  await tokenService.clearTokens();
  if (typeof window !== 'undefined') {
    window.location.href = '/login';
  }
};
```

### Step 3: Initialize in Your App

```typescript
// App.tsx (React/React Native)
import { setupRepositoryServices } from './config/repositoryConfig';

// Call once at app startup
setupRepositoryServices();

export default function App() {
  return (
    <YourAppComponent />
  );
}
```

```typescript
// app/layout.tsx (Next.js App Router)
'use client';

import { useEffect } from 'react';
import { setupRepositoryServices } from '@/config/repositoryConfig';

export default function RootLayout({ children }) {
  useEffect(() => {
    setupRepositoryServices();
  }, []);

  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
```

---

## 📚 Create a Service Layer

Wrap the repository client with business logic:

```typescript
// services/orderService.ts
import { RepositoryServices } from "rystem.repository.client";
import { 
  Order, 
  OrderRaw, 
  OrderStatus,
  mapRawToOrder, 
  mapOrderToRaw 
} from "../types/order";

export class OrderService {
  private getRepository() {
    return RepositoryServices.Repository<OrderRaw, string>("Order");
  }

  // ============================================
  // CRUD OPERATIONS
  // ============================================

  async getOrder(orderId: string): Promise<Order | null> {
    try {
      const raw = await this.getRepository().get(orderId);
      return raw ? mapRawToOrder(raw) : null;
    } catch (error) {
      console.error('Error fetching order:', error);
      return null;
    }
  }

  async createOrder(order: Order): Promise<boolean> {
    try {
      const raw = mapOrderToRaw(order);
      const result = await this.getRepository().insert(order.id, raw);
      return result.isOk;
    } catch (error) {
      console.error('Error creating order:', error);
      return false;
    }
  }

  async updateOrder(order: Order): Promise<boolean> {
    try {
      const raw = mapOrderToRaw(order);
      const result = await this.getRepository().update(order.id, raw);
      return result.isOk;
    } catch (error) {
      console.error('Error updating order:', error);
      return false;
    }
  }

  async deleteOrder(orderId: string): Promise<boolean> {
    try {
      const result = await this.getRepository().delete(orderId);
      return result.isOk;
    } catch (error) {
      console.error('Error deleting order:', error);
      return false;
    }
  }

  async orderExists(orderId: string): Promise<boolean> {
    try {
      const result = await this.getRepository().exist(orderId);
      return result.isOk;
    } catch (error) {
      console.error('Error checking order existence:', error);
      return false;
    }
  }

  // ============================================
  // QUERY OPERATIONS
  // ============================================

  async getAllOrders(): Promise<Order[]> {
    try {
      const results = await this.getRepository().query().execute();
      return results.map(r => mapRawToOrder(r.value));
    } catch (error) {
      console.error('Error fetching orders:', error);
      return [];
    }
  }

  async getOrdersByCustomer(customerId: string): Promise<Order[]> {
    try {
      const results = await this.getRepository()
        .query()
        .filter(`x => x.c == "${customerId}"`)
        .execute();
      
      return results.map(r => mapRawToOrder(r.value));
    } catch (error) {
      console.error('Error fetching customer orders:', error);
      return [];
    }
  }

  async getOrdersByStatus(status: OrderStatus): Promise<Order[]> {
    try {
      const results = await this.getRepository()
        .query()
        .filter(`x => x.s == ${status}`)
        .execute();
      
      return results.map(r => mapRawToOrder(r.value));
    } catch (error) {
      console.error('Error fetching orders by status:', error);
      return [];
    }
  }

  async getRecentOrders(days: number = 7): Promise<Order[]> {
    try {
      const cutoffDate = new Date();
      cutoffDate.setDate(cutoffDate.getDate() - days);
      const isoDate = cutoffDate.toISOString();

      const results = await this.getRepository()
        .query()
        .filter(`x => x.d > "${isoDate}"`)
        .execute();
      
      return results.map(r => mapRawToOrder(r.value));
    } catch (error) {
      console.error('Error fetching recent orders:', error);
      return [];
    }
  }

  // Query with builder (type-safe)
  async getOrdersAboveAmount(minAmount: number): Promise<Order[]> {
    try {
      const results = await this.getRepository()
        .query()
        .where()
        .select(x => x.a)
        .greaterThanOrEqual(minAmount)
        .build()
        .orderBy(x => x.a) // Order by amount
        .execute();
      
      return results.map(r => mapRawToOrder(r.value));
    } catch (error) {
      console.error('Error fetching orders by amount:', error);
      return [];
    }
  }

  // ============================================
  // AGGREGATIONS
  // ============================================

  async countOrders(): Promise<number> {
    try {
      return await this.getRepository().query().count();
    } catch (error) {
      console.error('Error counting orders:', error);
      return 0;
    }
  }

  async countOrdersByStatus(status: OrderStatus): Promise<number> {
    try {
      return await this.getRepository()
        .query()
        .where()
        .select(x => x.s)
        .equal(status)
        .count();
    } catch (error) {
      console.error('Error counting orders by status:', error);
      return 0;
    }
  }

  async getTotalRevenue(): Promise<number> {
    try {
      return await this.getRepository()
        .query()
        .where()
        .select(x => x.s)
        .equal(OrderStatus.Delivered)
        .sum(x => x.a);
    } catch (error) {
      console.error('Error calculating revenue:', error);
      return 0;
    }
  }

  // ============================================
  // BATCH OPERATIONS
  // ============================================

  async bulkCreateOrders(orders: Order[]): Promise<void> {
    try {
      const batcher = this.getRepository().batch();
      
      orders.forEach(order => {
        const raw = mapOrderToRaw(order);
        batcher.addInsert(order.id, raw);
      });
      
      const results = await batcher.execute();
      
      results.forEach(result => {
        if (!result.state.isOk) {
          console.error(`Failed to create order ${result.key}:`, result.state.message);
        }
      });
    } catch (error) {
      console.error('Error in bulk create:', error);
    }
  }

  async bulkUpdateOrders(orders: Order[]): Promise<void> {
    try {
      const batcher = this.getRepository().batch();
      
      orders.forEach(order => {
        const raw = mapOrderToRaw(order);
        batcher.addUpdate(order.id, raw);
      });
      
      await batcher.execute();
    } catch (error) {
      console.error('Error in bulk update:', error);
    }
  }

  async bulkDeleteOrders(orderIds: string[]): Promise<void> {
    try {
      const batcher = this.getRepository().batch();
      
      orderIds.forEach(id => {
        batcher.addDelete(id);
      });
      
      await batcher.execute();
    } catch (error) {
      console.error('Error in bulk delete:', error);
    }
  }
}

// Export singleton instance
export const orderService = new OrderService();
```

---

## 🎣 Create React Hooks

Make it easy to use in React components:

```typescript
// hooks/useOrder.ts
import { useState, useEffect, useCallback } from 'react';
import { orderService } from '../services/orderService';
import { Order, OrderStatus } from '../types/order';

export interface UseOrderOptions {
  refreshInterval?: number;
  skip?: boolean;
}

export interface UseOrderResult {
  order: Order | null;
  loading: boolean;
  error: string | null;
  refetch: () => Promise<void>;
}

export const useOrder = (
  orderId: string | null,
  options: UseOrderOptions = {}
): UseOrderResult => {
  const { refreshInterval = 0, skip = false } = options;
  const [order, setOrder] = useState<Order | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const fetchOrder = useCallback(async (silent = false) => {
    if (skip || !orderId) {
      setOrder(null);
      setError(null);
      return;
    }

    if (!silent) {
      setLoading(true);
    }
    setError(null);

    try {
      const fetchedOrder = await orderService.getOrder(orderId);
      setOrder(fetchedOrder);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to fetch order';
      setError(message);
      console.error('Error fetching order:', err);
    } finally {
      if (!silent) {
        setLoading(false);
      }
    }
  }, [orderId, skip]);

  useEffect(() => {
    fetchOrder(false);
  }, [fetchOrder]);

  // Auto-refresh
  useEffect(() => {
    if (refreshInterval > 0) {
      const interval = setInterval(() => fetchOrder(true), refreshInterval);
      return () => clearInterval(interval);
    }
  }, [fetchOrder, refreshInterval]);

  const refetch = useCallback(() => fetchOrder(false), [fetchOrder]);

  return { order, loading, error, refetch };
};

// Hook for list of orders
export interface UseOrdersResult {
  orders: Order[];
  loading: boolean;
  error: string | null;
  refetch: () => Promise<void>;
}

export const useOrdersByCustomer = (
  customerId: string | null,
  options: UseOrderOptions = {}
): UseOrdersResult => {
  const { refreshInterval = 0, skip = false } = options;
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const fetchOrders = useCallback(async (silent = false) => {
    if (skip || !customerId) {
      setOrders([]);
      setError(null);
      return;
    }

    if (!silent) {
      setLoading(true);
    }
    setError(null);

    try {
      const fetchedOrders = await orderService.getOrdersByCustomer(customerId);
      setOrders(fetchedOrders);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to fetch orders';
      setError(message);
      console.error('Error fetching orders:', err);
    } finally {
      if (!silent) {
        setLoading(false);
      }
    }
  }, [customerId, skip]);

  useEffect(() => {
    fetchOrders(false);
  }, [fetchOrders]);

  useEffect(() => {
    if (refreshInterval > 0) {
      const interval = setInterval(() => fetchOrders(true), refreshInterval);
      return () => clearInterval(interval);
    }
  }, [fetchOrders, refreshInterval]);

  const refetch = useCallback(() => fetchOrders(false), [fetchOrders]);

  return { orders, loading, error, refetch };
};

// Hook for orders by status
export const useOrdersByStatus = (
  status: OrderStatus | null,
  options: UseOrderOptions = {}
): UseOrdersResult => {
  const { refreshInterval = 0, skip = false } = options;
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const fetchOrders = useCallback(async (silent = false) => {
    if (skip || status === null) {
      setOrders([]);
      setError(null);
      return;
    }

    if (!silent) {
      setLoading(true);
    }
    setError(null);

    try {
      const fetchedOrders = await orderService.getOrdersByStatus(status);
      setOrders(fetchedOrders);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to fetch orders';
      setError(message);
      console.error('Error fetching orders:', err);
    } finally {
      if (!silent) {
        setLoading(false);
      }
    }
  }, [status, skip]);

  useEffect(() => {
    fetchOrders(false);
  }, [fetchOrders]);

  useEffect(() => {
    if (refreshInterval > 0) {
      const interval = setInterval(() => fetchOrders(true), refreshInterval);
      return () => clearInterval(interval);
    }
  }, [fetchOrders, refreshInterval]);

  const refetch = useCallback(() => fetchOrders(false), [fetchOrders]);

  return { orders, loading, error, refetch };
};
```

---

## 💻 Usage in Components

### React Component Example

```typescript
// components/OrderDetail.tsx
import React from 'react';
import { useOrder } from '../hooks/useOrder';

interface OrderDetailProps {
  orderId: string;
}

export const OrderDetail: React.FC<OrderDetailProps> = ({ orderId }) => {
  const { order, loading, error, refetch } = useOrder(orderId, {
    refreshInterval: 30000 // Refresh every 30 seconds
  });

  if (loading) {
    return <div>Loading order...</div>;
  }

  if (error) {
    return (
      <div>
        <p>Error: {error}</p>
        <button onClick={refetch}>Retry</button>
      </div>
    );
  }

  if (!order) {
    return <div>Order not found</div>;
  }

  return (
    <div>
      <h2>Order {order.orderNumber}</h2>
      <p>Status: {OrderStatus[order.status]}</p>
      <p>Customer: {order.customerId}</p>
      <p>Amount: ${order.totalAmount.toFixed(2)}</p>
      <p>Created: {order.createdAt.toLocaleDateString()}</p>
      <button onClick={refetch}>Refresh</button>
    </div>
  );
};
```

### React Native Component Example

```typescript
// screens/OrderListScreen.tsx
import React from 'react';
import { View, Text, FlatList, RefreshControl } from 'react-native';
import { useOrdersByStatus } from '../hooks/useOrder';
import { OrderStatus } from '../types/order';

export const OrderListScreen = () => {
  const { orders, loading, error, refetch } = useOrdersByStatus(
    OrderStatus.Pending
  );

  return (
    <View style={{ flex: 1 }}>
      <FlatList
        data={orders}
        keyExtractor={item => item.id}
        renderItem={({ item }) => (
          <View style={{ padding: 16, borderBottomWidth: 1 }}>
            <Text style={{ fontWeight: 'bold' }}>{item.orderNumber}</Text>
            <Text>${item.totalAmount.toFixed(2)}</Text>
          </View>
        )}
        refreshControl={
          <RefreshControl refreshing={loading} onRefresh={refetch} />
        }
        ListEmptyComponent={
          <Text style={{ textAlign: 'center', marginTop: 20 }}>
            {error ? `Error: ${error}` : 'No pending orders'}
          </Text>
        }
      />
    </View>
  );
};
```

---

## 🔐 Authentication Integration

### Token Storage Service

```typescript
// services/tokenService.ts

export interface TokenData {
  accessToken: string;
  refreshToken: string;
  expiresAt: number; // Timestamp in milliseconds
}

class TokenService {
  private TOKEN_KEY = 'auth_token';

  async saveToken(tokenData: TokenData): Promise<void> {
    try {
      // For web
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem(this.TOKEN_KEY, JSON.stringify(tokenData));
      }
      // For React Native - use AsyncStorage
      // await AsyncStorage.setItem(this.TOKEN_KEY, JSON.stringify(tokenData));
    } catch (error) {
      console.error('Error saving token:', error);
    }
  }

  async getToken(): Promise<TokenData | null> {
    try {
      // For web
      if (typeof localStorage !== 'undefined') {
        const data = localStorage.getItem(this.TOKEN_KEY);
        return data ? JSON.parse(data) : null;
      }
      // For React Native
      // const data = await AsyncStorage.getItem(this.TOKEN_KEY);
      // return data ? JSON.parse(data) : null;
      return null;
    } catch (error) {
      console.error('Error getting token:', error);
      return null;
    }
  }

  async getValidToken(): Promise<string | null> {
    const tokenData = await this.getToken();
    
    if (!tokenData) {
      return null;
    }

    // Check if token is expired (with 5-minute buffer)
    const now = Date.now();
    const buffer = 5 * 60 * 1000; // 5 minutes
    
    if (tokenData.expiresAt - buffer < now) {
      console.log('Token expired or about to expire, needs refresh');
      return null;
    }

    return tokenData.accessToken;
  }

  async getRefreshToken(): Promise<string | null> {
    const tokenData = await this.getToken();
    return tokenData?.refreshToken || null;
  }

  async clearTokens(): Promise<void> {
    try {
      // For web
      if (typeof localStorage !== 'undefined') {
        localStorage.removeItem(this.TOKEN_KEY);
      }
      // For React Native
      // await AsyncStorage.removeItem(this.TOKEN_KEY);
    } catch (error) {
      console.error('Error clearing tokens:', error);
    }
  }
}

export const tokenService = new TokenService();
```

### Auth Service (with Rystem.Authentication.Social)

```typescript
// services/authService.ts

export interface LoginResponse {
  tokenType: string;
  accessToken: string;
  refreshToken: string;
  expiresIn: number; // Seconds
}

export interface UserInfo {
  id: string;
  email: string;
  name: string;
}

class AuthService {
  private apiUrl = process.env.NEXT_PUBLIC_API_URL || "https://api.myapp.com";

  async login(email: string, password: string): Promise<LoginResponse> {
    const response = await fetch(`${this.apiUrl}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });

    if (!response.ok) {
      throw new Error('Login failed');
    }

    return await response.json();
  }

  async refreshToken(refreshToken: string): Promise<LoginResponse> {
    const response = await fetch(`${this.apiUrl}/auth/refresh`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ refreshToken })
    });

    if (!response.ok) {
      throw new Error('Token refresh failed');
    }

    return await response.json();
  }

  async getUserInfo(accessToken: string): Promise<UserInfo | null> {
    const response = await fetch(`${this.apiUrl}/auth/userinfo`, {
      headers: { 
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      }
    });

    if (!response.ok) {
      return null;
    }

    return await response.json();
  }

  async logout(): Promise<void> {
    await tokenService.clearTokens();
  }
}

export const authService = new AuthService();
```

---

## 🔧 Advanced Configuration

### Multiple Repositories with Different URLs

```typescript
RepositoryServices
  .Create("https://api.myapp.com/api/")
  .addRepository<OrderRaw, string>(x => {
    x.name = "Order";
    x.path = "Order"; // Full URL: https://api.myapp.com/api/Order
    x.addHeadersEnricher(() => getAuthHeaders());
  })
  .addRepository<ProductRaw, string>(x => {
    x.name = "Product";
    x.uri = "https://catalog-api.myapp.com/api/Product"; // Override full URL
    x.addHeadersEnricher(() => getAuthHeaders());
  });
```

### CQRS Repositories

```typescript
RepositoryServices
  .Create("https://api.myapp.com/api/")
  // Write operations to primary database
  .addCommand<OrderRaw, string>(x => {
    x.name = "OrderCommand";
    x.path = "Order";
    x.addHeadersEnricher(() => getAuthHeaders());
  })
  // Read operations from read replica
  .addQuery<OrderRaw, string>(x => {
    x.name = "OrderQuery";
    x.uri = "https://read-api.myapp.com/api/Order";
    x.addHeadersEnricher(() => getAuthHeaders());
  });

// Usage in service
const command = RepositoryServices.Command<OrderRaw, string>("OrderCommand");
const query = RepositoryServices.Query<OrderRaw, string>("OrderQuery");

await command.insert(orderId, orderRaw); // Write
const order = await query.get(orderId);   // Read
```

### Multiple Header Enrichers

```typescript
.addRepository<OrderRaw, string>(x => {
  x.name = "Order";
  x.path = "Order";
  
  // Add Authorization header
  x.addHeadersEnricher(async () => {
    const token = await tokenService.getValidToken();
    return { "Authorization": `Bearer ${token}` };
  });
  
  // Add custom tracking header
  x.addHeadersEnricher(async () => {
    return { "X-Request-Id": crypto.randomUUID() };
  });
  
  // Add tenant header (for multi-tenant apps)
  x.addHeadersEnricher(async () => {
    const tenantId = await getTenantId();
    return { "X-Tenant-Id": tenantId };
  });
})
```

### Custom Error Handlers

```typescript
.addRepository<OrderRaw, string>(x => {
  x.name = "Order";
  x.path = "Order";
  
  // Handle 401 Unauthorized
  x.addErrorHandler(async (endpoint, uri, method, headers, body, err) => {
    if (err.status === 401) {
      const refreshed = await refreshAuthToken();
      return refreshed; // true = retry, false = stop
    }
    return false;
  });
  
  // Handle 429 Rate Limit
  x.addErrorHandler(async (endpoint, uri, method, headers, body, err) => {
    if (err.status === 429) {
      const retryAfter = err.headers?.['retry-after'] || 60;
      console.log(`Rate limited. Retrying after ${retryAfter}s`);
      await new Promise(resolve => setTimeout(resolve, retryAfter * 1000));
      return true; // Retry
    }
    return false;
  });
  
  // Handle network errors
  x.addErrorHandler(async (endpoint, uri, method, headers, body, err) => {
    if (err.message?.includes('network')) {
      console.log('Network error detected, retrying...');
      await new Promise(resolve => setTimeout(resolve, 2000));
      return true; // Retry after 2 seconds
    }
    return false;
  });
})
```

---

## 🎯 Best Practices

### 1. Always Map Raw to Clean Types

```typescript
// ✅ GOOD - Clean separation
export interface OrderRaw { i: string; n: string; a: number; }
export interface Order { id: string; orderNumber: string; amount: number; }
export const mapRawToOrder = (raw: OrderRaw): Order => ({ ... });

// ❌ BAD - Using raw types directly in UI
const order: OrderRaw = await repository.get(id);
console.log(order.i); // What is 'i'?
```

### 2. Use Service Layer

```typescript
// ✅ GOOD - Business logic in service
class OrderService {
  async getActiveOrders() {
    const orders = await this.getOrdersByStatus(OrderStatus.Pending);
    return orders.filter(o => o.totalAmount > 0);
  }
}

// ❌ BAD - Business logic in component
const orders = await RepositoryServices.Repository<OrderRaw, string>("Order")
  .query().execute();
const activeOrders = orders.filter(...); // Logic in component!
```

### 3. Use Hooks for React

```typescript
// ✅ GOOD - Reusable hook
const { order, loading, error } = useOrder(orderId);

// ❌ BAD - Direct service call in component
const [order, setOrder] = useState(null);
useEffect(() => {
  orderService.getOrder(orderId).then(setOrder);
}, [orderId]);
```

### 4. Handle Errors Gracefully

```typescript
// ✅ GOOD - Error handling
try {
  const order = await orderService.getOrder(orderId);
  if (!order) {
    showToast('Order not found');
    return;
  }
  // Process order
} catch (error) {
  console.error('Error:', error);
  showToast('Failed to load order');
}

// ❌ BAD - No error handling
const order = await orderService.getOrder(orderId);
processOrder(order); // Will crash if null!
```

### 5. Use TypeScript Generics Correctly

```typescript
// ✅ GOOD - Correct generic types
RepositoryServices.Repository<OrderRaw, string>("Order")
//                             ^entity  ^key

// ❌ BAD - Wrong types
RepositoryServices.Repository<Order, number>("Order")
// Should use OrderRaw (raw interface) and string (key type)
```

---

## ⚠️ Important Notes

1. **Always use Raw types** with Repository client (matching C# JsonPropertyName)
2. **Map to clean types** in your service layer for use in UI
3. **Configure once** at app startup with `setupRepositoryServices()`
4. **Error handlers run in order** - first one returning `true` stops the chain
5. **Header enrichers are called** for every request
6. **CQRS requires separate** `addCommand` and `addQuery` calls
7. **Package name**: `rystem.repository.client` (npm)

---

## 🔗 Related Resources

- **repository-api-server**: How to expose repositories as REST APIs on backend
- **repository-api-client-dotnet**: Client for .NET/C# apps (Blazor, MAUI, WPF)
- **repository-setup**: How to configure repositories on backend
- **auth-flow**: Setting up authentication with Rystem.Authentication.Social

---

## 📖 Further Reading

- [rystem.repository.client GitHub](https://github.com/KeyserDSoze/RepositoryFramework/tree/master/src/RepositoryFramework.Api.Client)
- [TypeScript Client Examples](https://github.com/KeyserDSoze/RepositoryFramework/tree/master/src/RepositoryFramework.Test/RepositoryFramework.Api.Client.Test)

---

## ✅ Summary

**rystem.repository.client** provides:
- ✅ Type-safe repository access from TypeScript/JavaScript
- ✅ Automatic authentication with token refresh
- ✅ Custom error handlers with retry logic
- ✅ LINQ-style queries from client-side
- ✅ Batch operations support
- ✅ CQRS pattern support
- ✅ Works in React, React Native, Next.js, Node.js
- ✅ Multiple header enrichers
- ✅ Custom error handling per repository

**Use this tool to build type-safe, production-ready frontend applications!** 🚀

---

## Repository API Server

> Auto-generate REST APIs from repositories without writing controllers - includes authentication, LINQ queries, and Swagger documentation

---
title: Repository API Server
description: Auto-generate REST APIs from repositories without writing controllers - includes authentication, LINQ queries, and Swagger documentation
---

# Repository API Server - Auto-Generated REST APIs

**Purpose**: This tool explains how to **automatically expose repositories as REST APIs** without writing controllers manually. Rystem.RepositoryFramework can generate complete REST endpoints for your repositories with built-in authentication, authorization, and Swagger documentation.

---

## 🎯 What is Repository API Server?

Rystem.RepositoryFramework includes an **API Server** feature that:
- ✅ **Auto-generates REST APIs** for all registered repositories
- ✅ **No controllers needed** - endpoints are created automatically
- ✅ **Built-in Swagger/OpenAPI** documentation
- ✅ **Flexible authorization** - no auth, default policies, or custom per-repository
- ✅ **LINQ query support** in URL parameters
- ✅ **CORS configuration** out of the box

**Key Benefit**: Register your repository once, get a complete REST API for free!

---

## 📦 Installation

```bash
dotnet add package Rystem.RepositoryFramework.Api.Server --version 9.1.3
dotnet add package Rystem.Api.Server --version 9.1.3
```

---

## 🚀 Quick Start - No Authorization

The simplest setup with no authentication required:

### Step 1: Register Repositories and API Server

```csharp
// Program.cs
var builder = WebApplication.CreateBuilder(args);

// Register repositories
builder.Services.AddRepository<Order, Guid>(settings =>
{
    settings.WithEntityFramework<OrdersDbContext>();
});

builder.Services.AddRepository<Customer, Guid>(settings =>
{
    settings.WithEntityFramework<CustomersDbContext>();
});

// Add API Server
builder.Services.AddApiFromRepositoryFramework()
    .WithDescriptiveName("CargoLens API")
    .WithPath("api")
    .WithVersion("v1")
    .WithSwagger()
    .WithDocumentation()
    .WithDefaultCors("https://app.cargolens.com");

var app = builder.Build();

// Configure middleware
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

// Use API from repositories - NO AUTHORIZATION
app.UseApiFromRepositoryFramework()
    .WithNoAuthorization();

app.Run();
```

### Step 2: Generated Endpoints

The above code automatically generates these REST endpoints:

#### For `Order` entity:
```
GET     /api/v1/order/{id}                 - Get single order
GET     /api/v1/order/exist/{id}          - Check if order exists
POST    /api/v1/order/query               - Query orders with filter
POST    /api/v1/order                     - Create new order
PUT     /api/v1/order/{id}                - Update order
DELETE  /api/v1/order/{id}                - Delete order
POST    /api/v1/order/batch               - Batch operations
GET     /api/v1/order/count               - Count orders
GET     /api/v1/order/max                 - Get max value
GET     /api/v1/order/min                 - Get min value
GET     /api/v1/order/sum                 - Get sum
GET     /api/v1/order/average             - Get average
```

#### For `Customer` entity:
```
GET     /api/v1/customer/{id}
GET     /api/v1/customer/exist/{id}
POST    /api/v1/customer/query
POST    /api/v1/customer
PUT     /api/v1/customer/{id}
DELETE  /api/v1/customer/{id}
POST    /api/v1/customer/batch
... (all CRUD + aggregation operations)
```

### Step 3: Test with Swagger

Navigate to: `https://localhost:5001/swagger`

You'll see all endpoints documented and ready to test!

---

## 🔒 Authorization - Default Policy

Apply a default authorization policy to all endpoints:

```csharp
var builder = WebApplication.CreateBuilder(args);

// Add authentication
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.Authority = "https://login.microsoftonline.com/{tenant-id}";
        options.Audience = "api://cargolens-api";
    });

// Add authorization
builder.Services.AddAuthorization();

// Register repositories
builder.Services.AddRepository<Order, Guid>(settings =>
{
    settings.WithEntityFramework<OrdersDbContext>();
});

// Add API Server
builder.Services.AddApiFromRepositoryFramework()
    .WithDescriptiveName("CargoLens API")
    .WithPath("api")
    .WithVersion("v1")
    .WithSwagger()
    .WithDocumentation();

var app = builder.Build();

app.UseHttpsRedirection();
app.UseAuthentication();
app.UseAuthorization();

// Use API with DEFAULT authorization
app.UseApiFromRepositoryFramework()
    .WithDefaultAuthorization();

app.Run();
```

**Result**: All endpoints require authentication (valid JWT token).

---

## 🔐 Authorization - Custom Policies

Apply different policies to different operations:

### Setup Policies

```csharp
var builder = WebApplication.CreateBuilder(args);

// Authentication setup
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(/* ... */);

// Authorization policies
builder.Services.AddAuthorization(options =>
{
    options.AddPolicy("NormalUser", policy =>
    {
        policy.RequireClaim(ClaimTypes.Name);
    });
    
    options.AddPolicy("Admin", policy =>
    {
        policy.RequireRole("Admin");
    });
    
    options.AddPolicy("SuperAdmin", policy =>
    {
        policy.RequireRole("SuperAdmin");
    });
});

// Register repositories
builder.Services.AddRepository<Order, Guid>(settings =>
{
    settings.WithEntityFramework<OrdersDbContext>();
});

builder.Services.AddRepository<Customer, Guid>(settings =>
{
    settings.WithEntityFramework<CustomersDbContext>();
});

// Add API Server
builder.Services.AddApiFromRepositoryFramework()
    .WithDescriptiveName("CargoLens API")
    .WithPath("api")
    .WithVersion("v1")
    .WithSwagger();

var app = builder.Build();

app.UseHttpsRedirection();
app.UseAuthentication();
app.UseAuthorization();

// Configure authorization per repository and method
app.UseEndpoints(endpoints =>
{
    // Order: SuperAdmin required for write operations
    endpoints.UseApiFromRepository<Order>()
        .SetPolicyForCommand()  // Insert, Update, Delete
        .With("SuperAdmin")
        .Build();
    
    // All other repositories: NormalUser for read, Admin for write
    endpoints.UseApiFromRepositoryFramework()
        .SetPolicyForAll()
        .With("NormalUser")  // Default for all operations
        .And()
        .SetPolicy(RepositoryMethods.Insert)
        .With("Admin")
        .And()
        .SetPolicy(RepositoryMethods.Update)
        .With("Admin")
        .And()
        .SetPolicy(RepositoryMethods.Delete)
        .With("Admin")
        .Build();
});

app.Run();
```

### Available Repository Methods

```csharp
RepositoryMethods.Get          // GET /{id}
RepositoryMethods.Exist        // GET /exist/{id}
RepositoryMethods.Query        // POST /query
RepositoryMethods.Insert       // POST /
RepositoryMethods.Update       // PUT /{id}
RepositoryMethods.Delete       // DELETE /{id}
RepositoryMethods.Batch        // POST /batch
RepositoryMethods.Count        // GET /count
RepositoryMethods.Max          // GET /max
RepositoryMethods.Min          // GET /min
RepositoryMethods.Sum          // GET /sum
RepositoryMethods.Average      // GET /average
```

---

## 🚫 Excluding Repositories from API

Sometimes you want a repository for internal use only (not exposed as API):

```csharp
builder.Services.AddRepository<InternalAuditLog, Guid>(settings =>
{
    settings.WithEntityFramework<AuditDbContext>();
    settings.SetNotExposable();  // ⚠️ NOT exposed as API
});

builder.Services.AddRepository<Order, Guid>(settings =>
{
    settings.WithEntityFramework<OrdersDbContext>();
    // This WILL be exposed as API (default)
});
```

**Result**: 
- `Order` endpoints are generated ✅
- `InternalAuditLog` endpoints are NOT generated ❌

---

## 🔍 Query API - Using LINQ Expressions

The most powerful feature: **Query with LINQ expressions in HTTP requests**!

### Query Endpoint

```
POST /api/v1/order/query
Content-Type: application/json
```

### Simple Filter

```json
{
  "filter": "ƒ => (ƒ.Status == 2)",
  "top": 10,
  "skip": 0,
  "orderBy": "CreatedAt",
  "ascending": false
}
```

**Explanation**: 
- `ƒ` is the entity variable
- `ƒ.Status == 2` filters where Status equals 2 (e.g., Shipped)
- `top` and `skip` for pagination
- `orderBy` sorts by property name

### Complex Filter with AND/OR

```json
{
  "filter": "ƒ => ((ƒ.Status == 2) AndAlso (ƒ.CustomerId == Guid.Parse(\"bf46510b-b7e6-4ba2-88da-cef208aa81f2\")))"
}
```

### String Operations

```json
{
  "filter": "ƒ => (ƒ.OrderNumber.Contains(\"ORD-\"))"
}
```

```json
{
  "filter": "ƒ => Not(String.IsNullOrWhiteSpace(ƒ.CustomerName))"
}
```

### Date Comparisons

```json
{
  "filter": "ƒ => (ƒ.CreatedAt > Convert.ToDateTime(\"2024-01-01\"))"
}
```

### Collections

```json
{
  "filter": "ƒ => (ƒ.Tags.Any(x => (x == \"urgent\")))"
}
```

### Nested Properties

```json
{
  "filter": "ƒ => (ƒ.Customer.Address.City == \"Milan\")"
}
```

### Complex Example

```json
{
  "filter": "ƒ => ((((ƒ.Status == 2) AndAlso (ƒ.TotalAmount > 1000)) OrElse (ƒ.Priority == \"High\")) AndAlso (ƒ.CreatedAt > Convert.ToDateTime(\"2024-01-01\")))",
  "top": 20,
  "skip": 0,
  "orderBy": "TotalAmount",
  "ascending": false
}
```

**Translation**: 
```
Get orders where:
  (Status is Shipped AND TotalAmount > 1000) 
  OR Priority is High
  AND CreatedAt after Jan 1, 2024
Order by TotalAmount descending
Take 20 results
```

---

## 📝 CRUD Operations Examples

### Create (Insert)

```http
POST /api/v1/order
Content-Type: application/json

{
  "key": "bf46510b-b7e6-4ba2-88da-cef208aa81f2",
  "value": {
    "orderNumber": "ORD-12345",
    "customerId": "550e8400-e29b-41d4-a716-446655440000",
    "status": 0,
    "createdAt": "2024-10-21T10:00:00Z",
    "totalAmount": 1500.50
  }
}
```

### Read (Get)

```http
GET /api/v1/order/bf46510b-b7e6-4ba2-88da-cef208aa81f2
```

Response:
```json
{
  "id": "bf46510b-b7e6-4ba2-88da-cef208aa81f2",
  "orderNumber": "ORD-12345",
  "customerId": "550e8400-e29b-41d4-a716-446655440000",
  "status": 0,
  "createdAt": "2024-10-21T10:00:00Z",
  "totalAmount": 1500.50
}
```

### Update

```http
PUT /api/v1/order/bf46510b-b7e6-4ba2-88da-cef208aa81f2
Content-Type: application/json

{
  "orderNumber": "ORD-12345",
  "customerId": "550e8400-e29b-41d4-a716-446655440000",
  "status": 2,
  "createdAt": "2024-10-21T10:00:00Z",
  "totalAmount": 1500.50
}
```

### Delete

```http
DELETE /api/v1/order/bf46510b-b7e6-4ba2-88da-cef208aa81f2
```

### Check Existence

```http
GET /api/v1/order/exist/bf46510b-b7e6-4ba2-88da-cef208aa81f2
```

Response:
```json
{
  "exists": true
}
```

---

## 🔢 Aggregation Operations

### Count

```http
GET /api/v1/order/count?filter=ƒ => (ƒ.Status == 2)
```

Response:
```json
{
  "count": 42
}
```

### Max

```http
GET /api/v1/order/max?property=TotalAmount
```

### Min

```http
GET /api/v1/order/min?property=TotalAmount
```

### Sum

```http
GET /api/v1/order/sum?property=TotalAmount&filter=ƒ => (ƒ.Status == 3)
```

### Average

```http
GET /api/v1/order/average?property=TotalAmount
```

---

## 📦 Batch Operations

Execute multiple operations in a single request:

```http
POST /api/v1/order/batch
Content-Type: application/json

{
  "operations": [
    {
      "type": "insert",
      "key": "guid-1",
      "value": { /* order data */ }
    },
    {
      "type": "update",
      "key": "guid-2",
      "value": { /* updated order data */ }
    },
    {
      "type": "delete",
      "key": "guid-3"
    }
  ]
}
```

Response:
```json
{
  "results": [
    {
      "key": "guid-1",
      "success": true,
      "message": "Inserted successfully"
    },
    {
      "key": "guid-2",
      "success": true,
      "message": "Updated successfully"
    },
    {
      "key": "guid-3",
      "success": false,
      "message": "Order not found"
    }
  ]
}
```

---

## 🌐 CORS Configuration

### Default CORS (Single Origin)

```csharp
builder.Services.AddApiFromRepositoryFramework()
    .WithDefaultCors("https://app.cargolens.com");
```

### Multiple Origins

```csharp
builder.Services.AddCors(options =>
{
    options.AddPolicy("CargoLensPolicy", policy =>
    {
        policy.WithOrigins(
            "https://app.cargolens.com",
            "https://admin.cargolens.com",
            "http://localhost:3000"
        )
        .AllowAnyMethod()
        .AllowAnyHeader()
        .AllowCredentials();
    });
});

var app = builder.Build();

app.UseCors("CargoLensPolicy");
```

---

## 📚 Real-World Example: Complete Setup

```csharp
// Program.cs
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Rystem;

var builder = WebApplication.CreateBuilder(args);

// Database
builder.Services.AddDbContext<OrdersDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("OrdersDb")));

builder.Services.AddDbContext<CustomersDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("CustomersDb")));

// Authentication
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.Authority = builder.Configuration["AzureAd:Authority"];
        options.Audience = builder.Configuration["AzureAd:ClientId"];
    });

// Authorization policies
builder.Services.AddAuthorization(options =>
{
    options.AddPolicy("User", policy =>
    {
        policy.RequireClaim("roles", "User");
    });
    
    options.AddPolicy("Admin", policy =>
    {
        policy.RequireClaim("roles", "Admin");
    });
});

// Repositories
builder.Services.AddRepository<Order, Guid>(settings =>
{
    settings.WithEntityFramework<OrdersDbContext>();
});

builder.Services.AddRepository<Customer, Guid>(settings =>
{
    settings.WithEntityFramework<CustomersDbContext>();
});

builder.Services.AddRepository<Shipment, Guid>(settings =>
{
    settings.WithEntityFramework<OrdersDbContext>();
});

// Internal repository - NOT exposed
builder.Services.AddRepository<AuditLog, Guid>(settings =>
{
    settings.WithEntityFramework<OrdersDbContext>();
    settings.SetNotExposable();
});

// API Server
builder.Services.AddApiFromRepositoryFramework()
    .WithDescriptiveName("CargoLens API")
    .WithPath("api")
    .WithVersion("v1")
    .WithSwagger()
    .WithDocumentation()
    .WithDefaultCors("https://app.cargolens.com");

var app = builder.Build();

// Middleware
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(options =>
    {
        options.SwaggerEndpoint("/swagger/v1/swagger.json", "CargoLens API v1");
        options.RoutePrefix = "swagger";
    });
}

app.UseHttpsRedirection();
app.UseAuthentication();
app.UseAuthorization();

// Configure API authorization
app.UseEndpoints(endpoints =>
{
    // Health check
    endpoints.MapHealthChecks("/healthz");
    
    // Order API: Admin only for write operations
    endpoints.UseApiFromRepository<Order>()
        .SetPolicyForCommand()
        .With("Admin")
        .Build();
    
    // Customer API: Admin only for write operations
    endpoints.UseApiFromRepository<Customer>()
        .SetPolicyForCommand()
        .With("Admin")
        .Build();
    
    // Shipment API: User can read, Admin can write
    endpoints.UseApiFromRepository<Shipment>()
        .SetPolicyForQuery()
        .With("User")
        .And()
        .SetPolicyForCommand()
        .With("Admin")
        .Build();
    
    // All other repositories: Default authorization
    endpoints.UseApiFromRepositoryFramework()
        .SetPolicyForAll()
        .With("User")
        .Build();
});

app.Run();
```

**Generated Endpoints**:
```
✅ /api/v1/order/*        - Admin required for POST/PUT/DELETE
✅ /api/v1/customer/*     - Admin required for POST/PUT/DELETE
✅ /api/v1/shipment/*     - User for GET, Admin for POST/PUT/DELETE
❌ /api/v1/auditlog/*     - NOT exposed (SetNotExposable)
```

---

## 📋 Configuration Options

### AddApiFromRepositoryFramework Options

```csharp
builder.Services.AddApiFromRepositoryFramework()
    .WithDescriptiveName("API Display Name")
    .WithPath("api")                // Base path (default: "api")
    .WithVersion("v1")              // Version (default: "v1")
    .WithSwagger()                  // Enable Swagger UI
    .WithDocumentation()            // Enable XML documentation
    .WithDefaultCors("origin");     // Single CORS origin
```

### UseApiFromRepositoryFramework Options

```csharp
// No authorization (default)
app.UseApiFromRepositoryFramework()
    .WithNoAuthorization();

// Default authorization (requires authenticated user)
app.UseApiFromRepositoryFramework()
    .WithDefaultAuthorization();

// Custom per-repository authorization
app.UseEndpoints(endpoints =>
{
    endpoints.UseApiFromRepository<Order>()
        .SetPolicyForCommand()      // All write operations
        .With("PolicyName")
        .And()
        .SetPolicyForQuery()        // All read operations
        .With("PolicyName")
        .And()
        .SetPolicy(RepositoryMethods.Insert)  // Specific method
        .With("PolicyName")
        .Build();
});
```

---

## 🎯 Best Practices

### 1. Always Use Policies for Production

```csharp
// ❌ BAD - No authorization in production
app.UseApiFromRepositoryFramework()
    .WithNoAuthorization();

// ✅ GOOD - Proper authorization
app.UseEndpoints(endpoints =>
{
    endpoints.UseApiFromRepositoryFramework()
        .SetPolicyForAll()
        .With("User")
        .And()
        .SetPolicyForCommand()
        .With("Admin")
        .Build();
});
```

### 2. Hide Internal Repositories

```csharp
// ✅ GOOD - Internal repositories not exposed
builder.Services.AddRepository<AuditLog, Guid>(settings =>
{
    settings.WithEntityFramework<AuditDbContext>();
    settings.SetNotExposable();
});
```

### 3. Use Different Policies for Different Entities

```csharp
// ✅ GOOD - Fine-grained control
endpoints.UseApiFromRepository<Order>()
    .SetPolicyForCommand()
    .With("OrderAdmin")
    .Build();

endpoints.UseApiFromRepository<Customer>()
    .SetPolicyForCommand()
    .With("CustomerAdmin")
    .Build();
```

### 4. Enable Swagger Only in Development

```csharp
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}
```

### 5. Use Health Checks

```csharp
builder.Services.AddHealthChecks()
    .AddDbContextCheck<OrdersDbContext>();

app.MapHealthChecks("/healthz");
```

---

## ⚠️ Important Notes

1. **Package Required**: `Rystem.RepositoryFramework.Api.Server` version 9.1.3
2. **Automatic Swagger**: Swagger is auto-configured when you use `.WithSwagger()`
3. **Default Behavior**: Repositories are exposed by default unless you use `.SetNotExposable()`
4. **LINQ Syntax**: Query filters use C# LINQ expression syntax (converted from string)
5. **Authorization Precedence**: Specific repository policies override global policies
6. **CORS**: Always configure CORS for production frontends

---

## 🔗 Related Resources

- **repository-setup**: How to configure repositories
- **repository-api-client-typescript**: Consume these APIs from TypeScript/JavaScript apps
- **repository-api-client-dotnet**: Consume these APIs from .NET/C# apps (Blazor, MAUI, WPF)
- **ddd-single-domain**: Organizing repositories in single-domain architecture
- **ddd-multi-domain**: Organizing repositories in multi-domain architecture
- **auth-flow**: Setting up authentication with Rystem.Authentication.Social

---

## 📖 Further Reading

- [Rystem.RepositoryFramework.Api.Server GitHub](https://github.com/KeyserDSoze/RepositoryFramework/tree/master/src/RepositoryFramework.Api.Server)
- [API Server Examples](https://github.com/KeyserDSoze/RepositoryFramework/tree/master/src/RepositoryFramework.Test/RepositoryFramework.Api.Server.Test)
- [Rystem.Api.Server Documentation](https://github.com/KeyserDSoze/Rystem/tree/master/src/Api/Rystem.Api.Server)

---

## ✅ Summary

**Rystem.RepositoryFramework.Api.Server** provides:
- ✅ Zero-code REST API generation
- ✅ Complete CRUD operations for all repositories
- ✅ LINQ query support in HTTP requests
- ✅ Flexible authorization (none, default, custom per-repository)
- ✅ Automatic Swagger/OpenAPI documentation
- ✅ Batch operations support
- ✅ Aggregation operations (Count, Max, Min, Sum, Average)
- ✅ CORS configuration
- ✅ Option to hide internal repositories

**Use this tool to quickly expose your repositories as production-ready REST APIs!** 🚀

---

## Repository Pattern Setup

> Configure data access with Rystem.RepositoryFramework - CQRS, multiple storage backends, business logic injection, and Factory pattern support

---
title: Repository Pattern Setup
description: Configure data access with Rystem.RepositoryFramework - CQRS, multiple storage backends, business logic injection, and Factory pattern support
---

# Repository Pattern Setup

**Purpose**: This tool explains how to implement the **Repository Pattern** using **Rystem.RepositoryFramework**. This is the **REQUIRED tool** to use whenever you need to implement data access in a Rystem application.

---



## 🎯 What is Rystem.RepositoryFramework?This tool helps you configure and setup the Rystem Repository Framework in your .NET project. It provides guidance for implementing the Repository pattern and CQRS (Command Query Responsibility Segregation).



Rystem.RepositoryFramework is a powerful abstraction layer for data access that:## Usage

- ✅ Implements **Repository Pattern** and **CQRS** out of the box

- ✅ Supports **multiple storage backends** (SQL, NoSQL, Blob, Table Storage, Cosmos DB)Use this tool when you need to:

- ✅ Provides **unified API** for all storage types- Set up a new repository for your entities

- ✅ Includes **business logic injection** (before/after operations)- Configure multiple storage backends (Entity Framework, Cosmos DB, Azure Storage, etc.)

- ✅ Supports **multiple implementations** with Factory pattern- Implement CQRS patterns in your application

- ✅ Built-in **caching**, **translation**, and **batch operations**- Add caching layers to your repositories



**Key Benefit**: Write your repository once, swap storage implementations without changing business logic!## Installation



---```bash

dotnet add package Rystem.RepositoryFramework.Abstractions

## 📦 Installationdotnet add package Rystem.RepositoryFramework.Infrastructure.EntityFramework

```

### Core Package (Required)

```bash## Basic Setup

dotnet add package Rystem.RepositoryFramework.Abstractions --version 9.1.3

``````csharp

// Program.cs

### Storage Backends (Choose One or More)builder.Services.AddRepository<User, string>(repositoryBuilder =>

{

**Entity Framework (SQL)**:    repositoryBuilder

```bash        .WithEntityFramework<ApplicationDbContext>(options =>

dotnet add package Rystem.RepositoryFramework.Infrastructure.EntityFramework --version 9.1.3        {

dotnet add package Microsoft.EntityFrameworkCore.SqlServer --version 9.0.0            options.AddForSqlServer(builder.Configuration["ConnectionStrings:Default"]);

# Or PostgreSQL, SQLite, etc.        });

```});

```

**Azure Cosmos DB (NoSQL)**:

```bash## Advanced Configuration

dotnet add package Rystem.RepositoryFramework.Infrastructure.Azure.Cosmos.Sql --version 9.1.3

``````csharp

// With caching

**Azure Blob Storage (NoSQL)**:builder.Services.AddRepository<Product, int>(repositoryBuilder =>

```bash{

dotnet add package Rystem.RepositoryFramework.Infrastructure.Azure.Storage.Blob --version 9.1.3    repositoryBuilder

```        .WithEntityFramework<CatalogDbContext>()

        .WithCache(cache =>

**Azure Table Storage (NoSQL)**:        {

```bash            cache.WithDistributedCache();

dotnet add package Rystem.RepositoryFramework.Infrastructure.Azure.Storage.Table --version 9.1.3            cache.WithDefaultExpiration(TimeSpan.FromMinutes(5));

```        });

});

---

// With CQRS

## 🏗️ Core Conceptsbuilder.Services.AddRepositoryFrameworkCQRS<Order, Guid>(cqrs =>

{

### 1. Repository Interfaces (CQRS)    cqrs.WithCommand(command =>

    {

Rystem.RepositoryFramework is based on **CQRS** principles:        command.WithCosmosDb(/* config */);

    });

#### ICommand (Write Operations)    cqrs.WithQuery(query =>

```csharp    {

public interface ICommandPattern<T, TKey>        query.WithBlobStorage(/* config */);

    where TKey : notnull    });

{});

    Task<State<T, TKey>> InsertAsync(TKey key, T value, CancellationToken cancellationToken = default);```

    Task<State<T, TKey>> UpdateAsync(TKey key, T value, CancellationToken cancellationToken = default);

    Task<State<T, TKey>> DeleteAsync(TKey key, CancellationToken cancellationToken = default);## Patterns

    IAsyncEnumerable<BatchResult<T, TKey>> BatchAsync(BatchOperations<T, TKey> operations, CancellationToken cancellationToken = default);

}### Repository Pattern

```Use for standard CRUD operations with a single storage backend and optional caching.



#### IQuery (Read Operations)### CQRS Pattern

```csharpUse when you need different storage or optimization strategies for reads vs writes.

public interface IQueryPattern<T, TKey>

    where TKey : notnull## See Also

{

    Task<State<T, TKey>> ExistAsync(TKey key, CancellationToken cancellationToken = default);- [Rystem.RepositoryFramework Documentation](https://github.com/KeyserDSoze/Rystem/tree/master/src/Repository)

    Task<T?> GetAsync(TKey key, CancellationToken cancellationToken = default);- [Entity Framework Integration](https://github.com/KeyserDSoze/Rystem/tree/master/src/Repository/Rystem.RepositoryFramework.Infrastructure.EntityFramework)

    IAsyncEnumerable<Entity<T, TKey>> QueryAsync(IFilterExpression filter, CancellationToken cancellationToken = default);- [CQRS Implementation](https://github.com/KeyserDSoze/Rystem/tree/master/src/Repository/Rystem.RepositoryFramework.Abstractions)

    ValueTask<TProperty> OperationAsync<TProperty>(OperationType<TProperty> operation, IFilterExpression filter, CancellationToken cancellationToken = default);
}
```

#### IRepository (Combined)
```csharp
public interface IRepositoryPattern<T, TKey> : ICommandPattern<T, TKey>, IQueryPattern<T, TKey>
    where TKey : notnull
{
    // Includes all methods from ICommand and IQuery
}
```

**⚠️ Important**: Always inject `IRepository<T, TKey>`, NOT `IRepositoryPattern<T, TKey>`!

---

## 🚀 Quick Start Examples

### Example 1: Simple Repository with Entity Framework

#### Step 1: Define Your Entity
```csharp
namespace CargoLens.Orders.Core.Entities;

public class Order
{
    public Guid Id { get; set; }
    public string OrderNumber { get; set; } = string.Empty;
    public Guid CustomerId { get; set; }
    public OrderStatus Status { get; set; }
    public DateTime CreatedAt { get; set; }
}

public enum OrderStatus
{
    Pending,
    Confirmed,
    Shipped,
    Delivered,
    Cancelled
}
```

#### Step 2: Register Repository in DI
```csharp
// Program.cs or Startup.cs
using Rystem;

services.AddDbContext<OrdersDbContext>(options =>
    options.UseSqlServer(configuration.GetConnectionString("OrdersDb")));

services.AddRepository<Order, Guid>(builder =>
{
    builder.WithEntityFramework<OrdersDbContext>();
});
```

#### Step 3: Use in Your Service
```csharp
namespace CargoLens.Orders.Business.Services;

public class OrderService
{
    private readonly IRepository<Order, Guid> _orderRepository;
    
    public OrderService(IRepository<Order, Guid> orderRepository)
    {
        _orderRepository = orderRepository;
    }
    
    public async Task<Order?> GetOrderAsync(Guid orderId)
    {
        return await _orderRepository.GetAsync(orderId);
    }
    
    public async Task<State<Order, Guid>> CreateOrderAsync(Order order)
    {
        return await _orderRepository.InsertAsync(order.Id, order);
    }
    
    public async Task<List<Order>> GetPendingOrdersAsync()
    {
        var query = await _orderRepository
            .Where(x => x.Status == OrderStatus.Pending)
            .ToListAsync();
        
        return query.Select(x => x.Value!).ToList();
    }
}
```

---

### Example 2: Complex Key (Multi-Property)

Many entities have composite keys. Rystem handles this elegantly.

#### Option 1: Using Record (Recommended)
```csharp
// Define composite key as record
public record OrderItemKey(Guid OrderId, int ItemNumber);

public class OrderItem
{
    public Guid OrderId { get; set; }
    public int ItemNumber { get; set; }
    public string ProductName { get; set; }
    public int Quantity { get; set; }
    public decimal Price { get; set; }
}

// Register
services.AddRepository<OrderItem, OrderItemKey>(builder =>
{
    builder.WithEntityFramework<OrdersDbContext>();
});

// Use
var item = await _repository.GetAsync(new OrderItemKey(orderId, 1));
```

#### Option 2: Using IDefaultKey (Auto-Parsing)
```csharp
public class OrderItemKey : IDefaultKey
{
    public Guid OrderId { get; set; }
    public int ItemNumber { get; set; }
}

// Set custom separator (optional, default is |||)
IDefaultKey.SetDefaultSeparator("$$$");

// Key will be serialized as: {OrderId}$$${ItemNumber}
var keyString = key.AsString();
var parsedKey = IDefaultKey.Parse(keyString);
```

#### Option 3: Using IKey (Custom Parsing)
```csharp
public class OrderItemKey : IKey
{
    public Guid OrderId { get; set; }
    public int ItemNumber { get; set; }
    
    public static IKey Parse(string keyAsString)
    {
        var parts = keyAsString.Split('$');
        return new OrderItemKey 
        { 
            OrderId = Guid.Parse(parts[0]), 
            ItemNumber = int.Parse(parts[1]) 
        };
    }
    
    public string AsString()
    {
        return $"{OrderId}${ItemNumber}";
    }
}
```

#### Option 4: Using Built-in Key<T1, T2, ...>
Rystem provides generic key types for 2-5 properties:

```csharp
// For 2 properties
services.AddRepository<OrderItem, Key<Guid, int>>(builder =>
{
    builder.WithEntityFramework<OrdersDbContext>();
});

// Usage
var key = new Key<Guid, int>(orderId, itemNumber);
var item = await _repository.GetAsync(key);

// Available: Key<T1, T2>, Key<T1, T2, T3>, Key<T1, T2, T3, T4>, Key<T1, T2, T3, T4, T5>
```

---

### Example 3: CQRS (Separate Read and Write)

When you have different storage for reads and writes:

```csharp
// Write to SQL Server
services.AddCommand<Order, Guid>(builder =>
{
    builder.WithEntityFramework<OrdersDbContext>();
});

// Read from In-Memory Cache or different DB
services.AddQuery<Order, Guid>(builder =>
{
    builder.WithInMemory(options =>
    {
        options.PopulateWithRandomData(100, 10); // For testing
    });
    // Or read from read-replica
    // builder.WithEntityFramework<OrdersReadDbContext>();
});

// Inject separately
public class OrderService
{
    private readonly ICommand<Order, Guid> _orderCommand;
    private readonly IQuery<Order, Guid> _orderQuery;
    
    public OrderService(
        ICommand<Order, Guid> orderCommand,
        IQuery<Order, Guid> orderQuery)
    {
        _orderCommand = orderCommand;
        _orderQuery = orderQuery;
    }
    
    public async Task CreateOrderAsync(Order order)
    {
        await _orderCommand.InsertAsync(order.Id, order);
    }
    
    public async Task<Order?> GetOrderAsync(Guid id)
    {
        return await _orderQuery.GetAsync(id);
    }
}
```

---

## 🏭 Factory Pattern (Multiple Implementations)

Rystem integrates with **IFactory** from `Rystem.DependencyInjection` to support multiple repository implementations for the same entity.

### Use Case
You want:
- Primary storage: SQL Server
- Cache: In-Memory or Redis
- Backup: Azure Blob Storage

### Setup
```csharp
services.AddRepository<Order, Guid>(builder =>
{
    builder.WithEntityFramework<OrdersDbContext>();
}, "primary"); // Factory key

services.AddRepository<Order, Guid>(builder =>
{
    builder.WithInMemory();
}, "cache"); // Factory key

services.AddRepository<Order, Guid>(builder =>
{
    builder.WithBlobStorage(options =>
    {
        options.ConnectionString = configuration["Azure:Storage"];
        options.ContainerName = "orders-backup";
    });
}, "backup"); // Factory key
```

### Usage
```csharp
public class OrderService
{
    private readonly IFactory<IRepository<Order, Guid>> _repositoryFactory;
    
    public OrderService(IFactory<IRepository<Order, Guid>> repositoryFactory)
    {
        _repositoryFactory = repositoryFactory;
    }
    
    public async Task<Order?> GetOrderAsync(Guid orderId)
    {
        // Try cache first
        var cacheRepo = _repositoryFactory.Create("cache");
        var cached = await cacheRepo.GetAsync(orderId);
        if (cached != null) return cached;
        
        // Fallback to primary
        var primaryRepo = _repositoryFactory.Create("primary");
        var order = await primaryRepo.GetAsync(orderId);
        
        // Store in cache
        if (order != null)
        {
            await cacheRepo.InsertAsync(orderId, order);
        }
        
        return order;
    }
    
    public async Task BackupOrderAsync(Guid orderId)
    {
        var primaryRepo = _repositoryFactory.Create("primary");
        var backupRepo = _repositoryFactory.Create("backup");
        
        var order = await primaryRepo.GetAsync(orderId);
        if (order != null)
        {
            await backupRepo.InsertAsync(orderId, order);
        }
    }
}
```

**Default Repository**: The **last registered** repository is injected by default when you use `IRepository<T, TKey>` directly.

```csharp
// This will inject the "backup" repository (last one registered)
public OrderService(IRepository<Order, Guid> repository)
{
    _repository = repository;
}
```

---

## 🔧 Query Operations

Rystem provides powerful LINQ-like query capabilities:

### Basic Queries
```csharp
// Get single item
var order = await _repository.GetAsync(orderId);

// Check existence
var exists = await _repository.ExistAsync(orderId);

// Get all
var allOrders = await _repository.QueryAsync().ToListAsync();

// Filter
var pendingOrders = await _repository
    .Where(x => x.Status == OrderStatus.Pending)
    .ToListAsync();

// Multiple conditions
var recentOrders = await _repository
    .Where(x => x.Status == OrderStatus.Confirmed && x.CreatedAt > DateTime.UtcNow.AddDays(-7))
    .ToListAsync();
```

### Sorting and Paging
```csharp
// Order by
var orderedOrders = await _repository
    .Where(x => x.Status == OrderStatus.Shipped)
    .OrderBy(x => x.CreatedAt)
    .ToListAsync();

// Order by descending
var latestOrders = await _repository
    .OrderByDescending(x => x.CreatedAt)
    .Top(10)
    .ToListAsync();

// Pagination
var page = await _repository
    .Where(x => x.Status == OrderStatus.Delivered)
    .OrderByDescending(x => x.CreatedAt)
    .PageAsync(pageNumber: 1, pageSize: 20);

// Skip and Take
var orders = await _repository
    .OrderBy(x => x.OrderNumber)
    .Skip(50)
    .Top(25)
    .ToListAsync();
```

### Aggregations
```csharp
// Count
var count = await _repository
    .Where(x => x.Status == OrderStatus.Pending)
    .CountAsync();

// Max
var maxOrderId = await _repository.MaxAsync(x => x.Id);

// Min
var minCreationDate = await _repository.MinAsync(x => x.CreatedAt);

// Sum (requires numeric property)
var totalQuantity = await _repository
    .Where(x => x.Status == OrderStatus.Delivered)
    .SumAsync(x => x.TotalQuantity);

// Average
var avgOrderValue = await _repository.AverageAsync(x => x.TotalAmount);
```

### First and Single
```csharp
// First or default
var firstOrder = await _repository
    .Where(x => x.CustomerId == customerId)
    .OrderBy(x => x.CreatedAt)
    .FirstOrDefaultAsync();

// Single or default (expects 0 or 1 result)
var order = await _repository
    .Where(x => x.OrderNumber == "ORD-12345")
    .SingleOrDefaultAsync();
```

---

## 🔄 Batch Operations

Execute multiple operations in a single call:

```csharp
var batchOperation = _repository.CreateBatchOperation();

// Add operations
for (var i = 0; i < 100; i++)
{
    var order = new Order 
    { 
        Id = Guid.NewGuid(), 
        OrderNumber = $"ORD-{i:D5}",
        Status = OrderStatus.Pending 
    };
    batchOperation.Insert(order.Id, order);
}

// Execute all at once
var results = await batchOperation.ExecuteAsync().ToListAsync();

// Check results
foreach (var result in results)
{
    if (!result.State.IsOk)
    {
        Console.WriteLine($"Failed: {result.Key} - {result.State.Message}");
    }
}
```

### Batch with Mixed Operations
```csharp
var batch = _repository.CreateBatchOperation();

// Insert
batch.Insert(newOrder.Id, newOrder);

// Update
batch.Update(existingOrder.Id, existingOrder);

// Delete
batch.Delete(oldOrderId);

await batch.ExecuteAsync().ToListAsync();
```

---

## 🌍 Translation (Property Mapping)

When your database schema differs from your domain model:

```csharp
// Domain model
public class Order
{
    public Guid Id { get; set; }
    public string OrderNumber { get; set; }
    public string CustomerEmail { get; set; }
}

// Database model
public class OrderEntity
{
    public Guid Identificativo { get; set; }
    public string NumeroOrdine { get; set; }
    public string EmailCliente { get; set; }
}

// Configure translation
services.AddRepository<Order, Guid>(builder =>
{
    builder.WithEntityFramework<OrdersDbContext>();
    
    builder.Translate<OrderEntity>()
        .With(x => x.Id, x => x.Identificativo)
        .With(x => x.OrderNumber, x => x.NumeroOrdine)
        .With(x => x.CustomerEmail, x => x.EmailCliente);
});
```

Now when you query:
```csharp
// This query on Order model...
var orders = await _repository
    .Where(x => x.CustomerEmail.Contains("@gmail.com"))
    .ToListAsync();

// ...is automatically translated to OrderEntity:
// context.Orders.Where(x => x.EmailCliente.Contains("@gmail.com"))
```

**How to Use Translation in Repository Implementation**:
```csharp
public class OrderRepository : IRepository<Order, Guid>
{
    private readonly OrdersDbContext _context;
    
    public async IAsyncEnumerable<Entity<Order, Guid>> QueryAsync(
        IFilterExpression filter, 
        CancellationToken cancellationToken = default)
    {
        // Apply translation and convert to IQueryable
        await foreach (var entity in filter.ApplyAsAsyncEnumerable(_context.Orders))
        {
            yield return new Entity<Order, Guid>
            {
                Key = entity.Identificativo,
                Value = new Order
                {
                    Id = entity.Identificativo,
                    OrderNumber = entity.NumeroOrdine,
                    CustomerEmail = entity.EmailCliente
                }
            };
        }
    }
}
```

---

## 💼 Business Logic Injection

Execute custom logic before or after repository operations:

### Create Business Class
```csharp
public class OrderBusinessLogic : 
    IRepositoryBusinessBeforeInsert<Order, Guid>,
    IRepositoryBusinessAfterInsert<Order, Guid>,
    IRepositoryBusinessBeforeUpdate<Order, Guid>,
    IRepositoryBusinessBeforeDelete<Order, Guid>
{
    private readonly ILogger<OrderBusinessLogic> _logger;
    
    public OrderBusinessLogic(ILogger<OrderBusinessLogic> logger)
    {
        _logger = logger;
    }
    
    // Before insert - validation
    public Task<State<Order, Guid>> BeforeInsertAsync(
        Entity<Order, Guid> entity, 
        CancellationToken cancellationToken = default)
    {
        var order = entity.Value;
        
        // Validation
        if (string.IsNullOrWhiteSpace(order.OrderNumber))
        {
            return Task.FromResult(State.Error<Order, Guid>("Order number is required"));
        }
        
        // Auto-generate values
        if (order.CreatedAt == default)
        {
            order.CreatedAt = DateTime.UtcNow;
        }
        
        _logger.LogInformation("Creating order {OrderNumber}", order.OrderNumber);
        
        return Task.FromResult(State.Ok(entity));
    }
    
    // After insert - side effects
    public Task<State<Order>> AfterInsertAsync(
        State<Order, Guid> state, 
        Entity<Order, Guid> entity, 
        CancellationToken cancellationToken = default)
    {
        if (state.IsOk)
        {
            _logger.LogInformation("Order created successfully: {OrderId}", entity.Key);
            // Send event, notification, etc.
        }
        
        return Task.FromResult(state);
    }
    
    // Before update - prevent invalid transitions
    public Task<State<Order, Guid>> BeforeUpdateAsync(
        Entity<Order, Guid> entity, 
        Entity<Order, Guid>? oldEntity,
        CancellationToken cancellationToken = default)
    {
        if (oldEntity?.Value?.Status == OrderStatus.Cancelled)
        {
            return Task.FromResult(State.Error<Order, Guid>("Cannot update cancelled orders"));
        }
        
        return Task.FromResult(State.Ok(entity));
    }
    
    // Before delete - soft delete
    public Task<State<Order, Guid>> BeforeDeleteAsync(
        Entity<Order, Guid> entity, 
        CancellationToken cancellationToken = default)
    {
        // Instead of deleting, mark as cancelled
        entity.Value!.Status = OrderStatus.Cancelled;
        return Task.FromResult(State.Error<Order, Guid>("Soft delete - order cancelled"));
    }
}
```

### Register Business Logic
```csharp
services.AddRepository<Order, Guid>(builder =>
{
    builder.WithEntityFramework<OrdersDbContext>();
    
    builder
        .AddBusiness()
            .AddBusinessBeforeInsert<OrderBusinessLogic>()
            .AddBusinessAfterInsert<OrderBusinessLogic>()
            .AddBusinessBeforeUpdate<OrderBusinessLogic>()
            .AddBusinessBeforeDelete<OrderBusinessLogic>();
});
```

### Separate Business Registration (Clean Architecture)
If you want to keep business logic in a different project:

```csharp
// In Infrastructure project - just repository setup
services.AddRepository<Order, Guid>(builder =>
{
    builder.WithEntityFramework<OrdersDbContext>();
});

// In Business project - add business logic
services.AddBusinessForRepository<Order, Guid>(builder =>
{
    builder
        .AddBusiness()
            .AddBusinessBeforeInsert<OrderBusinessLogic>()
            .AddBusinessAfterInsert<OrderBusinessLogic>()
            .AddBusinessBeforeUpdate<OrderBusinessLogic>()
            .AddBusinessBeforeDelete<OrderBusinessLogic>();
});
```

**Available Interfaces**:
- `IRepositoryBusinessBeforeInsert<T, TKey>`
- `IRepositoryBusinessAfterInsert<T, TKey>`
- `IRepositoryBusinessBeforeUpdate<T, TKey>`
- `IRepositoryBusinessAfterUpdate<T, TKey>`
- `IRepositoryBusinessBeforeDelete<T, TKey>`
- `IRepositoryBusinessAfterDelete<T, TKey>`

**⚠️ Important**: Business logic classes must be **public** for DI to instantiate them!

---

## 🗄️ Storage Backend Examples

### 1. Entity Framework (SQL Server, PostgreSQL, SQLite)

```csharp
// DbContext
public class OrdersDbContext : DbContext
{
    public OrdersDbContext(DbContextOptions<OrdersDbContext> options)
        : base(options)
    {
    }
    
    public DbSet<Order> Orders { get; set; }
    
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Order>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.OrderNumber).IsRequired().HasMaxLength(50);
            entity.HasIndex(e => e.OrderNumber).IsUnique();
        });
    }
}

// Registration
services.AddDbContext<OrdersDbContext>(options =>
    options.UseSqlServer(configuration.GetConnectionString("OrdersDb")));

services.AddRepository<Order, Guid>(builder =>
{
    builder.WithEntityFramework<OrdersDbContext>();
});
```

### 2. Azure Cosmos DB (NoSQL)

```csharp
services.AddRepository<Order, Guid>(builder =>
{
    builder.WithCosmosDb(options =>
    {
        options.ConnectionString = configuration["CosmosDb:ConnectionString"];
        options.DatabaseName = "OrdersDb";
        options.ContainerName = "orders";
        options.PartitionKey = "/customerId"; // Partition key path
    });
});
```

### 3. Azure Blob Storage (NoSQL - JSON documents)

```csharp
services.AddRepository<Order, Guid>(builder =>
{
    builder.WithBlobStorage(options =>
    {
        options.ConnectionString = configuration["Azure:Storage"];
        options.ContainerName = "orders";
    });
});
```

### 4. Azure Table Storage (NoSQL - Key-Value)

```csharp
services.AddRepository<Order, OrderKey>(builder =>
{
    builder.WithTableStorage(options =>
    {
        options.ConnectionString = configuration["Azure:Storage"];
        options.TableName = "Orders";
        options.PartitionKey = "CustomerId";
        options.RowKey = "OrderId";
        options.PartitionKeyFunction = x => x.CustomerId.ToString();
        options.RowKeyFunction = x => x.OrderId.ToString();
    });
});
```

### 5. In-Memory (Testing)

```csharp
services.AddRepository<Order, Guid>(builder =>
{
    builder.WithInMemory(options =>
    {
        // Pre-populate with random data
        options
            .PopulateWithRandomData(count: 100, numberOfEntities: 10)
            .WithPattern(x => x.Value!.OrderNumber, @"ORD-[0-9]{5}");
    });
});
```

---

## 🎯 Real-World Example: Complete Order Repository

```csharp
// 1. Entity
namespace CargoLens.Orders.Core.Entities;

public class Order
{
    public Guid Id { get; init; }
    public string OrderNumber { get; set; } = string.Empty;
    public Guid CustomerId { get; set; }
    public OrderStatus Status { get; private set; }
    public DateTime CreatedAt { get; init; }
    public List<OrderItem> Items { get; set; } = new();
    
    public void MarkAsConfirmed() => Status = OrderStatus.Confirmed;
    public void MarkAsShipped() => Status = OrderStatus.Shipped;
}

// 2. Repository Interface (Optional - for DDD)
namespace CargoLens.Orders.Core.Interfaces;

public interface IOrderRepository : IRepository<Order, Guid>
{
    // Custom methods if needed
    Task<List<Order>> GetOrdersByCustomerAsync(Guid customerId);
}

// 3. Repository Implementation (if custom methods)
namespace CargoLens.Orders.Storage.Repositories;

public class OrderRepository : IOrderRepository
{
    private readonly IRepository<Order, Guid> _baseRepository;
    private readonly OrdersDbContext _context;
    
    public OrderRepository(
        IRepository<Order, Guid> baseRepository,
        OrdersDbContext context)
    {
        _baseRepository = baseRepository;
        _context = context;
    }
    
    // Delegate all IRepository methods to base
    public Task<State<Order, Guid>> InsertAsync(Guid key, Order value, CancellationToken cancellationToken = default)
        => _baseRepository.InsertAsync(key, value, cancellationToken);
    
    public Task<State<Order, Guid>> UpdateAsync(Guid key, Order value, CancellationToken cancellationToken = default)
        => _baseRepository.UpdateAsync(key, value, cancellationToken);
    
    public Task<State<Order, Guid>> DeleteAsync(Guid key, CancellationToken cancellationToken = default)
        => _baseRepository.DeleteAsync(key, cancellationToken);
    
    public IAsyncEnumerable<BatchResult<Order, Guid>> BatchAsync(BatchOperations<Order, Guid> operations, CancellationToken cancellationToken = default)
        => _baseRepository.BatchAsync(operations, cancellationToken);
    
    public Task<State<Order, Guid>> ExistAsync(Guid key, CancellationToken cancellationToken = default)
        => _baseRepository.ExistAsync(key, cancellationToken);
    
    public Task<Order?> GetAsync(Guid key, CancellationToken cancellationToken = default)
        => _baseRepository.GetAsync(key, cancellationToken);
    
    public IAsyncEnumerable<Entity<Order, Guid>> QueryAsync(IFilterExpression filter, CancellationToken cancellationToken = default)
        => _baseRepository.QueryAsync(filter, cancellationToken);
    
    public ValueTask<TProperty> OperationAsync<TProperty>(OperationType<TProperty> operation, IFilterExpression filter, CancellationToken cancellationToken = default)
        => _baseRepository.OperationAsync(operation, filter, cancellationToken);
    
    // Custom method
    public async Task<List<Order>> GetOrdersByCustomerAsync(Guid customerId)
    {
        return await _context.Orders
            .Where(o => o.CustomerId == customerId)
            .OrderByDescending(o => o.CreatedAt)
            .ToListAsync();
    }
}

// 4. Registration
services.AddDbContext<OrdersDbContext>(options =>
    options.UseSqlServer(configuration.GetConnectionString("OrdersDb")));

services.AddRepository<Order, Guid>(builder =>
{
    builder.WithEntityFramework<OrdersDbContext>();
    
    builder
        .AddBusiness()
            .AddBusinessBeforeInsert<OrderBusinessLogic>();
});

// If custom repository interface
services.AddScoped<IOrderRepository, OrderRepository>();

// 5. Usage in Service
namespace CargoLens.Orders.Business.Services;

public class OrderService
{
    private readonly IOrderRepository _orderRepository;
    
    public OrderService(IOrderRepository orderRepository)
    {
        _orderRepository = orderRepository;
    }
    
    public async Task<Guid> CreateOrderAsync(CreateOrderDto dto)
    {
        var order = new Order
        {
            Id = Guid.NewGuid(),
            OrderNumber = GenerateOrderNumber(),
            CustomerId = dto.CustomerId,
            CreatedAt = DateTime.UtcNow,
            Items = dto.Items.Select(MapToOrderItem).ToList()
        };
        
        var result = await _orderRepository.InsertAsync(order.Id, order);
        
        if (!result.IsOk)
            throw new InvalidOperationException(result.Message);
        
        return order.Id;
    }
    
    public async Task<List<OrderDto>> GetCustomerOrdersAsync(Guid customerId)
    {
        var orders = await _orderRepository.GetOrdersByCustomerAsync(customerId);
        return orders.Select(MapToDto).ToList();
    }
}
```

---

## 📚 Common Patterns

### Pattern 1: Repository + Business Logic + Factory
```csharp
// Primary database
services.AddRepository<Order, Guid>(builder =>
{
    builder.WithEntityFramework<OrdersDbContext>();
    builder.AddBusiness()
        .AddBusinessBeforeInsert<OrderValidationBusiness>()
        .AddBusinessAfterInsert<OrderEventPublisherBusiness>();
}, "primary");

// Read replica or cache
services.AddRepository<Order, Guid>(builder =>
{
    builder.WithEntityFramework<OrdersReadDbContext>();
}, "readonly");
```

### Pattern 2: CQRS with Different Databases
```csharp
// Write to SQL
services.AddCommand<Order, Guid>(builder =>
{
    builder.WithEntityFramework<OrdersDbContext>();
});

// Read from Cosmos DB (denormalized for fast queries)
services.AddQuery<Order, Guid>(builder =>
{
    builder.WithCosmosDb(options => { /* ... */ });
});
```

### Pattern 3: Layered Caching
```csharp
// L1 Cache: In-Memory
services.AddRepository<Order, Guid>(builder =>
{
    builder.WithInMemory();
}, "memory");

// L2 Cache: Redis
services.AddRepository<Order, Guid>(builder =>
{
    builder.WithDistributedCache();
}, "redis");

// Primary: Database
services.AddRepository<Order, Guid>(builder =>
{
    builder.WithEntityFramework<OrdersDbContext>();
}, "database");
```

---

## ⚠️ Important Notes

1. **Always use `IRepository<T, TKey>`**, NOT `IRepositoryPattern<T, TKey>` when injecting
2. **Always use `ICommand<T, TKey>`**, NOT `ICommandPattern<T, TKey>` when injecting
3. **Always use `IQuery<T, TKey>`**, NOT `IQueryPattern<T, TKey>` when injecting
4. **Business logic classes must be `public`** for DI to instantiate them
5. **Factory pattern uses `IFactory<IRepository<T, TKey>>`** from Rystem.DependencyInjection
6. **Last registered** repository is the default when injecting `IRepository<T, TKey>` directly
7. **Version 9.1.3** is the current stable version for all Rystem packages

---

## 🔗 Related Resources

- **ddd-single-domain**: How to organize repositories in single-domain architecture
- **ddd-multi-domain**: How to organize repositories in multi-domain architecture
- **repository-api-server**: Auto-generate REST APIs from repositories (no controllers needed)
- **repository-api-client-typescript**: Consume repositories from TypeScript/JavaScript apps
- **repository-api-client-dotnet**: Consume repositories from .NET/C# apps (Blazor, MAUI, WPF)
- **install-rystem**: How to install Rystem packages
- **Background Jobs**: Use with repositories for async operations
- **Concurrency**: Lock repositories during critical operations

---

## 📖 Further Reading

- [Rystem.RepositoryFramework GitHub](https://github.com/KeyserDSoze/RepositoryFramework)
- [Unit Tests Examples](https://github.com/KeyserDSoze/RepositoryFramework/tree/master/src/RepositoryFramework.Test)
- [Entity Framework Integration](https://github.com/KeyserDSoze/RepositoryFramework/tree/master/src/RepositoryFramework.Test/RepositoryFramework.Test.Infrastructure.EntityFramework)

---

## ✅ Summary

**Rystem.RepositoryFramework** provides:
- ✅ Unified repository pattern for all storage types
- ✅ Built-in CQRS support
- ✅ Multiple implementations with Factory pattern
- ✅ Business logic injection (before/after hooks)
- ✅ Powerful LINQ-like queries
- ✅ Batch operations
- ✅ Translation for schema mapping
- ✅ Support for complex keys

**Use this tool whenever you need to implement data access in a Rystem application!** 🚀

---

## repository/repositoryframework-abstractions

> Based on CQRS we could split our repository pattern in two main interfaces, one for update (write, delete) and one for read.

### [What is Rystem?](https://github.com/KeyserDSoze/Rystem)

### Interfaces
Based on CQRS we could split our repository pattern in two main interfaces, one for update (write, delete) and one for read.

#### Command (Write-Delete)
    public interface ICommandPattern<T, TKey> : ICommandPattern
        where TKey : notnull
    {
        Task<State<T, TKey>> InsertAsync(TKey key, T value, CancellationToken cancellationToken = default);
        Task<State<T, TKey>> UpdateAsync(TKey key, T value, CancellationToken cancellationToken = default);
        Task<State<T, TKey>> DeleteAsync(TKey key, CancellationToken cancellationToken = default);
        IAsyncEnumerable<BatchResult<T, TKey>> BatchAsync(BatchOperations<T, TKey> operations, CancellationToken cancellationToken = default);
    }

#### Query (Read)
    public interface IQueryPattern<T, TKey> : IQueryPattern
        where TKey : notnull
    {
        Task<State<T, TKey>> ExistAsync(TKey key, CancellationToken cancellationToken = default);
        Task<T?> GetAsync(TKey key, CancellationToken cancellationToken = default);
        IAsyncEnumerable<IEntity<T, TKey>> QueryAsync(IFilterExpression filter, CancellationToken cancellationToken = default);
        ValueTask<TProperty> OperationAsync<TProperty>(OperationType<TProperty> operation, IFilterExpression filter, CancellationToken cancellationToken = default);
    }

#### Repository Pattern (Write-Delete-Read)
Repository pattern is a sum of CQRS interfaces.

    public interface IRepositoryPattern<T, TKey> : ICommandPattern<T, TKey>, IQueryPattern<T, TKey>, IRepositoryPattern, ICommandPattern, IQueryPattern
        where TKey : notnull
    {
        Task<State<T, TKey>> InsertAsync(TKey key, T value, CancellationToken cancellationToken = default);
        Task<State<T, TKey>> UpdateAsync(TKey key, T value, CancellationToken cancellationToken = default);
        Task<State<T, TKey>> DeleteAsync(TKey key, CancellationToken cancellationToken = default);
        IAsyncEnumerable<BatchResult<T, TKey>> BatchAsync(BatchOperations<T, TKey> operations, CancellationToken cancellationToken = default);
        Task<State<T, TKey>> ExistAsync(TKey key, CancellationToken cancellationToken = default);
        Task<T?> GetAsync(TKey key, CancellationToken cancellationToken = default);
        IAsyncEnumerable<IEntity<T, TKey>> QueryAsync(IFilterExpression filter, CancellationToken cancellationToken = default);
        ValueTask<TProperty> OperationAsync<TProperty>(OperationType<TProperty> operation, IFilterExpression filter, CancellationToken cancellationToken = default);
    }

### Examples

#### Model
    public class User
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
    }
#### Command
Your storage class has to extend ICommand, and use it on injection

    public class UserWriter : ICommand<User, string>
    {
        public Task<State<User, string>> DeleteAsync(string key, CancellationToken cancellationToken = default)
        {
            //delete on with DB or storage context
            throw new NotImplementedException();
        }
        public Task<State<User, string>> InsertAsync(string key, User value, CancellationToken cancellationToken = default)
        {
            //insert on DB or storage context
            throw new NotImplementedException();
        }
        public Task<State<User, string>> UpdateAsync(string key, User value, CancellationToken cancellationToken = default)
        {
            //update on DB or storage context
            throw new NotImplementedException();
        }
        public Task<BatchResults<User, string>> BatchAsync(BatchOperations<User, string> operations, CancellationToken cancellationToken = default)
        {
            //insert, update or delete some items on DB or storage context
            throw new NotImplementedException();
        }
    }

#### Query
Your storage class has to extend IQuery, and use it on injection

    public class UserReader : IQuery<User, string>
    {
        public Task<User?> GetAsync(string key, CancellationToken cancellationToken = default)
        {
            //get an item by key from DB or storage context
            throw new NotImplementedException();
        }
        public Task<State<User, string>> ExistAsync(string key, CancellationToken cancellationToken = default)
        {
            //check if an item by key exists in DB or storage context
            throw new NotImplementedException();
        }
        public IAsyncEnumerable<IEntity<User, string>> QueryAsync(IFilterExpression filter, CancellationToken cancellationToken = default)
        {
            //get a list of items by a predicate with top and skip from DB or storage context
            throw new NotImplementedException();
        }
        public ValueTask<TProperty> OperationAsync<TProperty>(OperationType<TProperty> operation, IFilterExpression filter, CancellationToken cancellationToken = default)
        {
            //get an items count by a predicate with top and skip from DB or storage context or max or min or some other operations
            throw new NotImplementedException();
        }
    }
    
#### Alltogether as repository pattern 
if you don't have CQRS infrastructure (usually it's correct to use CQRS when you have minimum two infrastructures one for write and delete and at least one for read).
You may choose to extend IRepository, but when you inject you have to use IRepository

    public class UserRepository : IRepository<User, string>, IQuery<User, string>, ICommand<User, string>
    {
        public Task<State<User, string>> DeleteAsync(string key, CancellationToken cancellationToken = default)
        {
            //delete on with DB or storage context
            throw new NotImplementedException();
        }
        public Task<State<User, string>> InsertAsync(string key, User value, CancellationToken cancellationToken = default)
        {
            //insert on DB or storage context
            throw new NotImplementedException();
        }
        public Task<State<User, string>> UpdateAsync(string key, User value, CancellationToken cancellationToken = default)
        {
            //update on DB or storage context
            throw new NotImplementedException();
        }
        public Task<BatchResults<User, string>> BatchAsync(BatchOperations<User, string> operations, CancellationToken cancellationToken = default)
        {
            //insert, update or delete some items on DB or storage context
            throw new NotImplementedException();
        }
        public Task<User?> GetAsync(string key, CancellationToken cancellationToken = default)
        {
            //get an item by key from DB or storage context
            throw new NotImplementedException();
        }
        public Task<State<User, string>> ExistAsync(string key, CancellationToken cancellationToken = default)
        {
            //check if an item by key exists in DB or storage context
            throw new NotImplementedException();
        }
        public IAsyncEnumerable<IEntity<User, string>> QueryAsync(IFilterExpression filter, CancellationToken cancellationToken = default)
        {
            //get a list of items by a predicate with top and skip from DB or storage context
            throw new NotImplementedException();
        }
        public ValueTask<TProperty> OperationAsync<TProperty>(OperationType<TProperty> operation, IFilterExpression filter, CancellationToken cancellationToken = default)
        {
            //get an items count by a predicate with top and skip from DB or storage context or max or min or some other operations
            throw new NotImplementedException();
        }
    }

### How to use it
In DI you install the service. Here an example on how to set a custom storage,
prepare a translation (to translate name of your properties for query during filtering),
and AddBusiness for your integration. Furthermore you may use the factory integration from Rystem.

    var factoryName = "storage";
     services.AddRepository<AppUser, AppUserKey>(builder =>
    {
        builder.SetStorage<AppUserStorage>(factoryName);
        builder.Translate<User>()
            .With(x => x.Id, x => x.Identificativo)
            .With(x => x.Username, x => x.Nome)
            .With(x => x.Email, x => x.IndirizzoElettronico);
        builder
            .AddBusiness()
                .AddBusinessBeforeInsert<AppUserBeforeInsertBusiness>()
                .AddBusinessBeforeInsert<AppUserBeforeInsertBusiness2>();
    });

And you may inject the object
## Please, use IRepository and not IRepositoryPattern
    
    IRepository<AppUser, AppUserKey> repository

### Query and Command
In DI you install the services

    services.AddCommand<AppUser, AppUserKey>(...);
    services.AddQuery<AppUser, AppUserKey>(...);

And you may inject the objects
## Please, use ICommand, IQuery and not ICommandPattern, IQueryPattern

    ICommand<AppUser, AppUserKey> command
    IQuery<AppUser, AppUserKey> query

### TKey when it's not a primitive
You can use a class or record. 
Record is better in my opinion, for example, if you want to use the Equals operator from key, with record you don't check it by the refence but by the value of the properties in the record.
My key:

    public class MyKey 
    {
        public int Id { get; set; }
        public int Id2 { get; set; }
    }

the DI
    
    services.AddRepository<User, MyKey>(...);

and you may inject (for ICommand and IQuery is the same)

    IRepository<User, MyKey> repository

### IKey interface
You may implement the IKey interface to decide how to work with your key.
Here an example with Parse and AsString method and custom implementation with separator $.

    public class ClassicKey : IKey
    {
        public string A { get; set; }
        public int B { get; set; }
        public double C { get; set; }

        public static IKey Parse(string keyAsString)
        {
            var splitted = keyAsString.Split('$');
            return new ClassicKey { A = splitted[0], B = int.Parse(splitted[1]), C = double.Parse(splitted[2]) };
        }

        public string AsString()
        {
            return $"{A}${B}${C}";
        }
    }

### IDefaultKey
You may implement IDefaultKey if you want a simple key preconstructed parser.

    public class DefaultKey : IDefaultKey
    {
        public string A { get; set; }
        public int B { get; set; }
        public double C { get; set; }
    }

Automatically you can call AsString to receive a string composed by all properties separated by triple |, for instance {A}|||{B}|||{C}.
You can decide during startup the separator in two ways.
One with ServiceCollectionExtensions

    builder.Services.AddDefaultSeparatorForDefaultKeyInterface("$$$");

the other one with a static method offered by IDefaultKey interface

    IDefaultKey.SetDefaultSeparator("$$$");

### Default TKey record
You may use the default record key in repository framework namespace.
It's not really useful when used with no-primitive or no-struct objects (in terms of memory usage [Heap]).
For 1 value (it's not really useful I know, but I liked to create it).

    new Key<int>(2);

or for 2 values (useful)
    
    new Key<int, int>(2, 4);

or for 3 values (unuseful)
    
    new Key<int, int, string>(2, 4, "312");

or for 4 values (useful)
    
    new Key<int, int, double, Guid>(2, 4, 3, Guid.NewGuid());

or for 5 values (unuseful)
    
    new Key<int, int, string, Guid, string>(2, 4, "312", Guid.NewGuid(), "3232");

the DI
    
    services.AddRepository<User, Key<int, int>, UserRepository>();

and you may inject (for ICommand and IQuery is the same)

    IRepository<User, Key<int, int>> repository

### Translation
In some cases you need to "translate" your query for your database context query, for example in case of EF integration.

    services.AddDbContext<SampleContext>(options =>
    {
        options.UseSqlServer(configuration["ConnectionString:Database"]);
    }, ServiceLifetime.Scoped);
    services.AddRepository<AppUser, AppUserKey>(repositoryBuilder =>
    {
        repositoryBuilder.SetStorage<AppUserStorage>();
        repositoryBuilder.Translate<User>()
            .With(x => x.Id, x => x.Identificativo)
            .With(x => x.Username, x => x.Nome)
            .With(x => x.Email, x => x.IndirizzoElettronico);
    });
    

In this case I'm helping the Filter class to understand how to transform itself when used in a different context.
Use Filter methods to help to translate and apply to your context the right query.

    await foreach (var user in filter.ApplyAsAsyncEnumerable(_context.Users))
        yield return new AppUser(user.Identificativo, user.Nome, user.IndirizzoElettronico, new());

You may use Filter for queryable, FilterAsEnumerable for Enumerable and FilterAsAsyncEnumerable for async enumerable context.

You can add more translations for the same model

    services.AddDbContext<SampleContext>(options =>
    {
        options.UseSqlServer(configuration["ConnectionString:Database"]);
    }, ServiceLifetime.Scoped);
    services.AddRepository<AppUser, AppUserKey>(repositoryBuilder =>
    {
        repositoryBuilder.SetStorage<AppUserStorage>();
        repositoryBuilder.Translate<User>()
            .With(x => x.Id, x => x.Identificativo)
            .With(x => x.Username, x => x.Nome)
            .With(x => x.Email, x => x.IndirizzoElettronico);
        repositoryBuilder
            .AddBusiness()
                .AddBusinessBeforeInsert<AppUserBeforeInsertBusiness>()
                .AddBusinessBeforeInsert<AppUserBeforeInsertBusiness2>();
    });

### Entity framework examples
[Here you may find the example](https://github.com/KeyserDSoze/RepositoryFramework/tree/master/src/RepositoryFramework.Test/RepositoryFramework.Test.Infrastructure.EntityFramework)
[Repository pattern applied](https://github.com/KeyserDSoze/RepositoryFramework/blob/master/src/RepositoryFramework.Test/RepositoryFramework.Test.Infrastructure.EntityFramework/AppUser.cs)
[Unit test flow](https://github.com/KeyserDSoze/RepositoryFramework/blob/master/src/RepositoryFramework.Test/RepositoryFramework.UnitTest/Tests/AllIntegration/AllIntegrationTest.cs)

## Business Manager
You have the chance to write your business methods to execute them before or after a command or query.
For instance, you have to check before an update or insert the value of an entity and deny the final insert/update on the database.

### Example
In this example BeforeInsertAsync runs before InsertAsync of IRepository/ICommand and AfterInsertAsync runs after InsertAsync of IRepository/ICommand.

    .AddRepository<Animal, long>(builder => {
        builder.
            WithInMemory();
        builder
            .AddBusiness()
                .AddBusinessAfterInsert<AnimalBusiness>()
                .AddBusinessBeforeInsert<AnimalBusiness>();
    });
        

more interesting usage comes to move business in another project, you can add to your infrastructure in the following way

    .AddBusinessForRepository<Animal, long>(builder => {
        builder
            .AddBusiness()
                .AddBusinessAfterInsert<AnimalBusiness>()
                .AddBusinessBeforeInsert<AnimalBusiness>();
    });
       

Then, you could have a library for infrastructure (or more than one) and a library for business to separate furthermore the concepts.

The animal business to inject will be the following one.

    public sealed class AnimalBusiness : IRepositoryBusinessBeforeInsert<Animal, long>, IRepositoryBusinessAfterInsert<Animal, long>
    {
        public static int After;
        public Task<State<Animal>> AfterInsertAsync(State<Animal, long> state, Entity<Animal, long> entity, CancellationToken cancellationToken = default)
        {
            After++;
            return Task.FromResult(state);
        }

        public static int Before;
        public Task<State<Animal, long>> BeforeInsertAsync(Entity<Animal, long> entity, CancellationToken cancellationToken = default)
        {
            Before++;
            return Task.FromResult(State.Ok(entity));
        }
    }

You have to create the class as public to allow the dependency injection to instastiate it. It's added directly to DI.

## Factory
Integration with factory from rystem is hidden in the framework, and it's ready to be used.
For instance here i'm installing two different repositories for the same model and key.

    var builder = WebApplication.CreateBuilder(args);
    builder.Services
    .AddRepository<SuperUser, string>(settins =>
    {
        settins.WithInMemory(builder =>
        {
            builder
                .PopulateWithRandomData(120, 5)
                .WithPattern(x => x.Value!.Email, @"[a-z]{5,10}@gmail\.com");
        });
        settins.WithInMemory(builder =>
        {
            builder
                .PopulateWithRandomData(2, 5)
                .WithPattern(x => x.Value!.Email, @"[a-z]{5,10}@gmail\.com");
        }, "inmemory");
    });

Usage

    var serviceProvider = ....;
    IFactory<IRepository<SuperUser, string>> superUserFactory = serviceProvider.GetRequiredService<IFactory<IRepository<SuperUser, string>>>();
    var firstIntegration = superUserFactory.Create();
    var secondIntegration = superUserFactory.Create("inmemory");

By default is injected directly the last one repository integration installed.

    var serviceProvider = ....;
    IRepository<SuperUser, string> secondIntegration = serviceProvider.GetRequiredService<IRepository<SuperUser, string>>();

Here you find the "inmemory" integration.
[You can use the decorator pattern offered by Rystem](https://github.com/KeyserDSoze/Rystem/tree/master/src/Core/Rystem)
for your integration to decorate an IRepository<T, TKey> or ICommand<T, TKey> or IQuery<T, TKey>.

---

## repository/repositoryframework-api-client

> You can add a client for a specific url

### [What is Rystem?](https://github.com/KeyserDSoze/Rystem)

## Services extensions

### HttpClient to use your API (example)
You can add a client for a specific url

    builder.Services.AddRepository<User, string>(builder =>
    {
        builder
            .WithApiClient()
            .WithHttpClient("localhost:7058");
    });

You may add a Polly policy to your api client for example:

    var retryPolicy = HttpPolicyExtensions
      .HandleTransientHttpError()
      .Or<TimeoutRejectedException>()
      .RetryAsync(3);

    builder.Services.AddRepository<User, string>(builder =>
    {
        builder
            .WithApiClient()
            .WithHttpClient("localhost:7058")
                .ClientBuilder
            .AddPolicyHandler(retryPolicy);
    });
    
and use it in DI with
    
    IRepository<User, string> repository

### Query and Command
In DI you install the services

    services.AddCommand<User, string>(builder => {
        builder
            .WithApiClient()
            .WithHttpClient("localhost:7058");
    });
    services.AddQuery<User, string>(builder => {
        builder
            .WithApiClient()
            .WithHttpClient("localhost:7058");
    });

And you may inject the objects
## Please, use ICommand, IQuery and not ICommandPattern, IQueryPattern

    ICommand<User, string> command
    IQuery<User, string> command

### With a non default key
In DI you install the services with a bool key for example.

    services.AddRepository<User, bool>(builder => {
        builder
            .WithApiClient()
            .WithHttpClient("localhost:7058");
    });
    services.AddCommand<User, bool>(builder => {
        builder
            .WithApiClient()
            .WithHttpClient("localhost:7058");
    });
    services.AddQuery<User, bool>(builder => {
        builder
            .WithApiClient()
            .WithHttpClient("localhost:7058");
    });

And you may inject the objects
## Please, use ICommand, IQuery, IRepository and not ICommandPattern, IQueryPattern, IRepositoryPattern
    
    IRepository<User, string> repository
    ICommand<User, string> command
    IQuery<User, string> command

### Interceptors
You may add a custom interceptor for every request for every model

    public static IServiceCollection AddApiClientInterceptor<TInterceptor>(this IServiceCollection services,
        ServiceLifetime serviceLifetime = ServiceLifetime.Scoped)
        where TInterceptor : class, IRepositoryClientInterceptor

or a specific interceptor for each model
    
    public static IServiceCollection AddApiClientInterceptor<TInterceptor>(this IServiceCollection services,
        ServiceLifetime serviceLifetime = ServiceLifetime.Scoped)
        where TInterceptor : class, IRepositoryClientInterceptor

or for a string as default TKey

     public static RepositorySettings<T, TKey> AddApiClientSpecificInterceptor<T, TKey, TInterceptor>(
        this RepositorySettings<T, TKey> settings,
        ServiceLifetime serviceLifetime = ServiceLifetime.Scoped)
        where TInterceptor : class, IRepositoryClientInterceptor<T>
        where TKey : notnull   

Maybe you can use it to add a token as JWT o another pre-request things.

### Default interceptor for Authentication with JWT
You may use the default interceptor to deal with the identity manager in .Net DI.

    builder.Services.AddDefaultAuthorizationInterceptorForApiHttpClient();

with package 
#### RepositoryFramework.Api.Client.Authentication.BlazorServer 
or if you need to use in Wasm blazor use with 
#### Rystem.RepositoryFramework.Api.Client.Authentication.BlazorWasm

---

## repository/repositoryframework-api-client-authentication-blazorserver

> You can add a client for a specific url

### [What is Rystem?](https://github.com/KeyserDSoze/Rystem)

## Services extensions

### HttpClient to use your API (example)
You can add a client for a specific url

    builder.Services.AddRepository<User, string>(builder =>
    {
        builder
            .WithApiClient()
            .WithHttpClient("localhost:7058");
    });

### Default interceptor for Authentication with JWT
You may use the default interceptor to deal with the identity manager in .Net DI.

    builder.Services.AddDefaultAuthorizationInterceptorForApiHttpClient();

This line of code inject an interceptor that works with ITokenAcquisition, injected by the framework during OpenId integration (for example AAD integration).
Automatically it adds the token to each request.

You may use the default identity interceptor not on all repositories, you can specificy them with

    builder.Services.AddRepository(builder => {
        builder
            .WithApiClient()
            .WithHttpClient("localhost:7058")
            .AddDefaultAuthorizationInterceptorForApiHttpClient<T, TKey>();
    });

Remember to add

    builder.Services.AddAuthentication(OpenIdConnectDefaults.AuthenticationScheme)
    .AddMicrosoftIdentityWebApp(builder.Configuration.GetSection("AzureAdB2C or AzureAd"))
     .EnableTokenAcquisitionToCallDownstreamApi(new string[] { "your_scope/access_as_user" })
     .AddInMemoryTokenCaches();

    builder.Services.AddServerSideBlazor()
    .AddMicrosoftIdentityConsentHandler();

    builder.Services.AddControllersWithViews()
    .AddMicrosoftIdentityUI();

---

## repository/repositoryframework-api-client-authentication-blazorwasm

> You can add a client for a specific url

### [What is Rystem?](https://github.com/KeyserDSoze/Rystem)

## Services extensions

### HttpClient to use your API (example)
You can add a client for a specific url

    builder.Services.AddRepository<User, string>(builder =>
    {
        builder
            .WithApiClient()
            .WithHttpClient("localhost:7058");
    });

### Default interceptor for Authentication with JWT
You may use the default interceptor to deal with the identity manager in .Net DI.

    builder.Services.AddDefaultAuthorizationInterceptorForApiHttpClient();

This line of code inject an interceptor that works with ITokenAcquisition, injected by the framework during OpenId integration (for example AAD integration).
Automatically it adds the token to each request.

You may use the default identity interceptor not on all repositories, you can specificy them with

    builder.Services.AddRepository(builder => {
        builder
            .WithApiClient()
            .WithHttpClient("localhost:7058")
            .AddDefaultAuthorizationInterceptorForApiHttpClient<T, TKey>();
    });

---

## repository/repositoryframework-api-server

> In your web application you have only to add one row after service build.

### [What is Rystem?](https://github.com/KeyserDSoze/Rystem)

## Api auto-generated
In your web application you have only to add one row after service build.

     services.AddApiFromRepositoryFramework()
        .WithDescriptiveName("Repository Api")
        .WithPath(Path)
        .WithSwagger()
        .WithVersion(Version)
        .WithDocumentation()
        .WithDefaultCors("http://example.com");

    var app = builder.Build();
    app.UseApiFromRepositoryFramework()
       .WithNoAuthorization();

    public static ApiAuthorizationBuilder UseApiFromRepositoryFramework<TEndpointRouteBuilder>(
        this TEndpointRouteBuilder app,
        string startingPath = "api")
        where TEndpointRouteBuilder : IEndpointRouteBuilder
    
You may add api for each service by

    public static ApiAuthorizationBuilder UseApiForRepository<T>(this IEndpointRouteBuilder app,
        string startingPath = "api")

### Startup example
In the example below you may find the setup of three populated repositories, two of them are of the same kind (SuperUser).
The SuperiorUser will be added to the app but will be not exposed as Api cause the SetNotExposable() method.
Futhermore, we are adding a configuration for AAD to implement authentication on api.

    var builder = WebApplication.CreateBuilder(args);
    builder.Services
    .AddRepository<SuperUser, string>(settins =>
    {
        settins.WithInMemory(builder =>
        {
            builder
                .PopulateWithRandomData(120, 5)
                .WithPattern(x => x.Value!.Email, @"[a-z]{5,10}@gmail\.com");
        });
        settins.WithInMemory(builder =>
        {
            builder
                .PopulateWithRandomData(2, 5)
                .WithPattern(x => x.Value!.Email, @"[a-z]{5,10}@gmail\.com");
        }, "inmemory");
    });

    builder.Services.AddRepository<SuperiorUser, string>(settings =>
    {
        settings.WithInMemory(builder =>
        {
            builder
                .PopulateWithRandomData(120, 5)
                .WithPattern(x => x.Value!.Email, @"[a-z]{5,10}@gmail\.com")
                .WithPattern(x => x.Value!.Port, @"[1-9]{3,4}");
        });
        settings.SetNotExposable();
    });
        
    builder.Services.AddApiFromRepositoryFramework()
        .WithDescriptiveName("Repository Api")
        .WithPath(Path)
        .WithSwagger()
        .WithVersion(Version)
        .WithDocumentation()
        .WithDefaultCors("http://example.com");  
    
    var app = builder.Build();
    await app.Services.WarmUpAsync();
    
    app.UseHttpsRedirection();
    app.UseApiFromRepositoryFramework()
        .WithDefaultAuthorization();
    app.Run();

### No Authorization flow - default

    var builder = WebApplication.CreateBuilder(args);
    builder.Services
    .AddRepository<SuperUser, string>(settins =>
    {
        settins.WithInMemory(builder =>
        {
            builder
                .PopulateWithRandomData(120, 5)
                .WithPattern(x => x.Value!.Email, @"[a-z]{5,10}@gmail\.com");
        });
        settins.WithInMemory(builder =>
        {
            builder
                .PopulateWithRandomData(2, 5)
                .WithPattern(x => x.Value!.Email, @"[a-z]{5,10}@gmail\.com");
        }, "inmemory");
    });

    builder.Services.AddRepository<SuperiorUser, string>(settings =>
    {
        settings.WithInMemory(builder =>
        {
            builder
                .PopulateWithRandomData(120, 5)
                .WithPattern(x => x.Value!.Email, @"[a-z]{5,10}@gmail\.com")
                .WithPattern(x => x.Value!.Port, @"[1-9]{3,4}");
        });
        settings.SetNotExposable();
    });
    builder.Services.AddApiFromRepositoryFramework()
        .WithDescriptiveName("Repository Api")
        .WithPath(Path)
        .WithSwagger()
        .WithVersion(Version)
        .WithDocumentation()
        .WithDefaultCors("http://example.com");    
    
    var app = builder.Build();
    await app.Services.WarmUpAsync();
    if (app.Environment.IsDevelopment())
    {
        app.UseSwagger();
        app.UseSwaggerUI();
    }
    app.UseHttpsRedirection();
    app.UseApiFromRepositoryFramework()
        .WithNoAuthorization();
    app.Run();

### Authorization flow - custom policies
You may configure the scoper for each method of your repository and for each repository, as you wish.

    var builder = WebApplication.CreateBuilder(args);
    builder.Services
    .AddRepository<SuperUser, string>(settins =>
    {
        settins.WithInMemory(builder =>
        {
            builder
                .PopulateWithRandomData(120, 5)
                .WithPattern(x => x.Value!.Email, @"[a-z]{5,10}@gmail\.com");
        });
        settins.WithInMemory(builder =>
        {
            builder
                .PopulateWithRandomData(2, 5)
                .WithPattern(x => x.Value!.Email, @"[a-z]{5,10}@gmail\.com");
        }, "inmemory");
    });

    builder.Services.AddRepository<SuperiorUser, string>(settings =>
    {
        settings.WithInMemory(builder =>
        {
            builder
                .PopulateWithRandomData(120, 5)
                .WithPattern(x => x.Value!.Email, @"[a-z]{5,10}@gmail\.com")
                .WithPattern(x => x.Value!.Port, @"[1-9]{3,4}");
        });
        settings.SetNotExposable();
    });
    
    builder.Services.AddAuthorization(
        options =>
        {
            options.AddPolicy("NormalUser", x =>
            {
                x.RequireClaim(ClaimTypes.Name);
            });
            options.AddPolicy("SuperAdmin", x =>
            {
                x.RequireRole("SuperAdmin");
            });
        });

    builder.Services.AddApiFromRepositoryFramework()
        .WithDescriptiveName("Repository Api")
        .WithPath(Path)
        .WithSwagger()
        .WithVersion(Version)
        .WithDocumentation()
        .WithDefaultCors("http://example.com");     
    
    var app = builder.Build();
    await app.Services.WarmUpAsync();
    if (app.Environment.IsDevelopment())
    {
        app.UseSwagger();
        app.UseSwaggerUI();
    }
    app.UseHttpsRedirection();

    app.UseEndpoints(endpoints =>
    {
        endpoints.MapHealthChecks("/healthz");
        endpoints.UseApiFromRepository<SuperUser>()
            .SetPolicyForCommand()
            .With("SuperAdmin")
            .Build();
        endpoints.UseApiFromRepositoryFramework()
            .SetPolicyForAll()
            .With("NormalUser")
            .And()
            .SetPolicy(RepositoryMethods.Insert)
            .With("SuperAdmin")
            .And()
            .SetPolicy(RepositoryMethods.Update)
            .With("SuperAdmin")
            .Build();
        endpoints
            .MapControllers();
    });
    app.Run();

In this example, I'm configuring a policy named "NormalUser" for all methods and all repositories, and a policy named "SuperAdmin" for the methods Insert and Update for all repositories and for the command (Insert, Updated and Delete) of SuperUser repository.
You can customize it repository for repository, using UseApiFromRepository<T>() method.

### Sample of filter usage when you use the api directly
All the requests are basic requests, the strangest request is only the query and you must use the Linq query.
You may find some examples down below:

    � => (((�.X == "dasda") AndAlso �.X.Contains("dasda")) AndAlso ((�.E == Guid.Parse("bf46510b-b7e6-4ba2-88da-cef208aa81f2")) Or (�.Id == 32)))
    � => ((((�.X == "dasda") AndAlso �.Sol) AndAlso �.X.Contains("dasda")) AndAlso ((�.E == Guid.Parse("bf46510b-b7e6-4ba2-88da-cef208aa81f2")) Or (�.Id == 32)))
    � => (((((�.X == "dasda") AndAlso �.Sol) AndAlso �.X.Contains("dasda")) AndAlso ((�.E == Guid.Parse("bf46510b-b7e6-4ba2-88da-cef208aa81f2")) Or (�.Id == 32))) AndAlso ((�.Type == 1) OrElse (�.Type == 2)))
    � => (�.Type == 2)
    � => (((((�.X == "dasda") AndAlso �.Sol) AndAlso (�.X.Contains("dasda") OrElse �.Sol.Equals(True))) AndAlso ((�.E == Guid.Parse("bf46510b-b7e6-4ba2-88da-cef208aa81f2")) Or (�.Id == 32))) AndAlso ((�.Type == 1) OrElse (�.Type == 2)))
    � => ((((((�.X == "dasda") AndAlso �.Samules.Any(x => (x == "ccccde"))) AndAlso �.Sol) AndAlso (�.X.Contains("dasda") OrElse �.Sol.Equals(True))) AndAlso ((�.E == Guid.Parse("bf46510b-b7e6-4ba2-88da-cef208aa81f2")) Or (�.Id == 32))) AndAlso ((�.Type == 1) OrElse (�.Type == 2)))
    � => (�.ExpirationTime > Convert.ToDateTime("7/6/2022 9:48:56 AM"))
    � => (�.TimeSpan > new TimeSpan(1000 as long))
    � => Not(�.Inside.Inside.A.Equals("dasdad"))
    � => Not(String.IsNullOrWhiteSpace(�.Inside.Inside.A))

---

## repository/repositoryframework-cache

> You can add a repository (with default blob integration for instance) and after attack an in memory cache for all methods.

### [What is Rystem?](https://github.com/KeyserDSoze/Rystem)

## Cache

### Examples
You can add a repository (with default blob integration for instance) and after attack an in memory cache for all methods.
The RefreshTime is a property that adds an Expiration date to the cached value, in the example below you can see that after 20 seconds the in memory cache requests again to the repository pattern a new value for each key.
The Methods is a flag that allows to setup what operations have to be cached.

Query -> query will be cached with this key

    var keyAsString = $"{nameof(RepositoryMethods.Query)}_{typeof(T).Name}_{FactoryName}_{filter.ToKey()}";

Operation -> operation will be cached with this key

    var keyAsString = $"{nameof(RepositoryMethods.Operation)}_{operation.Name}_{typeof(T).Name}_{FactoryName}_{filter.ToKey()}";

Get -> query will be cached with this key
    
    var keyAsString = $"{nameof(RepositoryMethods.Get)}_{typeof(T).Name}_{FactoryName}_{key.AsString()}";

Exist -> query will be cached with this key
    
    var keyAsString = $"{nameof(RepositoryMethod.Exist)}_{typeof(T).Name}_{FactoryName}_{key.AsString()}";

Now you can understand the special behavior for commands. If you set Insert and/or Update and/or Delete, during any command if you allowed it for each command automatically the framework will update the cache value, with updated or inserted value or removing the deleted value.
The code below allows everything

    x.Methods = RepositoryMethod.All

In the example below you're setting up the following behavior: setting up a cache only for Get operation, and update the Get cache when exists a new Insert or an Update, or a removal when Delete operation were perfomed.
    
    x.Methods = RepositoryMethod.Get | RepositoryMethod.Insert | RepositoryMethod.Update | RepositoryMethod.Delete

### Setup in DI

	services
        .AddRepository<Plant, int>(settings =>
        {
            settings
                .WithInMemory();
            settings
                .WithInMemoryCache(x =>
                {
                    x.ExpiringTime = TimeSpan.FromSeconds(1);
                    x.Methods = RepositoryMethods.All;
                });
        });

### Usage
You always will find the same interface. For instance

    IRepository<Plant, int> repository

or if you added a query pattern or command pattern

    IQuery<Plant, int> query 
    ICommand<Plant, int> command

### Distributed Cache
Based on this [link](https://docs.microsoft.com/en-us/aspnet/core/performance/caching/distributed) you may use the standard interface IDistributedCache instead of create a custom IDistributedCache<T, TKey, TState>.
For instance you may choose between three libraries: Distributed SQL Server cache, Distributed Redis cache, Distributed NCache cache.
You need to add the cache

    builder.Services.AddStackExchangeRedisCache(options =>
     {
         options.Configuration = builder.Configuration.GetConnectionString("MyRedisConStr");
         options.InstanceName = "SampleInstance";
     });

then you add the IDistributedCache implementation to your repository patterns or CQRS.

    .AddRepository<Country, CountryKey>(builder =>
    {
        builder
            .WithInMemory(inMemoryBuilder =>
            {
                inMemoryBuilder
                    .PopulateWithRandomData(NumberOfEntries, NumberOfEntries);
            });
        builder
            .WithDistributedCache(distributedCacheBuilder =>
            {
                distributedCacheBuilder.ExpiringTime = TimeSpan.FromSeconds(10);
            });
    });

or a mix of them

    .AddRepository<Country, CountryKey>(builder =>
    {
        builder
            .WithInMemory(inMemoryBuilder =>
            {
                inMemoryBuilder
                    .PopulateWithRandomData(NumberOfEntries, NumberOfEntries);
            });
        builder
            .WithInMemoryCache(inMemoryCacheBuilder =>
            {
                inMemoryCacheBuilder.ExpiringTime = TimeSpan.FromSeconds(10);
            })
            .WithDistributedCache(distributedCacheBuilder =>
            {
                distributedCacheBuilder.ExpiringTime = TimeSpan.FromSeconds(10);
            });
    });

and as always you will use the standard interface that is automatically integrated in the repository flow.
    
    IRepository<User, string> repository;

The same is valid for ICommand and IQuery.

---

## repository/repositoryframework-cache-azure-storage-blob

> .AddRepository<User, string>(repositoryBuilder =>

### [What is Rystem?](https://github.com/KeyserDSoze/Rystem)

## Cache example

    .AddRepository<User, string>(repositoryBuilder =>
    {
        repositoryBuilder
        .WithBlobStorage(storageBuilder =>
        {
            storageBuilder.Settings.ConnectionString = builder.Configuration["ConnectionString:Storage"];
        });
        repositoryBuilder
        .WithInMemoryCache(x =>
        {
            x.ExpiringTime = TimeSpan.FromSeconds(60);
            x.Methods = RepositoryMethods.Get | RepositoryMethods.Insert | RepositoryMethods.Update | RepositoryMethods.Delete;
        })
        .WithBlobStorageCache(
            x =>
            {
                x.Settings.ConnectionString = builder.Configuration["ConnectionString:Storage"];
            }
            , x =>
            {
                x.ExpiringTime = TimeSpan.FromSeconds(120);
                x.Methods = RepositoryMethods.All;
            });
    });

### Usage
You always will find the same interface. For instance

    IRepository<User, string> repository

or if you added a query pattern or command pattern

    IQuery<User, string> query 
    ICommand<User, string> command

---

## repository/repositoryframework-infrastructure-inmemory

> With this library you can add in memory integration with the chance to create random data with random values, random based on regular expressions and delegated 

### [What is Rystem?](https://github.com/KeyserDSoze/Rystem)

## In memory integration by default
With this library you can add in memory integration with the chance to create random data with random values, random based on regular expressions and delegated methods
        
### How to populate with random data?

#### Simple random (example)
Populate your in memory storage with 120 users

    var builder = WebApplication.CreateBuilder(args);
    builder.Services.AddRepository<IperUser, string>(repositoryBuilder =>
    {
        repositoryBuilder
            .WithInMemory(inMemoryBuilder =>
            {
                inMemoryBuilder
                    .PopulateWithRandomData(120, 5)
                    .WithPattern(x => x.Value.Email, @"[a-z]{5,10}@gmail\.com");
            });
        repositoryBuilder
            .AddBusiness()
                .AddBusinessBeforeInsert<IperRepositoryBeforeInsertBusiness>();
        repositoryBuilder
            .Translate<IperUser>();
    });

and in app after build during startup of your application
    
    var app = builder.Build();
    await app.Services.WarmUpAsync();
    
#### Simple random with regex (example)
Populate your in memory storage with 100 users and property Email with a random regex @"[a-z]{4,10}@gmail\.com"

    .AddRepository<User, string>(builder => {
        builder
            .WithInMemory(inMemoryBuilder => {
                inMemoryBuilder
                    .PopulateWithRandomData(100)
                    .WithPattern(x => x.Email, @"[a-z]{4,10}@gmail\.com")
            });
    });

and in app after build during startup of your application
    
    var app = builder.Build();
    await app.Services.WarmUpAsync();

#### Where can I use the regex pattern?
You can use regex pattern on all primitives type and most used structs.
##### Complete list:
##### int, uint, byte, sbyte, short, ushort, long, ulong, nint, nuint, float, double, decimal, bool, char, Guid, DateTime, TimeSpan, Range, string, int?, uint?, byte?, sbyte?, short?, ushort?, long?, ulong?, nint?, nuint?, float?, double?, decimal?, bool?, char?, Guid?, DateTime?, TimeSpan?, Range?, string?

You can use the pattern in Class, IEnumerable, IDictionary, or Array, and in everything that extends IEnumerable or IDictionary

**Important!! You can override regex service in your DI**
    
    public static IServiceCollection AddRegexService<T>(
            this IServiceCollection services)
            where T : class, IRegexService

#### IEnumerable or Array one-dimension (example)
You have your model x (User) that has a property Groups as IEnumerable or something that extends IEnumerable, Groups is a class with a property Id as string.
In the code below you are creating a list of class Groups with 8 elements in each 100 User instances, in each element of Groups you randomize based on this regex "[a-z]{4,5}".
You may take care of use First() linq method to set correctly the Id property.
    
    .AddRepository<User, string>(builder => {
        builder
            .WithInMemory(inMemoryBuilder => {
                inMemoryBuilder
                    .PopulateWithRandomData(100, 8)
                    .WithPattern(x => x.Groups!.First().Id, "[a-z]{4,5}");
            });
    });
    
and in app after build during startup of your application
    
    var app = builder.Build();
    await app.Services.WarmUpAsync();

#### IDictionary (example)
Similar to IEnumerable population you may populate your Claims property (a dictionary) with random key but with values based on regular expression "[a-z]{4,5}". As well as IEnumerable implementation you will have 6 elements (because I choose to create 6 elements in Populate method)

    .AddRepository<User, string>(builder => {
        builder
            .WithInMemory(inMemoryBuilder => {
                inMemoryBuilder
                    .PopulateWithRandomData(100, 6)
                    .WithPattern(x => x.Claims!.First().Value, "[a-z]{4,5}");
            });
    });

and in app after build during startup of your application
    
    var app = builder.Build();
    await app.Services.WarmUpAsync();
    
or if you have in Value an object
    
    AddRepository<User, string>(builder => {
        builder
            .WithInMemory(inMemoryBuilder => {
                inMemoryBuilder
                    .PopulateWithRandomData(100, 6)
                    .WithPattern(x => x.Claims!.First().Value.SomeProperty, "[a-z]{4,5}");
            });
    });
    
and in app after build during startup of your application
    
    var app = builder.Build();
    await app.Services.WarmUpAsync();

### Populate with delegation
Similar to regex pattern, you can use a delegation to populate something.

#### Dictionary (example)
Here you can see that all 6 elements in each 100 users are populated in Value with string "A"

    .AddRepository<User, string>(builder => {
        builder
            .WithInMemory(inMemoryBuilder => {
                inMemoryBuilder
                    .PopulateWithRandomData(100, 6)
                    .WithPattern(x => x.Claims!.First().Value, () => "A");
            });
    });
    
and in app after build during startup of your application
    
    var app = builder.Build();
    await app.Services.WarmUpAsync();

### Populate with Implementation
If you have an interface or abstraction in your model, you can specify an implementation type for population.
You have two different methods, with typeof

    .AddRepository<PopulationTest, string>(builder => {
        builder
            .WithInMemory(inMemoryBuilder => {
                inMemoryBuilder
                    .PopulateWithRandomData(100, 2)
                    .WithImplementation(x => x.I, typeof(MyInnerInterfaceImplementation));
            });
    });

or generics

    .AddRepository<PopulationTest, string>(builder => {
        builder
            .WithInMemory(inMemoryBuilder => {
                inMemoryBuilder
                    .PopulateWithRandomData(100)
                    .WithImplementation<IInnerInterface, MyInnerInterfaceImplementation>(x => x.I!);
            });
    });

## In Memory, simulate real implementation
If you want to test with possible exceptions (for your reliability tests) and waiting time (for your load tests) you may do it with this library and in memory behavior settings.

### Add random exceptions
You can set different custom exceptions and different percentage for each operation: Delete, Get, Insert, Update, Query.
In the code below I'm adding three exceptions with a percentage of throwing them, they are the same for each operation.
I have a 0.45% for normal Exception, 0.1% for "Big Exception" and 0.548% for "Great Exception"

    .AddRepository<Car, string>(settings =>
    {
        settings.WithInMemory(builder =>
        {
            var customExceptions = new List<ExceptionOdds>
            {
                new ExceptionOdds()
                {
                    Exception = new Exception("Normal Exception"),
                    Percentage = 10.352
                },
                new ExceptionOdds()
                {
                    Exception = new Exception("Big Exception"),
                    Percentage = 49.1
                },
                new ExceptionOdds()
                {
                    Exception = new Exception("Great Exception"),
                    Percentage = 40.548
                }
            };
            builder.Settings.AddForRepositoryPattern(new MethodBehaviorSetting
            {
                ExceptionOdds = customExceptions
            });
        });
    });
    
### Add random waiting time
You can set different range in milliseconds for each operation to simulate the await of an external integration.
In the code below I'm adding a same custom range for all Repository interfaces between 1000ms and 2000ms.

    .AddRepository<User, string>(builder =>
    {
        builder.WithInMemory(inMemoryBuilder =>
        {
            var customRange = new Range(1000, 2000);
            inMemoryBuilder.Settings.AddForRepositoryPattern(new MethodBehaviorSetting
            {
                MillisecondsOfWait = customRange
            });
        });
    });

---

## repository/repositoryframework-infrastructure-azure-cosmos-sql

> Example from unit test with a business integration too.

### [What is Rystem?](https://github.com/KeyserDSoze/Rystem)

## Integration with Azure Cosmos Sql and Repository Framework
Example from unit test with a business integration too.

     await services
        .AddRepositoryAsync<AppUser, AppUserKey>(async builder =>
            {
                await builder.WithCosmosSqlAsync(x =>
                {
                    x.Settings.ConnectionString = configuration["ConnectionString:CosmosSql"];
                    x.Settings.DatabaseName = "unittestdatabase";
                    x.WithId(x => new AppUserKey(x.Id));
                }).NoContext();
            builder
                .AddBusiness()
                .AddBusinessBeforeInsert<AppUserBeforeInsertBusiness>()
                .AddBusinessBeforeInsert<AppUserBeforeInsertBusiness2>();
        }).NoContext();

You found the IRepository<AppUser, AppUserKey> in DI to play with it.

### Automated api with Rystem.RepositoryFramework.Api.Server package
With automated api, you may have the api implemented with your cosmos sql integration.
You need only to add the AddApiFromRepositoryFramework and UseApiForRepositoryFramework

     builder.Services.AddApiFromRepositoryFramework()
        .WithDescriptiveName("Repository Api")
        .WithPath(Path)
        .WithSwagger()
        .WithVersion(Version)
        .WithDocumentation()
        .WithDefaultCors("http://example.com");  

    var app = builder.Build();

    app.UseApiFromRepositoryFramework()
        .WithNoAuthorization();

---

## repository/repositoryframework-infrastructure-azure-storage-blob

> Example from unit test with a business integration too.

### [What is Rystem?](https://github.com/KeyserDSoze/Rystem)

## Integration with Azure BlobStorage and Repository Framework
Example from unit test with a business integration too.

    services
        .AddRepository<Car, Guid>(builder =>
        {
            builder.WithBlobStorage(builder =>
            {
                builder.Settings.ConnectionString = configuration["ConnectionString:Storage"];
                builder.Settings.Prefix = "MyFolder/";
            });
        });
    services
        .AddBusinessForRepository<Car, Guid>()
            .AddBusinessBeforeInsert<CarBeforeInsertBusiness>()
            .AddBusinessBeforeInsert<CarBeforeInsertBusiness2>();

You found the IRepository<Car, Guid> in DI to play with it.

### Automated api with Rystem.RepositoryFramework.Api.Server package
With automated api, you may have the api implemented with your blobstorage integration.
You need only to add the AddApiFromRepositoryFramework and UseApiForRepositoryFramework

     builder.Services.AddApiFromRepositoryFramework()
        .WithDescriptiveName("Repository Api")
        .WithPath(Path)
        .WithSwagger()
        .WithVersion(Version)
        .WithDocumentation()
        .WithDefaultCors("http://example.com");  

    var app = builder.Build();

    app.UseApiFromRepositoryFramework()
        .WithNoAuthorization();

---

## repository/repositoryframework-infrastructure-azure-storage-table

> Example from unit test with a business integration too.

### [What is Rystem?](https://github.com/KeyserDSoze/Rystem)

## Integration with Azure TableStorage and Repository Framework
Example from unit test with a business integration too.
Here you may find the chance to use ToResult() in services to avoid the async method.

    services
        .AddRepositoryAsync<AppUser, AppUserKey>(async builder =>
        {
            await builder
                .WithTableStorageAsync(tableStorageBuilder =>
                {
                    tableStorageBuilder
                        .Settings.ConnectionString = configuration["ConnectionString:Storage"];
                    tableStorageBuilder
                        .WithTableStorageKeyReader<TableStorageKeyReader>()
                        .WithPartitionKey(x => x.Id, x => x.Id)
                        .WithRowKey(x => x.Username)
                        .WithTimestamp(x => x.CreationTime);
                });
        }).ToResult();

You found the IRepository<SuperCar, Guid> in DI to play with it.

### Automated api with Rystem.RepositoryFramework.Api.Server package
With automated api, you may have the api implemented with your tablestorage integration.
You need only to add the AddApiFromRepositoryFramework and UseApiForRepositoryFramework

     builder.Services.AddApiFromRepositoryFramework()
        .WithDescriptiveName("Repository Api")
        .WithPath(Path)
        .WithSwagger()
        .WithVersion(Version)
        .WithDocumentation()
        .WithDefaultCors("http://example.com");  

    var app = builder.Build();

    app.UseApiFromRepositoryFramework()
        .WithNoAuthorization();

---

## repository/repositoryframework-infrastructure-dynamics-dataverse

> Example from unit test with a business integration too.

### [What is Rystem?](https://github.com/KeyserDSoze/Rystem)

## Integration with Dataverse (Dynamics) and Repository Framework
Example from unit test with a business integration too.

     services.
        AddRepository<CalamityUniverseUser, string>(builder =>
        {
            builder.WithDataverse(dataverserBuilder =>
            {
                dataverserBuilder.Settings.Prefix = "repo_";
                dataverserBuilder.Settings.SolutionName = "TestAlessandro";
                if (configuration != null)
                    dataverserBuilder.Settings.SetConnection(configuration["ConnectionString:Dataverse:Environment"],
                        new(configuration["ConnectionString:Dataverse:ClientId"],
                        configuration["ConnectionString:Dataverse:ClientSecret"]));
            });
            builder
                .AddBusiness()
                .AddBusinessBeforeInsert<CalamityUniverseUserBeforeInsertBusiness>()
                .AddBusinessBeforeInsert<CalamityUniverseUserBeforeInsertBusiness2>();
        });

You found the IRepository<CalamityUniverseUser, string> in DI to play with it.

## Configure database after build
You have to run a method after the service collection build during startup. This method creates your tables.

    var app = builder.Build();
    await app.Services.WarmUpAsync();

### Automated api with Rystem.RepositoryFramework.Api.Server package
With automated api, you may have the api implemented with your dataverse integration.
You need only to add the AddApiFromRepositoryFramework and UseApiForRepositoryFramework

     builder.Services.AddApiFromRepositoryFramework()
        .WithDescriptiveName("Repository Api")
        .WithPath(Path)
        .WithSwagger()
        .WithVersion(Version)
        .WithDocumentation()
        .WithDefaultCors("http://example.com");  

    var app = builder.Build();

    app.UseApiFromRepositoryFramework()
        .WithNoAuthorization();

---

## repository/repositoryframework-infrastructure-entityframework

> This package enables seamless integration between Entity Framework Core and the Repository Framework, allowing you to leverage the Repository pattern with autom

### [What is Rystem?](https://github.com/KeyserDSoze/Rystem)

## Integration with Entity Framework and Repository Framework

This package enables seamless integration between Entity Framework Core and the Repository Framework, allowing you to leverage the Repository pattern with automatic mapping between your **Domain Model** and **Database Model**.

### Core Concepts

#### 1️⃣ **Domain Model vs Database Model**

In Domain-Driven Design (DDD), you often have:
- **Domain Model** (`MappingUser`): Your business model with domain logic and clean interfaces
- **Database Model** (`User`): The actual Entity Framework entity that maps to your database schema

The Entity Framework integration allows you to work with your domain model while the framework automatically handles mapping to/from the database model.

#### 2️⃣ **Configuration Components**

##### **DbSet**: Database Table Reference
```csharp
t.DbSet = x => x.Users;
```
This specifies **which DbSet from your Entity Framework context** holds the data for this repository. It tells the framework: "Find the data in the `Users` table through this DbSet property."

##### **References**: Related Data Loading
```csharp
t.References = x => x.Include(x => x.IdGruppos);
```
These are **Entity Framework Include() statements** that specify which related entities should be eagerly loaded with your main entity. In this example, whenever you fetch a `User`, its related `IdGruppos` collection will automatically be loaded. You can chain multiple includes here.

**Why this matters**: Without proper references, your related data won't be loaded, causing N+1 query problems.

##### **Translate**: Domain-to-Database Model Mapping
```csharp
builder.Translate<User>()
    .With(x => x.Username, x => x.Nome)
    .With(x => x.Username, x => x.Cognome)
    .With(x => x.Email, x => x.IndirizzoElettronico)
    .With(x => x.Groups, x => x.IdGruppos)
    .With(x => x.Id, x => x.Identificativo)
    .WithKey(x => x, x => x.Identificativo);
```
This configures **how properties are mapped** between your domain model and database model:
- `.With(domainProperty, databaseProperty)`: Maps individual properties
- `.WithKey(domainKey, databaseKey)`: Specifies the primary key mapping
- Each domain property is mapped to its corresponding database column/property

**When to use Translation**:
- ✅ Different property names (e.g., `Username` → `Nome`)
- ✅ Different data structures (e.g., entity relationships)
- ✅ Property name conventions differ between domain and database

### Two Approaches: Choose Your Path

#### **Approach A: Separate Models (with Translation)** - Recommended for DDD
Use **different classes** for domain and database, with translation configured:

```csharp
// Domain Model - Clean, business-focused
public class MappingUser
{
    public int Id { get; set; }
    public string Username { get; set; }
    public string Email { get; set; }
    public List<Group> Groups { get; set; }
}

// Database Model - Maps to actual DB schema
public class User
{
    public int Identificativo { get; set; }      // Different naming
    public string Nome { get; set; }
    public string Cognome { get; set; }
    public string IndirizzoElettronico { get; set; }
    public List<Gruppo> IdGruppos { get; set; }  // Different structure
}

// Configuration
services.AddRepository<MappingUser, int>(builder =>
{
    builder.WithEntityFramework<MappingUser, int, User, SampleContext>(
        t =>
        {
            t.DbSet = x => x.Users;
            t.References = x => x.Include(x => x.IdGruppos);
        });
    
    // Map domain model properties to database model properties
    builder.Translate<User>()
        .With(x => x.Username, x => x.Nome)
        .With(x => x.Email, x => x.IndirizzoElettronico)
        .With(x => x.Groups, x => x.IdGruppos)
        .With(x => x.Id, x => x.Identificativo)
        .WithKey(x => x, x => x.Identificativo);
});
```

**Benefits**:
- Domain model stays clean and focused on business logic
- Database schema can evolve independently
- Better encapsulation of domain concepts

#### **Approach B: Same Model (No Translation)** - Simpler Setup
Use the **same class** for both domain and database:

```csharp
// Single Model - Used for both domain and database
public class User
{
    public int Id { get; set; }
    public string Username { get; set; }
    public string Email { get; set; }
    public List<Group> Groups { get; set; }
}

// Configuration - No translation needed!
services.AddRepository<User, int>(builder =>
{
    builder.WithEntityFramework<User, int, User, SampleContext>(
        t =>
        {
            t.DbSet = x => x.Users;
            t.References = x => x.Include(x => x.Groups);
        });
    // No Translate() call needed when domain model = database model
});
```

**Benefits**:
- Simpler configuration (no mapping overhead)
- Faster setup for small projects
- Less boilerplate code

**Trade-offs**:
- Domain model is tightly coupled to database schema
- Harder to refactor database without affecting domain logic

### Complete Example with Business Logic

```csharp
services.AddDbContext<SampleContext>(options =>
{
    options.UseSqlServer(configuration["ConnectionString:Database"]);
}, ServiceLifetime.Scoped);

services.AddRepository<MappingUser, int>(builder =>
{
    // Step 1: Configure Entity Framework
    builder.WithEntityFramework<MappingUser, int, User, SampleContext>(
        t =>
        {
            t.DbSet = x => x.Users;
            t.References = x => x.Include(x => x.IdGruppos);
        });
    
    // Step 2: Configure Translation (if using separate models)
    builder.Translate<User>()
        .With(x => x.Username, x => x.Nome)
        .With(x => x.Username, x => x.Cognome)
        .With(x => x.Email, x => x.IndirizzoElettronico)
        .With(x => x.Groups, x => x.IdGruppos)
        .With(x => x.Id, x => x.Identificativo)
        .WithKey(x => x, x => x.Identificativo);
    
    // Step 3: Add Business Logic Interceptors
    // See: RepositoryFramework.Abstractions > Business > IRepositoryBusiness
    builder.AddBusiness()
        .AddBusinessBeforeInsert<MappingUserBeforeInsertBusiness>()
        .AddBusinessBeforeInsert<MappingUserBeforeInsertBusiness2>();
});
```

**Now available in Dependency Injection**:
```csharp
public class UserService(IRepository<MappingUser, int> repository)
{
    public async Task CreateUserAsync(MappingUser user)
    {
        // Business interceptors run here automatically
        await repository.InsertAsync(user);
    }
}
```

### Business Logic Interceptors

Business interceptors run at specific points in the repository lifecycle:

- **BeforeInsert**: Runs before inserting a new entity
- **AfterInsert**: Runs after inserting a new entity
- **BeforeUpdate**: Runs before updating an entity
- **AfterUpdate**: Runs after updating an entity
- **BeforeDelete**: Runs before deleting an entity
- **AfterDelete**: Runs after deleting an entity
- **BeforeQuery**: Runs before querying entities

See the `IRepositoryBusiness` interface in `RepositoryFramework.Abstractions` for detailed documentation on implementing custom business logic.

---

**Key Takeaway**: 
- Choose **Approach A (Separate Models)** for enterprise applications following DDD principles
- Choose **Approach B (Same Model)** for smaller projects prioritizing simplicity

## Automated REST API with Rystem.RepositoryFramework.Api.Server

Once your repository is configured, you can automatically expose it as a fully-featured REST API without writing endpoint code:

```csharp
var builder = WebApplicationBuilder.CreateBuilder(args);

// ... your repository configuration ...

builder.Services.AddApiFromRepositoryFramework()
    .WithDescriptiveName("Repository API")
    .WithPath("/api")
    .WithSwagger()
    .WithVersion("v1")
    .WithDocumentation()
    .WithDefaultCors("http://example.com");

var app = builder.Build();

app.UseApiFromRepositoryFramework()
    .WithNoAuthorization();

app.Run();
```

This automatically generates REST endpoints for all your repositories:
- `GET /api/mappinguser` - List all users
- `GET /api/mappinguser/{id}` - Get user by ID
- `POST /api/mappinguser` - Create user
- `PUT /api/mappinguser/{id}` - Update user
- `DELETE /api/mappinguser/{id}` - Delete user

Your business interceptors run automatically for each operation!

See [Repository API Server Documentation](https://rystem.net/mcp/tools/repository-api-server.md) for advanced configuration.

---

## repository/repositoryframework-infrastructure-mssql

> Example from unit test with a business integration too.

### [What is Rystem?](https://github.com/KeyserDSoze/Rystem)

## Integration with MsSql and Repository Framework
Example from unit test with a business integration too.

     services.
        AddRepository<Cat, Guid>(settings =>
        {
            settings
            .WithMsSql(builder =>
            {
                builder.Schema = "repo";
                builder.ConnectionString = configuration["ConnectionString:Database"];
                builder.WithPrimaryKey(x => x.Id, x =>
                    {
                        x.ColumnName = "Key";
                    })
                .WithColumn(x => x.Paws, x =>
                {
                    x.ColumnName = "Zampe";
                    x.IsNullable = true;
                });
            });
        });

You found the IRepository<Cat, Guid> in DI to play with it.

## Configure database after build
You have to run a method after the service collection build during startup. This method creates your tables.

    var app = builder.Build();
    await app.Services.WarmUpAsync();

### Automated api with Rystem.RepositoryFramework.Api.Server package
With automated api, you may have the api implemented with your dataverse integration.
You need only to add the AddApiFromRepositoryFramework and UseApiForRepositoryFramework

    builder.Services.AddApiFromRepositoryFramework()
        .WithDescriptiveName("Repository Api")
        .WithPath(Path)
        .WithSwagger()
        .WithVersion(Version)
        .WithDocumentation()
        .WithDefaultCors("http://example.com");  

    var app = builder.Build();

    app.UseApiFromRepositoryFramework()
        .WithNoAuthorization();

---

## repository/repositoryframework-migrationtools

> You need to create a base model as a bridge for your migration. After that you can use the two repositories with repository pattern to help yourself with the mi

### [What is Rystem?](https://github.com/KeyserDSoze/Rystem)

## Migration Tools

You need to create a base model as a bridge for your migration. After that you can use the two repositories with repository pattern to help yourself with the migration from a old storage to a brand new storage.

### Sample with in memory integration (From UnitTest)
For instance you can create two repositories, one as source and one as target.
In the example we use an easy test integration with two in memory integrations.

    .AddRepository<SuperMigrationUser, string>(builder =>
    {
        builder.WithInMemory(builder =>
        {
            builder
                .PopulateWithRandomData(NumberOfItems);
        }, "source");
    })
    .AddRepository<SuperMigrationUser, string>(builder =>
    {
        builder.WithInMemory(builder =>
        {
            builder
                .PopulateWithRandomData(NumberOfItems);
        }, "target");
    })
        .AddMigrationManager<SuperMigrationUser, string>(settings =>
        {
            settings.SourceFactoryName = "source";
            settings.DestinationFactoryName = "target";
            settings.NumberOfConcurrentInserts = 10;
        })

Now you may use the interface in DI

    IMigrationManager<SuperMigrationUser, string> migrationService

and let the sorcery happens

    var migrationResult = await _migrationService.MigrateAsync(x => x.Id!, true);

### Parameters
| Name | Description |
| ------------------------- | ------------------------------ |
| Expression<Func<T, TKey>> navigationKey | Explain how to create the TKey from the TValue |
| bool checkIfExists = false | check existence on target before download from source |
| bool deleteEverythingBeforeStart = false | delete all items before starting the migration from target |

---

## Rystem TypeScript Generator

> CLI tool to generate TypeScript types and services from C# Rystem Repository/CQRS models.

# Rystem TypeScript Generator

CLI tool to generate TypeScript types and services from C# Rystem Repository/CQRS models.

## Installation

### Global Installation (recommended)

```bash
dotnet tool install -g Rystem.RepositoryFramework.TypescriptGenerator
```

### Local Installation (per-project)

```bash
dotnet new tool-manifest # if you don't have one already
dotnet tool install Rystem.RepositoryFramework.TypescriptGenerator
```

### Update

```bash
# Global
dotnet tool update -g Rystem.RepositoryFramework.TypescriptGenerator

# Local
dotnet tool update Rystem.RepositoryFramework.TypescriptGenerator
```

### Uninstall

```bash
# Global
dotnet tool uninstall -g Rystem.RepositoryFramework.TypescriptGenerator

# Local
dotnet tool uninstall Rystem.RepositoryFramework.TypescriptGenerator
```

## Usage

### Basic Syntax

```bash
rystem-ts generate --dest <destination> --models <model-definitions> [options]
```

### Options

| Option | Alias | Required | Description |
|--------|-------|----------|-------------|
| `--dest` | `-d` | ✅ | Destination folder for generated TypeScript files |
| `--models` | `-m` | ✅ | Repository definitions (see format below) |
| `--project` | `-p` | ❌ | Path to C# project (.csproj) or assembly (.dll) |
| `--overwrite` | | ❌ | Overwrite existing files (default: `true`) |
| `--include-deps` | | ❌ | Include project dependencies in type scanning (default: `false`) |
| `--deps-prefix` | | ❌ | Only load dependencies starting with this prefix (e.g., `MyCompany.`) |

### Model Definition Format

The `--models` option accepts repository definitions in the following format:

```
"{Model,Key,Type,Factory,BackendFactory},{Model2,Key2,Type2,Factory2,}"
```

**Fields:**
- **ModelName**: Name of the C# entity class. Can be simple (`Calendar`) or fully qualified (`Fantacalcio.Domain.Calendar`)
- **KeyName**: Name of the key type. Can be simple (`LeagueKey`) or fully qualified (`Fantacalcio.Domain.LeagueKey`)
- **RepositoryType**: One of `Repository`, `Query`, or `Command`
- **FactoryName**: Client-side name used in `RepositoryLocator.{factoryName}` (optional, defaults to ModelName)
- **BackendFactoryName**: Backend factory name used in API path (optional)

**API Path Generation:**
- If **BackendFactoryName is empty** (e.g., `{Rank,RankKey,Repository,rank,}`) → path = `Rank` (just ModelName)
- If **BackendFactoryName is set** (e.g., `{Rank,RankKey,Repository,rank,rank}`) → path = `Rank/rank` (ModelName/BackendFactory)

> **Note:** If multiple types with the same name exist in different namespaces, you must use the fully qualified name (with namespace) to avoid ambiguity.

### Examples

#### Single Repository (no backend factory - path will be just ModelName)

```bash
rystem-ts generate \
  --dest ./src/api \
  --models "{User,Guid,Repository,users,}"
```

This generates `x.path = 'User'` and `x.name = 'users'`.

#### With Backend Factory Name (path will be ModelName/BackendFactory)

```bash
rystem-ts generate \
  --dest ./src/api \
  --models "{User,Guid,Repository,users,users}"
```

This generates `x.path = 'User/users'` and `x.name = 'users'`.

#### Multiple Repositories with Mixed Backend Factories

```bash
rystem-ts generate \
  --dest ./src/api \
  --models "{Calendar,LeagueKey,Repository,serieA,serieA},{Team,Guid,Query,teams,},{Match,int,Command,matches,matches}"
```

This generates:
- Calendar: `x.path = 'Calendar/serieA'`, `x.name = 'serieA'`
- Team: `x.path = 'Team'`, `x.name = 'teams'`
- Match: `x.path = 'Match/matches'`, `x.name = 'matches'`

#### With Fully Qualified Names (Namespaces)

Use fully qualified names when you have types with the same name in different namespaces:

```bash
rystem-ts generate \
  --dest ./src/api \
  --models "{Fantacalcio.Domain.Calendar,Fantacalcio.Domain.LeagueKey,Repository,serieA}"
```

#### With Generic Types

The tool supports generic types with both user-friendly and .NET reflection syntax:

**User-friendly syntax** (recommended):

```bash
rystem-ts generate \
  --dest ./src/api \
  --models "{EntityVersions<Timeline>,Guid,Repository,versionedtimelines,}"
```

**.NET Reflection syntax** (auto-detected):

```bash
rystem-ts generate \
  --dest ./src/api \
  --models "{EntityVersions`1[[GhostWriter.Business.Timeline]],Guid,Repository,versionedtimelines,}"
```

Both syntaxes will generate:
```typescript
// TypeScript output
export interface EntityVersions<Timeline> {
  // ...
}
```

**Fully qualified generic types**:

```bash
rystem-ts generate \
  --dest ./src/api \
  --models "{MyCompany.Infrastructure.EntityVersions<MyCompany.Domain.Timeline>,Guid,Repository,versionedtimelines,}"
```

#### With Specific Project

```bash
rystem-ts generate \
  --dest ./src/api \
  --models "{Product,int,Repository,products}" \
  --project ./src/MyApp.Core/MyApp.Core.csproj
```

#### Disable Overwrite

```bash
rystem-ts generate \
  --dest ./src/api \
  --models "{Order,Guid,Repository,orders}" \
  --overwrite false
```

#### With Project Dependencies

When your models reference types from other projects or NuGet packages:

```bash
rystem-ts generate \
  --dest ./src/api \
  --models "{Order,OrderKey,Repository,orders,orders}" \
  --project ./src/MyApp.Api/MyApp.Api.csproj \
  --include-deps
```

This will scan all DLLs in the output directory (except system assemblies).

#### With Dependency Prefix Filter

To only load dependencies from your company/organization:

```bash
rystem-ts generate \
  --dest ./src/api \
  --models "{Order,OrderKey,Repository,orders,orders}" \
  --project ./src/MyApp.Api/MyApp.Api.csproj \
  --include-deps \
  --deps-prefix "MyCompany."
```

This will only load:
- ✅ `MyCompany.Core.dll`
- ✅ `MyCompany.Domain.dll`
- ❌ `Newtonsoft.Json.dll` (skipped)
- ❌ `Microsoft.Extensions.dll` (skipped)

## Generated Output

The tool generates the following structure:

```
📁 <destination>/
├── 📁 types/
│   ├── calendar.ts           # Raw + Clean interfaces + Mappers
│   ├── leaguekey.ts
│   ├── team.ts
│   └── dayofweek.ts          # Enums
├── 📁 transformers/
│   ├── CalendarTransformer.ts    # ITransformer<Calendar>
│   ├── LeagueKeyTransformer.ts   # ITransformer<LeagueKey>
│   └── index.ts
├── 📁 bootstrap/
│   └── repositorySetup.ts    # RepositoryServices configuration with transformers
└── 📁 services/
    └── repositoryLocator.ts  # RepositoryLocator.{factoryName} -> IRepository
```

### Generated Types

#### Types (`types/*.ts`)

For each C# model, the tool generates:

```typescript
// Raw interface (matches JSON from API)
export interface CalendarRaw {
  league_id: string;           // Uses JsonPropertyName if present
  start_date: string;          // Dates as strings
  teams: TeamRaw[];
}

// Clean interface (TypeScript-friendly)
export interface Calendar {
  leagueId: string;            // camelCase names
  startDate: Date;             // Proper Date type
  teams: Team[];
}

// Mapper function
export function mapCalendar(raw: CalendarRaw): Calendar {
  return {
    leagueId: raw.league_id,
    startDate: new Date(raw.start_date),
    teams: raw.teams.map(mapTeam),
  };
}
```

#### Common Types (`services/common.ts`)

```typescript
export interface Entity<T, TKey> {
  key: TKey;
  value: T | null;
}

export interface State<T> {
  isOk: boolean;
  message?: string;
  value?: T;
}

export interface Page<T, TKey> {
  items: Entity<T, TKey>[];
  totalCount: number;
  pageSize: number;
  pageIndex: number;
  totalPages: number;
}

export interface BatchOperation<T, TKey> {
  command: 'insert' | 'update' | 'delete';
  key: TKey;
  value?: T;
}
```

#### Services (`services/*.service.ts`)

```typescript
export class SerieAService {
  private baseUrl: string;
  
  constructor(baseUrl: string) {
    this.baseUrl = baseUrl;
  }

  // Query methods
  async get(key: LeagueKey): Promise<Calendar | null> { ... }
  async query(options?: QueryOptions): Promise<Entity<Calendar, LeagueKey>[]> { ... }
  async page(pageIndex: number, pageSize: number): Promise<Page<Calendar, LeagueKey>> { ... }
  async exist(key: LeagueKey): Promise<State<boolean>> { ... }
  async count(): Promise<number> { ... }

  // Command methods (Repository/Command only)
  async insert(key: LeagueKey, value: Calendar): Promise<State<Calendar>> { ... }
  async update(key: LeagueKey, value: Calendar): Promise<State<Calendar>> { ... }
  async delete(key: LeagueKey): Promise<State<boolean>> { ... }
  async batch(operations: BatchOperation<Calendar, LeagueKey>[]): Promise<BatchResult[]> { ... }
}
```

#### Transformers (`transformers/*.ts`)

Transformers implement `ITransformer<T>` from `rystem.repository.client` to convert between Raw and Clean types:

```typescript
import type { ITransformer } from 'rystem.repository.client';
import type { Calendar, CalendarRaw } from '../types/calendar';
import { mapRawCalendarToCalendar, mapCalendarToRawCalendar } from '../types/calendar';

export const CalendarTransformer: ITransformer<Calendar> = {
  fromPlain: (plain: CalendarRaw): Calendar => mapRawCalendarToCalendar(plain),
  toPlain: (instance: Calendar): CalendarRaw => mapCalendarToRawCalendar(instance),
};
```

#### Bootstrap Setup (`bootstrap/repositorySetup.ts`)

The bootstrap file configures `RepositoryServices` with transformers for automatic JSON conversion:

```typescript
import { RepositoryServices } from 'rystem.repository.client';
import type { RepositoryEndpoint } from 'rystem.repository.client';
import { CalendarTransformer } from '../transformers/CalendarTransformer';
import { LeagueKeyTransformer } from '../transformers/LeagueKeyTransformer';

export interface RepositoryConfig {
  baseUrl: string;
  headersEnricher?: (...) => Promise<HeadersInit>;
  errorHandler?: (...) => Promise<boolean>;
}

export const setupRepositoryServices = (config: RepositoryConfig): void => {
  const services = RepositoryServices.Create(config.baseUrl);

  services.addRepository<Calendar, LeagueKey>(x => {
    x.name = 'calendar';
    x.path = 'calendar';
    x.transformer = CalendarTransformer;       // Auto-converts model
    x.keyTransformer = LeagueKeyTransformer;   // Auto-converts key
    x.complexKey = true;
    if (config.headersEnricher) x.addHeadersEnricher(config.headersEnricher);
    if (config.errorHandler) x.addErrorHandler(config.errorHandler);
  });
};
```

#### Repository Locator (`repositoryLocator.ts`)

Provides strongly-typed access to all configured repositories:

```typescript
import { RepositoryServices } from 'rystem.repository.client';
import type { IRepository, IQuery, ICommand } from 'rystem.repository.client';
import type { Calendar } from './types/calendar';
import type { LeagueKey } from './types/leaguekey';

export const RepositoryLocator = {
  get calendar(): IRepository<Calendar, LeagueKey> {
    return RepositoryServices.Repository<Calendar, LeagueKey>('calendar');
  },
  get teams(): IQuery<Team, string> {
    return RepositoryServices.Query<Team, string>('teams');
  },
  get orders(): ICommand<Order, number> {
    return RepositoryServices.Command<Order, number>('orders');
  },
} as const;
```

**Usage:**

```typescript
import { setupRepositoryServices } from './bootstrap/repositorySetup';
import { RepositoryLocator } from './repositoryLocator';

// 1. Setup once at app startup
setupRepositoryServices({
  baseUrl: 'https://api.example.com/api/',
  headersEnricher: async () => ({
    Authorization: `Bearer ${getToken()}`
  }),
  errorHandler: async (endpoint, uri, method, headers, body, err) => {
    if (err?.status === 401) {
      await refreshToken();
      return true; // Retry
    }
    return false;
  }
});

// 2. Use anywhere in your app with full type safety
const calendar = await RepositoryLocator.calendar.get({ leagueId: 'serie-a', season: 2024 });
const allTeams = await RepositoryLocator.teams.query().toListAsync();
await RepositoryLocator.orders.insert({ orderId: 123 }, { /* order data */ });
```

## Repository Types

| Type | Query Methods | Command Methods |
|------|---------------|-----------------|
| `Repository` | ✅ get, query, page, exist, count | ✅ insert, update, delete, batch |
| `Query` | ✅ get, query, page, exist, count | ❌ |
| `Command` | ❌ | ✅ insert, update, delete, batch |

## C# Model Requirements

### Basic Model

```csharp
public class User
{
    public Guid Id { get; set; }
    public string Name { get; set; }
    public DateTime CreatedAt { get; set; }
}
```

### With JsonPropertyName (for Raw types)

```csharp
public class User
{
    [JsonPropertyName("user_id")]
    public Guid Id { get; set; }
    
    [JsonPropertyName("full_name")]
    public string Name { get; set; }
    
    [JsonPropertyName("created_at")]
    public DateTime CreatedAt { get; set; }
}
```

### Custom Key Types

```csharp
public record LeagueKey(string LeagueId, int Season);
```

### Enums

```csharp
public enum OrderStatus
{
    Pending = 0,
    Processing = 1,
    Completed = 2,
    Cancelled = 3
}
```

## Integration with Rystem Repository API

This tool is designed to work with [Rystem.RepositoryFramework.Api.Server](../RepositoryFramework.Api.Server/README.md).

### Server Setup

```csharp
// Program.cs
builder.Services.AddRepository<Calendar, LeagueKey>(settings =>
{
    settings.WithEntityFramework<AppDbContext>();
});

// Expose as REST API
app.UseEndpointsForRepositoryPattern();
```

### Client Usage

```typescript
// Setup (once at app startup)
Services.configure({ 
  baseUrl: 'https://localhost:5001/api' 
});

// Use anywhere in your app
const calendars = await Services.serieA.query();
const calendar = await Services.serieA.get({ leagueId: 'serie-a', season: 2024 });

// Create/Update
await Services.serieA.insert(
  { leagueId: 'serie-a', season: 2025 },
  { startDate: new Date(), teams: [] }
);
```

## Troubleshooting

### "Project file not found"

Make sure the `--project` path is correct, or run the command from a directory containing a `.csproj` file.

### "Multiple .csproj files found"

Specify which project to use with `--project`:

```bash
rystem-ts generate --dest ./src/api --models "{User,Guid,Repository,users}" --project ./src/MyApp.Core.csproj
```

### "Model not found in assembly"

Ensure:
1. The model class is `public`
2. The project has been built (`dotnet build`)
3. The model name matches exactly (case-sensitive)

### "Multiple types found with name 'X'"

This error occurs when you have multiple classes with the same name in different namespaces:

```
Multiple types found with name 'Calendar'. Please use the fully qualified name:
  - Fantacalcio.Domain.Calendar
  - OtherProject.Models.Calendar
```

**Solution:** Use the fully qualified name (with namespace) in your `--models` argument:

```bash
# Instead of:
--models "{Calendar,LeagueKey,Repository,serieA}"

# Use:
--models "{Fantacalcio.Domain.Calendar,Fantacalcio.Domain.LeagueKey,Repository,serieA}"
```

## Contributing

This tool is part of the [Rystem](https://github.com/KeyserDSoze/Rystem) framework.

## License

MIT License - see the main repository for details.

---

## repository/repositoryframework-web-components

> You have to add a service for UI

### [What is Rystem?](https://github.com/KeyserDSoze/Rystem)

## Add to service collection the UI service in your blazor DI

You have to add a service for UI

    builder.Services
        .AddRepositoryUI();

and add the endpoint for your repository

    app
        .AddDefaultRepositoryEndpoints();


### Demand everything to the framework        

In the Host.cshtml you have to add style, javascript files and the RepositoryApp.

    <html>
        <head>
          <!-- inside of head section -->
          <partial name="RepositoryStyle" />
        </head>
        <body>
          <component type="typeof(RepositoryApp<App>)" render-mode="ServerPrerendered" />
          <!-- inside of body section and after the div/app tag  -->
          <partial name="RepositoryScript" />
        </body>
    </html>

Instead of "App" class you can use every class in your DLL, but remember the class needs to be inside your blazor/razor application.

### Demand everything to the framework with authentication

In the Host.cshtml you have to add style, javascript files and the RepositoryAuthenticatedApp.

    <html>
        <head>
          <!-- inside of head section -->
          <partial name="RepositoryStyle" />
        </head>
        <body>
          <component type="typeof(RepositoryAuthenticatedApp<App>)" render-mode="ServerPrerendered" />
          <!-- inside of body section and after the div/app tag  -->
          <partial name="RepositoryScript" />
        </body>
    </html>

Instead of "App" class you can use every class in your DLL, but remember the class needs to be inside your blazor/razor application.

### Use razor component instead to build your mixed custom repository UI

In the Host.cshtml you have to add style, javascript files
 
    <html>
        <head>
          <!-- inside of head section -->
          <partial name="RepositoryStyle" />
        </head>
        <body>
          <component type="typeof(App)" render-mode="ServerPrerendered" />
          <!-- inside of body section and after the div/app tag  -->
          <partial name="RepositoryScript" />
        </body>
    </html>

In your app you can use

Component          | Usage
------------------ | --------------------------------------------------
RepositoryManager  | A component to manage your repository in one page
