---
name: Rystem - Get Rystem Docs / Repository
description: Rystem Framework docs: Repository API Client - .NET, Repository API Client - TypeScript, Repository API Server, Repository Pattern Setup and 17 more. Use for repository questions in Rystem.
---

# Rystem - Get Rystem Docs / Repository

> Auto-generated from Rystem MCP manifest (tool: `get-rystem-docs`, category: `repository`)

---

## Repository API Client - .NET

> Consume Repository APIs from .NET/C# apps using same IRepository interface as backend - supports Blazor Server, Blazor WASM, MAUI, WPF, and Console apps

---
title: Repository API Client - .NET
description: Consume Repository APIs from .NET/C# apps using same IRepository interface as backend - supports Blazor Server, Blazor WASM, MAUI, WPF, and Console apps
---

# Repository API Client - .NET/C#

**Purpose**: This tool explains how to **consume auto-generated Repository APIs** from .NET/C# applications (Blazor Server, Blazor WASM, MAUI, WPF, Console apps). The client provides the same `IRepository<T, TKey>` interface you use on the server, making it seamless to work with remote data.

---

## 🎯 What is Rystem Repository API Client?

The **Rystem.RepositoryFramework.Api.Client** package provides:
- ✅ **Same interface as server** - use `IRepository<T, TKey>` everywhere
- ✅ **Automatic HttpClient configuration** with Polly retry policies
- ✅ **Built-in authentication** interceptors for JWT tokens
- ✅ **Factory pattern support** for multiple endpoints
- ✅ **CQRS support** with `ICommand` and `IQuery`
- ✅ **Works everywhere**: Blazor Server, Blazor WASM, MAUI, WPF, Console

**Key Benefit**: Write once, use the same repository interface on server and client!

---

## 📦 Installation

```bash
# Core API Client
dotnet add package Rystem.RepositoryFramework.Api.Client --version 9.1.3

# For Blazor Server with JWT authentication
dotnet add package Rystem.RepositoryFramework.Api.Client.Authentication.BlazorServer --version 9.1.3

# For Blazor WASM with JWT authentication
dotnet add package Rystem.RepositoryFramework.Api.Client.Authentication.BlazorWasm --version 9.1.3
```

---

## 🚀 Quick Start - Simple Repository

### Step 1: Register Repository Client

```csharp
// Program.cs (Blazor Server, MAUI, WPF, Console)
using Rystem;

var builder = WebApplication.CreateBuilder(args);

// Register repository client
builder.Services.AddRepository<Order, Guid>(repositoryBuilder =>
{
    repositoryBuilder
        .WithApiClient()
        .WithHttpClient("https://api.myapp.com/api/");
});

var app = builder.Build();
app.Run();
```

### Step 2: Use in Your Service

```csharp
// Services/OrderService.cs
public class OrderService
{
    private readonly IRepository<Order, Guid> _orderRepository;
    
    public OrderService(IRepository<Order, Guid> orderRepository)
    {
        _orderRepository = orderRepository;
    }
    
    public async Task<Order?> GetOrderAsync(Guid orderId)
    {
        return await _orderRepository.GetAsync(orderId);
    }
    
    public async Task<State<Order, Guid>> CreateOrderAsync(Order order)
    {
        return await _orderRepository.InsertAsync(order.Id, order);
    }
    
    public async Task<List<Order>> GetPendingOrdersAsync()
    {
        var results = await _orderRepository
            .Where(x => x.Status == OrderStatus.Pending)
            .ToListAsync();
        
        return results.Select(x => x.Value!).ToList();
    }
}
```

**That's it!** The same interface works on client and server.

---

## 🔄 Advanced Setup - Multiple Repositories

### Extension Method Pattern

```csharp
// Extensions/ServiceCollectionExtensions.cs
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddApiRepositories(
        this IServiceCollection services, 
        IConfiguration configuration)
    {
        var apiUri = configuration["Api:Uri"] ?? "https://api.myapp.com/api/";
        
        // Order Repository
        services.AddHttpClientIntegration<Order, Guid>(apiUri);
        
        // Customer Repository
        services.AddHttpClientIntegration<Customer, Guid>(apiUri);
        
        // Product Repository
        services.AddHttpClientIntegration<Product, int>(apiUri);
        
        // Complex key example
        services.AddHttpClientIntegration<OrderItem, OrderItemKey>(apiUri);
        
        return services;
    }
    
    // Helper method for consistent configuration
    private static IServiceCollection AddHttpClientIntegration<T, TKey>(
        this IServiceCollection services,
        string apiUri,
        string? factoryName = null)
        where TKey : notnull
    {
        return services.AddRepository<T, TKey>(builder =>
        {
            builder.WithApiClient(apiBuilder =>
            {
                apiBuilder
                    .WithHttpClient(apiUri)
                    .WithDefaultRetryPolicy();
                
                if (factoryName != null)
                    apiBuilder.WithServerFactoryName(factoryName);
            }, factoryName, ServiceLifetime.Transient);
        });
    }
}
```

### Usage in Program.cs

```csharp
// Program.cs
var builder = WebApplication.CreateBuilder(args);

// Add all API repositories
builder.Services.AddApiRepositories(builder.Configuration);

var app = builder.Build();
app.Run();
```

---

## 🔐 Authentication with JWT

### Blazor Server

```csharp
// Program.cs (Blazor Server)
using Rystem;

var builder = WebApplication.CreateBuilder(args);

// Add authentication services
builder.Services.AddAuthentication(/* your auth config */);
builder.Services.AddAuthorization();

// Add default JWT interceptor
builder.Services.AddDefaultAuthorizationInterceptorForApiHttpClient();

// Register repositories
builder.Services.AddRepository<Order, Guid>(repositoryBuilder =>
{
    repositoryBuilder
        .WithApiClient()
        .WithHttpClient("https://api.myapp.com/api/");
});

var app = builder.Build();

app.UseAuthentication();
app.UseAuthorization();

app.Run();
```

**Package required**: `Rystem.RepositoryFramework.Api.Client.Authentication.BlazorServer`

### Blazor WASM

```csharp
// Program.cs (Blazor WASM)
using Microsoft.AspNetCore.Components.WebAssembly.Hosting;
using Rystem;

var builder = WebAssemblyHostBuilder.CreateDefault(args);

// Add authentication services
builder.Services.AddAuthorizationCore();

// Add default JWT interceptor for WASM
builder.Services.AddDefaultAuthorizationInterceptorForApiHttpClient();

// Register repositories
builder.Services.AddRepository<Order, Guid>(repositoryBuilder =>
{
    repositoryBuilder
        .WithApiClient()
        .WithHttpClient("https://api.myapp.com/api/");
});

await builder.Build().RunAsync();
```

**Package required**: `Rystem.RepositoryFramework.Api.Client.Authentication.BlazorWasm`

---

## 🔧 Polly Retry Policies

Add resilience with Polly retry policies:

```csharp
using Polly;
using Polly.Extensions.Http;
using Polly.Timeout;

var builder = WebApplication.CreateBuilder(args);

// Define retry policy
var retryPolicy = HttpPolicyExtensions
    .HandleTransientHttpError()
    .Or<TimeoutRejectedException>()
    .WaitAndRetryAsync(3, retryAttempt => 
        TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)));

// Register repository with policy
builder.Services.AddRepository<Order, Guid>(repositoryBuilder =>
{
    repositoryBuilder
        .WithApiClient()
        .WithHttpClient("https://api.myapp.com/api/")
            .ClientBuilder  // Access underlying HttpClientBuilder
        .AddPolicyHandler(retryPolicy);
});
```

### Advanced Polly Configuration

```csharp
// Retry with exponential backoff
var retryPolicy = HttpPolicyExtensions
    .HandleTransientHttpError()
    .WaitAndRetryAsync(
        retryCount: 3,
        sleepDurationProvider: retryAttempt => 
            TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)),
        onRetry: (outcome, timespan, retryCount, context) =>
        {
            Console.WriteLine($"Retry {retryCount} after {timespan.TotalSeconds}s");
        });

// Circuit breaker
var circuitBreakerPolicy = HttpPolicyExtensions
    .HandleTransientHttpError()
    .CircuitBreakerAsync(
        handledEventsAllowedBeforeBreaking: 5,
        durationOfBreak: TimeSpan.FromSeconds(30));

// Timeout
var timeoutPolicy = Policy.TimeoutAsync<HttpResponseMessage>(
    TimeSpan.FromSeconds(10));

// Register with multiple policies
builder.Services.AddRepository<Order, Guid>(repositoryBuilder =>
{
    repositoryBuilder
        .WithApiClient()
        .WithHttpClient("https://api.myapp.com/api/")
            .ClientBuilder
        .AddPolicyHandler(retryPolicy)
        .AddPolicyHandler(circuitBreakerPolicy)
        .AddPolicyHandler(timeoutPolicy);
});
```

---

## 🏭 Factory Pattern - Multiple Endpoints

Use multiple API endpoints for the same entity:

```csharp
// Setup multiple repositories with factory names
builder.Services.AddRepository<Order, Guid>(repositoryBuilder =>
{
    repositoryBuilder.WithApiClient(apiBuilder =>
    {
        apiBuilder
            .WithHttpClient("https://api-primary.myapp.com/api/")
            .WithDefaultRetryPolicy();
        apiBuilder.WithServerFactoryName("primary");
    }, "primary");
});

builder.Services.AddRepository<Order, Guid>(repositoryBuilder =>
{
    repositoryBuilder.WithApiClient(apiBuilder =>
    {
        apiBuilder
            .WithHttpClient("https://api-backup.myapp.com/api/")
            .WithDefaultRetryPolicy();
        apiBuilder.WithServerFactoryName("backup");
    }, "backup");
});

// Usage with Factory
public class OrderService
{
    private readonly IFactory<IRepository<Order, Guid>> _repositoryFactory;
    
    public OrderService(IFactory<IRepository<Order, Guid>> repositoryFactory)
    {
        _repositoryFactory = repositoryFactory;
    }
    
    public async Task<Order?> GetOrderAsync(Guid orderId)
    {
        // Try primary first
        var primaryRepo = _repositoryFactory.Create("primary");
        var order = await primaryRepo.GetAsync(orderId);
        
        if (order != null)
            return order;
        
        // Fallback to backup
        var backupRepo = _repositoryFactory.Create("backup");
        return await backupRepo.GetAsync(orderId);
    }
}
```

---

## 📊 CQRS Pattern

Separate read and write operations with different endpoints:

### Setup

```csharp
// Command (write) to primary API
builder.Services.AddCommand<Order, Guid>(commandBuilder =>
{
    commandBuilder
        .WithApiClient()
        .WithHttpClient("https://api-write.myapp.com/api/");
});

// Query (read) from read replica API
builder.Services.AddQuery<Order, Guid>(queryBuilder =>
{
    queryBuilder
        .WithApiClient()
        .WithHttpClient("https://api-read.myapp.com/api/");
});
```

### Usage

```csharp
public class OrderService
{
    private readonly ICommand<Order, Guid> _orderCommand;
    private readonly IQuery<Order, Guid> _orderQuery;
    
    public OrderService(
        ICommand<Order, Guid> orderCommand,
        IQuery<Order, Guid> orderQuery)
    {
        _orderCommand = orderCommand;
        _orderQuery = orderQuery;
    }
    
    // Write operations use Command
    public async Task<State<Order, Guid>> CreateOrderAsync(Order order)
    {
        return await _orderCommand.InsertAsync(order.Id, order);
    }
    
    public async Task<State<Order, Guid>> UpdateOrderAsync(Order order)
    {
        return await _orderCommand.UpdateAsync(order.Id, order);
    }
    
    // Read operations use Query
    public async Task<Order?> GetOrderAsync(Guid orderId)
    {
        return await _orderQuery.GetAsync(orderId);
    }
    
    public async Task<List<Order>> GetPendingOrdersAsync()
    {
        var results = await _orderQuery
            .Where(x => x.Status == OrderStatus.Pending)
            .ToListAsync();
        
        return results.Select(x => x.Value!).ToList();
    }
}
```

**⚠️ Important**: Always inject `ICommand`, `IQuery`, `IRepository` - NOT `ICommandPattern`, `IQueryPattern`, `IRepositoryPattern`!

---

## 🎭 Custom Interceptors

Add custom logic before/after every HTTP request:

### Create Interceptor

```csharp
// Interceptors/CustomHeaderInterceptor.cs
using Rystem.RepositoryFramework.Api.Client;

public class CustomHeaderInterceptor : IRepositoryClientInterceptor
{
    private readonly IHttpContextAccessor _httpContextAccessor;
    
    public CustomHeaderInterceptor(IHttpContextAccessor httpContextAccessor)
    {
        _httpContextAccessor = httpContextAccessor;
    }
    
    public async ValueTask<HttpClient> EnrichAsync(
        HttpClient client,
        RepositoryMethod method,
        CancellationToken cancellationToken = default)
    {
        // Add custom headers
        var userId = _httpContextAccessor.HttpContext?.User.FindFirst("sub")?.Value;
        if (userId != null)
        {
            client.DefaultRequestHeaders.Add("X-User-Id", userId);
        }
        
        // Add correlation ID
        client.DefaultRequestHeaders.Add("X-Correlation-Id", Guid.NewGuid().ToString());
        
        // Add tenant ID for multi-tenancy
        var tenantId = await GetTenantIdAsync();
        if (tenantId != null)
        {
            client.DefaultRequestHeaders.Add("X-Tenant-Id", tenantId);
        }
        
        return client;
    }
    
    private async Task<string?> GetTenantIdAsync()
    {
        // Your tenant resolution logic
        return "tenant-123";
    }
}
```

### Register Interceptor

#### Global Interceptor (for all repositories)

```csharp
builder.Services.AddApiClientInterceptor<CustomHeaderInterceptor>(ServiceLifetime.Scoped);
```

#### Specific Interceptor (for one repository)

```csharp
builder.Services.AddRepository<Order, Guid>(repositoryBuilder =>
{
    repositoryBuilder
        .WithApiClient()
        .WithHttpClient("https://api.myapp.com/api/")
        .AddApiClientSpecificInterceptor<Order, Guid, CustomHeaderInterceptor>(ServiceLifetime.Scoped);
});
```

### Built-in JWT Interceptor

For standard JWT authentication:

```csharp
// For Blazor Server
builder.Services.AddDefaultAuthorizationInterceptorForApiHttpClient();

// For Blazor WASM
builder.Services.AddDefaultAuthorizationInterceptorForApiHttpClient();
```

This automatically adds the JWT token from the current user's authentication context.

---

## 🌐 Real-World Example - Complete Setup

```csharp
// Program.cs (Blazor Server)
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Polly;
using Polly.Extensions.Http;
using Rystem;

var builder = WebApplication.CreateBuilder(args);

// Add Blazor services
builder.Services.AddRazorPages();
builder.Services.AddServerSideBlazor();

// Add authentication
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.Authority = builder.Configuration["Auth:Authority"];
        options.Audience = builder.Configuration["Auth:Audience"];
    });

builder.Services.AddAuthorization();

// Add HttpContextAccessor for interceptors
builder.Services.AddHttpContextAccessor();

// Add default JWT interceptor
builder.Services.AddDefaultAuthorizationInterceptorForApiHttpClient();

// Add custom interceptor
builder.Services.AddApiClientInterceptor<CustomHeaderInterceptor>(ServiceLifetime.Scoped);

// Add API repositories
builder.Services.AddApiRepositories(builder.Configuration);

var app = builder.Build();

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

app.MapBlazorHub();
app.MapFallbackToPage("/_Host");

app.Run();
```

```csharp
// Extensions/ServiceCollectionExtensions.cs
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Polly;
using Polly.Extensions.Http;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddApiRepositories(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        var apiUri = configuration["Api:Uri"];
        if (!string.IsNullOrEmpty(apiUri) && !apiUri.StartsWith("http"))
            apiUri = $"https://{apiUri}";
        
        // Orders
        services.AddHttpClientIntegration<Order, Guid>(apiUri);
        
        // Customers
        services.AddHttpClientIntegration<Customer, Guid>(apiUri);
        
        // Products
        services.AddHttpClientIntegration<Product, int>(apiUri);
        
        // Shipments with factory name
        services.AddHttpClientIntegration<Shipment, Guid>(apiUri, "primary");
        
        // Live data with different endpoint
        services.AddRepository<LiveData, string>(builder =>
        {
            builder.WithApiClient(apiBuilder =>
            {
                apiBuilder
                    .WithHttpClient($"{apiUri}/live")
                    .WithDefaultRetryPolicy();
                apiBuilder.WithServerFactoryName("live");
            }, "live");
        });
        
        return services;
    }
    
    private static IServiceCollection AddHttpClientIntegration<T, TKey>(
        this IServiceCollection services,
        string apiUri,
        string? factoryName = null)
        where TKey : notnull
    {
        return services.AddRepository<T, TKey>(builder =>
        {
            builder.WithApiClient(apiBuilder =>
            {
                apiBuilder
                    .WithHttpClient(apiUri)
                    .WithDefaultRetryPolicy();
                
                if (factoryName != null)
                    apiBuilder.WithServerFactoryName(factoryName);
            }, factoryName, ServiceLifetime.Transient);
        });
    }
}
```

---

## 📱 Platform-Specific Examples

### Blazor Server

```csharp
// Program.cs
var builder = WebApplication.CreateBuilder(args);

builder.Services.AddRazorPages();
builder.Services.AddServerSideBlazor();

builder.Services.AddDefaultAuthorizationInterceptorForApiHttpClient();
builder.Services.AddApiRepositories(builder.Configuration);

var app = builder.Build();
app.UseAuthentication();
app.UseAuthorization();
app.MapBlazorHub();
app.Run();
```

### Blazor WASM

```csharp
// Program.cs
using Microsoft.AspNetCore.Components.WebAssembly.Hosting;

var builder = WebAssemblyHostBuilder.CreateDefault(args);

builder.Services.AddAuthorizationCore();
builder.Services.AddDefaultAuthorizationInterceptorForApiHttpClient();
builder.Services.AddApiRepositories(builder.Configuration);

await builder.Build().RunAsync();
```

### MAUI

```csharp
// MauiProgram.cs
using Microsoft.Extensions.Configuration;
using Microsoft.Maui.Hosting;

public static class MauiProgram
{
    public static MauiApp CreateMauiApp()
    {
        var builder = MauiApp.CreateBuilder();
        
        builder
            .UseMauiApp<App>()
            .ConfigureFonts(fonts =>
            {
                fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
            });
        
        // Add configuration
        var configuration = new ConfigurationBuilder()
            .AddJsonFile("appsettings.json")
            .Build();
        
        builder.Services.AddSingleton<IConfiguration>(configuration);
        
        // Add API repositories
        builder.Services.AddApiRepositories(configuration);
        
        return builder.Build();
    }
}
```

### WPF

```csharp
// App.xaml.cs
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

public partial class App : Application
{
    private readonly IHost _host;
    
    public App()
    {
        _host = Host.CreateDefaultBuilder()
            .ConfigureServices((context, services) =>
            {
                // Add API repositories
                services.AddApiRepositories(context.Configuration);
                
                // Add views
                services.AddSingleton<MainWindow>();
            })
            .Build();
    }
    
    protected override async void OnStartup(StartupEventArgs e)
    {
        await _host.StartAsync();
        
        var mainWindow = _host.Services.GetRequiredService<MainWindow>();
        mainWindow.Show();
        
        base.OnStartup(e);
    }
}
```

### Console App

```csharp
// Program.cs
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

var host = Host.CreateDefaultBuilder(args)
    .ConfigureServices((context, services) =>
    {
        services.AddApiRepositories(context.Configuration);
    })
    .Build();

// Use repository
var orderRepository = host.Services.GetRequiredService<IRepository<Order, Guid>>();
var order = await orderRepository.GetAsync(Guid.Parse("..."));

await host.RunAsync();
```

---

## 🎯 Best Practices

### 1. Use Extension Methods for Configuration

```csharp
// ✅ GOOD - Centralized configuration
public static IServiceCollection AddApiRepositories(this IServiceCollection services, IConfiguration configuration)
{
    services.AddHttpClientIntegration<Order, Guid>(configuration["Api:Uri"]);
    services.AddHttpClientIntegration<Customer, Guid>(configuration["Api:Uri"]);
    return services;
}

// ❌ BAD - Scattered configuration
builder.Services.AddRepository<Order, Guid>(...);
builder.Services.AddRepository<Customer, Guid>(...);
```

### 2. Always Add Retry Policies

```csharp
// ✅ GOOD - Resilient with retry
apiBuilder
    .WithHttpClient(apiUri)
    .WithDefaultRetryPolicy();

// ❌ BAD - No retry policy
apiBuilder.WithHttpClient(apiUri);
```

### 3. Use Proper Lifetime for Interceptors

```csharp
// ✅ GOOD - Scoped for user context
services.AddApiClientInterceptor<CustomHeaderInterceptor>(ServiceLifetime.Scoped);

// ❌ BAD - Singleton with user-specific data
services.AddApiClientInterceptor<CustomHeaderInterceptor>(ServiceLifetime.Singleton);
```

### 4. Inject IRepository, Not IRepositoryPattern

```csharp
// ✅ GOOD
public OrderService(IRepository<Order, Guid> repository)

// ❌ BAD
public OrderService(IRepositoryPattern<Order, Guid> repository)
```

### 5. Use Factory for Multiple Endpoints

```csharp
// ✅ GOOD - Factory for multiple endpoints
public OrderService(IFactory<IRepository<Order, Guid>> factory)
{
    var primary = factory.Create("primary");
    var backup = factory.Create("backup");
}

// ❌ BAD - Multiple injections
public OrderService(
    IRepository<Order, Guid> repo1,
    IRepository<Order, Guid> repo2) // Won't work!
```

---

## ⚠️ Important Notes

1. **Package version**: Use `9.1.3` for all Rystem packages
2. **Authentication packages**:
   - Blazor Server: `Rystem.RepositoryFramework.Api.Client.Authentication.BlazorServer`
   - Blazor WASM: `Rystem.RepositoryFramework.Api.Client.Authentication.BlazorWasm`
3. **Inject interfaces**: Use `IRepository`, `ICommand`, `IQuery` (NOT Pattern versions)
4. **Polly is optional**: But highly recommended for production
5. **Interceptors run in order**: Global first, then specific
6. **Factory names must match**: Client factory name must match server factory name
7. **HttpClient base address**: Should end with `/` for proper URL joining

---

## 🔗 Related Resources

- **repository-setup**: How to configure repositories on backend
- **repository-api-server**: How to expose repositories as REST APIs
- **repository-api-client-typescript**: Client for TypeScript/JavaScript apps
- **auth-flow**: Setting up authentication with Rystem.Authentication.Social

---

## 📖 Further Reading

- [Rystem.RepositoryFramework.Api.Client GitHub](https://github.com/KeyserDSoze/RepositoryFramework/tree/master/src/RepositoryFramework.Api.Client)
- [Authentication Integration](https://github.com/KeyserDSoze/RepositoryFramework/tree/master/src/RepositoryFramework.Api.Client.Authentication.BlazorServer)
- [Polly Documentation](https://github.com/App-vNext/Polly)

---

## ✅ Summary

**Rystem.RepositoryFramework.Api.Client** provides:
- ✅ Same `IRepository<T, TKey>` interface as server
- ✅ Automatic HttpClient configuration
- ✅ Built-in JWT authentication interceptors
- ✅ Polly retry policies support
- ✅ Custom interceptors for headers/logging
- ✅ Factory pattern for multiple endpoints
- ✅ CQRS with `ICommand` and `IQuery`
- ✅ Works on Blazor Server, Blazor WASM, MAUI, WPF, Console

**Use this tool to build .NET/C# clients that consume your Repository APIs seamlessly!** 🚀

---

## Repository API Client - TypeScript

> Consume Repository APIs from TypeScript/JavaScript apps with type-safe access, automatic authentication, and retry logic for React, Next.js, and Node.js

---
title: Repository API Client - TypeScript
description: Consume Repository APIs from TypeScript/JavaScript apps with type-safe access, automatic authentication, and retry logic for React, Next.js, and Node.js
---

# Repository API Client - TypeScript/JavaScript

**Purpose**: This tool explains how to **consume auto-generated Repository APIs** from TypeScript/JavaScript applications (React, React Native, Next.js, Node.js). The client provides type-safe access to your backend repositories with automatic authentication, error handling, and retry logic.

---

## 🎯 What is Rystem Repository Client?

The **rystem.repository.client** npm package provides:
- ✅ **Type-safe repository access** with TypeScript generics
- ✅ **Automatic authentication** with token refresh
- ✅ **Custom error handlers** with retry logic
- ✅ **CQRS support** (Command/Query separation)
- ✅ **LINQ-style queries** from client-side
- ✅ **Batch operations** support
- ✅ **Works everywhere**: React, React Native, Next.js, Node.js

**Key Benefit**: Configure once, use type-safe repositories throughout your app!

---

## 📦 Installation

```bash
npm install rystem.repository.client
# or
yarn add rystem.repository.client
# or
pnpm add rystem.repository.client
```

---

## 🚀 Quick Start

### Step 1: Define Your Types

Create TypeScript interfaces matching your C# entities:

```typescript
// types/order.ts

// Raw interface (matching C# JsonPropertyName attributes)
export interface OrderRaw {
  i: string;      // Id
  n: string;      // OrderNumber
  c: string;      // CustomerId
  s: number;      // Status (enum as number)
  a: number;      // TotalAmount
  d: string;      // CreatedAt (ISO string)
}

// Clean interface (readable property names)
export interface Order {
  id: string;
  orderNumber: string;
  customerId: string;
  status: OrderStatus;
  totalAmount: number;
  createdAt: Date;
}

export enum OrderStatus {
  Pending = 0,
  Confirmed = 1,
  Shipped = 2,
  Delivered = 3,
  Cancelled = 4
}

// Mapping functions
export function mapRawToOrder(raw: OrderRaw): Order {
  return {
    id: raw.i,
    orderNumber: raw.n,
    customerId: raw.c,
    status: raw.s as OrderStatus,
    totalAmount: raw.a,
    createdAt: new Date(raw.d)
  };
}

export function mapOrderToRaw(order: Order): OrderRaw {
  return {
    i: order.id,
    n: order.orderNumber,
    c: order.customerId,
    s: order.status,
    a: order.totalAmount,
    d: order.createdAt.toISOString()
  };
}
```

### Step 2: Configure Repository Services

```typescript
// config/repositoryConfig.ts
import { RepositoryServices } from "rystem.repository.client";
import { OrderRaw } from "../types/order";
import { CustomerRaw } from "../types/customer";
import { tokenService } from "../services/tokenService";
import { authService } from "../services/authService";

export const setupRepositoryServices = () => {
  const baseUrl = process.env.NEXT_PUBLIC_API_URL || "https://api.myapp.com/api/";

  RepositoryServices
    .Create(baseUrl)
    // Order Repository
    .addRepository<OrderRaw, string>(x => {
      x.name = "Order";
      x.path = "Order";
      x.addHeadersEnricher(() => getAuthHeaders());
      x.addErrorHandler(handleAuthError);
    })
    // Customer Repository
    .addRepository<CustomerRaw, string>(x => {
      x.name = "Customer";
      x.path = "Customer";
      x.addHeadersEnricher(() => getAuthHeaders());
      x.addErrorHandler(handleAuthError);
    });
};

// Helper: Add authorization header
const getAuthHeaders = async (): Promise<HeadersInit> => {
  const accessToken = await tokenService.getValidToken();
  
  return accessToken ? {
    "Authorization": `Bearer ${accessToken}`,
    "Content-Type": "application/json"
  } : {
    "Content-Type": "application/json"
  };
};

// Helper: Handle 401 errors with automatic retry
const handleAuthError = async (
  endpoint: any,
  uri: string,
  method: string,
  headers: any,
  body: any,
  err: any
) => {
  if (err.status === 401) {
    console.log('🔐 401 Unauthorized - attempting token refresh...');
    try {
      const refreshToken = await tokenService.getRefreshToken();
      if (refreshToken) {
        const newTokenData = await authService.refreshToken(refreshToken);
        await tokenService.saveToken(newTokenData);
        console.log('✅ Token refreshed successfully');
        return true; // Retry the request
      }
    } catch (error) {
      console.error('❌ Token refresh failed:', error);
      await handleAuthenticationFailure();
    }
  }
  return false; // Don't retry
};

// Helper: Clear tokens and redirect to login
const handleAuthenticationFailure = async () => {
  await tokenService.clearTokens();
  if (typeof window !== 'undefined') {
    window.location.href = '/login';
  }
};
```

### Step 3: Initialize in Your App

```typescript
// App.tsx (React/React Native)
import { setupRepositoryServices } from './config/repositoryConfig';

// Call once at app startup
setupRepositoryServices();

export default function App() {
  return (
    <YourAppComponent />
  );
}
```

```typescript
// app/layout.tsx (Next.js App Router)
'use client';

import { useEffect } from 'react';
import { setupRepositoryServices } from '@/config/repositoryConfig';

export default function RootLayout({ children }) {
  useEffect(() => {
    setupRepositoryServices();
  }, []);

  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
```

---

## 📚 Create a Service Layer

Wrap the repository client with business logic:

```typescript
// services/orderService.ts
import { RepositoryServices } from "rystem.repository.client";
import { 
  Order, 
  OrderRaw, 
  OrderStatus,
  mapRawToOrder, 
  mapOrderToRaw 
} from "../types/order";

export class OrderService {
  private getRepository() {
    return RepositoryServices.Repository<OrderRaw, string>("Order");
  }

  // ============================================
  // CRUD OPERATIONS
  // ============================================

  async getOrder(orderId: string): Promise<Order | null> {
    try {
      const raw = await this.getRepository().get(orderId);
      return raw ? mapRawToOrder(raw) : null;
    } catch (error) {
      console.error('Error fetching order:', error);
      return null;
    }
  }

  async createOrder(order: Order): Promise<boolean> {
    try {
      const raw = mapOrderToRaw(order);
      const result = await this.getRepository().insert(order.id, raw);
      return result.isOk;
    } catch (error) {
      console.error('Error creating order:', error);
      return false;
    }
  }

  async updateOrder(order: Order): Promise<boolean> {
    try {
      const raw = mapOrderToRaw(order);
      const result = await this.getRepository().update(order.id, raw);
      return result.isOk;
    } catch (error) {
      console.error('Error updating order:', error);
      return false;
    }
  }

  async deleteOrder(orderId: string): Promise<boolean> {
    try {
      const result = await this.getRepository().delete(orderId);
      return result.isOk;
    } catch (error) {
      console.error('Error deleting order:', error);
      return false;
    }
  }

  async orderExists(orderId: string): Promise<boolean> {
    try {
      const result = await this.getRepository().exist(orderId);
      return result.isOk;
    } catch (error) {
      console.error('Error checking order existence:', error);
      return false;
    }
  }

  // ============================================
  // QUERY OPERATIONS
  // ============================================

  async getAllOrders(): Promise<Order[]> {
    try {
      const results = await this.getRepository().query().execute();
      return results.map(r => mapRawToOrder(r.value));
    } catch (error) {
      console.error('Error fetching orders:', error);
      return [];
    }
  }

  async getOrdersByCustomer(customerId: string): Promise<Order[]> {
    try {
      const results = await this.getRepository()
        .query()
        .filter(`x => x.c == "${customerId}"`)
        .execute();
      
      return results.map(r => mapRawToOrder(r.value));
    } catch (error) {
      console.error('Error fetching customer orders:', error);
      return [];
    }
  }

  async getOrdersByStatus(status: OrderStatus): Promise<Order[]> {
    try {
      const results = await this.getRepository()
        .query()
        .filter(`x => x.s == ${status}`)
        .execute();
      
      return results.map(r => mapRawToOrder(r.value));
    } catch (error) {
      console.error('Error fetching orders by status:', error);
      return [];
    }
  }

  async getRecentOrders(days: number = 7): Promise<Order[]> {
    try {
      const cutoffDate = new Date();
      cutoffDate.setDate(cutoffDate.getDate() - days);
      const isoDate = cutoffDate.toISOString();

      const results = await this.getRepository()
        .query()
        .filter(`x => x.d > "${isoDate}"`)
        .execute();
      
      return results.map(r => mapRawToOrder(r.value));
    } catch (error) {
      console.error('Error fetching recent orders:', error);
      return [];
    }
  }

  // Query with builder (type-safe)
  async getOrdersAboveAmount(minAmount: number): Promise<Order[]> {
    try {
      const results = await this.getRepository()
        .query()
        .where()
        .select(x => x.a)
        .greaterThanOrEqual(minAmount)
        .build()
        .orderBy(x => x.a) // Order by amount
        .execute();
      
      return results.map(r => mapRawToOrder(r.value));
    } catch (error) {
      console.error('Error fetching orders by amount:', error);
      return [];
    }
  }

  // ============================================
  // AGGREGATIONS
  // ============================================

  async countOrders(): Promise<number> {
    try {
      return await this.getRepository().query().count();
    } catch (error) {
      console.error('Error counting orders:', error);
      return 0;
    }
  }

  async countOrdersByStatus(status: OrderStatus): Promise<number> {
    try {
      return await this.getRepository()
        .query()
        .where()
        .select(x => x.s)
        .equal(status)
        .count();
    } catch (error) {
      console.error('Error counting orders by status:', error);
      return 0;
    }
  }

  async getTotalRevenue(): Promise<number> {
    try {
      return await this.getRepository()
        .query()
        .where()
        .select(x => x.s)
        .equal(OrderStatus.Delivered)
        .sum(x => x.a);
    } catch (error) {
      console.error('Error calculating revenue:', error);
      return 0;
    }
  }

  // ============================================
  // BATCH OPERATIONS
  // ============================================

  async bulkCreateOrders(orders: Order[]): Promise<void> {
    try {
      const batcher = this.getRepository().batch();
      
      orders.forEach(order => {
        const raw = mapOrderToRaw(order);
        batcher.addInsert(order.id, raw);
      });
      
      const results = await batcher.execute();
      
      results.forEach(result => {
        if (!result.state.isOk) {
          console.error(`Failed to create order ${result.key}:`, result.state.message);
        }
      });
    } catch (error) {
      console.error('Error in bulk create:', error);
    }
  }

  async bulkUpdateOrders(orders: Order[]): Promise<void> {
    try {
      const batcher = this.getRepository().batch();
      
      orders.forEach(order => {
        const raw = mapOrderToRaw(order);
        batcher.addUpdate(order.id, raw);
      });
      
      await batcher.execute();
    } catch (error) {
      console.error('Error in bulk update:', error);
    }
  }

  async bulkDeleteOrders(orderIds: string[]): Promise<void> {
    try {
      const batcher = this.getRepository().batch();
      
      orderIds.forEach(id => {
        batcher.addDelete(id);
      });
      
      await batcher.execute();
    } catch (error) {
      console.error('Error in bulk delete:', error);
    }
  }
}

// Export singleton instance
export const orderService = new OrderService();
```

---

## 🎣 Create React Hooks

Make it easy to use in React components:

```typescript
// hooks/useOrder.ts
import { useState, useEffect, useCallback } from 'react';
import { orderService } from '../services/orderService';
import { Order, OrderStatus } from '../types/order';

export interface UseOrderOptions {
  refreshInterval?: number;
  skip?: boolean;
}

export interface UseOrderResult {
  order: Order | null;
  loading: boolean;
  error: string | null;
  refetch: () => Promise<void>;
}

export const useOrder = (
  orderId: string | null,
  options: UseOrderOptions = {}
): UseOrderResult => {
  const { refreshInterval = 0, skip = false } = options;
  const [order, setOrder] = useState<Order | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const fetchOrder = useCallback(async (silent = false) => {
    if (skip || !orderId) {
      setOrder(null);
      setError(null);
      return;
    }

    if (!silent) {
      setLoading(true);
    }
    setError(null);

    try {
      const fetchedOrder = await orderService.getOrder(orderId);
      setOrder(fetchedOrder);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to fetch order';
      setError(message);
      console.error('Error fetching order:', err);
    } finally {
      if (!silent) {
        setLoading(false);
      }
    }
  }, [orderId, skip]);

  useEffect(() => {
    fetchOrder(false);
  }, [fetchOrder]);

  // Auto-refresh
  useEffect(() => {
    if (refreshInterval > 0) {
      const interval = setInterval(() => fetchOrder(true), refreshInterval);
      return () => clearInterval(interval);
    }
  }, [fetchOrder, refreshInterval]);

  const refetch = useCallback(() => fetchOrder(false), [fetchOrder]);

  return { order, loading, error, refetch };
};

// Hook for list of orders
export interface UseOrdersResult {
  orders: Order[];
  loading: boolean;
  error: string | null;
  refetch: () => Promise<void>;
}

export const useOrdersByCustomer = (
  customerId: string | null,
  options: UseOrderOptions = {}
): UseOrdersResult => {
  const { refreshInterval = 0, skip = false } = options;
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const fetchOrders = useCallback(async (silent = false) => {
    if (skip || !customerId) {
      setOrders([]);
      setError(null);
      return;
    }

    if (!silent) {
      setLoading(true);
    }
    setError(null);

    try {
      const fetchedOrders = await orderService.getOrdersByCustomer(customerId);
      setOrders(fetchedOrders);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to fetch orders';
      setError(message);
      console.error('Error fetching orders:', err);
    } finally {
      if (!silent) {
        setLoading(false);
      }
    }
  }, [customerId, skip]);

  useEffect(() => {
    fetchOrders(false);
  }, [fetchOrders]);

  useEffect(() => {
    if (refreshInterval > 0) {
      const interval = setInterval(() => fetchOrders(true), refreshInterval);
      return () => clearInterval(interval);
    }
  }, [fetchOrders, refreshInterval]);

  const refetch = useCallback(() => fetchOrders(false), [fetchOrders]);

  return { orders, loading, error, refetch };
};

// Hook for orders by status
export const useOrdersByStatus = (
  status: OrderStatus | null,
  options: UseOrderOptions = {}
): UseOrdersResult => {
  const { refreshInterval = 0, skip = false } = options;
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const fetchOrders = useCallback(async (silent = false) => {
    if (skip || status === null) {
      setOrders([]);
      setError(null);
      return;
    }

    if (!silent) {
      setLoading(true);
    }
    setError(null);

    try {
      const fetchedOrders = await orderService.getOrdersByStatus(status);
      setOrders(fetchedOrders);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to fetch orders';
      setError(message);
      console.error('Error fetching orders:', err);
    } finally {
      if (!silent) {
        setLoading(false);
      }
    }
  }, [status, skip]);

  useEffect(() => {
    fetchOrders(false);
  }, [fetchOrders]);

  useEffect(() => {
    if (refreshInterval > 0) {
      const interval = setInterval(() => fetchOrders(true), refreshInterval);
      return () => clearInterval(interval);
    }
  }, [fetchOrders, refreshInterval]);

  const refetch = useCallback(() => fetchOrders(false), [fetchOrders]);

  return { orders, loading, error, refetch };
};
```

---

## 💻 Usage in Components

### React Component Example

```typescript
// components/OrderDetail.tsx
import React from 'react';
import { useOrder } from '../hooks/useOrder';

interface OrderDetailProps {
  orderId: string;
}

export const OrderDetail: React.FC<OrderDetailProps> = ({ orderId }) => {
  const { order, loading, error, refetch } = useOrder(orderId, {
    refreshInterval: 30000 // Refresh every 30 seconds
  });

  if (loading) {
    return <div>Loading order...</div>;
  }

  if (error) {
    return (
      <div>
        <p>Error: {error}</p>
        <button onClick={refetch}>Retry</button>
      </div>
    );
  }

  if (!order) {
    return <div>Order not found</div>;
  }

  return (
    <div>
      <h2>Order {order.orderNumber}</h2>
      <p>Status: {OrderStatus[order.status]}</p>
      <p>Customer: {order.customerId}</p>
      <p>Amount: ${order.totalAmount.toFixed(2)}</p>
      <p>Created: {order.createdAt.toLocaleDateString()}</p>
      <button onClick={refetch}>Refresh</button>
    </div>
  );
};
```

### React Native Component Example

```typescript
// screens/OrderListScreen.tsx
import React from 'react';
import { View, Text, FlatList, RefreshControl } from 'react-native';
import { useOrdersByStatus } from '../hooks/useOrder';
import { OrderStatus } from '../types/order';

export const OrderListScreen = () => {
  const { orders, loading, error, refetch } = useOrdersByStatus(
    OrderStatus.Pending
  );

  return (
    <View style={{ flex: 1 }}>
      <FlatList
        data={orders}
        keyExtractor={item => item.id}
        renderItem={({ item }) => (
          <View style={{ padding: 16, borderBottomWidth: 1 }}>
            <Text style={{ fontWeight: 'bold' }}>{item.orderNumber}</Text>
            <Text>${item.totalAmount.toFixed(2)}</Text>
          </View>
        )}
        refreshControl={
          <RefreshControl refreshing={loading} onRefresh={refetch} />
        }
        ListEmptyComponent={
          <Text style={{ textAlign: 'center', marginTop: 20 }}>
            {error ? `Error: ${error}` : 'No pending orders'}
          </Text>
        }
      />
    </View>
  );
};
```

---

## 🔐 Authentication Integration

### Token Storage Service

```typescript
// services/tokenService.ts

export interface TokenData {
  accessToken: string;
  refreshToken: string;
  expiresAt: number; // Timestamp in milliseconds
}

class TokenService {
  private TOKEN_KEY = 'auth_token';

  async saveToken(tokenData: TokenData): Promise<void> {
    try {
      // For web
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem(this.TOKEN_KEY, JSON.stringify(tokenData));
      }
      // For React Native - use AsyncStorage
      // await AsyncStorage.setItem(this.TOKEN_KEY, JSON.stringify(tokenData));
    } catch (error) {
      console.error('Error saving token:', error);
    }
  }

  async getToken(): Promise<TokenData | null> {
    try {
      // For web
      if (typeof localStorage !== 'undefined') {
        const data = localStorage.getItem(this.TOKEN_KEY);
        return data ? JSON.parse(data) : null;
      }
      // For React Native
      // const data = await AsyncStorage.getItem(this.TOKEN_KEY);
      // return data ? JSON.parse(data) : null;
      return null;
    } catch (error) {
      console.error('Error getting token:', error);
      return null;
    }
  }

  async getValidToken(): Promise<string | null> {
    const tokenData = await this.getToken();
    
    if (!tokenData) {
      return null;
    }

    // Check if token is expired (with 5-minute buffer)
    const now = Date.now();
    const buffer = 5 * 60 * 1000; // 5 minutes
    
    if (tokenData.expiresAt - buffer < now) {
      console.log('Token expired or about to expire, needs refresh');
      return null;
    }

    return tokenData.accessToken;
  }

  async getRefreshToken(): Promise<string | null> {
    const tokenData = await this.getToken();
    return tokenData?.refreshToken || null;
  }

  async clearTokens(): Promise<void> {
    try {
      // For web
      if (typeof localStorage !== 'undefined') {
        localStorage.removeItem(this.TOKEN_KEY);
      }
      // For React Native
      // await AsyncStorage.removeItem(this.TOKEN_KEY);
    } catch (error) {
      console.error('Error clearing tokens:', error);
    }
  }
}

export const tokenService = new TokenService();
```

### Auth Service (with Rystem.Authentication.Social)

```typescript
// services/authService.ts

export interface LoginResponse {
  tokenType: string;
  accessToken: string;
  refreshToken: string;
  expiresIn: number; // Seconds
}

export interface UserInfo {
  id: string;
  email: string;
  name: string;
}

class AuthService {
  private apiUrl = process.env.NEXT_PUBLIC_API_URL || "https://api.myapp.com";

  async login(email: string, password: string): Promise<LoginResponse> {
    const response = await fetch(`${this.apiUrl}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });

    if (!response.ok) {
      throw new Error('Login failed');
    }

    return await response.json();
  }

  async refreshToken(refreshToken: string): Promise<LoginResponse> {
    const response = await fetch(`${this.apiUrl}/auth/refresh`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ refreshToken })
    });

    if (!response.ok) {
      throw new Error('Token refresh failed');
    }

    return await response.json();
  }

  async getUserInfo(accessToken: string): Promise<UserInfo | null> {
    const response = await fetch(`${this.apiUrl}/auth/userinfo`, {
      headers: { 
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      }
    });

    if (!response.ok) {
      return null;
    }

    return await response.json();
  }

  async logout(): Promise<void> {
    await tokenService.clearTokens();
  }
}

export const authService = new AuthService();
```

---

## 🔧 Advanced Configuration

### Multiple Repositories with Different URLs

```typescript
RepositoryServices
  .Create("https://api.myapp.com/api/")
  .addRepository<OrderRaw, string>(x => {
    x.name = "Order";
    x.path = "Order"; // Full URL: https://api.myapp.com/api/Order
    x.addHeadersEnricher(() => getAuthHeaders());
  })
  .addRepository<ProductRaw, string>(x => {
    x.name = "Product";
    x.uri = "https://catalog-api.myapp.com/api/Product"; // Override full URL
    x.addHeadersEnricher(() => getAuthHeaders());
  });
```

### CQRS Repositories

```typescript
RepositoryServices
  .Create("https://api.myapp.com/api/")
  // Write operations to primary database
  .addCommand<OrderRaw, string>(x => {
    x.name = "OrderCommand";
    x.path = "Order";
    x.addHeadersEnricher(() => getAuthHeaders());
  })
  // Read operations from read replica
  .addQuery<OrderRaw, string>(x => {
    x.name = "OrderQuery";
    x.uri = "https://read-api.myapp.com/api/Order";
    x.addHeadersEnricher(() => getAuthHeaders());
  });

// Usage in service
const command = RepositoryServices.Command<OrderRaw, string>("OrderCommand");
const query = RepositoryServices.Query<OrderRaw, string>("OrderQuery");

await command.insert(orderId, orderRaw); // Write
const order = await query.get(orderId);   // Read
```

### Multiple Header Enrichers

```typescript
.addRepository<OrderRaw, string>(x => {
  x.name = "Order";
  x.path = "Order";
  
  // Add Authorization header
  x.addHeadersEnricher(async () => {
    const token = await tokenService.getValidToken();
    return { "Authorization": `Bearer ${token}` };
  });
  
  // Add custom tracking header
  x.addHeadersEnricher(async () => {
    return { "X-Request-Id": crypto.randomUUID() };
  });
  
  // Add tenant header (for multi-tenant apps)
  x.addHeadersEnricher(async () => {
    const tenantId = await getTenantId();
    return { "X-Tenant-Id": tenantId };
  });
})
```

### Custom Error Handlers

```typescript
.addRepository<OrderRaw, string>(x => {
  x.name = "Order";
  x.path = "Order";
  
  // Handle 401 Unauthorized
  x.addErrorHandler(async (endpoint, uri, method, headers, body, err) => {
    if (err.status === 401) {
      const refreshed = await refreshAuthToken();
      return refreshed; // true = retry, false = stop
    }
    return false;
  });
  
  // Handle 429 Rate Limit
  x.addErrorHandler(async (endpoint, uri, method, headers, body, err) => {
    if (err.status === 429) {
      const retryAfter = err.headers?.['retry-after'] || 60;
      console.log(`Rate limited. Retrying after ${retryAfter}s`);
      await new Promise(resolve => setTimeout(resolve, retryAfter * 1000));
      return true; // Retry
    }
    return false;
  });
  
  // Handle network errors
  x.addErrorHandler(async (endpoint, uri, method, headers, body, err) => {
    if (err.message?.includes('network')) {
      console.log('Network error detected, retrying...');
      await new Promise(resolve => setTimeout(resolve, 2000));
      return true; // Retry after 2 seconds
    }
    return false;
  });
})
```

---

## 🎯 Best Practices

### 1. Always Map Raw to Clean Types

```typescript
// ✅ GOOD - Clean separation
export interface OrderRaw { i: string; n: string; a: number; }
export interface Order { id: string; orderNumber: string; amount: number; }
export const mapRawToOrder = (raw: OrderRaw): Order => ({ ... });

// ❌ BAD - Using raw types directly in UI
const order: OrderRaw = await repository.get(id);
console.log(order.i); // What is 'i'?
```

### 2. Use Service Layer

```typescript
// ✅ GOOD - Business logic in service
class OrderService {
  async getActiveOrders() {
    const orders = await this.getOrdersByStatus(OrderStatus.Pending);
    return orders.filter(o => o.totalAmount > 0);
  }
}

// ❌ BAD - Business logic in component
const orders = await RepositoryServices.Repository<OrderRaw, string>("Order")
  .query().execute();
const activeOrders = orders.filter(...); // Logic in component!
```

### 3. Use Hooks for React

```typescript
// ✅ GOOD - Reusable hook
const { order, loading, error } = useOrder(orderId);

// ❌ BAD - Direct service call in component
const [order, setOrder] = useState(null);
useEffect(() => {
  orderService.getOrder(orderId).then(setOrder);
}, [orderId]);
```

### 4. Handle Errors Gracefully

```typescript
// ✅ GOOD - Error handling
try {
  const order = await orderService.getOrder(orderId);
  if (!order) {
    showToast('Order not found');
    return;
  }
  // Process order
} catch (error) {
  console.error('Error:', error);
  showToast('Failed to load order');
}

// ❌ BAD - No error handling
const order = await orderService.getOrder(orderId);
processOrder(order); // Will crash if null!
```

### 5. Use TypeScript Generics Correctly

```typescript
// ✅ GOOD - Correct generic types
RepositoryServices.Repository<OrderRaw, string>("Order")
//                             ^entity  ^key

// ❌ BAD - Wrong types
RepositoryServices.Repository<Order, number>("Order")
// Should use OrderRaw (raw interface) and string (key type)
```

---

## ⚠️ Important Notes

1. **Always use Raw types** with Repository client (matching C# JsonPropertyName)
2. **Map to clean types** in your service layer for use in UI
3. **Configure once** at app startup with `setupRepositoryServices()`
4. **Error handlers run in order** - first one returning `true` stops the chain
5. **Header enrichers are called** for every request
6. **CQRS requires separate** `addCommand` and `addQuery` calls
7. **Package name**: `rystem.repository.client` (npm)

---

## 🔗 Related Resources

- **repository-api-server**: How to expose repositories as REST APIs on backend
- **repository-api-client-dotnet**: Client for .NET/C# apps (Blazor, MAUI, WPF)
- **repository-setup**: How to configure repositories on backend
- **auth-flow**: Setting up authentication with Rystem.Authentication.Social

---

## 📖 Further Reading

- [rystem.repository.client GitHub](https://github.com/KeyserDSoze/RepositoryFramework/tree/master/src/RepositoryFramework.Api.Client)
- [TypeScript Client Examples](https://github.com/KeyserDSoze/RepositoryFramework/tree/master/src/RepositoryFramework.Test/RepositoryFramework.Api.Client.Test)

---

## ✅ Summary

**rystem.repository.client** provides:
- ✅ Type-safe repository access from TypeScript/JavaScript
- ✅ Automatic authentication with token refresh
- ✅ Custom error handlers with retry logic
- ✅ LINQ-style queries from client-side
- ✅ Batch operations support
- ✅ CQRS pattern support
- ✅ Works in React, React Native, Next.js, Node.js
- ✅ Multiple header enrichers
- ✅ Custom error handling per repository

**Use this tool to build type-safe, production-ready frontend applications!** 🚀

---

## Repository API Server

> Auto-generate REST APIs from repositories without writing controllers - includes authentication, LINQ queries, and Swagger documentation

---
title: Repository API Server
description: Auto-generate REST APIs from repositories without writing controllers - includes authentication, LINQ queries, and Swagger documentation
---

# Repository API Server - Auto-Generated REST APIs

**Purpose**: This tool explains how to **automatically expose repositories as REST APIs** without writing controllers manually. Rystem.RepositoryFramework can generate complete REST endpoints for your repositories with built-in authentication, authorization, and Swagger documentation.

---

## 🎯 What is Repository API Server?

Rystem.RepositoryFramework includes an **API Server** feature that:
- ✅ **Auto-generates REST APIs** for all registered repositories
- ✅ **No controllers needed** - endpoints are created automatically
- ✅ **Built-in Swagger/OpenAPI** documentation
- ✅ **Flexible authorization** - no auth, default policies, or custom per-repository
- ✅ **LINQ query support** in URL parameters
- ✅ **CORS configuration** out of the box

**Key Benefit**: Register your repository once, get a complete REST API for free!

---

## 📦 Installation

```bash
dotnet add package Rystem.RepositoryFramework.Api.Server --version 9.1.3
dotnet add package Rystem.Api.Server --version 9.1.3
```

---

## 🚀 Quick Start - No Authorization

The simplest setup with no authentication required:

### Step 1: Register Repositories and API Server

```csharp
// Program.cs
var builder = WebApplication.CreateBuilder(args);

// Register repositories
builder.Services.AddRepository<Order, Guid>(settings =>
{
    settings.WithEntityFramework<OrdersDbContext>();
});

builder.Services.AddRepository<Customer, Guid>(settings =>
{
    settings.WithEntityFramework<CustomersDbContext>();
});

// Add API Server
builder.Services.AddApiFromRepositoryFramework()
    .WithDescriptiveName("CargoLens API")
    .WithPath("api")
    .WithVersion("v1")
    .WithSwagger()
    .WithDocumentation()
    .WithDefaultCors("https://app.cargolens.com");

var app = builder.Build();

// Configure middleware
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

// Use API from repositories - NO AUTHORIZATION
app.UseApiFromRepositoryFramework()
    .WithNoAuthorization();

app.Run();
```

### Step 2: Generated Endpoints

The above code automatically generates these REST endpoints:

#### For `Order` entity:
```
GET     /api/v1/order/{id}                 - Get single order
GET     /api/v1/order/exist/{id}          - Check if order exists
POST    /api/v1/order/query               - Query orders with filter
POST    /api/v1/order                     - Create new order
PUT     /api/v1/order/{id}                - Update order
DELETE  /api/v1/order/{id}                - Delete order
POST    /api/v1/order/batch               - Batch operations
GET     /api/v1/order/count               - Count orders
GET     /api/v1/order/max                 - Get max value
GET     /api/v1/order/min                 - Get min value
GET     /api/v1/order/sum                 - Get sum
GET     /api/v1/order/average             - Get average
```

#### For `Customer` entity:
```
GET     /api/v1/customer/{id}
GET     /api/v1/customer/exist/{id}
POST    /api/v1/customer/query
POST    /api/v1/customer
PUT     /api/v1/customer/{id}
DELETE  /api/v1/customer/{id}
POST    /api/v1/customer/batch
... (all CRUD + aggregation operations)
```

### Step 3: Test with Swagger

Navigate to: `https://localhost:5001/swagger`

You'll see all endpoints documented and ready to test!

---

## 🔒 Authorization - Default Policy

Apply a default authorization policy to all endpoints:

```csharp
var builder = WebApplication.CreateBuilder(args);

// Add authentication
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.Authority = "https://login.microsoftonline.com/{tenant-id}";
        options.Audience = "api://cargolens-api";
    });

// Add authorization
builder.Services.AddAuthorization();

// Register repositories
builder.Services.AddRepository<Order, Guid>(settings =>
{
    settings.WithEntityFramework<OrdersDbContext>();
});

// Add API Server
builder.Services.AddApiFromRepositoryFramework()
    .WithDescriptiveName("CargoLens API")
    .WithPath("api")
    .WithVersion("v1")
    .WithSwagger()
    .WithDocumentation();

var app = builder.Build();

app.UseHttpsRedirection();
app.UseAuthentication();
app.UseAuthorization();

// Use API with DEFAULT authorization
app.UseApiFromRepositoryFramework()
    .WithDefaultAuthorization();

app.Run();
```

**Result**: All endpoints require authentication (valid JWT token).

---

## 🔐 Authorization - Custom Policies

Apply different policies to different operations:

### Setup Policies

```csharp
var builder = WebApplication.CreateBuilder(args);

// Authentication setup
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(/* ... */);

// Authorization policies
builder.Services.AddAuthorization(options =>
{
    options.AddPolicy("NormalUser", policy =>
    {
        policy.RequireClaim(ClaimTypes.Name);
    });
    
    options.AddPolicy("Admin", policy =>
    {
        policy.RequireRole("Admin");
    });
    
    options.AddPolicy("SuperAdmin", policy =>
    {
        policy.RequireRole("SuperAdmin");
    });
});

// Register repositories
builder.Services.AddRepository<Order, Guid>(settings =>
{
    settings.WithEntityFramework<OrdersDbContext>();
});

builder.Services.AddRepository<Customer, Guid>(settings =>
{
    settings.WithEntityFramework<CustomersDbContext>();
});

// Add API Server
builder.Services.AddApiFromRepositoryFramework()
    .WithDescriptiveName("CargoLens API")
    .WithPath("api")
    .WithVersion("v1")
    .WithSwagger();

var app = builder.Build();

app.UseHttpsRedirection();
app.UseAuthentication();
app.UseAuthorization();

// Configure authorization per repository and method
app.UseEndpoints(endpoints =>
{
    // Order: SuperAdmin required for write operations
    endpoints.UseApiFromRepository<Order>()
        .SetPolicyForCommand()  // Insert, Update, Delete
        .With("SuperAdmin")
        .Build();
    
    // All other repositories: NormalUser for read, Admin for write
    endpoints.UseApiFromRepositoryFramework()
        .SetPolicyForAll()
        .With("NormalUser")  // Default for all operations
        .And()
        .SetPolicy(RepositoryMethods.Insert)
        .With("Admin")
        .And()
        .SetPolicy(RepositoryMethods.Update)
        .With("Admin")
        .And()
        .SetPolicy(RepositoryMethods.Delete)
        .With("Admin")
        .Build();
});

app.Run();
```

### Available Repository Methods

```csharp
RepositoryMethods.Get          // GET /{id}
RepositoryMethods.Exist        // GET /exist/{id}
RepositoryMethods.Query        // POST /query
RepositoryMethods.Insert       // POST /
RepositoryMethods.Update       // PUT /{id}
RepositoryMethods.Delete       // DELETE /{id}
RepositoryMethods.Batch        // POST /batch
RepositoryMethods.Count        // GET /count
RepositoryMethods.Max          // GET /max
RepositoryMethods.Min          // GET /min
RepositoryMethods.Sum          // GET /sum
RepositoryMethods.Average      // GET /average
```

---

## 🚫 Excluding Repositories from API

Sometimes you want a repository for internal use only (not exposed as API):

```csharp
builder.Services.AddRepository<InternalAuditLog, Guid>(settings =>
{
    settings.WithEntityFramework<AuditDbContext>();
    settings.SetNotExposable();  // ⚠️ NOT exposed as API
});

builder.Services.AddRepository<Order, Guid>(settings =>
{
    settings.WithEntityFramework<OrdersDbContext>();
    // This WILL be exposed as API (default)
});
```

**Result**: 
- `Order` endpoints are generated ✅
- `InternalAuditLog` endpoints are NOT generated ❌

---

## 🔍 Query API - Using LINQ Expressions

The most powerful feature: **Query with LINQ expressions in HTTP requests**!

### Query Endpoint

```
POST /api/v1/order/query
Content-Type: application/json
```

### Simple Filter

```json
{
  "filter": "ƒ => (ƒ.Status == 2)",
  "top": 10,
  "skip": 0,
  "orderBy": "CreatedAt",
  "ascending": false
}
```

**Explanation**: 
- `ƒ` is the entity variable
- `ƒ.Status == 2` filters where Status equals 2 (e.g., Shipped)
- `top` and `skip` for pagination
- `orderBy` sorts by property name

### Complex Filter with AND/OR

```json
{
  "filter": "ƒ => ((ƒ.Status == 2) AndAlso (ƒ.CustomerId == Guid.Parse(\"bf46510b-b7e6-4ba2-88da-cef208aa81f2\")))"
}
```

### String Operations

```json
{
  "filter": "ƒ => (ƒ.OrderNumber.Contains(\"ORD-\"))"
}
```

```json
{
  "filter": "ƒ => Not(String.IsNullOrWhiteSpace(ƒ.CustomerName))"
}
```

### Date Comparisons

```json
{
  "filter": "ƒ => (ƒ.CreatedAt > Convert.ToDateTime(\"2024-01-01\"))"
}
```

### Collections

```json
{
  "filter": "ƒ => (ƒ.Tags.Any(x => (x == \"urgent\")))"
}
```

### Nested Properties

```json
{
  "filter": "ƒ => (ƒ.Customer.Address.City == \"Milan\")"
}
```

### Complex Example

```json
{
  "filter": "ƒ => ((((ƒ.Status == 2) AndAlso (ƒ.TotalAmount > 1000)) OrElse (ƒ.Priority == \"High\")) AndAlso (ƒ.CreatedAt > Convert.ToDateTime(\"2024-01-01\")))",
  "top": 20,
  "skip": 0,
  "orderBy": "TotalAmount",
  "ascending": false
}
```

**Translation**: 
```
Get orders where:
  (Status is Shipped AND TotalAmount > 1000) 
  OR Priority is High
  AND CreatedAt after Jan 1, 2024
Order by TotalAmount descending
Take 20 results
```

---

## 📝 CRUD Operations Examples

### Create (Insert)

```http
POST /api/v1/order
Content-Type: application/json

{
  "key": "bf46510b-b7e6-4ba2-88da-cef208aa81f2",
  "value": {
    "orderNumber": "ORD-12345",
    "customerId": "550e8400-e29b-41d4-a716-446655440000",
    "status": 0,
    "createdAt": "2024-10-21T10:00:00Z",
    "totalAmount": 1500.50
  }
}
```

### Read (Get)

```http
GET /api/v1/order/bf46510b-b7e6-4ba2-88da-cef208aa81f2
```

Response:
```json
{
  "id": "bf46510b-b7e6-4ba2-88da-cef208aa81f2",
  "orderNumber": "ORD-12345",
  "customerId": "550e8400-e29b-41d4-a716-446655440000",
  "status": 0,
  "createdAt": "2024-10-21T10:00:00Z",
  "totalAmount": 1500.50
}
```

### Update

```http
PUT /api/v1/order/bf46510b-b7e6-4ba2-88da-cef208aa81f2
Content-Type: application/json

{
  "orderNumber": "ORD-12345",
  "customerId": "550e8400-e29b-41d4-a716-446655440000",
  "status": 2,
  "createdAt": "2024-10-21T10:00:00Z",
  "totalAmount": 1500.50
}
```

### Delete

```http
DELETE /api/v1/order/bf46510b-b7e6-4ba2-88da-cef208aa81f2
```

### Check Existence

```http
GET /api/v1/order/exist/bf46510b-b7e6-4ba2-88da-cef208aa81f2
```

Response:
```json
{
  "exists": true
}
```

---

## 🔢 Aggregation Operations

### Count

```http
GET /api/v1/order/count?filter=ƒ => (ƒ.Status == 2)
```

Response:
```json
{
  "count": 42
}
```

### Max

```http
GET /api/v1/order/max?property=TotalAmount
```

### Min

```http
GET /api/v1/order/min?property=TotalAmount
```

### Sum

```http
GET /api/v1/order/sum?property=TotalAmount&filter=ƒ => (ƒ.Status == 3)
```

### Average

```http
GET /api/v1/order/average?property=TotalAmount
```

---

## 📦 Batch Operations

Execute multiple operations in a single request:

```http
POST /api/v1/order/batch
Content-Type: application/json

{
  "operations": [
    {
      "type": "insert",
      "key": "guid-1",
      "value": { /* order data */ }
    },
    {
      "type": "update",
      "key": "guid-2",
      "value": { /* updated order data */ }
    },
    {
      "type": "delete",
      "key": "guid-3"
    }
  ]
}
```

Response:
```json
{
  "results": [
    {
      "key": "guid-1",
      "success": true,
      "message": "Inserted successfully"
    },
    {
      "key": "guid-2",
      "success": true,
      "message": "Updated successfully"
    },
    {
      "key": "guid-3",
      "success": false,
      "message": "Order not found"
    }
  ]
}
```

---

## 🌐 CORS Configuration

### Default CORS (Single Origin)

```csharp
builder.Services.AddApiFromRepositoryFramework()
    .WithDefaultCors("https://app.cargolens.com");
```

### Multiple Origins

```csharp
builder.Services.AddCors(options =>
{
    options.AddPolicy("CargoLensPolicy", policy =>
    {
        policy.WithOrigins(
            "https://app.cargolens.com",
            "https://admin.cargolens.com",
            "http://localhost:3000"
        )
        .AllowAnyMethod()
        .AllowAnyHeader()
        .AllowCredentials();
    });
});

var app = builder.Build();

app.UseCors("CargoLensPolicy");
```

---

## 📚 Real-World Example: Complete Setup

```csharp
// Program.cs
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Rystem;

var builder = WebApplication.CreateBuilder(args);

// Database
builder.Services.AddDbContext<OrdersDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("OrdersDb")));

builder.Services.AddDbContext<CustomersDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("CustomersDb")));

// Authentication
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.Authority = builder.Configuration["AzureAd:Authority"];
        options.Audience = builder.Configuration["AzureAd:ClientId"];
    });

// Authorization policies
builder.Services.AddAuthorization(options =>
{
    options.AddPolicy("User", policy =>
    {
        policy.RequireClaim("roles", "User");
    });
    
    options.AddPolicy("Admin", policy =>
    {
        policy.RequireClaim("roles", "Admin");
    });
});

// Repositories
builder.Services.AddRepository<Order, Guid>(settings =>
{
    settings.WithEntityFramework<OrdersDbContext>();
});

builder.Services.AddRepository<Customer, Guid>(settings =>
{
    settings.WithEntityFramework<CustomersDbContext>();
});

builder.Services.AddRepository<Shipment, Guid>(settings =>
{
    settings.WithEntityFramework<OrdersDbContext>();
});

// Internal repository - NOT exposed
builder.Services.AddRepository<AuditLog, Guid>(settings =>
{
    settings.WithEntityFramework<OrdersDbContext>();
    settings.SetNotExposable();
});

// API Server
builder.Services.AddApiFromRepositoryFramework()
    .WithDescriptiveName("CargoLens API")
    .WithPath("api")
    .WithVersion("v1")
    .WithSwagger()
    .WithDocumentation()
    .WithDefaultCors("https://app.cargolens.com");

var app = builder.Build();

// Middleware
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(options =>
    {
        options.SwaggerEndpoint("/swagger/v1/swagger.json", "CargoLens API v1");
        options.RoutePrefix = "swagger";
    });
}

app.UseHttpsRedirection();
app.UseAuthentication();
app.UseAuthorization();

// Configure API authorization
app.UseEndpoints(endpoints =>
{
    // Health check
    endpoints.MapHealthChecks("/healthz");
    
    // Order API: Admin only for write operations
    endpoints.UseApiFromRepository<Order>()
        .SetPolicyForCommand()
        .With("Admin")
        .Build();
    
    // Customer API: Admin only for write operations
    endpoints.UseApiFromRepository<Customer>()
        .SetPolicyForCommand()
        .With("Admin")
        .Build();
    
    // Shipment API: User can read, Admin can write
    endpoints.UseApiFromRepository<Shipment>()
        .SetPolicyForQuery()
        .With("User")
        .And()
        .SetPolicyForCommand()
        .With("Admin")
        .Build();
    
    // All other repositories: Default authorization
    endpoints.UseApiFromRepositoryFramework()
        .SetPolicyForAll()
        .With("User")
        .Build();
});

app.Run();
```

**Generated Endpoints**:
```
✅ /api/v1/order/*        - Admin required for POST/PUT/DELETE
✅ /api/v1/customer/*     - Admin required for POST/PUT/DELETE
✅ /api/v1/shipment/*     - User for GET, Admin for POST/PUT/DELETE
❌ /api/v1/auditlog/*     - NOT exposed (SetNotExposable)
```

---

## 📋 Configuration Options

### AddApiFromRepositoryFramework Options

```csharp
builder.Services.AddApiFromRepositoryFramework()
    .WithDescriptiveName("API Display Name")
    .WithPath("api")                // Base path (default: "api")
    .WithVersion("v1")              // Version (default: "v1")
    .WithSwagger()                  // Enable Swagger UI
    .WithDocumentation()            // Enable XML documentation
    .WithDefaultCors("origin");     // Single CORS origin
```

### UseApiFromRepositoryFramework Options

```csharp
// No authorization (default)
app.UseApiFromRepositoryFramework()
    .WithNoAuthorization();

// Default authorization (requires authenticated user)
app.UseApiFromRepositoryFramework()
    .WithDefaultAuthorization();

// Custom per-repository authorization
app.UseEndpoints(endpoints =>
{
    endpoints.UseApiFromRepository<Order>()
        .SetPolicyForCommand()      // All write operations
        .With("PolicyName")
        .And()
        .SetPolicyForQuery()        // All read operations
        .With("PolicyName")
        .And()
        .SetPolicy(RepositoryMethods.Insert)  // Specific method
        .With("PolicyName")
        .Build();
});
```

---

## 🎯 Best Practices

### 1. Always Use Policies for Production

```csharp
// ❌ BAD - No authorization in production
app.UseApiFromRepositoryFramework()
    .WithNoAuthorization();

// ✅ GOOD - Proper authorization
app.UseEndpoints(endpoints =>
{
    endpoints.UseApiFromRepositoryFramework()
        .SetPolicyForAll()
        .With("User")
        .And()
        .SetPolicyForCommand()
        .With("Admin")
        .Build();
});
```

### 2. Hide Internal Repositories

```csharp
// ✅ GOOD - Internal repositories not exposed
builder.Services.AddRepository<AuditLog, Guid>(settings =>
{
    settings.WithEntityFramework<AuditDbContext>();
    settings.SetNotExposable();
});
```

### 3. Use Different Policies for Different Entities

```csharp
// ✅ GOOD - Fine-grained control
endpoints.UseApiFromRepository<Order>()
    .SetPolicyForCommand()
    .With("OrderAdmin")
    .Build();

endpoints.UseApiFromRepository<Customer>()
    .SetPolicyForCommand()
    .With("CustomerAdmin")
    .Build();
```

### 4. Enable Swagger Only in Development

```csharp
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}
```

### 5. Use Health Checks

```csharp
builder.Services.AddHealthChecks()
    .AddDbContextCheck<OrdersDbContext>();

app.MapHealthChecks("/healthz");
```

---

## ⚠️ Important Notes

1. **Package Required**: `Rystem.RepositoryFramework.Api.Server` version 9.1.3
2. **Automatic Swagger**: Swagger is auto-configured when you use `.WithSwagger()`
3. **Default Behavior**: Repositories are exposed by default unless you use `.SetNotExposable()`
4. **LINQ Syntax**: Query filters use C# LINQ expression syntax (converted from string)
5. **Authorization Precedence**: Specific repository policies override global policies
6. **CORS**: Always configure CORS for production frontends

---

## 🔗 Related Resources

- **repository-setup**: How to configure repositories
- **repository-api-client-typescript**: Consume these APIs from TypeScript/JavaScript apps
- **repository-api-client-dotnet**: Consume these APIs from .NET/C# apps (Blazor, MAUI, WPF)
- **ddd-single-domain**: Organizing repositories in single-domain architecture
- **ddd-multi-domain**: Organizing repositories in multi-domain architecture
- **auth-flow**: Setting up authentication with Rystem.Authentication.Social

---

## 📖 Further Reading

- [Rystem.RepositoryFramework.Api.Server GitHub](https://github.com/KeyserDSoze/RepositoryFramework/tree/master/src/RepositoryFramework.Api.Server)
- [API Server Examples](https://github.com/KeyserDSoze/RepositoryFramework/tree/master/src/RepositoryFramework.Test/RepositoryFramework.Api.Server.Test)
- [Rystem.Api.Server Documentation](https://github.com/KeyserDSoze/Rystem/tree/master/src/Api/Rystem.Api.Server)

---

## ✅ Summary

**Rystem.RepositoryFramework.Api.Server** provides:
- ✅ Zero-code REST API generation
- ✅ Complete CRUD operations for all repositories
- ✅ LINQ query support in HTTP requests
- ✅ Flexible authorization (none, default, custom per-repository)
- ✅ Automatic Swagger/OpenAPI documentation
- ✅ Batch operations support
- ✅ Aggregation operations (Count, Max, Min, Sum, Average)
- ✅ CORS configuration
- ✅ Option to hide internal repositories

**Use this tool to quickly expose your repositories as production-ready REST APIs!** 🚀

---

## Repository Pattern Setup

> Configure data access with Rystem.RepositoryFramework - CQRS, multiple storage backends, business logic injection, and Factory pattern support

---
title: Repository Pattern Setup
description: Configure data access with Rystem.RepositoryFramework - CQRS, multiple storage backends, business logic injection, and Factory pattern support
---

# Repository Pattern Setup

**Purpose**: This tool explains how to implement the **Repository Pattern** using **Rystem.RepositoryFramework**. This is the **REQUIRED tool** to use whenever you need to implement data access in a Rystem application.

---



## 🎯 What is Rystem.RepositoryFramework?This tool helps you configure and setup the Rystem Repository Framework in your .NET project. It provides guidance for implementing the Repository pattern and CQRS (Command Query Responsibility Segregation).



Rystem.RepositoryFramework is a powerful abstraction layer for data access that:## Usage

- ✅ Implements **Repository Pattern** and **CQRS** out of the box

- ✅ Supports **multiple storage backends** (SQL, NoSQL, Blob, Table Storage, Cosmos DB)Use this tool when you need to:

- ✅ Provides **unified API** for all storage types- Set up a new repository for your entities

- ✅ Includes **business logic injection** (before/after operations)- Configure multiple storage backends (Entity Framework, Cosmos DB, Azure Storage, etc.)

- ✅ Supports **multiple implementations** with Factory pattern- Implement CQRS patterns in your application

- ✅ Built-in **caching**, **translation**, and **batch operations**- Add caching layers to your repositories



**Key Benefit**: Write your repository once, swap storage implementations without changing business logic!## Installation



---```bash

dotnet add package Rystem.RepositoryFramework.Abstractions

## 📦 Installationdotnet add package Rystem.RepositoryFramework.Infrastructure.EntityFramework

```

### Core Package (Required)

```bash## Basic Setup

dotnet add package Rystem.RepositoryFramework.Abstractions --version 9.1.3

``````csharp

// Program.cs

### Storage Backends (Choose One or More)builder.Services.AddRepository<User, string>(repositoryBuilder =>

{

**Entity Framework (SQL)**:    repositoryBuilder

```bash        .WithEntityFramework<ApplicationDbContext>(options =>

dotnet add package Rystem.RepositoryFramework.Infrastructure.EntityFramework --version 9.1.3        {

dotnet add package Microsoft.EntityFrameworkCore.SqlServer --version 9.0.0            options.AddForSqlServer(builder.Configuration["ConnectionStrings:Default"]);

# Or PostgreSQL, SQLite, etc.        });

```});

```

**Azure Cosmos DB (NoSQL)**:

```bash## Advanced Configuration

dotnet add package Rystem.RepositoryFramework.Infrastructure.Azure.Cosmos.Sql --version 9.1.3

``````csharp

// With caching

**Azure Blob Storage (NoSQL)**:builder.Services.AddRepository<Product, int>(repositoryBuilder =>

```bash{

dotnet add package Rystem.RepositoryFramework.Infrastructure.Azure.Storage.Blob --version 9.1.3    repositoryBuilder

```        .WithEntityFramework<CatalogDbContext>()

        .WithCache(cache =>

**Azure Table Storage (NoSQL)**:        {

```bash            cache.WithDistributedCache();

dotnet add package Rystem.RepositoryFramework.Infrastructure.Azure.Storage.Table --version 9.1.3            cache.WithDefaultExpiration(TimeSpan.FromMinutes(5));

```        });

});

---

// With CQRS

## 🏗️ Core Conceptsbuilder.Services.AddRepositoryFrameworkCQRS<Order, Guid>(cqrs =>

{

### 1. Repository Interfaces (CQRS)    cqrs.WithCommand(command =>

    {

Rystem.RepositoryFramework is based on **CQRS** principles:        command.WithCosmosDb(/* config */);

    });

#### ICommand (Write Operations)    cqrs.WithQuery(query =>

```csharp    {

public interface ICommandPattern<T, TKey>        query.WithBlobStorage(/* config */);

    where TKey : notnull    });

{});

    Task<State<T, TKey>> InsertAsync(TKey key, T value, CancellationToken cancellationToken = default);```

    Task<State<T, TKey>> UpdateAsync(TKey key, T value, CancellationToken cancellationToken = default);

    Task<State<T, TKey>> DeleteAsync(TKey key, CancellationToken cancellationToken = default);## Patterns

    IAsyncEnumerable<BatchResult<T, TKey>> BatchAsync(BatchOperations<T, TKey> operations, CancellationToken cancellationToken = default);

}### Repository Pattern

```Use for standard CRUD operations with a single storage backend and optional caching.



#### IQuery (Read Operations)### CQRS Pattern

```csharpUse when you need different storage or optimization strategies for reads vs writes.

public interface IQueryPattern<T, TKey>

    where TKey : notnull## See Also

{

    Task<State<T, TKey>> ExistAsync(TKey key, CancellationToken cancellationToken = default);- [Rystem.RepositoryFramework Documentation](https://github.com/KeyserDSoze/Rystem/tree/master/src/Repository)

    Task<T?> GetAsync(TKey key, CancellationToken cancellationToken = default);- [Entity Framework Integration](https://github.com/KeyserDSoze/Rystem/tree/master/src/Repository/Rystem.RepositoryFramework.Infrastructure.EntityFramework)

    IAsyncEnumerable<Entity<T, TKey>> QueryAsync(IFilterExpression filter, CancellationToken cancellationToken = default);- [CQRS Implementation](https://github.com/KeyserDSoze/Rystem/tree/master/src/Repository/Rystem.RepositoryFramework.Abstractions)

    ValueTask<TProperty> OperationAsync<TProperty>(OperationType<TProperty> operation, IFilterExpression filter, CancellationToken cancellationToken = default);
}
```

#### IRepository (Combined)
```csharp
public interface IRepositoryPattern<T, TKey> : ICommandPattern<T, TKey>, IQueryPattern<T, TKey>
    where TKey : notnull
{
    // Includes all methods from ICommand and IQuery
}
```

**⚠️ Important**: Always inject `IRepository<T, TKey>`, NOT `IRepositoryPattern<T, TKey>`!

---

## 🚀 Quick Start Examples

### Example 1: Simple Repository with Entity Framework

#### Step 1: Define Your Entity
```csharp
namespace CargoLens.Orders.Core.Entities;

public class Order
{
    public Guid Id { get; set; }
    public string OrderNumber { get; set; } = string.Empty;
    public Guid CustomerId { get; set; }
    public OrderStatus Status { get; set; }
    public DateTime CreatedAt { get; set; }
}

public enum OrderStatus
{
    Pending,
    Confirmed,
    Shipped,
    Delivered,
    Cancelled
}
```

#### Step 2: Register Repository in DI
```csharp
// Program.cs or Startup.cs
using Rystem;

services.AddDbContext<OrdersDbContext>(options =>
    options.UseSqlServer(configuration.GetConnectionString("OrdersDb")));

services.AddRepository<Order, Guid>(builder =>
{
    builder.WithEntityFramework<OrdersDbContext>();
});
```

#### Step 3: Use in Your Service
```csharp
namespace CargoLens.Orders.Business.Services;

public class OrderService
{
    private readonly IRepository<Order, Guid> _orderRepository;
    
    public OrderService(IRepository<Order, Guid> orderRepository)
    {
        _orderRepository = orderRepository;
    }
    
    public async Task<Order?> GetOrderAsync(Guid orderId)
    {
        return await _orderRepository.GetAsync(orderId);
    }
    
    public async Task<State<Order, Guid>> CreateOrderAsync(Order order)
    {
        return await _orderRepository.InsertAsync(order.Id, order);
    }
    
    public async Task<List<Order>> GetPendingOrdersAsync()
    {
        var query = await _orderRepository
            .Where(x => x.Status == OrderStatus.Pending)
            .ToListAsync();
        
        return query.Select(x => x.Value!).ToList();
    }
}
```

---

### Example 2: Complex Key (Multi-Property)

Many entities have composite keys. Rystem handles this elegantly.

#### Option 1: Using Record (Recommended)
```csharp
// Define composite key as record
public record OrderItemKey(Guid OrderId, int ItemNumber);

public class OrderItem
{
    public Guid OrderId { get; set; }
    public int ItemNumber { get; set; }
    public string ProductName { get; set; }
    public int Quantity { get; set; }
    public decimal Price { get; set; }
}

// Register
services.AddRepository<OrderItem, OrderItemKey>(builder =>
{
    builder.WithEntityFramework<OrdersDbContext>();
});

// Use
var item = await _repository.GetAsync(new OrderItemKey(orderId, 1));
```

#### Option 2: Using IDefaultKey (Auto-Parsing)
```csharp
public class OrderItemKey : IDefaultKey
{
    public Guid OrderId { get; set; }
    public int ItemNumber { get; set; }
}

// Set custom separator (optional, default is |||)
IDefaultKey.SetDefaultSeparator("$$$");

// Key will be serialized as: {OrderId}$$${ItemNumber}
var keyString = key.AsString();
var parsedKey = IDefaultKey.Parse(keyString);
```

#### Option 3: Using IKey (Custom Parsing)
```csharp
public class OrderItemKey : IKey
{
    public Guid OrderId { get; set; }
    public int ItemNumber { get; set; }
    
    public static IKey Parse(string keyAsString)
    {
        var parts = keyAsString.Split('$');
        return new OrderItemKey 
        { 
            OrderId = Guid.Parse(parts[0]), 
            ItemNumber = int.Parse(parts[1]) 
        };
    }
    
    public string AsString()
    {
        return $"{OrderId}${ItemNumber}";
    }
}
```

#### Option 4: Using Built-in Key<T1, T2, ...>
Rystem provides generic key types for 2-5 properties:

```csharp
// For 2 properties
services.AddRepository<OrderItem, Key<Guid, int>>(builder =>
{
    builder.WithEntityFramework<OrdersDbContext>();
});

// Usage
var key = new Key<Guid, int>(orderId, itemNumber);
var item = await _repository.GetAsync(key);

// Available: Key<T1, T2>, Key<T1, T2, T3>, Key<T1, T2, T3, T4>, Key<T1, T2, T3, T4, T5>
```

---

### Example 3: CQRS (Separate Read and Write)

When you have different storage for reads and writes:

```csharp
// Write to SQL Server
services.AddCommand<Order, Guid>(builder =>
{
    builder.WithEntityFramework<OrdersDbContext>();
});

// Read from In-Memory Cache or different DB
services.AddQuery<Order, Guid>(builder =>
{
    builder.WithInMemory(options =>
    {
        options.PopulateWithRandomData(100, 10); // For testing
    });
    // Or read from read-replica
    // builder.WithEntityFramework<OrdersReadDbContext>();
});

// Inject separately
public class OrderService
{
    private readonly ICommand<Order, Guid> _orderCommand;
    private readonly IQuery<Order, Guid> _orderQuery;
    
    public OrderService(
        ICommand<Order, Guid> orderCommand,
        IQuery<Order, Guid> orderQuery)
    {
        _orderCommand = orderCommand;
        _orderQuery = orderQuery;
    }
    
    public async Task CreateOrderAsync(Order order)
    {
        await _orderCommand.InsertAsync(order.Id, order);
    }
    
    public async Task<Order?> GetOrderAsync(Guid id)
    {
        return await _orderQuery.GetAsync(id);
    }
}
```

---

## 🏭 Factory Pattern (Multiple Implementations)

Rystem integrates with **IFactory** from `Rystem.DependencyInjection` to support multiple repository implementations for the same entity.

### Use Case
You want:
- Primary storage: SQL Server
- Cache: In-Memory or Redis
- Backup: Azure Blob Storage

### Setup
```csharp
services.AddRepository<Order, Guid>(builder =>
{
    builder.WithEntityFramework<OrdersDbContext>();
}, "primary"); // Factory key

services.AddRepository<Order, Guid>(builder =>
{
    builder.WithInMemory();
}, "cache"); // Factory key

services.AddRepository<Order, Guid>(builder =>
{
    builder.WithBlobStorage(options =>
    {
        options.ConnectionString = configuration["Azure:Storage"];
        options.ContainerName = "orders-backup";
    });
}, "backup"); // Factory key
```

### Usage
```csharp
public class OrderService
{
    private readonly IFactory<IRepository<Order, Guid>> _repositoryFactory;
    
    public OrderService(IFactory<IRepository<Order, Guid>> repositoryFactory)
    {
        _repositoryFactory = repositoryFactory;
    }
    
    public async Task<Order?> GetOrderAsync(Guid orderId)
    {
        // Try cache first
        var cacheRepo = _repositoryFactory.Create("cache");
        var cached = await cacheRepo.GetAsync(orderId);
        if (cached != null) return cached;
        
        // Fallback to primary
        var primaryRepo = _repositoryFactory.Create("primary");
        var order = await primaryRepo.GetAsync(orderId);
        
        // Store in cache
        if (order != null)
        {
            await cacheRepo.InsertAsync(orderId, order);
        }
        
        return order;
    }
    
    public async Task BackupOrderAsync(Guid orderId)
    {
        var primaryRepo = _repositoryFactory.Create("primary");
        var backupRepo = _repositoryFactory.Create("backup");
        
        var order = await primaryRepo.GetAsync(orderId);
        if (order != null)
        {
            await backupRepo.InsertAsync(orderId, order);
        }
    }
}
```

**Default Repository**: The **last registered** repository is injected by default when you use `IRepository<T, TKey>` directly.

```csharp
// This will inject the "backup" repository (last one registered)
public OrderService(IRepository<Order, Guid> repository)
{
    _repository = repository;
}
```

---

## 🔧 Query Operations

Rystem provides powerful LINQ-like query capabilities:

### Basic Queries
```csharp
// Get single item
var order = await _repository.GetAsync(orderId);

// Check existence
var exists = await _repository.ExistAsync(orderId);

// Get all
var allOrders = await _repository.QueryAsync().ToListAsync();

// Filter
var pendingOrders = await _repository
    .Where(x => x.Status == OrderStatus.Pending)
    .ToListAsync();

// Multiple conditions
var recentOrders = await _repository
    .Where(x => x.Status == OrderStatus.Confirmed && x.CreatedAt > DateTime.UtcNow.AddDays(-7))
    .ToListAsync();
```

### Sorting and Paging
```csharp
// Order by
var orderedOrders = await _repository
    .Where(x => x.Status == OrderStatus.Shipped)
    .OrderBy(x => x.CreatedAt)
    .ToListAsync();

// Order by descending
var latestOrders = await _repository
    .OrderByDescending(x => x.CreatedAt)
    .Top(10)
    .ToListAsync();

// Pagination
var page = await _repository
    .Where(x => x.Status == OrderStatus.Delivered)
    .OrderByDescending(x => x.CreatedAt)
    .PageAsync(pageNumber: 1, pageSize: 20);

// Skip and Take
var orders = await _repository
    .OrderBy(x => x.OrderNumber)
    .Skip(50)
    .Top(25)
    .ToListAsync();
```

### Aggregations
```csharp
// Count
var count = await _repository
    .Where(x => x.Status == OrderStatus.Pending)
    .CountAsync();

// Max
var maxOrderId = await _repository.MaxAsync(x => x.Id);

// Min
var minCreationDate = await _repository.MinAsync(x => x.CreatedAt);

// Sum (requires numeric property)
var totalQuantity = await _repository
    .Where(x => x.Status == OrderStatus.Delivered)
    .SumAsync(x => x.TotalQuantity);

// Average
var avgOrderValue = await _repository.AverageAsync(x => x.TotalAmount);
```

### First and Single
```csharp
// First or default
var firstOrder = await _repository
    .Where(x => x.CustomerId == customerId)
    .OrderBy(x => x.CreatedAt)
    .FirstOrDefaultAsync();

// Single or default (expects 0 or 1 result)
var order = await _repository
    .Where(x => x.OrderNumber == "ORD-12345")
    .SingleOrDefaultAsync();
```

---

## 🔄 Batch Operations

Execute multiple operations in a single call:

```csharp
var batchOperation = _repository.CreateBatchOperation();

// Add operations
for (var i = 0; i < 100; i++)
{
    var order = new Order 
    { 
        Id = Guid.NewGuid(), 
        OrderNumber = $"ORD-{i:D5}",
        Status = OrderStatus.Pending 
    };
    batchOperation.Insert(order.Id, order);
}

// Execute all at once
var results = await batchOperation.ExecuteAsync().ToListAsync();

// Check results
foreach (var result in results)
{
    if (!result.State.IsOk)
    {
        Console.WriteLine($"Failed: {result.Key} - {result.State.Message}");
    }
}
```

### Batch with Mixed Operations
```csharp
var batch = _repository.CreateBatchOperation();

// Insert
batch.Insert(newOrder.Id, newOrder);

// Update
batch.Update(existingOrder.Id, existingOrder);

// Delete
batch.Delete(oldOrderId);

await batch.ExecuteAsync().ToListAsync();
```

---

## 🌍 Translation (Property Mapping)

When your database schema differs from your domain model:

```csharp
// Domain model
public class Order
{
    public Guid Id { get; set; }
    public string OrderNumber { get; set; }
    public string CustomerEmail { get; set; }
}

// Database model
public class OrderEntity
{
    public Guid Identificativo { get; set; }
    public string NumeroOrdine { get; set; }
    public string EmailCliente { get; set; }
}

// Configure translation
services.AddRepository<Order, Guid>(builder =>
{
    builder.WithEntityFramework<OrdersDbContext>();
    
    builder.Translate<OrderEntity>()
        .With(x => x.Id, x => x.Identificativo)
        .With(x => x.OrderNumber, x => x.NumeroOrdine)
        .With(x => x.CustomerEmail, x => x.EmailCliente);
});
```

Now when you query:
```csharp
// This query on Order model...
var orders = await _repository
    .Where(x => x.CustomerEmail.Contains("@gmail.com"))
    .ToListAsync();

// ...is automatically translated to OrderEntity:
// context.Orders.Where(x => x.EmailCliente.Contains("@gmail.com"))
```

**How to Use Translation in Repository Implementation**:
```csharp
public class OrderRepository : IRepository<Order, Guid>
{
    private readonly OrdersDbContext _context;
    
    public async IAsyncEnumerable<Entity<Order, Guid>> QueryAsync(
        IFilterExpression filter, 
        CancellationToken cancellationToken = default)
    {
        // Apply translation and convert to IQueryable
        await foreach (var entity in filter.ApplyAsAsyncEnumerable(_context.Orders))
        {
            yield return new Entity<Order, Guid>
            {
                Key = entity.Identificativo,
                Value = new Order
                {
                    Id = entity.Identificativo,
                    OrderNumber = entity.NumeroOrdine,
                    CustomerEmail = entity.EmailCliente
                }
            };
        }
    }
}
```

---

## 💼 Business Logic Injection

Execute custom logic before or after repository operations:

### Create Business Class
```csharp
public class OrderBusinessLogic : 
    IRepositoryBusinessBeforeInsert<Order, Guid>,
    IRepositoryBusinessAfterInsert<Order, Guid>,
    IRepositoryBusinessBeforeUpdate<Order, Guid>,
    IRepositoryBusinessBeforeDelete<Order, Guid>
{
    private readonly ILogger<OrderBusinessLogic> _logger;
    
    public OrderBusinessLogic(ILogger<OrderBusinessLogic> logger)
    {
        _logger = logger;
    }
    
    // Before insert - validation
    public Task<State<Order, Guid>> BeforeInsertAsync(
        Entity<Order, Guid> entity, 
        CancellationToken cancellationToken = default)
    {
        var order = entity.Value;
        
        // Validation
        if (string.IsNullOrWhiteSpace(order.OrderNumber))
        {
            return Task.FromResult(State.Error<Order, Guid>("Order number is required"));
        }
        
        // Auto-generate values
        if (order.CreatedAt == default)
        {
            order.CreatedAt = DateTime.UtcNow;
        }
        
        _logger.LogInformation("Creating order {OrderNumber}", order.OrderNumber);
        
        return Task.FromResult(State.Ok(entity));
    }
    
    // After insert - side effects
    public Task<State<Order>> AfterInsertAsync(
        State<Order, Guid> state, 
        Entity<Order, Guid> entity, 
        CancellationToken cancellationToken = default)
    {
        if (state.IsOk)
        {
            _logger.LogInformation("Order created successfully: {OrderId}", entity.Key);
            // Send event, notification, etc.
        }
        
        return Task.FromResult(state);
    }
    
    // Before update - prevent invalid transitions
    public Task<State<Order, Guid>> BeforeUpdateAsync(
        Entity<Order, Guid> entity, 
        Entity<Order, Guid>? oldEntity,
        CancellationToken cancellationToken = default)
    {
        if (oldEntity?.Value?.Status == OrderStatus.Cancelled)
        {
            return Task.FromResult(State.Error<Order, Guid>("Cannot update cancelled orders"));
        }
        
        return Task.FromResult(State.Ok(entity));
    }
    
    // Before delete - soft delete
    public Task<State<Order, Guid>> BeforeDeleteAsync(
        Entity<Order, Guid> entity, 
        CancellationToken cancellationToken = default)
    {
        // Instead of deleting, mark as cancelled
        entity.Value!.Status = OrderStatus.Cancelled;
        return Task.FromResult(State.Error<Order, Guid>("Soft delete - order cancelled"));
    }
}
```

### Register Business Logic
```csharp
services.AddRepository<Order, Guid>(builder =>
{
    builder.WithEntityFramework<OrdersDbContext>();
    
    builder
        .AddBusiness()
            .AddBusinessBeforeInsert<OrderBusinessLogic>()
            .AddBusinessAfterInsert<OrderBusinessLogic>()
            .AddBusinessBeforeUpdate<OrderBusinessLogic>()
            .AddBusinessBeforeDelete<OrderBusinessLogic>();
});
```

### Separate Business Registration (Clean Architecture)
If you want to keep business logic in a different project:

```csharp
// In Infrastructure project - just repository setup
services.AddRepository<Order, Guid>(builder =>
{
    builder.WithEntityFramework<OrdersDbContext>();
});

// In Business project - add business logic
services.AddBusinessForRepository<Order, Guid>(builder =>
{
    builder
        .AddBusiness()
            .AddBusinessBeforeInsert<OrderBusinessLogic>()
            .AddBusinessAfterInsert<OrderBusinessLogic>()
            .AddBusinessBeforeUpdate<OrderBusinessLogic>()
            .AddBusinessBeforeDelete<OrderBusinessLogic>();
});
```

**Available Interfaces**:
- `IRepositoryBusinessBeforeInsert<T, TKey>`
- `IRepositoryBusinessAfterInsert<T, TKey>`
- `IRepositoryBusinessBeforeUpdate<T, TKey>`
- `IRepositoryBusinessAfterUpdate<T, TKey>`
- `IRepositoryBusinessBeforeDelete<T, TKey>`
- `IRepositoryBusinessAfterDelete<T, TKey>`

**⚠️ Important**: Business logic classes must be **public** for DI to instantiate them!

---

## 🗄️ Storage Backend Examples

### 1. Entity Framework (SQL Server, PostgreSQL, SQLite)

```csharp
// DbContext
public class OrdersDbContext : DbContext
{
    public OrdersDbContext(DbContextOptions<OrdersDbContext> options)
        : base(options)
    {
    }
    
    public DbSet<Order> Orders { get; set; }
    
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Order>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.OrderNumber).IsRequired().HasMaxLength(50);
            entity.HasIndex(e => e.OrderNumber).IsUnique();
        });
    }
}

// Registration
services.AddDbContext<OrdersDbContext>(options =>
    options.UseSqlServer(configuration.GetConnectionString("OrdersDb")));

services.AddRepository<Order, Guid>(builder =>
{
    builder.WithEntityFramework<OrdersDbContext>();
});
```

### 2. Azure Cosmos DB (NoSQL)

```csharp
services.AddRepository<Order, Guid>(builder =>
{
    builder.WithCosmosDb(options =>
    {
        options.ConnectionString = configuration["CosmosDb:ConnectionString"];
        options.DatabaseName = "OrdersDb";
        options.ContainerName = "orders";
        options.PartitionKey = "/customerId"; // Partition key path
    });
});
```

### 3. Azure Blob Storage (NoSQL - JSON documents)

```csharp
services.AddRepository<Order, Guid>(builder =>
{
    builder.WithBlobStorage(options =>
    {
        options.ConnectionString = configuration["Azure:Storage"];
        options.ContainerName = "orders";
    });
});
```

### 4. Azure Table Storage (NoSQL - Key-Value)

```csharp
services.AddRepository<Order, OrderKey>(builder =>
{
    builder.WithTableStorage(options =>
    {
        options.ConnectionString = configuration["Azure:Storage"];
        options.TableName = "Orders";
        options.PartitionKey = "CustomerId";
        options.RowKey = "OrderId";
        options.PartitionKeyFunction = x => x.CustomerId.ToString();
        options.RowKeyFunction = x => x.OrderId.ToString();
    });
});
```

### 5. In-Memory (Testing)

```csharp
services.AddRepository<Order, Guid>(builder =>
{
    builder.WithInMemory(options =>
    {
        // Pre-populate with random data
        options
            .PopulateWithRandomData(count: 100, numberOfEntities: 10)
            .WithPattern(x => x.Value!.OrderNumber, @"ORD-[0-9]{5}");
    });
});
```

---

## 🎯 Real-World Example: Complete Order Repository

```csharp
// 1. Entity
namespace CargoLens.Orders.Core.Entities;

public class Order
{
    public Guid Id { get; init; }
    public string OrderNumber { get; set; } = string.Empty;
    public Guid CustomerId { get; set; }
    public OrderStatus Status { get; private set; }
    public DateTime CreatedAt { get; init; }
    public List<OrderItem> Items { get; set; } = new();
    
    public void MarkAsConfirmed() => Status = OrderStatus.Confirmed;
    public void MarkAsShipped() => Status = OrderStatus.Shipped;
}

// 2. Repository Interface (Optional - for DDD)
namespace CargoLens.Orders.Core.Interfaces;

public interface IOrderRepository : IRepository<Order, Guid>
{
    // Custom methods if needed
    Task<List<Order>> GetOrdersByCustomerAsync(Guid customerId);
}

// 3. Repository Implementation (if custom methods)
namespace CargoLens.Orders.Storage.Repositories;

public class OrderRepository : IOrderRepository
{
    private readonly IRepository<Order, Guid> _baseRepository;
    private readonly OrdersDbContext _context;
    
    public OrderRepository(
        IRepository<Order, Guid> baseRepository,
        OrdersDbContext context)
    {
        _baseRepository = baseRepository;
        _context = context;
    }
    
    // Delegate all IRepository methods to base
    public Task<State<Order, Guid>> InsertAsync(Guid key, Order value, CancellationToken cancellationToken = default)
        => _baseRepository.InsertAsync(key, value, cancellationToken);
    
    public Task<State<Order, Guid>> UpdateAsync(Guid key, Order value, CancellationToken cancellationToken = default)
        => _baseRepository.UpdateAsync(key, value, cancellationToken);
    
    public Task<State<Order, Guid>> DeleteAsync(Guid key, CancellationToken cancellationToken = default)
        => _baseRepository.DeleteAsync(key, cancellationToken);
    
    public IAsyncEnumerable<BatchResult<Order, Guid>> BatchAsync(BatchOperations<Order, Guid> operations, CancellationToken cancellationToken = default)
        => _baseRepository.BatchAsync(operations, cancellationToken);
    
    public Task<State<Order, Guid>> ExistAsync(Guid key, CancellationToken cancellationToken = default)
        => _baseRepository.ExistAsync(key, cancellationToken);
    
    public Task<Order?> GetAsync(Guid key, CancellationToken cancellationToken = default)
        => _baseRepository.GetAsync(key, cancellationToken);
    
    public IAsyncEnumerable<Entity<Order, Guid>> QueryAsync(IFilterExpression filter, CancellationToken cancellationToken = default)
        => _baseRepository.QueryAsync(filter, cancellationToken);
    
    public ValueTask<TProperty> OperationAsync<TProperty>(OperationType<TProperty> operation, IFilterExpression filter, CancellationToken cancellationToken = default)
        => _baseRepository.OperationAsync(operation, filter, cancellationToken);
    
    // Custom method
    public async Task<List<Order>> GetOrdersByCustomerAsync(Guid customerId)
    {
        return await _context.Orders
            .Where(o => o.CustomerId == customerId)
            .OrderByDescending(o => o.CreatedAt)
            .ToListAsync();
    }
}

// 4. Registration
services.AddDbContext<OrdersDbContext>(options =>
    options.UseSqlServer(configuration.GetConnectionString("OrdersDb")));

services.AddRepository<Order, Guid>(builder =>
{
    builder.WithEntityFramework<OrdersDbContext>();
    
    builder
        .AddBusiness()
            .AddBusinessBeforeInsert<OrderBusinessLogic>();
});

// If custom repository interface
services.AddScoped<IOrderRepository, OrderRepository>();

// 5. Usage in Service
namespace CargoLens.Orders.Business.Services;

public class OrderService
{
    private readonly IOrderRepository _orderRepository;
    
    public OrderService(IOrderRepository orderRepository)
    {
        _orderRepository = orderRepository;
    }
    
    public async Task<Guid> CreateOrderAsync(CreateOrderDto dto)
    {
        var order = new Order
        {
            Id = Guid.NewGuid(),
            OrderNumber = GenerateOrderNumber(),
            CustomerId = dto.CustomerId,
            CreatedAt = DateTime.UtcNow,
            Items = dto.Items.Select(MapToOrderItem).ToList()
        };
        
        var result = await _orderRepository.InsertAsync(order.Id, order);
        
        if (!result.IsOk)
            throw new InvalidOperationException(result.Message);
        
        return order.Id;
    }
    
    public async Task<List<OrderDto>> GetCustomerOrdersAsync(Guid customerId)
    {
        var orders = await _orderRepository.GetOrdersByCustomerAsync(customerId);
        return orders.Select(MapToDto).ToList();
    }
}
```

---

## 📚 Common Patterns

### Pattern 1: Repository + Business Logic + Factory
```csharp
// Primary database
services.AddRepository<Order, Guid>(builder =>
{
    builder.WithEntityFramework<OrdersDbContext>();
    builder.AddBusiness()
        .AddBusinessBeforeInsert<OrderValidationBusiness>()
        .AddBusinessAfterInsert<OrderEventPublisherBusiness>();
}, "primary");

// Read replica or cache
services.AddRepository<Order, Guid>(builder =>
{
    builder.WithEntityFramework<OrdersReadDbContext>();
}, "readonly");
```

### Pattern 2: CQRS with Different Databases
```csharp
// Write to SQL
services.AddCommand<Order, Guid>(builder =>
{
    builder.WithEntityFramework<OrdersDbContext>();
});

// Read from Cosmos DB (denormalized for fast queries)
services.AddQuery<Order, Guid>(builder =>
{
    builder.WithCosmosDb(options => { /* ... */ });
});
```

### Pattern 3: Layered Caching
```csharp
// L1 Cache: In-Memory
services.AddRepository<Order, Guid>(builder =>
{
    builder.WithInMemory();
}, "memory");

// L2 Cache: Redis
services.AddRepository<Order, Guid>(builder =>
{
    builder.WithDistributedCache();
}, "redis");

// Primary: Database
services.AddRepository<Order, Guid>(builder =>
{
    builder.WithEntityFramework<OrdersDbContext>();
}, "database");
```

---

## ⚠️ Important Notes

1. **Always use `IRepository<T, TKey>`**, NOT `IRepositoryPattern<T, TKey>` when injecting
2. **Always use `ICommand<T, TKey>`**, NOT `ICommandPattern<T, TKey>` when injecting
3. **Always use `IQuery<T, TKey>`**, NOT `IQueryPattern<T, TKey>` when injecting
4. **Business logic classes must be `public`** for DI to instantiate them
5. **Factory pattern uses `IFactory<IRepository<T, TKey>>`** from Rystem.DependencyInjection
6. **Last registered** repository is the default when injecting `IRepository<T, TKey>` directly
7. **Version 9.1.3** is the current stable version for all Rystem packages

---

## 🔗 Related Resources

- **ddd-single-domain**: How to organize repositories in single-domain architecture
- **ddd-multi-domain**: How to organize repositories in multi-domain architecture
- **repository-api-server**: Auto-generate REST APIs from repositories (no controllers needed)
- **repository-api-client-typescript**: Consume repositories from TypeScript/JavaScript apps
- **repository-api-client-dotnet**: Consume repositories from .NET/C# apps (Blazor, MAUI, WPF)
- **install-rystem**: How to install Rystem packages
- **Background Jobs**: Use with repositories for async operations
- **Concurrency**: Lock repositories during critical operations

---

## 📖 Further Reading

- [Rystem.RepositoryFramework GitHub](https://github.com/KeyserDSoze/RepositoryFramework)
- [Unit Tests Examples](https://github.com/KeyserDSoze/RepositoryFramework/tree/master/src/RepositoryFramework.Test)
- [Entity Framework Integration](https://github.com/KeyserDSoze/RepositoryFramework/tree/master/src/RepositoryFramework.Test/RepositoryFramework.Test.Infrastructure.EntityFramework)

---

## ✅ Summary

**Rystem.RepositoryFramework** provides:
- ✅ Unified repository pattern for all storage types
- ✅ Built-in CQRS support
- ✅ Multiple implementations with Factory pattern
- ✅ Business logic injection (before/after hooks)
- ✅ Powerful LINQ-like queries
- ✅ Batch operations
- ✅ Translation for schema mapping
- ✅ Support for complex keys

**Use this tool whenever you need to implement data access in a Rystem application!** 🚀

---

## Rystem.RepositoryFramework.Abstractions

> !NuGet(https://img.shields.io/nuget/v/Rystem.RepositoryFramework.Abstractions)(https://www.nuget.org/packages/Rystem.RepositoryFramework.Abstractions)

### [What is Rystem?](https://github.com/KeyserDSoze/Rystem)

# Rystem.RepositoryFramework.Abstractions

[![NuGet](https://img.shields.io/nuget/v/Rystem.RepositoryFramework.Abstractions)](https://www.nuget.org/packages/Rystem.RepositoryFramework.Abstractions)
[![NuGet Downloads](https://img.shields.io/nuget/dt/Rystem.RepositoryFramework.Abstractions)](https://www.nuget.org/packages/Rystem.RepositoryFramework.Abstractions)

Core contracts, query primitives, registration builders, and runtime metadata for the Rystem repository ecosystem.

This is the foundation for the whole Repository Framework area documented in `src/Repository/README.md`.

It defines:

- repository, command, and query contracts
- DI registration builders for repository and CQRS setups
- key abstractions and key serialization rules
- query/filter primitives used by every storage provider
- business hooks and translation builders
- runtime metadata used by the API packages and diagnostics

## Resources

- Complete Documentation: [https://rystem.net](https://rystem.net)
- MCP Server for AI: [https://rystem.cloud/mcp](https://rystem.cloud/mcp)
- Discord Community: [https://discord.gg/tkWvy4WPjt](https://discord.gg/tkWvy4WPjt)
- Support the Project: [https://www.buymeacoffee.com/keyserdsoze](https://www.buymeacoffee.com/keyserdsoze)

---

## Installation

```bash
dotnet add package Rystem.RepositoryFramework.Abstractions
```

The current package metadata in `src/Repository/RepositoryFramework.Abstractions/RepositoryFramework.Abstractions.csproj` is:

- package id: `Rystem.RepositoryFramework.Abstractions`
- version: `10.0.6`
- target framework: `net11.0`

This package builds on top of `Rystem.DependencyInjection`.

---

## Package architecture

At a high level, this package is organized around these areas.

| Area | Purpose |
|---|---|
| Pattern interfaces | Low-level storage contracts such as `IRepositoryPattern<T, TKey>` |
| Consumer interfaces | DI-facing contracts such as `IRepository<T, TKey>` |
| Service registration builders | `AddRepository`, `AddCommand`, `AddQuery`, and their async variants |
| Query model | `QueryBuilder<T, TKey>`, `IFilterExpression`, paging, aggregate operations |
| Keys and state models | `IKey`, `IDefaultKey`, `Key<T1,...>`, `Entity<T, TKey>`, `State<T, TKey>` |
| Business and translation hooks | interceptors, examples, exposure rules, filter translation |
| Runtime metadata | `RepositoryFrameworkRegistry` and `RepositoryFrameworkService` |

---

## What this package provides

- Core storage contracts: `IRepositoryPattern<T, TKey>`, `ICommandPattern<T, TKey>`, `IQueryPattern<T, TKey>`
- Consumer contracts for DI: `IRepository<T, TKey>`, `ICommand<T, TKey>`, `IQuery<T, TKey>`
- Fluent registration builders: `AddRepository`, `AddCommand`, `AddQuery`, plus async variants
- Storage wiring primitives: `SetStorage`, `SetStorageWithOptions`, `SetStorageAndBuildOptions`, `SetStorageAndBuildOptionsAsync`, `SetStorageAndServiceConnection`
- Key helpers: `IKey`, `IDefaultKey`, `Key<T1>` through `Key<T1, T2, T3, T4, T5>`, and `KeySettings<TKey>`
- Query/filter model: `QueryBuilder<T, TKey>`, `FilterExpression`, `SerializableFilter`, metadata, paging, and aggregate operations
- Business hooks and translation builders for cross-cutting logic and model remapping
- Runtime registry data used by diagnostics and API exposure packages

---

## Mental model

This package does not ship a database provider by itself. Instead, it gives you a stable abstraction layer for three concerns:

1. Implement storage behavior behind repository contracts.
2. Register those implementations in DI, optionally with named factories.
3. Reuse the same query/filter/key model across in-memory, EF, blob, table, Cosmos, API client, and custom providers.

Most other packages in `src/Repository` are adapters built on top of these abstractions.

---

## Core interfaces

### Implementation interfaces

Implement one of these in your storage class.

```csharp
// Full repository (read + write)
public interface IRepositoryPattern<T, TKey> : ICommandPattern<T, TKey>, IQueryPattern<T, TKey>
    where TKey : notnull { }

// Write only
public interface ICommandPattern<T, TKey>
    where TKey : notnull
{
    Task<State<T, TKey>> InsertAsync(TKey key, T value, CancellationToken cancellationToken = default);
    Task<State<T, TKey>> UpdateAsync(TKey key, T value, CancellationToken cancellationToken = default);
    Task<State<T, TKey>> DeleteAsync(TKey key, CancellationToken cancellationToken = default);
    IAsyncEnumerable<BatchResult<T, TKey>> BatchAsync(BatchOperations<T, TKey> operations, CancellationToken cancellationToken = default);
}

// Read only
public interface IQueryPattern<T, TKey>
    where TKey : notnull
{
    Task<State<T, TKey>> ExistAsync(TKey key, CancellationToken cancellationToken = default);
    Task<T?> GetAsync(TKey key, CancellationToken cancellationToken = default);
    IAsyncEnumerable<Entity<T, TKey>> QueryAsync(IFilterExpression filter, CancellationToken cancellationToken = default);
    ValueTask<TProperty> OperationAsync<TProperty>(OperationType<TProperty> operation, IFilterExpression filter, CancellationToken cancellationToken = default);
}
```

Both query and command abstractions also inherit the non-generic bootstrap contract through their base interfaces, so storage implementations can participate in warm-up/startup bootstrap logic.

### Consumer interfaces

Inject these into application services instead of the pattern interfaces directly.

```csharp
IRepository<T, TKey>   // read + write + query extensions
ICommand<T, TKey>      // write only
IQuery<T, TKey>        // read only
```

The consumer interfaces are what the registration builders expose through DI and named factories.

---

## Basic registration

### Repository (read + write)

```csharp
builder.Services.AddRepository<AppUser, Guid>(repositoryBuilder =>
{
    repositoryBuilder.SetStorage<AppUserStorage>();
});
```

### CQRS split

```csharp
builder.Services.AddCommand<AppUser, Guid>(commandBuilder =>
{
    commandBuilder.SetStorage<AppUserCommandStorage>();
});

builder.Services.AddQuery<AppUser, Guid>(queryBuilder =>
{
    queryBuilder.SetStorage<AppUserQueryStorage>();
});
```

### Async registration

Use async variants when the builder itself needs asynchronous setup.

```csharp
await builder.Services.AddRepositoryAsync<AppUser, Guid>(async repositoryBuilder =>
{
    repositoryBuilder.SetStorage<AppUserStorage>();
    await Task.CompletedTask;
});

await builder.Services.AddCommandAsync<AppUser, Guid>(async commandBuilder =>
{
    commandBuilder.SetStorage<AppUserCommandStorage>();
    await Task.CompletedTask;
});

await builder.Services.AddQueryAsync<AppUser, Guid>(async queryBuilder =>
{
    queryBuilder.SetStorage<AppUserQueryStorage>();
    await Task.CompletedTask;
});
```

---

## Storage registration primitives

All repository builders eventually flow through the storage registration methods in `RepositoryBaseBuilder`.

### `SetStorage<TStorage>()`

Use this when the storage can be resolved directly from DI.

```csharp
builder.Services.AddRepository<AppUser, Guid>(repositoryBuilder =>
{
    repositoryBuilder.SetStorage<AppUserStorage>();
});
```

### `SetStorageWithOptions<TStorage, TStorageOptions>()`

Use this when the storage consumes a simple options object implementing `IFactoryOptions`.

```csharp
builder.Services.AddRepository<AppUser, Guid>(repositoryBuilder =>
{
    repositoryBuilder.SetStorageWithOptions<AppUserStorage, AppUserStorageOptions>(options =>
    {
        options.ConnectionString = builder.Configuration["ConnectionStrings:Default"]!;
    });
});
```

### `SetStorageAndBuildOptions<TStorage, TStorageOptions, TConnection>()`

Use this when the builder must transform fluent configuration into a factory-backed connection/options object.

```csharp
builder.Services.AddRepository<AppUser, Guid>(repositoryBuilder =>
{
    repositoryBuilder.SetStorageAndBuildOptions<AppUserStorage, AppUserBuilder, AppUserConnection>(options =>
    {
        options.Name = "users";
    });
});
```

### `SetStorageAndBuildOptionsAsync<TStorage, TStorageOptions, TConnection>()`

Same as the previous one, but the options builder can perform asynchronous work.

```csharp
await builder.Services.AddRepositoryAsync<AppUser, Guid>(async repositoryBuilder =>
{
    await repositoryBuilder.SetStorageAndBuildOptionsAsync<AppUserStorage, AppUserBuilder, AppUserConnection>(options =>
    {
        options.Name = "users";
    });
});
```

### `SetStorageAndServiceConnection<TStorage, TConnectionService, TConnectionClient>()`

Use this when the actual connection or client is request-aware or tenant-aware.

```csharp
public sealed class TenantAwareConnectionService : IConnectionService<Order, Guid, DbConnection>
{
    private readonly ITenantResolver _tenantResolver;

    public TenantAwareConnectionService(ITenantResolver tenantResolver)
        => _tenantResolver = tenantResolver;

    public DbConnection GetConnection(string entityName, string? factoryName = null)
    {
        var connectionString = _tenantResolver.GetConnectionString(entityName, factoryName);
        return new SqlConnection(connectionString);
    }
}

builder.Services.AddRepository<Order, Guid>(repositoryBuilder =>
{
    repositoryBuilder.SetStorageAndServiceConnection<OrderStorage, TenantAwareConnectionService, DbConnection>();
});
```

### Lifetime and naming

- All `SetStorage*` methods default to `ServiceLifetime.Scoped`.
- Every `SetStorage*` overload accepts an optional `name` and `serviceLifetime`.
- The `name` is stored as the repository `FactoryName` in the runtime registry and is how named factories resolve a specific storage.

---

## Named registrations and factories

One model can be backed by multiple repositories or providers at the same time. The common pattern is to register each one with a `name`, then resolve it through `IFactory<TService>`.

This is heavily used in the integration tests and sample web API.

```csharp
builder.Services.AddRepository<AppUser, AppUserKey>(repositoryBuilder =>
{
    repositoryBuilder.SetStorage<PrimaryAppUserStorage>(name: "primary");
    repositoryBuilder.SetStorage<ArchiveAppUserStorage>(name: "archive");
});
```

```csharp
public sealed class AppUserImportService
{
    private readonly IFactory<IRepository<AppUser, AppUserKey>> _repositoryFactory;

    public AppUserImportService(IFactory<IRepository<AppUser, AppUserKey>> repositoryFactory)
        => _repositoryFactory = repositoryFactory;

    public Task<AppUser?> GetFromArchiveAsync(AppUserKey key, CancellationToken cancellationToken = default)
    {
        var repository = _repositoryFactory.Create("archive")!;
        return repository.GetAsync(key, cancellationToken);
    }
}
```

The same pattern works for:

- `IFactory<IRepository<T, TKey>>`
- `IFactory<IQuery<T, TKey>>`
- `IFactory<ICommand<T, TKey>>`

This makes it easy to switch between environments, fallback providers, multi-tenant routing, cache layers, or migration tooling without changing the domain-facing contract.

---

## Keys

Key handling is more flexible than the old docs suggest. `KeySettings<TKey>` supports several strategies.

### Primitive and framework-native keys

These work out of the box:

- primitive numeric types
- `string`
- `Guid`
- `DateTime`
- `DateTimeOffset`
- `TimeSpan`
- `nint`
- `nuint`

```csharp
builder.Services.AddRepository<AppUser, Guid>(...);
builder.Services.AddRepository<Product, int>(...);
builder.Services.AddRepository<Session, string>(...);
```

### Composite keys with `Key<T1, T2, ...>`

You can use the built-in `Key<>` helpers for common composite-key scenarios.

```csharp
builder.Services.AddRepository<Order, Key<int, string>>(repositoryBuilder =>
{
    repositoryBuilder.SetStorage<OrderStorage>();
});

var key = new Key<int, string>(42, "region-eu");
var order = await repository.GetAsync(key);
```

### Custom keys with `IKey`

Implement `IKey` when you want full control over string serialization.

```csharp
public sealed class AppUserKey : IKey
{
    public string TenantId { get; set; } = string.Empty;
    public Guid UserId { get; set; }

    public static IKey Parse(string keyAsString)
    {
        var parts = keyAsString.Split('-', 2);
        return new AppUserKey { TenantId = parts[0], UserId = Guid.Parse(parts[1]) };
    }

    public string AsString() => $"{TenantId}-{UserId}";
}
```

### Property-based keys with `IDefaultKey`

Implement `IDefaultKey` when you want the framework to serialize all key properties using the default separator.

```csharp
public sealed class OrderKey : IDefaultKey
{
    public int OrderId { get; set; }
    public string Region { get; set; } = string.Empty;
}

builder.Services.AddDefaultSeparatorForDefaultKeyInterface("$$$");
```

### Plain POCO keys also work

If `TKey` is not primitive, not `IKey`, and not `IDefaultKey`, `KeySettings<TKey>` still supports it as long as the type exposes properties. In that case it falls back to JSON serialization.

This behavior is covered by the key tests and the class-key repository tests.

```csharp
public sealed class ClassAnimalKey
{
    public string Area { get; set; } = string.Empty;
    public int Id { get; set; }
    public Guid CorrelationId { get; set; }

    public ClassAnimalKey() { }

    public ClassAnimalKey(string area, int id, Guid correlationId)
        => (Area, Id, CorrelationId) = (area, id, correlationId);
}

builder.Services.AddRepository<ClassAnimal, ClassAnimalKey>(repositoryBuilder =>
{
    repositoryBuilder.SetStorage<ClassAnimalRepository>();
});
```

The practical rule is simple: if the key can be converted to and from a stable string representation, the abstraction layer can carry it through providers and APIs.

---

## Core models

### `State<T, TKey>`

All command methods return `State<T, TKey>`.

```csharp
public class State<T, TKey>
{
    public bool IsOk { get; set; }
    public Entity<T, TKey>? Entity { get; set; }
    public int? Code { get; set; }
    public string? Message { get; set; }
    public bool HasEntity { get; }
}
```

Useful factory helpers include:

```csharp
return State.Ok(value, key);
return State.NotOk(value, key);
return State.Default(isOk, value, key);

return await State.OkAsTask(value, key);
return await State.NotOkAsTask(value, key);
```

### `Entity<T, TKey>`

Query operations return `Entity<T, TKey>` so callers can keep both the key and the value.

```csharp
public class Entity<T, TKey>
{
    public TKey? Key { get; set; }
    public T? Value { get; set; }
    public bool HasValue { get; }
    public bool HasKey { get; }

    public State<T, TKey> ToOkState();
    public State<T, TKey> ToNotOkState();
}
```

### Batch models

Use `BatchOperations<T, TKey>` and `BatchResult<T, TKey>` when the provider supports grouped write operations.

```csharp
var batch = new BatchOperations<AppUser, Guid>()
    .AddInsert(Guid.NewGuid(), new AppUser { Name = "Alice" })
    .AddUpdate(existingId, updatedUser)
    .AddDelete(oldId);

await foreach (var result in command.BatchAsync(batch))
{
    // result.Command
    // result.Key
    // result.State
}
```

The command and repository consumers also expose the fluent helper:

```csharp
await repository.CreateBatchOperation()
    .AddInsert(key1, value1)
    .AddDelete(key2)
    .ExecuteAsync()
    .ToListAsync();
```

---

## Fluent query builder

`IQuery<T, TKey>` and `IRepository<T, TKey>` expose extension methods that create a `QueryBuilder<T, TKey>`.

```csharp
var items = await repository
    .Where(x => x.IsActive)
    .OrderByDescending(x => x.Price)
    .Skip(20)
    .Take(10)
    .ToListAsync();

foreach (var entity in items)
    Console.WriteLine(entity.Value!.Name);

List<Product> values = await repository
    .Where(x => x.IsActive)
    .ToListAsEntityAsync();
```

### Main query methods

| Method | Description |
|---|---|
| `Where(expr)` | Filter by entity predicate |
| `WhereKey(expr)` | Filter by key predicate |
| `Take(n)` | Limit results |
| `Skip(n)` | Offset results |
| `OrderBy(expr)` | Ascending sort |
| `OrderByDescending(expr)` | Descending sort |
| `ThenBy(expr)` | Secondary ascending sort |
| `ThenByDescending(expr)` | Secondary descending sort |
| `AnyAsync(expr?)` | Returns `bool` |
| `FirstOrDefaultAsync(expr?)` | Returns `Entity<T, TKey>?` |
| `FirstAsync(expr?)` | Returns `Entity<T, TKey>` |
| `FirstOrDefaultByKeyAsync(expr?)` | Returns first entity filtered on key |
| `FirstByKeyAsync(expr?)` | Returns first entity filtered on key |
| `PageAsync(page, pageSize)` | Returns `Page<T, TKey>` |
| `ToListAsync()` | Returns `List<Entity<T, TKey>>` |
| `ToListAsEntityAsync()` | Returns `List<T>` |
| `QueryAsync()` | Returns `IAsyncEnumerable<Entity<T, TKey>>` |
| `QueryAsEntityAsync()` | Returns `IAsyncEnumerable<T>` |
| `CountAsync()` | Aggregate count |
| `SumAsync(expr)` | Aggregate sum |
| `AverageAsync(expr)` | Aggregate average |
| `MaxAsync(expr)` | Aggregate max |
| `MinAsync(expr)` | Aggregate min |
| `OperationAsync(operation)` | Custom aggregate operation |
| `AddMetadata(key, value)` | Attach metadata to the filter |

### Important behavior notes

- `PageAsync` validates that `page >= 1` and `pageSize >= 1`.
- `PageAsync` calculates total pages using a separate `Count` operation.
- `GroupByAsync` is not translated into provider-native grouping. It first enumerates `QueryAsync()` and then groups client-side.

```csharp
Page<AppUser, AppUserKey> firstPage = await repository
    .Where(x => x.Id > 0)
    .OrderByDescending(x => x.Id)
    .PageAsync(page: 1, pageSize: 20);
```

---

## Filter model and custom storage integration

`IFilterExpression` is the portable query description that storage providers receive in `QueryAsync` and `OperationAsync`.

This is the bridge between LINQ-like consumer code and your provider implementation.

### What it can do

- carry ordered filter operations such as `Where`, `OrderBy`, `Skip`, and `Take`
- serialize itself through `Serialize()` into a `SerializableFilter`
- produce a stable cache/transport key through `ToKey()`
- apply the filter directly to in-memory collections or queryables
- expose filter metadata and parsed values through `GetFilters(...)`
- translate mapped expressions through `Translate(...)`

### Typical custom repository usage

For in-memory or adapter-style repositories, the simplest pattern is to let the filter apply itself.

```csharp
public async IAsyncEnumerable<Entity<AppUser, AppUserKey>> QueryAsync(
    IFilterExpression filter,
    [EnumeratorCancellation] CancellationToken cancellationToken = default)
{
    await Task.Yield();

    foreach (var item in filter.Apply(_items))
    {
        cancellationToken.ThrowIfCancellationRequested();
        yield return Entity.Default(item, new AppUserKey(item.Id));
    }
}
```

### Metadata and caching scenarios

`AddMetadata(key, value)` is useful when your provider needs extra information that is not part of the entity predicate itself, such as tenant, partition, read consistency, or a custom projection mode.

```csharp
var query = repository
    .Where(x => x.IsActive)
    .AddMetadata("tenant", "eu-west")
    .AddMetadata("mode", "snapshot");
```

The metadata becomes part of the filter representation available to the storage layer through `IFilterExpression`.

---

## Business hooks

Business interceptors let you wrap every repository operation with validation, auditing, policy checks, or side effects.

### Register inline during repository setup

```csharp
builder.Services.AddRepository<AppUser, Guid>(repositoryBuilder =>
{
    repositoryBuilder.SetStorage<AppUserStorage>();

    repositoryBuilder
        .AddBusiness()
        .AddBusinessBeforeInsert<AppUserValidation>()
        .AddBusinessAfterInsert<AppUserAudit>()
        .AddBusinessBeforeDelete<AppUserDeletionGuard>();
});
```

### Register independently

```csharp
builder.Services
    .AddBusinessForRepository<AppUser, Guid>()
    .AddBusinessBeforeUpdate<AppUserUpdateValidation>()
    .AddBusinessAfterUpdate<AppUserUpdateAudit>();
```

### Scan assemblies

```csharp
builder.Services.ScanBusinessForRepositoryFramework();
builder.Services.ScanBusinessForRepositoryFramework(typeof(MyAssemblyMarker).Assembly);
```

`ScanBusinessForRepositoryFramework()` inspects all before/after business interfaces for the repositories already registered in the framework registry.

### Available hook families

| Interface | Triggered |
|---|---|
| `IRepositoryBusinessBeforeInsert<T, TKey>` | Before `InsertAsync` |
| `IRepositoryBusinessAfterInsert<T, TKey>` | After `InsertAsync` |
| `IRepositoryBusinessBeforeUpdate<T, TKey>` | Before `UpdateAsync` |
| `IRepositoryBusinessAfterUpdate<T, TKey>` | After `UpdateAsync` |
| `IRepositoryBusinessBeforeDelete<T, TKey>` | Before `DeleteAsync` |
| `IRepositoryBusinessAfterDelete<T, TKey>` | After `DeleteAsync` |
| `IRepositoryBusinessBeforeBatch<T, TKey>` | Before `BatchAsync` |
| `IRepositoryBusinessAfterBatch<T, TKey>` | After `BatchAsync` |
| `IRepositoryBusinessBeforeGet<T, TKey>` | Before `GetAsync` |
| `IRepositoryBusinessAfterGet<T, TKey>` | After `GetAsync` |
| `IRepositoryBusinessBeforeExist<T, TKey>` | Before `ExistAsync` |
| `IRepositoryBusinessAfterExist<T, TKey>` | After `ExistAsync` |
| `IRepositoryBusinessBeforeQuery<T, TKey>` | Before `QueryAsync` |
| `IRepositoryBusinessAfterQuery<T, TKey>` | After `QueryAsync` |
| `IRepositoryBusinessBeforeOperation<T, TKey>` | Before `OperationAsync` |
| `IRepositoryBusinessAfterOperation<T, TKey>` | After `OperationAsync` |

Priority controls ordering. Lower values run first.

---

## Translation mapper

The translation builder is what lets consumer code keep writing filters against the domain model while the provider translates them to a different storage model.

This is covered by the translation tests.

```csharp
builder.Services.AddRepository<Translatable, string>(repositoryBuilder =>
{
    repositoryBuilder
        .SetStorage<TranslatableRepository>()
        .Translate<ToTranslateSomething>()
            .With(x => x.Foolish, x => x.Folle)
            .With(x => x.Id, x => x.IdccnlValidita)
            .With(x => x.CcnlId, x => x.Idccnl)
            .With(x => x.From, x => x.DataInizio)
            .With(x => x.To, x => x.DataFine)
        .AndTranslate<ToTranslateSomethingElse>()
            .With(x => x.Foolish, x => x.Folle)
            .With(x => x.Id, x => x.IdccnlValidita)
            .With(x => x.CcnlId, x => x.Idccnl);
});
```

Common helpers include:

- `Translate<TTranslated>()`
- `With(domainProperty, translatedProperty)`
- `WithKey(...)`
- `WithSamePorpertiesName()`
- `AndTranslate<TTranslated>()`

This is especially useful for EF models, API DTOs, cache projections, or legacy schemas where names do not line up with the public domain model.

---

## API exposure and examples

These settings matter when the repository is later surfaced through `Rystem.RepositoryFramework.Api.Server`.

### Control exposed methods

```csharp
builder.Services.AddRepository<AppUser, Guid>(repositoryBuilder =>
{
    repositoryBuilder.SetStorage<AppUserStorage>();

    repositoryBuilder.SetExposable(RepositoryMethods.All);
    repositoryBuilder.SetOnlyQueryExposable();
    repositoryBuilder.SetOnlyCommandExposable();
    repositoryBuilder.SetExposable(RepositoryMethods.Get | RepositoryMethods.Query);
    repositoryBuilder.SetNotExposable();
});
```

`RepositoryMethods` also includes `Bootstrap`, so the bootstrap endpoint can be included or hidden when you expose repositories as APIs.

### Provide OpenAPI examples

```csharp
builder.Services.AddRepository<AppUser, Guid>(repositoryBuilder =>
{
    repositoryBuilder.SetStorage<AppUserStorage>();
    repositoryBuilder.SetExamples(
        new AppUser { Name = "Alice", Email = "alice@example.com" },
        Guid.NewGuid());
});
```

---

## Bootstrap and warm-up lifecycle

If a storage implementation needs startup work such as schema creation, seeding, or client warm-up, implement the bootstrap contract.

```csharp
public sealed class AppUserStorage : IRepositoryPattern<AppUser, Guid>, IBootstrapPattern
{
    public async ValueTask<bool> BootstrapAsync(CancellationToken cancellationToken = default)
    {
        await EnsureTableExistsAsync(cancellationToken);
        return true;
    }

    // other IRepositoryPattern members omitted
}
```

Important: bootstrap does not run just because `AddRepository` was called.

In the real tests and sample web API, bootstrap is executed by calling `WarmUpAsync()` on the built service provider:

```csharp
var app = builder.Build();
await app.Services.WarmUpAsync();
```

That is the practical startup lifecycle to document and rely on.

---

## Post-build callbacks

You can run synchronous or asynchronous logic after the repository builder delegate finishes.

```csharp
builder.Services.AddRepository<AppUser, Guid>(repositoryBuilder =>
{
    repositoryBuilder.SetStorage<AppUserStorage>();

    repositoryBuilder.AfterBuild = () =>
    {
        Console.WriteLine("AppUser repository registered.");
    };

    repositoryBuilder.AfterBuildAsync = async () =>
    {
        await ValidateSchemaAsync();
    };
});
```

The important detail is timing: `AfterBuild` and `AfterBuildAsync` run after the whole `AddRepository` or `AddCommand` or `AddQuery` builder delegate returns, not after each individual `SetStorage*` call.

---

## Runtime registry

`RepositoryFrameworkRegistry` is registered automatically as a singleton. It tracks every repository, command, and query configured through the framework.

```csharp
public sealed class RepositoryDiagnosticsService
{
    private readonly RepositoryFrameworkRegistry _registry;

    public RepositoryDiagnosticsService(RepositoryFrameworkRegistry registry)
        => _registry = registry;

    public void PrintAll()
    {
        foreach (var (_, service) in _registry.Services)
        {
            Console.WriteLine(
                $"{service.ModelType.Name} {service.Type} -> {service.ImplementationType.Name} [{service.FactoryName}]");
        }
    }
}
```

### `RepositoryFrameworkService` metadata

| Property | Description |
|---|---|
| `ModelType` | The domain model type |
| `KeyType` | The key type |
| `InterfaceType` | The DI-facing contract |
| `ImplementationType` | The storage implementation |
| `ExposedMethods` | API-visible methods |
| `ServiceLifetime` | DI lifetime used by registration |
| `Type` | `Repository`, `Command`, or `Query` |
| `FactoryName` | Named registration key, empty when default |
| `Policies` | Authorization policy names used by UI/API tooling |

This registry is what later packages use to expose repositories as APIs, create documentation, or inspect configured services.

---

## Related packages

| Package | Purpose |
|---|---|
| `Rystem.RepositoryFramework.Infrastructure.InMemory` | In-memory storage and test-friendly provider |
| `Rystem.RepositoryFramework.Infrastructure.EntityFramework` | EF Core adapter |
| `Rystem.RepositoryFramework.Api.Server` | Auto-generate REST APIs from repository registrations |
| `Rystem.RepositoryFramework.Api.Client` | .NET and TypeScript client adapters |

If you are continuing through the repository area, this README is the conceptual base to read before the infrastructure packages.

---

## Rystem.RepositoryFramework.Api.Client

> !NuGet(https://img.shields.io/nuget/v/Rystem.RepositoryFramework.Api.Client)(https://www.nuget.org/packages/Rystem.RepositoryFramework.Api.Client)

### [What is Rystem?](https://github.com/KeyserDSoze/Rystem)

# Rystem.RepositoryFramework.Api.Client

[![NuGet](https://img.shields.io/nuget/v/Rystem.RepositoryFramework.Api.Client)](https://www.nuget.org/packages/Rystem.RepositoryFramework.Api.Client)
[![NuGet Downloads](https://img.shields.io/nuget/dt/Rystem.RepositoryFramework.Api.Client)](https://www.nuget.org/packages/Rystem.RepositoryFramework.Api.Client)

.NET client adapter for APIs generated by `Rystem.RepositoryFramework.Api.Server`.

It lets you inject `IRepository<T, TKey>`, `IQuery<T, TKey>`, or `ICommand<T, TKey>` locally while the actual work happens over HTTP against a remote repository API.

## Resources

- Complete Documentation: [https://rystem.net](https://rystem.net)
- MCP Server for AI: [https://rystem.cloud/mcp](https://rystem.cloud/mcp)
- Discord Community: [https://discord.gg/tkWvy4WPjt](https://discord.gg/tkWvy4WPjt)
- Support the Project: [https://www.buymeacoffee.com/keyserdsoze](https://www.buymeacoffee.com/keyserdsoze)

---

## Installation

```bash
dotnet add package Rystem.RepositoryFramework.Api.Client
```

The current package metadata in `src/Repository/RepositoryFramework.Api.Client/RepositoryFramework.Api.Client.csproj` is:

- package id: `Rystem.RepositoryFramework.Api.Client`
- version: `10.0.6`
- target framework: `net11.0`
- HTTP packages: `Microsoft.Extensions.Http`, `Microsoft.Extensions.Http.Polly`, `Polly`

---

## Package architecture

| Area | Purpose |
|---|---|
| `WithApiClient(...)` | Register repository/query/command consumers backed by HTTP |
| `RepositoryClient<T, TKey>` | Concrete client implementation that translates repository calls to HTTP requests |
| `IApiRepositoryBuilder<T, TKey>` | Configure base address, path, version, server name, and server factory name |
| `HttpClientRepositoryBuilder<T, TKey>` | Access `IHttpClientBuilder` and the built-in policy helper |
| Request interceptors | Enrich outgoing `HttpClient` instances |
| Response interceptors | Inspect responses and optionally retry requests |
| Bearer authorization helpers | Provide token-based request enrichment and optional 401 retry flow |

---

## Mental model

This package is not a general REST client generator. It is a client for the wire format produced by `RepositoryFramework.Api.Server`.

That means it expects the server to expose routes and payload shapes like:

- `Get`, `Exist`, `Delete` endpoints following repository conventions
- `Query/Stream` and `Batch/Stream` endpoints
- `SerializableFilter`, `BatchOperations<T, TKey>`, `State<T, TKey>`, and `Entity<T, TKey>` payloads

If the server follows the matching Rystem API-server conventions, the client can make the remote repository feel local.

---

## Quick start

```csharp
builder.Services.AddRepository<Product, int>(repositoryBuilder =>
{
    repositoryBuilder.WithApiClient(apiBuilder =>
    {
        apiBuilder
            .WithHttpClient("https://api.example.com")
            .ApiBuilder
            .WithStartingPath("api")
            .WithVersion("v1");
    });
});

public sealed class ProductService
{
    private readonly IRepository<Product, int> _repository;

    public ProductService(IRepository<Product, int> repository)
        => _repository = repository;

    public Task<Product?> GetAsync(int id)
        => _repository.GetAsync(id);
}
```

---

## Registration patterns

`WithApiClient(...)` is available on repository, query, and command builders.

### Full repository

```csharp
builder.Services.AddRepository<Product, int>(repositoryBuilder =>
{
    repositoryBuilder.WithApiClient(apiBuilder =>
    {
        apiBuilder.WithHttpClient("https://api.example.com");
    });
});
```

### Query only

```csharp
builder.Services.AddQuery<Product, int>(queryBuilder =>
{
    queryBuilder.WithApiClient(apiBuilder =>
    {
        apiBuilder.WithHttpClient("https://api.example.com");
    });
});
```

### Command only

```csharp
builder.Services.AddCommand<Product, int>(commandBuilder =>
{
    commandBuilder.WithApiClient(apiBuilder =>
    {
        apiBuilder.WithHttpClient("https://api.example.com");
    });
});
```

`WithApiClient(...)` itself defaults to `ServiceLifetime.Scoped`.

---

## `IApiRepositoryBuilder<T, TKey>`

| Method | Purpose |
|---|---|
| `WithHttpClient(string domain)` | Register a named `HttpClient`; adds `https://` automatically when missing |
| `WithHttpClient(Action<HttpClient>)` | Configure the `HttpClient` directly |
| `WithStartingPath(string)` | Override the base path, default `api` |
| `WithVersion(string)` | Add a version segment |
| `WithName(string)` | Override the remote model segment |
| `WithServerFactoryName(string)` | Target a named repository registration on the server |

### `WithHttpClient(string domain)`

```csharp
apiBuilder.WithHttpClient("localhost:7058");
```

If the string does not start with `http://` or `https://`, the builder prepends `https://`.

### `WithHttpClient(Action<HttpClient>)`

Use this overload when you want full control.

```csharp
apiBuilder.WithHttpClient(client =>
{
    client.BaseAddress = new Uri("https://api.example.com");
    client.Timeout = TimeSpan.FromSeconds(30);
});
```

---

## Route building

`ApiClientSettings<T, TKey>` builds the final paths from:

- `StartingPath`, default `api`
- optional `Version`
- remote `Name`, default `typeof(T).Name`
- optional remote `FactoryName`

The effective base route is:

```text
{startingPath}/{version?}/{name}/{serverFactoryName?}
```

Examples:

- `api/Product/Get?key=42`
- `api/v2/Product/Get?key=42`
- `SuperApi/v2/calamityuser/Get?key=abc@example.com`
- `api/Product/premium/Get?key=42`

### Named segments and factory segments are different concepts

- `WithName(...)` changes the remote model segment
- `WithServerFactoryName(...)` adds the remote server factory segment
- the `name` parameter on `WithApiClient(..., name: "local")` is only the local DI factory name for your client registration

So a local named client and a remote named server repository are separate configuration knobs.

---

## Request shapes used by the client

The client mirrors the server conventions from `RepositoryFramework.Api.Server`.

### Non-JSON keys

For keys that are not treated as JSONable by `KeySettings<TKey>`:

- `GetAsync`, `ExistAsync`, `DeleteAsync` use `GET ...?key=...`
- `InsertAsync`, `UpdateAsync` use `POST ...?key=...` with body `T`

### JSONable keys

For keys treated as JSONable:

- `GetAsync`, `ExistAsync`, `DeleteAsync` send `POST` with body `TKey`
- `InsertAsync`, `UpdateAsync` send `POST` with body `Entity<T, TKey>`

### Query, batch, and operation

- `QueryAsync(...)` posts a serialized filter to `.../Query/Stream`
- `BatchAsync(...)` posts `BatchOperations<T, TKey>` to `.../Batch/Stream`
- `OperationAsync(...)` posts a serialized filter to `.../Operation?op=...&returnType=...`

The client intentionally uses the streaming endpoints for query and batch operations, even when the caller later materializes the results into a list.

---

## What `RepositoryClient<T, TKey>` actually does

The concrete client implementation maps local repository calls to HTTP like this:

- `GetAsync` -> GET or POST depending on key serialization
- `ExistAsync` -> GET or POST depending on key serialization
- `InsertAsync` -> POST
- `UpdateAsync` -> POST
- `DeleteAsync` -> GET or POST depending on key serialization
- `QueryAsync` -> POST to `Query/Stream` and `DeserializeAsyncEnumerable<Entity<T, TKey>>`
- `BatchAsync` -> POST to `Batch/Stream` and `DeserializeAsyncEnumerable<BatchResult<T, TKey>>`
- `OperationAsync` -> POST to `Operation`

The client expects `200 OK` for success. Any other status code becomes an `HttpRequestException` containing the raw response body.

That is one reason this package works best against the matching Rystem API server rather than arbitrary REST endpoints.

---

## Built-in HTTP policy helper

`WithHttpClient(...)` returns `HttpClientRepositoryBuilder<T, TKey>`.

```csharp
repositoryBuilder.WithApiClient(apiBuilder =>
{
    apiBuilder
        .WithHttpClient("https://api.example.com")
        .WithDefaultRetryPolicy();
});
```

### Important note about `WithDefaultRetryPolicy()`

Despite the method name, the built-in policy is not a retry policy.

It registers an advanced circuit breaker with these settings:

- failure threshold: `50%`
- sampling duration: `10` seconds
- minimum throughput: `10`
- break duration: `15` seconds

If you want retries, attach your own policy through `ClientBuilder`.

```csharp
var retryPolicy = HttpPolicyExtensions
    .HandleTransientHttpError()
    .RetryAsync(3);

repositoryBuilder.WithApiClient(apiBuilder =>
{
    apiBuilder
        .WithHttpClient("https://api.example.com")
        .ClientBuilder
        .AddPolicyHandler(retryPolicy);
});
```

---

## Request interceptors

Request interceptors let you mutate the `HttpClient` before the repository client starts using it.

Registration options:

```csharp
services.AddApiClientInterceptor<MyGlobalInterceptor>();
services.AddApiClientSpecificInterceptor<Product, MyProductInterceptor>();
services.AddApiClientSpecificInterceptor<Product, int, MyProductKeyInterceptor>();
```

Interfaces:

```csharp
public interface IRepositoryClientInterceptor
{
    Task<HttpClient> EnrichAsync(HttpClient client, RepositoryMethods path);
}

public interface IRepositoryClientInterceptor<T> : IRepositoryClientInterceptor { }
public interface IRepositoryClientInterceptor<T, TKey> : IRepositoryClientInterceptor { }
```

### Important lifecycle nuance

In the current implementation, request interceptors do not run on every repository call.

They run the first time a given `RepositoryClient<T, TKey>` instance enriches its `HttpClient`, then that client is reused for the rest of the repository-client lifetime.

So request interceptors are a good fit for:

- default auth headers
- sticky headers
- long-lived client setup

They are not a good fit for truly per-request values such as a fresh correlation ID on every repository method call.

The execution order is:

1. global interceptors
2. model-specific interceptors
3. model-plus-key-specific interceptors

---

## Response interceptors

Response interceptors run after the HTTP call returns and before the client enforces the final `200 OK` success check.

Registration options:

```csharp
services.AddApiClientResponseInterceptor<MyGlobalResponseInterceptor>();
services.AddApiClientResponseInterceptor<Product, MyProductResponseInterceptor>();
services.AddApiClientResponseInterceptor<Product, int, MyProductKeyResponseInterceptor>();
```

Interfaces:

```csharp
public interface IRepositoryResponseClientInterceptor
{
    Task<HttpResponseMessage> CheckResponseAsync(
        HttpClient client,
        HttpResponseMessage response,
        Func<HttpClient, Task<HttpResponseMessage>> request);
}

public interface IRepositoryClientResponseInterceptor<T> : IRepositoryResponseClientInterceptor { }
public interface IRepositoryResponseClientInterceptor<T, TKey> : IRepositoryResponseClientInterceptor
    where TKey : notnull { }
```

Typical use cases:

- retry after refreshing a token
- logging failed responses
- translating selected server failures before the client throws

The same ordering applies here: global, then model-specific, then model-plus-key-specific.

---

## Bearer token helpers

The package includes a default bearer authenticator based on `ITokenManager`.

### Implement `ITokenManager`

```csharp
public sealed class MyTokenManager : ITokenManager
{
    public Task<string?> GetTokenAsync()
    {
        throw new NotImplementedException();
    }

    public Task<string?> RefreshTokenAsync()
    {
        throw new NotImplementedException();
    }

    public async Task EnrichWithAuthorizationAsync(HttpClient client)
    {
        var token = await GetTokenAsync();
        client.DefaultRequestHeaders.Authorization =
            new AuthenticationHeaderValue("Bearer", token);
    }
}
```

### Register globally

```csharp
services.AddDefaultAuthorizationInterceptorForApiHttpClient<MyTokenManager>();
```

### Register for one model

```csharp
services.AddDefaultAuthorizationInterceptorForApiHttpClient<Product, MyTokenManager>();
```

### Register for one model and key

```csharp
services.AddDefaultAuthorizationInterceptorForApiHttpClient<Product, int, MyTokenManager>();
```

### Authenticator settings

```csharp
services.AddDefaultAuthorizationInterceptorForApiHttpClient<MyTokenManager>(settings =>
{
    settings.Scopes = ["api.read", "api.write"];
    settings.ExceptionHandler = async (exception, serviceProvider) =>
    {
        await Task.CompletedTask;
    };
});
```

### Important behavior notes

- global bearer registration adds both a request interceptor and a response interceptor
- model-specific bearer registration also adds both request and response interceptors
- model-plus-key-specific bearer registration currently adds only the request interceptor, not the response interceptor

So automatic `401 Unauthorized` refresh-and-retry is available in the global and model-specific registrations, but not fully wired in the model-plus-key-specific registration path.

Also note that `AuthenticatorSettings.Scopes` exists in the core client package but is not consumed by the core bearer interceptor itself. It becomes meaningful in the companion authentication packages that provide concrete token managers.

---

## Bootstrap note

`RepositoryClient<T, TKey>` exposes `BootstrapAsync()` because the repository abstraction includes it.

However, the current client implementation simply performs:

```text
GET {basePath}/Bootstrap
```

without sending a key.

The stock API-server bootstrap endpoint is currently wired through the key-binding path, so bootstrap interoperability is less polished than the rest of the client surface. In practice, prefer server-side `WarmUpAsync()` for startup bootstrap flows.

---

## Practical examples from the repo

### Point the client at a custom server path and version

The API tests register clients like this:

```csharp
settings.WithApiClient(apiBuilder =>
{
    apiBuilder
        .WithVersion("v2")
        .WithStartingPath("SuperApi");
});
```

### Match a renamed server route segment

The tests also use the client-side name override to match a server-side `WithName<T>(...)` route customization:

```csharp
settings.WithApiClient(apiBuilder =>
{
    apiBuilder
        .WithName("calamityuser")
        .WithVersion("v2")
        .WithStartingPath("SuperApi");
});
```

### Attach a custom Polly policy

The web client sample configures a retry policy through `ClientBuilder`:

```csharp
var retryPolicy = HttpPolicyExtensions
    .HandleTransientHttpError()
    .Or<TimeoutRejectedException>()
    .RetryAsync(3);

settings.WithApiClient(apiBuilder =>
{
    apiBuilder
        .WithHttpClient("localhost:7058")
        .ClientBuilder
        .AddPolicyHandler(retryPolicy);
});
```

### Global bearer integration

The web client sample also registers the built-in authorization interceptor globally:

```csharp
builder.Services.AddDefaultAuthorizationInterceptorForApiHttpClient(settings =>
{
    settings.Scopes = builder.Configuration["AzureAd:Scopes"]!.Split(' ');
});
```

---

## Related packages

| Package | Purpose |
|---|---|
| `Rystem.RepositoryFramework.Abstractions` | Core repository contracts and DI registration |
| `Rystem.RepositoryFramework.Api.Server` | The server package this client is designed to call |
| `Rystem.RepositoryFramework.Api.Client.Authentication.BlazorServer` | Token-manager helpers for Blazor Server |
| `Rystem.RepositoryFramework.Api.Client.Authentication.BlazorWasm` | Token-manager helpers for Blazor WebAssembly |

If you are continuing through the repository area, this is the package to read right after `src/Repository/RepositoryFramework.Api.Server/README.md`.

---

## Rystem.RepositoryFramework.Api.Client.Authentication.BlazorServer

> !NuGet(https://img.shields.io/nuget/v/Rystem.RepositoryFramework.Api.Client.Authentication.BlazorServer)(https://www.nuget.org/packages/Rystem.RepositoryFramewo

### [What is Rystem?](https://github.com/KeyserDSoze/Rystem)

# Rystem.RepositoryFramework.Api.Client.Authentication.BlazorServer

[![NuGet](https://img.shields.io/nuget/v/Rystem.RepositoryFramework.Api.Client.Authentication.BlazorServer)](https://www.nuget.org/packages/Rystem.RepositoryFramework.Api.Client.Authentication.BlazorServer)
[![NuGet Downloads](https://img.shields.io/nuget/dt/Rystem.RepositoryFramework.Api.Client.Authentication.BlazorServer)](https://www.nuget.org/packages/Rystem.RepositoryFramework.Api.Client.Authentication.BlazorServer)

Blazor Server authentication helpers for `Rystem.RepositoryFramework.Api.Client`.

This package plugs concrete token managers into the API client's interceptor pipeline so repository calls can automatically add bearer tokens in Blazor Server hosts.

## Resources

- Complete Documentation: [https://rystem.net](https://rystem.net)
- MCP Server for AI: [https://rystem.cloud/mcp](https://rystem.cloud/mcp)
- Discord Community: [https://discord.gg/tkWvy4WPjt](https://discord.gg/tkWvy4WPjt)
- Support the Project: [https://www.buymeacoffee.com/keyserdsoze](https://www.buymeacoffee.com/keyserdsoze)

---

## Installation

```bash
dotnet add package Rystem.RepositoryFramework.Api.Client.Authentication.BlazorServer
```

The current package metadata in `src/Repository/RepositoryFramework.Api.Client.Authentication.BlazorServer/RepositoryFramework.Api.Client.Authentication.BlazorServer.csproj` is:

- package id: `Rystem.RepositoryFramework.Api.Client.Authentication.BlazorServer`
- version: `10.0.6`
- target framework: `net11.0`
- main auth dependency: `Microsoft.Identity.Abstractions` `11.0.0`
- companion dependency: `Rystem.Authentication.Social.Blazor`

---

## Package architecture

| Area | Purpose |
|---|---|
| `TokenManager` | Microsoft Identity / MSAL path via `IAuthorizationHeaderProvider` |
| `SocialTokenManager` | Social-login path via `SocialLoginManager` |
| Convenience extensions | Register the right token manager into the base API-client interceptor pipeline |
| Shared `AuthenticatorSettings` | Reuse the settings model from `Rystem.RepositoryFramework.Api.Client` |

---

## Mental model

This package does not implement a new HTTP client. It only provides Blazor Server-specific token sources for the base repository API client.

The actual HTTP behavior still comes from `Rystem.RepositoryFramework.Api.Client`:

- request interceptors add headers
- response interceptors can retry after `401 Unauthorized`
- repository calls still use the same API-client routes and payload shapes

This package only decides how the bearer token is acquired.

---

## Option 1: Microsoft Identity / MSAL

This path is built on `IAuthorizationHeaderProvider` from `Microsoft.Identity.Abstractions`.

### Typical setup

```csharp
builder.Services
    .AddAuthentication(OpenIdConnectDefaults.AuthenticationScheme)
    .AddMicrosoftIdentityWebApp(builder.Configuration.GetSection("AzureAd"))
    .EnableTokenAcquisitionToCallDownstreamApi(["api://your-api-id/.default"])
    .AddInMemoryTokenCaches();

builder.Services.AddDefaultAuthorizationInterceptorForApiHttpClient(settings =>
{
    settings.Scopes = ["api://your-api-id/.default"];
});

builder.Services.AddRepository<Product, int>(repositoryBuilder =>
{
    repositoryBuilder.WithApiClient(apiBuilder =>
    {
        apiBuilder.WithHttpClient("https://api.example.com");
    });
});
```

### How `TokenManager` works

- it asks `IAuthorizationHeaderProvider.CreateAuthorizationHeaderForUserAsync(...)` for a full authorization header value
- it expects that value to look like `Bearer {token}`
- it splits the returned string and applies it to `HttpClient.DefaultRequestHeaders.Authorization`
- if token acquisition fails, it returns `null` and the request proceeds without an auth header

### Scope requirement

In practice you should provide `settings.Scopes` for this path, because the underlying token-manager implementation passes `_settings.Scopes!` to `CreateAuthorizationHeaderForUserAsync(...)`.

---

## Option 2: Rystem social login

This path is built on `SocialLoginManager` from `Rystem.Authentication.Social.Blazor`.

### Typical setup

```csharp
builder.Services.AddDefaultSocialLoginAuthorizationInterceptorForApiHttpClient();

builder.Services.AddRepository<Product, int>(repositoryBuilder =>
{
    repositoryBuilder.WithApiClient(apiBuilder =>
    {
        apiBuilder.WithHttpClient("https://api.example.com");
    });
});
```

### How `SocialTokenManager` works

- it calls `SocialLoginManager.FetchTokenAsync()`
- when a token exists, it sends `Authorization: Bearer {accessToken}`
- when a token is missing, it calls `LogoutAsync()`
- if `NavigationManager` is available, it forces a page refresh so the login flow can restart

This makes the social-login path more aggressive than the MSAL path: missing auth state can immediately push the user back into a sign-in flow.

### Scope of the helper

This package only exposes the social-login convenience method in its global form:

```csharp
builder.Services.AddDefaultSocialLoginAuthorizationInterceptorForApiHttpClient();
```

There is no package-level convenience overload for model-only or model-plus-key-only social auth.

---

## Extension methods

All convenience methods are registered on `IServiceCollection`.

| Method | Token source | Scope |
|---|---|---|
| `AddDefaultAuthorizationInterceptorForApiHttpClient(settings?)` | `TokenManager` | all repository clients |
| `AddDefaultAuthorizationInterceptorForApiHttpClient<T>(settings?)` | `TokenManager` | one model |
| `AddDefaultAuthorizationInterceptorForApiHttpClient<T, TKey>(settings?)` | `TokenManager` | one model + key |
| `AddDefaultSocialLoginAuthorizationInterceptorForApiHttpClient(settings?)` | `SocialTokenManager` | all repository clients |

---

## `AuthenticatorSettings`

This package reuses the shared settings model from the core API client package.

```csharp
public class AuthenticatorSettings
{
    public string[]? Scopes { get; set; }
    public Func<Exception, IServiceProvider, Task>? ExceptionHandler { get; set; }
}
```

- `Scopes` matters for the Microsoft Identity path
- `ExceptionHandler` is used by the base bearer interceptor when request-time token enrichment throws

---

## Source-backed behavior notes

### Request/response behavior comes from the base client package

These helpers ultimately call the generic registration methods in `Rystem.RepositoryFramework.Api.Client`, so the same caveats still apply here:

- global and model-specific registrations add both request and response interceptors
- model-plus-key registration adds only the request interceptor in the current implementation

That means automatic `401` refresh-and-retry is available for the global and model-specific registrations, but not fully for the model-plus-key registration path.

### Token acquisition failures are soft failures

For the Microsoft Identity path, the token manager catches token-acquisition exceptions and returns `null`, so the outgoing request can continue without the bearer header.

### Social-login failures trigger logout behavior

For the social-login path, failure to fetch a token leads to logout plus optional forced navigation refresh.

---

## Practical examples

### Global MSAL registration

```csharp
builder.Services.AddDefaultAuthorizationInterceptorForApiHttpClient(settings =>
{
    settings.Scopes = builder.Configuration["AzureAd:Scopes"]!.Split(' ');
});
```

### Model-specific MSAL registration

```csharp
builder.Services.AddDefaultAuthorizationInterceptorForApiHttpClient<Product>(settings =>
{
    settings.Scopes = ["api://your-api-id/.default"];
});
```

### Global social-login registration

```csharp
builder.Services.AddDefaultSocialLoginAuthorizationInterceptorForApiHttpClient();
```

---

## Related packages

| Package | Purpose |
|---|---|
| `Rystem.RepositoryFramework.Api.Client` | Base repository HTTP client and interceptor pipeline |
| `Rystem.RepositoryFramework.Api.Client.Authentication.BlazorWasm` | Equivalent auth helpers for Blazor WebAssembly |
| `Rystem.Authentication.Social.Blazor` | Social-login infrastructure used by `SocialTokenManager` |
| `Rystem.RepositoryFramework.Api.Server` | Matching server package |

Read this package after `src/Repository/RepositoryFramework.Api.Client/README.md` when your repository client runs in Blazor Server.

---

## Rystem.RepositoryFramework.Api.Client.Authentication.BlazorWasm

> !NuGet(https://img.shields.io/nuget/v/Rystem.RepositoryFramework.Api.Client.Authentication.BlazorWasm)(https://www.nuget.org/packages/Rystem.RepositoryFramework

### [What is Rystem?](https://github.com/KeyserDSoze/Rystem)

# Rystem.RepositoryFramework.Api.Client.Authentication.BlazorWasm

[![NuGet](https://img.shields.io/nuget/v/Rystem.RepositoryFramework.Api.Client.Authentication.BlazorWasm)](https://www.nuget.org/packages/Rystem.RepositoryFramework.Api.Client.Authentication.BlazorWasm)
[![NuGet Downloads](https://img.shields.io/nuget/dt/Rystem.RepositoryFramework.Api.Client.Authentication.BlazorWasm)](https://www.nuget.org/packages/Rystem.RepositoryFramework.Api.Client.Authentication.BlazorWasm)

Blazor WebAssembly authentication helpers for `Rystem.RepositoryFramework.Api.Client`.

This package plugs a WASM-friendly token manager based on `IAccessTokenProvider` into the repository API client's interceptor pipeline.

## Resources

- Complete Documentation: [https://rystem.net](https://rystem.net)
- MCP Server for AI: [https://rystem.cloud/mcp](https://rystem.cloud/mcp)
- Discord Community: [https://discord.gg/tkWvy4WPjt](https://discord.gg/tkWvy4WPjt)
- Support the Project: [https://www.buymeacoffee.com/keyserdsoze](https://www.buymeacoffee.com/keyserdsoze)

---

## Installation

```bash
dotnet add package Rystem.RepositoryFramework.Api.Client.Authentication.BlazorWasm
```

The current package metadata in `src/Repository/RepositoryFramework.Api.Client.Authentication.BlazorWasm/RepositoryFramework.Api.Client.Authentication.BlazorWasm.csproj` is:

- package id: `Rystem.RepositoryFramework.Api.Client.Authentication.BlazorWasm`
- version: `10.0.6`
- target framework: `net11.0`
- main auth dependency: `Microsoft.AspNetCore.Components.WebAssembly.Authentication` `10.0.3`

---

## Package architecture

| Area | Purpose |
|---|---|
| `TokenManager` | Acquire and cache access tokens through `IAccessTokenProvider` |
| Convenience extensions | Register the token manager in the base repository API-client interceptor pipeline |
| Shared `AuthenticatorSettings` | Carry scopes and optional exception handling settings |

---

## Mental model

Like the Blazor Server package, this package does not replace the repository API client. It only supplies a WASM-specific token source.

All HTTP behavior still comes from `Rystem.RepositoryFramework.Api.Client`:

- repository methods map to the same server routes
- request interceptors enrich the outgoing client
- response interceptors can react to non-success responses

This package only handles token acquisition in the browser-hosted auth model.

---

## Typical setup

```csharp
builder.Services.AddOidcAuthentication(options =>
{
    builder.Configuration.Bind("OidcProvider", options.ProviderOptions);
    options.ProviderOptions.DefaultScopes.Add("api.access");
});

builder.Services.AddDefaultAuthorizationInterceptorForApiHttpClient(settings =>
{
    settings.Scopes = ["api.access"];
});

builder.Services.AddRepository<Product, int>(repositoryBuilder =>
{
    repositoryBuilder.WithApiClient(apiBuilder =>
    {
        apiBuilder.WithHttpClient("https://api.example.com");
    });
});
```

---

## Extension methods

All convenience methods are registered on `IServiceCollection`.

| Method | Scope |
|---|---|
| `AddDefaultAuthorizationInterceptorForApiHttpClient(settings?)` | all repository clients |
| `AddDefaultAuthorizationInterceptorForApiHttpClient<T>(settings?)` | one model |
| `AddDefaultAuthorizationInterceptorForApiHttpClient<T, TKey>(settings?)` | one model + key |

These are just WASM-friendly wrappers over the generic bearer-registration helpers from `Rystem.RepositoryFramework.Api.Client`.

---

## How `TokenManager` works

The token manager keeps a cached `AccessToken` and refreshes it when needed.

### Token lifecycle

1. If there is no cached token, request a new one.
2. If the cached token expires within the next 5 minutes, request a new one.
3. If the cached token is still valid, reuse it.
4. When a token is available, set `Authorization: Bearer {token}` on the outgoing `HttpClient`.

### Scopes

- when `AuthenticatorSettings.Scopes` is present, it calls `RequestAccessToken(new AccessTokenRequestOptions { Scopes = ... })`
- when scopes are missing, it calls the parameterless `RequestAccessToken()` overload

---

## `AuthenticatorSettings`

This package reuses the shared settings model from the core API client package.

```csharp
public class AuthenticatorSettings
{
    public string[]? Scopes { get; set; }
    public Func<Exception, IServiceProvider, Task>? ExceptionHandler { get; set; }
}
```

- `Scopes` directly affects the `IAccessTokenProvider` request
- `ExceptionHandler` is executed by the base bearer interceptor when token enrichment throws

---

## Source-backed behavior notes

### Client-side token cache

The token manager stores the last successful `AccessToken` instance and reuses it until the token is within 5 minutes of expiry.

### Exception behavior

If token acquisition throws, the base bearer interceptor catches the exception and can call `ExceptionHandler` if configured.

### No-token result nuance

If `IAccessTokenProvider.RequestAccessToken()` completes without a usable token, the current implementation returns `string.Empty` rather than `null`.

That means the base bearer interceptor can still set an empty bearer header on that path. The happy path is solid, but this edge case is less polished than the Blazor Server variant.

### Inherited interceptor caveat

Because these helpers use the base API-client registration pipeline:

- global and model-specific registrations add both request and response interceptors
- model-plus-key registration currently adds only the request interceptor

So automatic `401` refresh-and-retry is available for the global and model-specific paths, but not fully for the model-plus-key path.

---

## Practical examples

### Global registration

```csharp
builder.Services.AddDefaultAuthorizationInterceptorForApiHttpClient(settings =>
{
    settings.Scopes = ["api://your-api-id/.default", "api.read"];
});
```

### Model-specific registration

```csharp
builder.Services.AddDefaultAuthorizationInterceptorForApiHttpClient<Product>(settings =>
{
    settings.Scopes = ["api://your-api-id/.default"];
});
```

### Model-and-key-specific registration

```csharp
builder.Services.AddDefaultAuthorizationInterceptorForApiHttpClient<Product, int>(settings =>
{
    settings.Scopes = ["api://your-api-id/.default"];
});
```

---

## Related packages

| Package | Purpose |
|---|---|
| `Rystem.RepositoryFramework.Api.Client` | Base repository HTTP client and interceptor pipeline |
| `Rystem.RepositoryFramework.Api.Client.Authentication.BlazorServer` | Equivalent auth helpers for Blazor Server |
| `Rystem.RepositoryFramework.Api.Server` | Matching server package |

Read this package after `src/Repository/RepositoryFramework.Api.Client/README.md` when your repository client runs in Blazor WebAssembly.

---

## Rystem.RepositoryFramework.Api.Server

> !NuGet(https://img.shields.io/nuget/v/Rystem.RepositoryFramework.Api.Server)(https://www.nuget.org/packages/Rystem.RepositoryFramework.Api.Server)

### [What is Rystem?](https://github.com/KeyserDSoze/Rystem)

# Rystem.RepositoryFramework.Api.Server

[![NuGet](https://img.shields.io/nuget/v/Rystem.RepositoryFramework.Api.Server)](https://www.nuget.org/packages/Rystem.RepositoryFramework.Api.Server)
[![NuGet Downloads](https://img.shields.io/nuget/dt/Rystem.RepositoryFramework.Api.Server)](https://www.nuget.org/packages/Rystem.RepositoryFramework.Api.Server)

Minimal-API endpoint generation for repositories and CQRS registrations created through the Rystem repository framework.

This package reads the runtime repository registry and turns registered repositories, commands, and queries into HTTP endpoints without controllers.

## Resources

- Complete Documentation: [https://rystem.net](https://rystem.net)
- MCP Server for AI: [https://rystem.cloud/mcp](https://rystem.cloud/mcp)
- Discord Community: [https://discord.gg/tkWvy4WPjt](https://discord.gg/tkWvy4WPjt)
- Support the Project: [https://www.buymeacoffee.com/keyserdsoze](https://www.buymeacoffee.com/keyserdsoze)

---

## Installation

```bash
dotnet add package Rystem.RepositoryFramework.Api.Server
```

The current package metadata in `src/Repository/RepositoryFramework.Api.Server/RepositoryFramework.Api.Server.csproj` is:

- package id: `Rystem.RepositoryFramework.Api.Server`
- version: `10.0.6`
- target framework: `net11.0`
- framework reference: `Microsoft.AspNetCore.App`
- Swagger package: `Swashbuckle.AspNetCore` `10.1.4`

---

## Package architecture

| Area | Purpose |
|---|---|
| `AddApiFromRepositoryFramework()` | Collect API-level settings such as path, version, Swagger, CORS, and diagnostics |
| `UseApiFromRepositoryFramework()` | Read `RepositoryFrameworkRegistry` and map endpoints |
| Authorization builder | Apply endpoint-level auth rules by repository method group |
| Repository authorization handlers | Add repository-specific authorization logic via `IRepositoryAuthorization<T, TKey>` |
| Map/models diagnostics | Expose generated endpoint metadata and generated TypeScript model definitions |
| Swagger/OpenID helpers | Configure Swagger UI and OpenID metadata for the generated API |

---

## Mental model

This package does not replace repository registration. It sits on top of it.

The flow is:

1. Register repositories, commands, or queries through the abstractions layer.
2. Optionally mark methods as exposable or hidden on each repository registration.
3. Configure API behavior with `AddApiFromRepositoryFramework()`.
4. Map the generated endpoints with `UseApiFromRepositoryFramework()`.

The package discovers what to expose from `RepositoryFrameworkRegistry`, so there is no controller layer to keep in sync.

---

## Quick start

This is the real shape used in the sample host under `src/Repository/RepositoryFramework.Test/RepositoryFramework.WebApi/Program.cs`.

```csharp
builder.Services.AddRepository<SuperUser, string>(repositoryBuilder =>
{
    repositoryBuilder.WithInMemory(inMemoryBuilder =>
    {
        inMemoryBuilder
            .PopulateWithRandomData(120, 5)
            .WithPattern(x => x.Value!.Email, @"[a-z]{5,10}@gmail\.com");
    });
});

builder.Services.AddApiFromRepositoryFramework()
    .WithDescriptiveName("Repository Api")
    .WithSwagger()
    .WithMapApi()
    .WithModelsApi()
    .WithDocumentation()
    .WithDefaultCorsWithAllOrigins();

var app = builder.Build();
await app.Services.WarmUpAsync();

app.UseAuthentication();
app.UseAuthorization();

app.UseApiFromRepositoryFramework()
    .WithNoAuthorization();

app.Run();
```

---

## Service-side configuration

`AddApiFromRepositoryFramework()` returns `IApiBuilder`.

```csharp
builder.Services.AddApiFromRepositoryFramework()
    .WithDescriptiveName("My API")
    .WithPath("api")
    .WithVersion("v2")
    .WithSwagger()
    .WithMapApi()
    .WithModelsApi();
```

### Configuration methods

| Method | What it does |
|---|---|
| `WithDescriptiveName(string)` | Sets the API name used by Swagger UI |
| `WithPath(string)` | Sets the base path segment, default `api` |
| `WithVersion(string)` | Adds a version segment after the base path |
| `WithName<T>(string)` | Overrides the route segment used for model `T` |
| `WithSwagger()` | Registers Swagger/OpenAPI services and UI support |
| `WithDocumentation()` | Enables extra Swagger UI customization and PDF export support |
| `WithMapApi()` | Enables the repository map endpoint |
| `WithModelsApi()` | Enables the generated-model endpoint |
| `WithDefaultCors(params string[] domains)` | Registers a default named CORS policy for the provided origins |
| `WithDefaultCorsWithAllOrigins()` | Registers a permissive named CORS policy |
| `WithCors(Action<CorsOptions>)` | Lets you configure CORS directly |
| `WithOpenIdAuthentication(...)` | Configures OpenID metadata for Swagger UI and returns `IIdentityApiBuilder` |
| `ConfigureAzureActiveDirectory(IConfiguration)` | Shortcut that reads `AzureAd:*` settings and configures OpenID metadata |

### Important note about `WithDocumentation()`

`WithDocumentation()` does not load XML doc comments.

In the current implementation it enhances Swagger UI by injecting custom UI content and a RapiPDF-based export button. It only has visible effect when Swagger is also enabled.

---

## Route generation

The main generated route shape is:

- default registration: `/{path}/{version?}/{modelName}/{method}`
- named registration: `/{path}/{version?}/{modelName}/{factoryName}/{method}`

Examples:

- `/api/v1/SuperUser/Get`
- `/api/v1/SuperUser/Insert`
- `/api/v1/SuperUser/inmemory/Get`

If you override a name with `WithName<T>(...)`, that custom segment is used instead of `typeof(T).Name`.

---

## Mapping all repositories or one repository

### Map every registered repository

```csharp
app.UseApiFromRepositoryFramework()
    .WithNoAuthorization();
```

### Map a single entity type

```csharp
app.UseApiFromRepositoryFramework<WebApplication, SuperUser, string>()
    .WithNoAuthorization();
```

### Map a specific named registration

```csharp
app.UseApiFromRepositoryFramework<WebApplication, SuperUser, string>(name: "inmemory")
    .WithNoAuthorization();
```

---

## Request shapes by method

The generated HTTP shape depends not only on the repository method, but also on whether `TKey` is JSON-serializable according to `KeySettings<TKey>`.

### Non-JSON keys

For primitive/string/`IKey`-style keys, the generated endpoints are:

| Method | HTTP | Shape |
|---|---|---|
| `Get` | `GET` | `?key=...` |
| `Exist` | `GET` | `?key=...` |
| `Delete` | `GET` | `?key=...` |
| `Insert` | `POST` | query `key` + body `T` |
| `Update` | `POST` | query `key` + body `T` |
| `Query` | `POST` | body `SerializableFilter?` |
| `Operation` | `POST` | query `op`, optional query `returnType`, body `SerializableFilter?` |
| `Batch` | `POST` | body `BatchOperations<T, TKey>` |

### JSON-style keys

For keys treated as JSONable by `KeySettings<TKey>`, the generated endpoints switch to request bodies for key-based methods.

| Method | HTTP | Shape |
|---|---|---|
| `Get` | `POST` | body `TKey` |
| `Exist` | `POST` | body `TKey` |
| `Delete` | `POST` | body `TKey` |
| `Insert` | `POST` | body `Entity<T, TKey>` |
| `Update` | `POST` | body `Entity<T, TKey>` |

### Stream endpoints

Two methods also generate streaming variants:

- `POST .../Query/Stream`
- `POST .../Batch/Stream`

These return the underlying async stream instead of materializing everything into a list first.

---

## Repository methods and exposure

The API server only maps methods that are both:

- implemented by the registered service
- allowed by the repository's `ExposedMethods`

That means abstractions-layer settings such as these directly affect the generated API:

- `SetExposable(...)`
- `SetOnlyQueryExposable()`
- `SetOnlyCommandExposable()`
- `SetNotExposable()`

For custom storages that are not marked as default integrations, the mapper also skips methods whose body is just `throw new NotImplementedException(...)`.

---

## Diagnostics endpoints

Two optional endpoints provide metadata about the generated API.

### Repository map

Enable it with:

```csharp
builder.Services.AddApiFromRepositoryFramework()
    .WithMapApi();
```

Route:

```text
/Repository/Map/All
```

This endpoint is not placed under your configured API base path. It is a fixed diagnostic route.

It returns:

- every generated API entry
- route URIs
- repository method names
- authentication/policy metadata
- sample request and response payloads

If you registered repository examples with `SetExamples(...)`, those values are used. Otherwise the package falls back to random sample generation.

### Models endpoint

Enable it with:

```csharp
builder.Services.AddApiFromRepositoryFramework()
    .WithModelsApi();
```

Current route:

```text
/Repository/Models/Typescript
```

This route returns generated TypeScript definitions for repository models and non-primitive keys. It is also outside the main API base path.

---

## Authorization at endpoint-mapping time

`UseApiFromRepositoryFramework()` returns `IApiAuthorizationBuilder`.

### No authorization

```csharp
app.UseApiFromRepositoryFramework()
    .WithNoAuthorization();
```

### Require authentication on all endpoints

```csharp
app.UseApiFromRepositoryFramework()
    .WithDefaultAuthorization();
```

This maps endpoints and applies `RequireAuthorization()` without naming a specific policy.

### Query vs command policies

```csharp
app.UseApiFromRepositoryFramework()
    .SetPolicyForQuery().With("ReadUser")
    .And()
    .SetPolicyForCommand().With("WriteUser")
    .Build();
```

### Specific methods

```csharp
app.UseApiFromRepositoryFramework()
    .SetPolicyForAll().With("AuthenticatedUser")
    .And()
    .SetPolicy(RepositoryMethods.Insert, RepositoryMethods.Update, RepositoryMethods.Delete).With("AdminUser")
    .Build();
```

### Builder methods

| Method | Purpose |
|---|---|
| `WithNoAuthorization()` | Map endpoints without auth requirements |
| `WithDefaultAuthorization()` | Require authentication on all mapped endpoints |
| `SetPolicyForAll()` | Target every repository method |
| `SetPolicyForCommand()` | Target `Insert`, `Update`, `Delete`, `Batch` |
| `SetPolicyForQuery()` | Target `Exist`, `Get`, `Query`, `Operation` |
| `SetPolicy(...)` | Target specific `RepositoryMethods` |
| `Build()` | Finalize endpoint mapping |

### Policy chaining methods

| Method | Purpose |
|---|---|
| `With(params string[])` | Attach ASP.NET policy names |
| `Empty()` | Require auth but clear explicit policy names |
| `And()` | Return to the main authorization builder |
| `Build()` | Finalize mapping |

---

## Repository-specific authorization handlers

This package also supports custom authorization handlers that run with repository-specific context.

### Register directly on a repository builder

```csharp
repositoryBuilder
    .ConfigureSpecificPolicies()
    .WithAuthorizationHandler<PolicyHandlerForSuperUser>();
```

### Scan assemblies for handlers

```csharp
builder.Services.ScanAuthorizationForRepositoryFramework();
```

Handlers implement:

```csharp
public interface IRepositoryAuthorization<in T, in TKey>
{
    Task<AuthorizedRepositoryResponse> HandleRequirementAsync(
        IHttpContextAccessor httpContextAccessor,
        AuthorizationHandlerContext context,
        RepositoryRequirement requirement,
        RepositoryMethods method,
        TKey? key,
        T? value);
}
```

This gives the handler access to:

- the current repository method
- the current request
- the parsed key when available
- the parsed entity body for insert/update when available

`ScanAuthorizationForRepositoryFramework()` attaches discovered handlers to repositories with the matching model/key pair and registers the backing ASP.NET authorization policies automatically.

---

## Swagger and OpenID notes

### Swagger

```csharp
builder.Services.AddApiFromRepositoryFramework()
    .WithDescriptiveName("Repository Api")
    .WithSwagger();
```

Swagger UI is activated when the endpoints are mapped through `UseApiFromRepositoryFramework(...)`.

### OpenID metadata for Swagger UI

```csharp
builder.Services.AddApiFromRepositoryFramework()
    .WithSwagger()
    .WithOpenIdAuthentication(settings =>
    {
        settings.AuthorizationUrl = new Uri("https://login.example.com/oauth2/authorize");
        settings.TokenUrl = new Uri("https://login.example.com/oauth2/token");
        settings.ClientId = "client-id";
        settings.Scopes.Add(new ApiIdentityScopeSettings
        {
            Value = "api.read",
            Description = "Read access"
        });
    })
    .WithAuthorization(options =>
    {
        options.AddPolicy("AdminOnly", policy => policy.RequireRole("Admin"));
    });
```

Important: `WithOpenIdAuthentication(...)` and `ConfigureAzureActiveDirectory(...)` configure Swagger/OpenAPI authentication metadata. They do not register your runtime ASP.NET authentication handler.

You still need the normal server-side authentication setup, for example:

```csharp
builder.Services
    .AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddMicrosoftIdentityWebApi(builder.Configuration.GetSection("AzureAd"));
```

### Azure Active Directory shortcut

```csharp
builder.Services.AddApiFromRepositoryFramework()
    .WithSwagger()
    .ConfigureAzureActiveDirectory(builder.Configuration);
```

This reads:

- `AzureAd:Instance`
- `AzureAd:TenantId`
- `AzureAd:ClientId`
- `AzureAd:Scopes`

and converts them into the OpenID settings used by Swagger UI.

---

## Warm-up and bootstrap

If your repositories rely on startup work such as in-memory data population or other bootstrap actions, keep calling:

```csharp
await app.Services.WarmUpAsync();
```

before serving requests.

The API package can also expose repository `Bootstrap` endpoints when that method is exposable.

One source-backed nuance: the current bootstrap endpoint still flows through the same key-binding pipeline as other key-based methods, even though the key is ignored by the implementation.

---

## Practical examples from the repo

### Rename an entity route segment

The API tests configure custom names like this:

```csharp
builder.Services.AddApiFromRepositoryFramework()
    .WithName<ExtremelyRareUser>("extremelyrareuserrefresh")
    .WithName<CalamityUniverseUser>("calamityuser")
    .WithPath("SuperApi")
    .WithVersion("v2");
```

That produces routes like:

```text
/SuperApi/v2/extremelyrareuserrefresh/Get
```

### Map endpoint metadata and models

The same API tests also enable:

```csharp
builder.Services.AddApiFromRepositoryFramework()
    .WithSwagger()
    .WithMapApi()
    .WithModelsApi()
    .WithDocumentation();
```

### Clear no-auth mapping in tests and samples

The tests and sample host generally use the explicit no-auth mapping form:

```csharp
app.UseApiFromRepositoryFramework()
    .WithNoAuthorization();
```

---

## Related packages

| Package | Purpose |
|---|---|
| `Rystem.RepositoryFramework.Abstractions` | Repository registration, exposure flags, keys, filters, and business hooks |
| `Rystem.RepositoryFramework.Api.Client` | .NET client for the generated server endpoints |
| `rystem.repository.client` | TypeScript/npm client for the generated server endpoints |

If you are continuing through the repository area, this package is the bridge between repository registrations and HTTP exposure.

---

## repository/repositoryframework-cache

> Rystem.RepositoryFramework.Cache adds cache decorators on top of Repository Framework registrations. You keep resolving the same IRepository<T, TKey>, IQuery<T,

# Rystem.RepositoryFramework.Cache

`Rystem.RepositoryFramework.Cache` adds cache decorators on top of Repository Framework registrations. You keep resolving the same `IRepository<T, TKey>`, `IQuery<T, TKey>`, or `ICommand<T, TKey>` services, but the runtime pipeline first checks a cache layer and then falls back to the original storage implementation.

The package is intentionally thin: it does not replace your storage, it decorates it.

## Installation

```bash
dotnet add package Rystem.RepositoryFramework.Cache
```

## How the cache layer is wired

The package registers one of these decorators:

- `CachedRepository<T, TKey>` for full repositories.
- `CachedQuery<T, TKey>` for query-only registrations.
- `CachedRepository<T, TKey>` for command-only registrations, but only when cache options include write methods.

That means caching is opt-in per registration and per method group.

```csharp
builder.Services.AddRepository<Country, CountryKey>(repositoryBuilder =>
{
    repositoryBuilder.WithInMemory(builder =>
    {
        builder.PopulateWithRandomData(100, 100);
    });

    repositoryBuilder.WithInMemoryCache(cache =>
    {
        cache.ExpiringTime = TimeSpan.FromSeconds(10);
        cache.Methods = RepositoryMethods.Get
            | RepositoryMethods.Query
            | RepositoryMethods.Exist;
    });
});
```

After registration, the resolved `IRepository<Country, CountryKey>` behaves like this:

1. try cache
2. fall back to the underlying repository when needed
3. write the result back to cache when the configured method allows it

## Supported cache backends

### `WithInMemoryCache(...)`

Uses the package-provided `InMemoryCache<T, TKey>` over `IMemoryCache`.

- Calls `AddMemoryCache()` automatically.
- Registers the cache service as `Singleton`.
- Good fit for single-instance apps or as the first level of a multi-layer cache.

```csharp
builder.Services.AddRepository<Plant, int>(repositoryBuilder =>
{
    repositoryBuilder.WithInMemory();

    repositoryBuilder.WithInMemoryCache(cache =>
    {
        cache.ExpiringTime = TimeSpan.FromMinutes(1);
        cache.Methods = RepositoryMethods.Query | RepositoryMethods.Get;
    });
});
```

### `WithDistributedCache(...)`

Wraps the `Microsoft.Extensions.Caching.Distributed.IDistributedCache` that is already in DI.

- The Repository Framework adapter serializes values as JSON.
- The default adapter sets `AbsoluteExpiration`, `AbsoluteExpirationRelativeToNow`, and `SlidingExpiration` to the same `ExpiringTime`.
- Registers the adapter as `Singleton` by default.

```csharp
builder.Services.AddStackExchangeRedisCache(options =>
{
    options.Configuration = builder.Configuration.GetConnectionString("Redis");
    options.InstanceName = "RepositoryFramework";
});

builder.Services.AddRepository<Country, CountryKey>(repositoryBuilder =>
{
    repositoryBuilder.WithInMemory(builder =>
    {
        builder.PopulateWithRandomData(100, 100);
    });

    repositoryBuilder.WithDistributedCache(cache =>
    {
        cache.ExpiringTime = TimeSpan.FromSeconds(10);
        cache.Methods = RepositoryMethods.Query | RepositoryMethods.Get | RepositoryMethods.Exist;
    });
});
```

### `WithCache<T, TKey, TCache>(...)`

Use this when you want a custom in-process or custom remote cache implementation.

```csharp
public sealed class MyCache<T, TKey> : ICache<T, TKey>
    where TKey : notnull
{
    public Task<CacheResponse<TValue>> RetrieveAsync<TValue>(
        string key,
        CancellationToken cancellationToken = default)
        => Task.FromResult(new CacheResponse<TValue>(false, default));

    public Task<bool> SetAsync<TValue>(
        string key,
        TValue value,
        CacheOptions<T, TKey> options,
        CancellationToken? cancellationToken = null)
        => Task.FromResult(true);

    public Task<bool> DeleteAsync(
        string key,
        CancellationToken cancellationToken = default)
        => Task.FromResult(true);
}

builder.Services.AddRepository<Plant, int>(repositoryBuilder =>
{
    repositoryBuilder.WithInMemory();

    repositoryBuilder.WithCache<Plant, int, MyCache<Plant, int>>(cache =>
    {
        cache.ExpiringTime = TimeSpan.FromMinutes(5);
        cache.Methods = RepositoryMethods.All;
    });
});
```

### `WithDistributedCache<T, TKey, TCache>(...)`

Use this when your custom cache should be treated as a distributed cache layer.

`TCache` must implement `IDistributedCache<T, TKey>`, which extends `ICache<T, TKey>`.

## CQRS registrations

The cache package works on full repositories and on CQRS-only registrations.

### Query only

```csharp
builder.Services.AddQuery<Plant, int>(queryBuilder =>
{
    queryBuilder.WithInMemory();
    queryBuilder.WithInMemoryCache(cache =>
    {
        cache.ExpiringTime = TimeSpan.FromMinutes(5);
    });
});
```

### Command only

For command-only registrations, the decorator is added only when you cache write methods.

```csharp
builder.Services.AddCommand<Plant, int>(commandBuilder =>
{
    commandBuilder.WithInMemory();
    commandBuilder.WithInMemoryCache(cache =>
    {
        cache.ExpiringTime = TimeSpan.FromMinutes(1);
        cache.Methods = RepositoryMethods.Insert
            | RepositoryMethods.Update
            | RepositoryMethods.Delete;
    });
});
```

If you configure only `Get`, `Query`, or `Exist` on a command registration, there is no command decorator to apply those settings.

## Two-level caching

The decorators support having both local and distributed cache layers on the same registration. The unit tests wire exactly that pattern with in-memory storage plus in-memory cache plus Redis-backed distributed cache.

```csharp
builder.Services.AddRepository<Country, CountryKey>(repositoryBuilder =>
{
    repositoryBuilder.WithInMemory(builder =>
    {
        builder.PopulateWithRandomData(100, 100);
    });

    repositoryBuilder
        .WithInMemoryCache(cache =>
        {
            cache.ExpiringTime = TimeSpan.FromSeconds(10);
        })
        .WithDistributedCache(cache =>
        {
            cache.ExpiringTime = TimeSpan.FromSeconds(10);
        });
});
```

Read flow in that setup:

1. check `ICache<T, TKey>`
2. check `IDistributedCache<T, TKey>`
3. hit the underlying repository
4. backfill any cache layers that missed

## What is cached

### Read methods

- `GetAsync(key)` caches the returned model.
- `ExistAsync(key)` caches the returned `State<T, TKey>`.
- `QueryAsync(filter)` materializes the full async stream to a `List<Entity<T, TKey>>` and caches that list.
- `OperationAsync(...)` is also cached, and it uses the `Query` flag to decide whether caching is enabled.

Because query results are materialized before caching, this package is best for repeated reads of the same filter, not for preserving streaming behavior end-to-end.

### Write methods

- `InsertAsync` can refresh `Get` and `Exist` cache entries for the affected key.
- `UpdateAsync` can refresh `Get` and `Exist` cache entries for the affected key.
- `DeleteAsync` can remove `Get` and `Exist` cache entries for the affected key.
- `BatchAsync` updates or removes per-key `Get` and `Exist` entries as it iterates through batch results.

The package does not keep a registry of query filters, so write operations do not invalidate previously cached query results.

That behavior is visible in `RepositoryFramework.UnitTest/Tests/Cache/CacheTest.cs`: deleting all records from the underlying repository does not remove the cached query result, so the old list is served again until cache expiration.

## Cache key behavior

The decorators build their own cache keys.

- `Get` and `Exist` include method name, model type name, factory name, and serialized key.
- `Query` includes method name, model type name, and the filter key.
- `Operation` includes method name, operation name, model type name, and the filter key.

Practical consequence:

- named repository registrations are respected for `Get` and `Exist`
- query and operation caches are not partitioned by factory name in the current implementation

If you use multiple named registrations for the same model with different backends, document that behavior for your team before enabling query caching.

## Defaults and options

## `CacheOptions<T, TKey>`

| Property | Default | Notes |
| --- | --- | --- |
| `Methods` | `Query | Get | Exist` | Controls which operations participate in caching. |
| `ExpiringTime` | `365 days` | Used by the built-in in-memory cache and passed to custom caches. |

`HasCommandPattern` becomes `true` when `Methods` includes `Insert`, `Update`, `Delete`, or `All`.

## `DistributedCacheOptions<T, TKey>`

Inherits from `CacheOptions<T, TKey>`.

| Property | Default | Notes |
| --- | --- | --- |
| `Methods` | `Query | Get | Exist` | Same behavior as `CacheOptions<T, TKey>`. |
| `ExpiringTime` | `365 * 365 days` | Very large default; set it explicitly for real workloads. |

## `RepositoryMethods` flags in cache scenarios

| Flag | Effect |
| --- | --- |
| `Get` | Enables read-through caching for `GetAsync`. |
| `Exist` | Enables read-through caching for `ExistAsync`. |
| `Query` | Enables caching for `QueryAsync` and `OperationAsync`. |
| `Insert` | After insert, refreshes key-based cache entries. |
| `Update` | After update, refreshes key-based cache entries. |
| `Delete` | After delete, removes key-based cache entries. |
| `All` | Enables every flag. |

## Warm-up and lifecycle notes

The cache package does not add its own bootstrap workflow. Any warm-up still comes from the underlying repository registration, for example when an in-memory repository is populated through `PopulateWithRandomData(...)` and then activated via `WarmUpAsync()`.

## When to use this package

Use it when you want to:

- add read caching without changing your repository consumers
- stack in-memory and distributed cache decorators
- keep cache concerns outside your domain repositories
- experiment with caching policies per registration or per named factory

If you also need a Blob Storage-backed distributed cache provider, see `../RepositoryFramework.Cache.Azure.Storage.Blob/README.md`.

---

## repository/repositoryframework-cache-azure-storage-blob

> Rystem.RepositoryFramework.Cache.Azure.Storage.Blob adds a Blob Storage-backed distributed cache adapter for Repository Framework decorators.

# Rystem.RepositoryFramework.Cache.Azure.Storage.Blob

`Rystem.RepositoryFramework.Cache.Azure.Storage.Blob` adds a Blob Storage-backed distributed cache adapter for Repository Framework decorators.

It does not cache entities directly inside your main repository storage. Instead, it registers a dedicated internal repository for `BlobStorageCacheModel` and uses Azure Blob Storage as the persistence layer for cache entries.

## Installation

```bash
dotnet add package Rystem.RepositoryFramework.Cache.Azure.Storage.Blob
```

This package builds on top of:

- `Rystem.RepositoryFramework.Cache`
- `Rystem.RepositoryFramework.Infrastructure.Azure.Storage.Blob`

## How it works

Calling `WithBlobStorageCache(...)` does two things:

1. registers an internal `IRepository<BlobStorageCacheModel, string>` backed by the Blob Storage infrastructure package
2. wires `BlobStorageCache<T, TKey>` as the distributed cache decorator for your repository, query, or command registration

Each cached value is stored as a blob containing:

- `Expiration` as a `DateTime`
- `Value` as serialized JSON

At read time the adapter:

1. checks whether the cache blob exists
2. downloads the blob
3. compares `Expiration` with `DateTime.UtcNow`
4. deserializes the stored JSON payload when still valid

If the entry is expired, the adapter simply returns a cache miss. The current implementation does not automatically delete the stale blob during that read.

## Basic repository example

```csharp
builder.Services.AddRepository<User, string>(repositoryBuilder =>
{
    repositoryBuilder.WithBlobStorage(storage =>
    {
        storage.Settings.ConnectionString = builder.Configuration["ConnectionStrings:Storage"];
        storage.Settings.ContainerName = "users";
    });

    repositoryBuilder.WithBlobStorageCache(
        cacheStorage =>
        {
            cacheStorage.Settings.ConnectionString = builder.Configuration["ConnectionStrings:Storage"];
            cacheStorage.Settings.ContainerName = "user-cache";
            cacheStorage.Settings.Prefix = "cache/";
        },
        cache =>
        {
            cache.ExpiringTime = TimeSpan.FromMinutes(5);
            cache.Methods = RepositoryMethods.Get
                | RepositoryMethods.Query
                | RepositoryMethods.Exist;
        });
});
```

This keeps your domain data container separate from your cache container, which is usually the cleanest setup.

## CQRS registrations

The package exposes overloads for all three Repository Framework patterns.

### Repository

```csharp
builder.Services.AddRepository<Document, Guid>(repositoryBuilder =>
{
    repositoryBuilder.WithBlobStorage(storage =>
    {
        storage.Settings.ConnectionString = builder.Configuration["ConnectionStrings:Storage"];
    });

    repositoryBuilder.WithBlobStorageCache(cacheStorage =>
    {
        cacheStorage.Settings.ConnectionString = builder.Configuration["ConnectionStrings:Storage"];
        cacheStorage.Settings.ContainerName = "document-cache";
    });
});
```

### Query only

```csharp
builder.Services.AddQuery<User, string>(queryBuilder =>
{
    queryBuilder.WithBlobStorage(storage =>
    {
        storage.Settings.ConnectionString = builder.Configuration["ConnectionStrings:Storage"];
    });

    queryBuilder.WithBlobStorageCache(
        cacheStorage =>
        {
            cacheStorage.Settings.ConnectionString = builder.Configuration["ConnectionStrings:Storage"];
            cacheStorage.Settings.ContainerName = "user-query-cache";
        },
        cache =>
        {
            cache.ExpiringTime = TimeSpan.FromMinutes(30);
            cache.Methods = RepositoryMethods.Get | RepositoryMethods.Query;
        });
});
```

### Command only

As with the base cache package, write caching on command-only registrations is meaningful only when `Methods` includes write flags.

```csharp
builder.Services.AddCommand<User, string>(commandBuilder =>
{
    commandBuilder.WithBlobStorage(storage =>
    {
        storage.Settings.ConnectionString = builder.Configuration["ConnectionStrings:Storage"];
    });

    commandBuilder.WithBlobStorageCache(
        cacheStorage =>
        {
            cacheStorage.Settings.ConnectionString = builder.Configuration["ConnectionStrings:Storage"];
            cacheStorage.Settings.ContainerName = "user-command-cache";
        },
        cache =>
        {
            cache.ExpiringTime = TimeSpan.FromMinutes(10);
            cache.Methods = RepositoryMethods.Insert
                | RepositoryMethods.Update
                | RepositoryMethods.Delete;
        });
});
```

## Two-level cache example

You can stack the standard in-memory decorator in front of Blob Storage.

```csharp
builder.Services.AddRepository<User, string>(repositoryBuilder =>
{
    repositoryBuilder.WithBlobStorage(storage =>
    {
        storage.Settings.ConnectionString = builder.Configuration["ConnectionStrings:Storage"];
        storage.Settings.ContainerName = "users";
    });

    repositoryBuilder.WithInMemoryCache(cache =>
    {
        cache.ExpiringTime = TimeSpan.FromSeconds(30);
        cache.Methods = RepositoryMethods.Get | RepositoryMethods.Query;
    });

    repositoryBuilder.WithBlobStorageCache(
        cacheStorage =>
        {
            cacheStorage.Settings.ConnectionString = builder.Configuration["ConnectionStrings:Storage"];
            cacheStorage.Settings.ContainerName = "user-cache";
        },
        cache =>
        {
            cache.ExpiringTime = TimeSpan.FromMinutes(10);
            cache.Methods = RepositoryMethods.All;
        });
});
```

Read flow in that setup:

1. try in-memory cache
2. try Blob Storage distributed cache
3. hit the underlying repository
4. repopulate missed layers

## Blob-specific behavior

The Blob Storage cache adapter is intentionally small and inherits most behavior from the base cache package.

Important details from the source:

- cache values are serialized with `System.Text.Json`
- `SetAsync(...)` writes through `UpdateAsync(...)` on the internal blob repository
- because the blob repository uses `UploadAsync(..., overwrite: true)`, cache writes behave like upserts
- `DeleteAsync(...)` first checks whether the cache blob exists and then deletes it
- the cache repository key type is always `string`

## Naming and factory behavior

`WithBlobStorageCache(...)` accepts the same optional `name` parameter used across Repository Framework registrations.

That name is used for two different things:

- selecting the decorated repository/query/command registration
- naming the internal `IRepository<BlobStorageCacheModel, string>` factory registration created for the cache backend

This means named registrations are supported, but the same caveats from the base cache package still apply:

- `Get` and `Exist` cache keys include the factory name
- `Query` and `Operation` cache keys do not include the factory name in the current implementation

If you have multiple named registrations for the same model and they expose different data sources, avoid query caching or keep their cache backends physically separate.

## Cache options

This package uses `DistributedCacheOptions<T, TKey>` from `Rystem.RepositoryFramework.Cache`.

| Property | Default | Notes |
| --- | --- | --- |
| `Methods` | `Query | Get | Exist` | Enables read-through caching by default. |
| `ExpiringTime` | `365 * 365 days` | Set this explicitly for production workloads. |

Relevant flags:

- `Get` caches `GetAsync`
- `Exist` caches `ExistAsync`
- `Query` caches `QueryAsync` and `OperationAsync`
- `Insert`, `Update`, and `Delete` keep key-based cache entries in sync
- `All` enables every flag

As with the base cache package, write operations update `Get` and `Exist` entries for affected keys, but they do not invalidate previously cached query result sets.

## Choosing containers and prefixes

The cache storage registration uses the same Blob Storage builder as the main Azure Blob infrastructure package, so you can configure:

- `ConnectionString`
- `EndpointUri`
- `ManagedIdentityClientId`
- `ContainerName`
- `Prefix`
- `ClientOptions`

Using a dedicated container like `user-cache` is usually easier to inspect and rotate than mixing cache blobs with domain blobs.

## When to use this package

Use it when you want:

- a distributed cache layer without bringing in Redis or SQL Server cache infrastructure
- cache entries that can be shared across app instances through Azure Blob Storage
- a cache backend configured with the same Blob Storage connection model already used by Repository Framework storage packages

If you want the generic cache decorators without Blob Storage, start with `../RepositoryFramework.Cache/README.md`.

---

## Rystem.RepositoryFramework.Infrastructure.InMemory

> !NuGet(https://img.shields.io/nuget/v/Rystem.RepositoryFramework.Infrastructure.InMemory)(https://www.nuget.org/packages/Rystem.RepositoryFramework.Infrastructu

### [What is Rystem?](https://github.com/KeyserDSoze/Rystem)

# Rystem.RepositoryFramework.Infrastructure.InMemory

[![NuGet](https://img.shields.io/nuget/v/Rystem.RepositoryFramework.Infrastructure.InMemory)](https://www.nuget.org/packages/Rystem.RepositoryFramework.Infrastructure.InMemory)
[![NuGet Downloads](https://img.shields.io/nuget/dt/Rystem.RepositoryFramework.Infrastructure.InMemory)](https://www.nuget.org/packages/Rystem.RepositoryFramework.Infrastructure.InMemory)

In-memory storage for the Rystem repository ecosystem, designed for local development, sample apps, integration tests, random data population, and resilience simulations.

This package sits on top of `Rystem.RepositoryFramework.Abstractions` and is usually the easiest concrete provider to start with when you want repository behavior without a real external database.

## Resources

- Complete Documentation: [https://rystem.net](https://rystem.net)
- MCP Server for AI: [https://rystem.cloud/mcp](https://rystem.cloud/mcp)
- Discord Community: [https://discord.gg/tkWvy4WPjt](https://discord.gg/tkWvy4WPjt)
- Support the Project: [https://www.buymeacoffee.com/keyserdsoze](https://www.buymeacoffee.com/keyserdsoze)

---

## Installation

```bash
dotnet add package Rystem.RepositoryFramework.Infrastructure.InMemory
```

The current package metadata in `src/Repository/RepositoryFramework.Infrastructure.InMemory/RepositoryFramework.Infrastructure.InMemory.csproj` is:

- package id: `Rystem.RepositoryFramework.Infrastructure.InMemory`
- version: `10.0.6`
- target framework: `net11.0`

---

## Package architecture

| Area | Purpose |
|---|---|
| `WithInMemory(...)` extensions | Register in-memory storage on repository, command, or query builders |
| `InMemoryStorage<T, TKey>` | Concrete storage implementation used by the registration extensions |
| `IRepositoryInMemoryBuilder<T, TKey>` | Builder used for seeding and behavior configuration |
| `RepositoryBehaviorSettings<T, TKey>` | Per-method latency and exception configuration |
| `MethodBehaviorSetting` / `ExceptionOdds` | Delay ranges and simulated failure probabilities |
| Warm-up population hooks | Deferred seeding from random generation, injected data, or JSON |

---

## What this package is good for

- fast tests that still go through repository contracts
- sample apps and demos that need realistic query/write behavior
- local development before wiring a real provider
- generating seeded datasets with `System.Population.Random`
- simulating latency and failures without external infrastructure

---

## Quick start

```csharp
builder.Services.AddRepository<User, string>(repositoryBuilder =>
{
    repositoryBuilder.WithInMemory();
});

var app = builder.Build();
await app.Services.WarmUpAsync();
app.Run();
```

`WithInMemory()` is available on:

- `IRepositoryBuilder<T, TKey>`
- `ICommandBuilder<T, TKey>`
- `IQueryBuilder<T, TKey>`

`WarmUpAsync()` is only required when you use the population helpers, but many repository-based apps already call it during startup for consistency across providers.

---

## Registration API

All three overloads share the same signature and the same defaults.

```csharp
.WithInMemory(
    Action<IRepositoryInMemoryBuilder<T, TKey>>? inMemoryBuilder = null,
    string? name = null,
    ServiceLifetime lifetime = ServiceLifetime.Singleton)
```

| Parameter | Default | Description |
|---|---|---|
| `inMemoryBuilder` | `null` | Optional callback for seeding and behavior settings |
| `name` | `null` | Named factory key used by DI and warm-up resolution |
| `lifetime` | `Singleton` | DI lifetime for the registered storage service |

This provider uses `SetStorageAndBuildOptions(...)` from the abstractions layer under the hood.

---

## How the in-memory store behaves

`InMemoryStorage<T, TKey>` stores data in a static `ConcurrentDictionary<string, Entity<T, TKey>>` keyed by `KeySettings<TKey>.AsString(key)`.

That has a few practical consequences:

- data is shared per closed generic pair `T` and `TKey`
- inserts, updates, and reads are thread-safe at the dictionary level
- values are deep-cloned through JSON when written and when returned from `GetAsync` and `QueryAsync`
- the storage behaves more like a serialization boundary than a simple in-process reference cache

### Important note about named registrations

Named registrations help you resolve different DI entries, but they do not create isolated backing stores for the same `T` and `TKey` pair.

For example, these two registrations resolve separately through `IFactory<IRepository<User, string>>`, but they still share the same underlying static dictionary:

```csharp
builder.Services.AddRepository<User, string>(repositoryBuilder =>
{
    repositoryBuilder.WithInMemory(name: "default");
    repositoryBuilder.WithInMemory(name: "secondary");
});
```

So in this provider, `name` is primarily a DI-selection and warm-up-routing concept, not a data-partitioning mechanism.

---

## Seeding and warm-up

The in-memory builder exposes three seeding styles:

- `PopulateWithRandomData(...)`
- `PopulateWithDataInjection(...)`
- `PopulateWithJsonData(...)`

These methods do not insert data immediately during service registration. They register warm-up actions, and those actions run when `WarmUpAsync()` is called on the built service provider.

### Random data

`PopulateWithRandomData(...)` uses `System.Population.Random` and returns `IPopulationBuilder<Entity<T, TKey>>`, which is why the lambda examples target `x.Value` and `x.Key`.

```csharp
builder.Services.AddRepository<NonPlusSuperUser, NonPlusSuperUserKey>(repositoryBuilder =>
{
    repositoryBuilder.WithInMemory(inMemoryBuilder =>
    {
        inMemoryBuilder
            .PopulateWithRandomData(120, 5)
            .WithPattern(x => x.Value!.Email, @"[a-z]{5,10}@gmail\.com");
    });
});

var app = builder.Build();
await app.Services.WarmUpAsync();
```

The two numeric parameters are:

- `numberOfElements`: how many root entities to generate
- `numberOfElementsWhenEnumerableIsFound`: how many items to generate for enumerable members

### Customizing random generation

Because random population returns an `IPopulationBuilder<Entity<T, TKey>>`, you can use the population features from the core ecosystem.

Real tests in the repository use helpers such as:

- `WithPattern(...)`
- `WithImplementation(...)`
- `WithValue(...)`
- `WithAutoIncrement(...)`

```csharp
repositoryBuilder.WithInMemory(inMemoryBuilder =>
{
    inMemoryBuilder
        .PopulateWithRandomData(90, 8)
        .WithAutoIncrement(x => x.Value!.Id, 0)
        .WithPattern(x => x.Value!.Email, @"[a-z]{5,10}@gmail\.com")
        .WithImplementation<IInnerInterface, MyInnerInterfaceImplementation>(x => x.Value!.Inner!)
        .WithValue(x => x.Value!.Enabled, () => true);
});
```

### Inject from existing data

Use `PopulateWithDataInjection(...)` when you already have a list of entities.

```csharp
var users = new List<User>
{
    new() { Id = "alice", Name = "Alice" },
    new() { Id = "bob", Name = "Bob" }
};

builder.Services.AddRepository<User, string>(repositoryBuilder =>
{
    repositoryBuilder.WithInMemory(inMemoryBuilder =>
    {
        inMemoryBuilder.PopulateWithDataInjection(x => x.Id, users);
    });
});
```

The key selector should point to a property that can be read from each entity.

### Inject from JSON

Use `PopulateWithJsonData(...)` when the source is a JSON array of `T`.

```csharp
var json = """
[
  { "Id": "alice", "Name": "Alice" },
  { "Id": "bob", "Name": "Bob" }
]
""";

builder.Services.AddRepository<User, string>(repositoryBuilder =>
{
    repositoryBuilder.WithInMemory(inMemoryBuilder =>
    {
        inMemoryBuilder.PopulateWithJsonData(x => x.Id, json);
    });
});
```

If the JSON cannot be deserialized into `IEnumerable<T>`, the builder simply leaves the store unchanged.

### Warm-up behavior details

- `PopulateWithRandomData(...)`, `PopulateWithDataInjection(...)`, and `PopulateWithJsonData(...)` all seed through warm-up actions
- warm-up resolves the named repository/command/query registration when a `name` is provided
- plain `WithInMemory()` without population does not need warm-up to function, because `InMemoryStorage<T, TKey>.BootstrapAsync()` is currently a no-op

---

## CRUD and query usage

Once registered, the provider behaves like any other repository implementation from the consumer side.

```csharp
var result = await repository.InsertAsync(1, new Animal { Id = 1, Name = "Eagle" });
var item = await repository.GetAsync(1);
var exists = await repository.ExistAsync(1);

var page = await repository
    .Where(x => x.Id > 0)
    .OrderByDescending(x => x.Id)
    .PageAsync(1, 2);

var batch = repository.CreateBatchOperation();
for (var i = 0; i < 10; i++)
    batch.AddInsert(i, new Animal { Id = i, Name = i.ToString() });

await batch.ExecuteAsync().ToListAsync();
```

This exact style is covered by the in-memory all-methods tests in the repository.

---

## Behavior simulation

The provider can simulate latency and failure probability per repository method family through `RepositoryBehaviorSettings<T, TKey>`.

```csharp
builder.Services.AddRepository<User, string>(repositoryBuilder =>
{
    repositoryBuilder.WithInMemory(inMemoryBuilder =>
    {
        inMemoryBuilder.Settings.AddForCommandPattern(new MethodBehaviorSetting
        {
            MillisecondsOfWait = new Range(50, 200)
        });

        inMemoryBuilder.Settings.AddForQueryPattern(new MethodBehaviorSetting
        {
            MillisecondsOfWait = new Range(5, 20)
        });
    });
});
```

### Configuration methods

| Method | Intended scope |
|---|---|
| `AddForRepositoryPattern(setting)` | All methods through `RepositoryMethods.All` fallback |
| `AddForCommandPattern(setting)` | `Insert`, `Update`, `Delete`, `Batch` |
| `AddForQueryPattern(setting)` | `Get`, `Query`, `Exist`, `Operation` |
| `AddForInsert(setting)` | `Insert` |
| `AddForUpdate(setting)` | `Update` |
| `AddForDelete(setting)` | `Delete` |
| `AddForBatch(setting)` | `Batch` |
| `AddForGet(setting)` | `Get` |
| `AddForQuery(setting)` | `Query` |
| `AddForExist(setting)` | `Exist` |
| `AddForCount(setting)` | `Operation` |

### `MethodBehaviorSetting`

| Property | Type | Meaning |
|---|---|---|
| `MillisecondsOfWait` | `Range` | Inclusive random delay added before the operation |
| `MillisecondsOfWaitWhenException` | `Range` | Additional delay added on the simulated-failure path |
| `ExceptionOdds` | `List<ExceptionOdds>` | Candidate exceptions and their probabilities |

### `ExceptionOdds`

| Property | Type | Meaning |
|---|---|---|
| `Percentage` | `double` | Probability from `> 0` to `100` |
| `Exception` | `Exception?` | Exception object associated with that probability |

### Validation rules

Before the options are finalized, the builder validates the configured percentages:

- each percentage must be greater than `0` and less than or equal to `100`
- the total of one list cannot exceed `100`

Invalid configurations throw during options building, not later at query time.

---

## Important behavior differences by method

The provider does not simulate failures in the exact same way for every method.

### Read-style methods

These methods throw the configured simulated exception when the probability path is hit:

- `GetAsync`
- `QueryAsync`
- `OperationAsync`

### Command-style methods

These methods do not throw the configured exception. Instead, the simulated failure path returns a failed `State<T, TKey>`:

- `InsertAsync`
- `UpdateAsync`
- `DeleteAsync`
- `ExistAsync`

So for writes and `ExistAsync`, you should check `state.IsOk` rather than expect an exception.

### Batch behavior

`BatchAsync` executes insert/update/delete operations one by one and yields a result for each operation. It is not transactional and does not roll back previous operations.

Also, as currently implemented, `BatchAsync` does not read the dedicated `RepositoryMethods.Batch` behavior setting directly. It inherits behavior from the individual insert/update/delete calls it performs.

That means `AddForBatch(...)` exists in the options API, but it is not consumed by `InMemoryStorage<T, TKey>` today.

---

## CQRS variants

The same extension exists for command-only and query-only registrations.

```csharp
builder.Services.AddCommand<Order, Guid>(commandBuilder =>
{
    commandBuilder.WithInMemory();
});

builder.Services.AddQuery<Product, int>(queryBuilder =>
{
    queryBuilder.WithInMemory(inMemoryBuilder =>
    {
        inMemoryBuilder.PopulateWithRandomData(50, 3);
    });
});
```

Because the concrete in-memory storage implements the full repository contract internally, warm-up seeding still works even when the public DI surface is query-only or command-only.

---

## Practical examples from the repo

### Sample web API seed data

The sample API under `src/Repository/RepositoryFramework.Test/RepositoryFramework.WebApi/Program.cs` registers repositories like this:

```csharp
builder.Services.AddRepository<SuperUser, string>(repositoryBuilder =>
{
    repositoryBuilder.WithInMemory(inMemoryBuilder =>
    {
        inMemoryBuilder
            .PopulateWithRandomData(120, 5)
            .WithPattern(x => x.Value!.Email, @"[a-z]{5,10}@gmail\.com");
    });
});

var app = builder.Build();
await app.Services.WarmUpAsync();
```

### Test-focused latency simulation

The population tests configure different delays for reads and writes:

```csharp
repositoryBuilder.WithInMemory(inMemoryBuilder =>
{
    inMemoryBuilder.Settings.AddForCommandPattern(new MethodBehaviorSetting
    {
        MillisecondsOfWait = new Range(100, 250)
    });

    inMemoryBuilder.Settings.AddForQueryPattern(new MethodBehaviorSetting
    {
        MillisecondsOfWait = new Range(10, 40)
    });
});
```

### Full exception distribution example

The exception tests configure a full distribution across several exceptions:

```csharp
repositoryBuilder.WithInMemory(inMemoryBuilder =>
{
    inMemoryBuilder.Settings.AddForRepositoryPattern(new MethodBehaviorSetting
    {
        ExceptionOdds = new List<ExceptionOdds>
        {
            new() { Exception = new Exception("Normal Exception"), Percentage = 10.352 },
            new() { Exception = new Exception("Big Exception"), Percentage = 49.1 },
            new() { Exception = new Exception("Great Exception"), Percentage = 40.548 }
        }
    });
});
```

---

## Related packages

| Package | Purpose |
|---|---|
| `Rystem.RepositoryFramework.Abstractions` | Core contracts, query model, and registration builders |
| `Rystem.RepositoryFramework.Api.Server` | Expose repositories as HTTP endpoints |
| `Rystem.RepositoryFramework.Api.Client` | Call repository APIs from .NET or TypeScript |

If you are continuing through the repository area, this is usually the next package to understand after `src/Repository/RepositoryFramework.Abstractions/README.md`.

---

## repository/repositoryframework-infrastructure-azure-cosmos-sql

> Rystem.RepositoryFramework.Infrastructure.Azure.Cosmos.Sql adds a Cosmos DB SQL API adapter for Repository Framework.

# Rystem.RepositoryFramework.Infrastructure.Azure.Cosmos.Sql

`Rystem.RepositoryFramework.Infrastructure.Azure.Cosmos.Sql` adds a Cosmos DB SQL API adapter for Repository Framework.

It is a thin integration: one container per model, one Cosmos item per entity, and a fixed partition key strategy based on `/id`.

## Installation

```bash
dotnet add package Rystem.RepositoryFramework.Infrastructure.Azure.Cosmos.Sql
```

## Architecture

At registration time the builder:

1. creates the Cosmos database if missing
2. creates the container if missing
3. uses `/id` as the container partition key path

At write time the repository builds an item like this:

- `id`: string form of `TKey` using `KeySettings<TKey>.Instance.AsString(key)`
- every public property from `T`

So the Cosmos item key and the Repository Framework key are tightly coupled.

## Registration APIs

Available on all three patterns:

- `WithCosmosSqlAsync(...)`
- `WithCosmosSql(...)`

Supported for:

- `IRepositoryBuilder<T, TKey>`
- `ICommandBuilder<T, TKey>`
- `IQueryBuilder<T, TKey>`

The sync overloads are wrappers over the async implementations.

There is no service-connection registration variant in this package.

## Example with a simple key

This mirrors the API tests.

```csharp
await builder.Services.AddRepositoryAsync<SuperUser, string>(async repositoryBuilder =>
{
    await repositoryBuilder.WithCosmosSqlAsync(cosmosBuilder =>
    {
        cosmosBuilder.Settings.ConnectionString = builder.Configuration["ConnectionStrings:CosmosSql"];
        cosmosBuilder.Settings.DatabaseName = "BigDatabase";
        cosmosBuilder.WithId(x => x.Email!);
    });
});
```

## Example with a custom key type

This follows the integration tests.

```csharp
await builder.Services.AddRepositoryAsync<AppUser, AppUserKey>(async repositoryBuilder =>
{
    await repositoryBuilder.WithCosmosSqlAsync(cosmosBuilder =>
    {
        cosmosBuilder.Settings.ConnectionString = builder.Configuration["ConnectionStrings:CosmosSql"];
        cosmosBuilder.Settings.DatabaseName = "unittestdatabase";
        cosmosBuilder.WithId(x => new AppUserKey(x.Id));
    }, name: "cosmos");
});
```

## Builder API

`ICosmosSqlRepositoryBuilder<T, TKey>` exposes:

| Member | Purpose |
| --- | --- |
| `Settings` | Cosmos connection and provisioning settings |
| `WithId(expr)` | Registers a default key manager that reads `TKey` from a model instance |
| `WithKeyManager<T>()` | Registers a custom `ICosmosSqlKeyManager<T, TKey>` |

## Configuration and defaults

`CosmosSqlConnectionSettings` exposes:

| Property | Notes |
| --- | --- |
| `ConnectionString` | Used when present. If both this and `EndpointUri` are set, connection string wins. |
| `EndpointUri` | Used for managed identity mode. |
| `ManagedIdentityClientId` | Null means system-assigned identity. |
| `DatabaseName` | Required in practice. |
| `ContainerName` | Defaults to `typeof(T).Name`. |
| `ClientOptions` | Passed to `CosmosClient`. |
| `DatabaseOptions` | Used only during `CreateDatabaseIfNotExistsAsync(...)`. |
| `ContainerOptions` | Used only during `CreateContainerIfNotExistsAsync(...)`. |

Default lifetime:

- `Singleton`

## Managed identity note

Managed identity is used only when:

- `ConnectionString == null`
- and `EndpointUri != null`

If both are configured, the builder silently uses the connection string path.

## Provisioning and lifecycle

Database and container creation happen during registration, not during warm-up.

That means `WithCosmosSqlAsync(...)` eagerly performs the create-if-not-exists calls.

`CosmosSqlRepository<T, TKey>.BootstrapAsync()` currently returns `true` and does nothing.

## Key behavior

There are two separate key concerns in this package.

### 1. How the repository addresses Cosmos items

CRUD methods always use:

```csharp
KeySettings<TKey>.Instance.AsString(key)
```

That string becomes both:

- the Cosmos item `id`
- the partition key value

### 2. How query results rebuild `TKey`

`WithId(...)` and `WithKeyManager<T>()` are used when the repository has to reconstruct `TKey` from an entity returned by Cosmos.

Important caveat:

- the custom key manager's `Read(entity)` is used for query results
- but CRUD methods do not use the key manager's string conversion

So a custom `ICosmosSqlKeyManager<T, TKey>` cannot change the actual Cosmos `id` serialization strategy. That is still controlled by `KeySettings<TKey>`.

## Fixed partition key strategy

The container partition key path is always created as:

```csharp
PartitionKeyPath = "/id"
```

This package does not expose a builder API to use another partition key path.

## Query behavior

`QueryAsync(...)` partially uses Cosmos LINQ and partially falls back to local processing.

What is pushed to Cosmos:

- `Where`

What is applied locally after materializing results:

- `OrderBy`
- `OrderByDescending`
- `ThenBy`
- `ThenByDescending`
- `Skip`
- `Top`

So the flow is:

1. run the `Where` portion against Cosmos
2. materialize matching items into memory
3. apply ordering and paging locally

This is important for large datasets, because `QueryAsync(...)` is not server-side paging over ordered results.

## Aggregate behavior

`OperationAsync(...)` uses Cosmos LINQ aggregates over the queryable for:

- `Count`
- `Sum`
- `Max`
- `Min`
- `Average`

That makes aggregate behavior more efficient than `QueryAsync(...)` plus client-side aggregation, but it still follows the generic Repository Framework operation model.

## CRUD and batch behavior

- `InsertAsync` uses `CreateItemAsync(...)`
- `UpdateAsync` uses `UpsertItemAsync(...)`
- `DeleteAsync` deletes by `id` and partition key
- `ExistAsync` runs a parameterized SQL query on `id`
- `BatchAsync(...)` is a sequential loop over operations, not a Cosmos transactional batch

So the package does not currently use Cosmos transactional batch support or rollback semantics.

## CQRS examples

```csharp
await builder.Services.AddCommandAsync<AppUser, AppUserKey>(async commandBuilder =>
{
    await commandBuilder.WithCosmosSqlAsync(cosmosBuilder =>
    {
        cosmosBuilder.Settings.ConnectionString = builder.Configuration["ConnectionStrings:CosmosSql"];
        cosmosBuilder.Settings.DatabaseName = "app-database";
        cosmosBuilder.WithId(x => new AppUserKey(x.Id));
    });
});

await builder.Services.AddQueryAsync<AppUser, AppUserKey>(async queryBuilder =>
{
    await queryBuilder.WithCosmosSqlAsync(cosmosBuilder =>
    {
        cosmosBuilder.Settings.ConnectionString = builder.Configuration["ConnectionStrings:CosmosSql"];
        cosmosBuilder.Settings.DatabaseName = "app-database";
        cosmosBuilder.WithId(x => new AppUserKey(x.Id));
    });
});
```

## When to use this package

Use it when you want:

- a straightforward Cosmos SQL repository adapter
- easy mapping from repository key to Cosmos `id`
- container provisioning handled by registration

Be careful when you need a custom partitioning strategy or fully server-side ordered paging, because the current implementation does not provide either.

---

## repository/repositoryframework-infrastructure-azure-storage-blob

> Rystem.RepositoryFramework.Infrastructure.Azure.Storage.Blob adds an Azure Blob Storage adapter for Repository Framework.

# Rystem.RepositoryFramework.Infrastructure.Azure.Storage.Blob

`Rystem.RepositoryFramework.Infrastructure.Azure.Storage.Blob` adds an Azure Blob Storage adapter for Repository Framework.

It stores one blob per repository entity and serializes the payload as `Entity<T, TKey>`, not as raw `T`.

This package is simple and flexible for key-based storage, but list queries are mostly client-side.

## Installation

```bash
dotnet add package Rystem.RepositoryFramework.Infrastructure.Azure.Storage.Blob
```

## Architecture

Each item is stored as:

- blob name: `{Prefix}{KeySettings<TKey>.AsString(key)}`
- blob content: JSON representation of `Entity<T, TKey>`

That means the key appears twice:

- in the blob name
- in the serialized payload

## Registration APIs

### Direct builder registration

Available on all three patterns:

- `WithBlobStorageAsync(...)`
- `WithBlobStorage(...)`

Supported for:

- `IRepositoryBuilder<T, TKey>`
- `ICommandBuilder<T, TKey>`
- `IQueryBuilder<T, TKey>`

The sync overloads are wrappers over the async versions.

### Connection service registration

Available overloads:

- `WithBlobStorage<T, TKey, TConnectionService>(...)`

Supported for repository, command, and query registrations.

This path is useful when the container or credential is selected per tenant or request.

## Direct builder example

This follows the test and sample usage style.

```csharp
builder.Services.AddRepository<Car, Guid>(repositoryBuilder =>
{
    repositoryBuilder.WithBlobStorage(blobStorageBuilder =>
    {
        blobStorageBuilder.Settings.ConnectionString = builder.Configuration["ConnectionStrings:Storage"];
        blobStorageBuilder.Settings.ContainerName = "cars";
        blobStorageBuilder.Settings.Prefix = "MyFolder/";
    });
});
```

## Connection service example

This mirrors the integration tests.

```csharp
builder.Services.AddRepository<AppUser, AppUserKey>(repositoryBuilder =>
{
    repositoryBuilder.WithBlobStorage<AppUser, AppUserKey, BlobStorageConnectionService>(
        name: "blobstorage2");
});
```

Example connection service:

```csharp
internal sealed class BlobStorageConnectionService
    : IConnectionService<AppUser, AppUserKey, BlobContainerClientWrapper>
{
    public BlobContainerClientWrapper GetConnection(string entityName, string? factoryName = null)
        => new()
        {
            Client = new BlobContainerClient("<connection-string>", entityName.ToLower())
        };
}
```

## Configuration and defaults

`BlobStorageConnectionSettings` exposes:

| Property | Notes |
| --- | --- |
| `ConnectionString` | Used when present. If both this and `EndpointUri` are set, connection string wins. |
| `EndpointUri` | Used for managed identity mode. This points to a container endpoint. |
| `ManagedIdentityClientId` | Null means system-assigned identity. |
| `ContainerName` | Used only in connection-string mode. Defaults to `typeof(T).Name.ToLower()`. |
| `Prefix` | Prepended to every blob name and used as the listing prefix for queries. |
| `ClientOptions` | Passed to the Azure Blob SDK. |

Default lifetimes:

- direct builder registration: `Singleton`
- connection service registration: `Scoped`

## Managed identity note

In managed identity mode, the builder constructs the client with:

```csharp
new BlobContainerClient(Settings.EndpointUri, credential, Settings.ClientOptions)
```

So `EndpointUri` must already identify the container. `ContainerName` is not applied in that path.

## Lifecycle and provisioning

### Direct builder path

When you use `WithBlobStorageAsync(...)` or `WithBlobStorage(...)`, the package calls `CreateIfNotExistsAsync()` during registration.

That behavior is visible in `RepositoryFramework.UnitTest/Tests/Singularity/BlobStorageSingularityTest.cs`: registration succeeds before any explicit warm-up.

### Connection service path

When you use `WithBlobStorage<T, TKey, TConnectionService>(...)`, container creation is your connection service's responsibility.

### Bootstrap behavior

`BlobStorageRepository<T, TKey>.BootstrapAsync()` currently returns `true` and does nothing.

So like the Table Storage provider, the real provisioning behavior is tied to direct registration, not to `WarmUpAsync()`.

## CRUD behavior

- `GetAsync(key)` checks blob existence and then downloads/deserializes the payload
- `ExistAsync(key)` checks blob existence only
- `InsertAsync(key, value)` uploads without overwrite
- `UpdateAsync(key, value)` uploads with overwrite enabled
- `DeleteAsync(key)` deletes the blob directly

Practical consequence:

- insert is create-only
- update behaves like upsert

## Query behavior

`QueryAsync(...)` is a client-side scan.

The repository does this:

1. list blobs by `Prefix`
2. download each blob
3. deserialize each payload
4. pre-apply only the first `Where` expression as an in-memory predicate
5. apply the full Repository Framework filter pipeline in memory

So there is:

- no blob tag query support
- no metadata filtering
- no server-side ordering or paging
- no projection pushdown

## Query limitations to know about

- the first `Where` expression is compiled to `Func<T, bool>` and run locally
- `OrderBy`, `ThenBy`, `Skip`, `Top`, and paging all happen after values are materialized
- aggregate operations such as `Count`, `Sum`, `Min`, `Max`, and `Average` run in memory
- `BatchAsync(...)` is sequential and non-transactional

There is also an implementation detail worth knowing: query buffering uses `Dictionary<T, Entity<T, TKey>>`. If two blobs deserialize to values that compare equal under `EqualityComparer<T>.Default`, query enumeration can fail or collapse duplicates.

## Named registrations and factory behavior

The optional `name` parameter is a Repository Framework factory name.

In connection-service mode the repository calls:

```csharp
connectionService.GetConnection(typeof(T).Name, name)
```

So the connection service receives the CLR model name, not the configured `ContainerName`.

## CQRS examples

```csharp
await builder.Services.AddCommandAsync<Document, Guid>(async commandBuilder =>
{
    await commandBuilder.WithBlobStorageAsync(blobStorageBuilder =>
    {
        blobStorageBuilder.Settings.ConnectionString = builder.Configuration["ConnectionStrings:Storage"];
    });
});

await builder.Services.AddQueryAsync<Document, Guid>(async queryBuilder =>
{
    await queryBuilder.WithBlobStorageAsync(blobStorageBuilder =>
    {
        blobStorageBuilder.Settings.ConnectionString = builder.Configuration["ConnectionStrings:Storage"];
        blobStorageBuilder.Settings.Prefix = "documents/";
    });
});
```

## When to use this package

Use it when you want:

- simple key-addressed storage in Azure Blob Storage
- easy handling of complex keys through `KeySettings<TKey>`
- a repository backend that is straightforward to inspect and reason about

Avoid it when you need efficient server-side querying across large datasets, because the current implementation scans and deserializes blobs on the client side.

---

## repository/repositoryframework-infrastructure-azure-storage-table

> Rystem.RepositoryFramework.Infrastructure.Azure.Storage.Table adds an Azure Table Storage adapter for Repository Framework.

# Rystem.RepositoryFramework.Infrastructure.Azure.Storage.Table

`Rystem.RepositoryFramework.Infrastructure.Azure.Storage.Table` adds an Azure Table Storage adapter for Repository Framework.

This package is not a column-per-property mapper. Each repository item is stored as:

- `PartitionKey`
- `RowKey`
- Azure-managed `Timestamp`
- a single JSON `Value` payload containing the model

That design makes key-based lookups simple, but most query behavior stays client-side.

## Installation

```bash
dotnet add package Rystem.RepositoryFramework.Infrastructure.Azure.Storage.Table
```

## Architecture

The storage implementation writes one internal `ITableEntity` per repository item.

- model data is serialized into one `Value` column
- `PartitionKey` and `RowKey` come from the configured table key reader
- `InsertAsync` delegates to `UpdateAsync`, so inserts behave like upserts

This package is best when Azure Table Storage is mainly your key-addressable backing store.

## Registration APIs

### Direct builder registration

Available on all three Repository Framework patterns:

- `WithTableStorageAsync(...)`
- `WithTableStorage(...)`

Supported for:

- `IRepositoryBuilder<T, TKey>`
- `ICommandBuilder<T, TKey>`
- `IQueryBuilder<T, TKey>`

The async overloads are the real implementations. The sync overloads just block on them.

### Connection service registration

Available overloads:

- `WithTableStorage<T, TKey, TConnectionService>(...)`
- `WithTableStorage<T, TKey, TConnectionService, TKeyReader>(...)`

These are useful when table clients are resolved per tenant or per request.

## Direct builder example

This mirrors the integration tests.

```csharp
await builder.Services.AddRepositoryAsync<AppUser, AppUserKey>(async repositoryBuilder =>
{
    await repositoryBuilder.WithTableStorageAsync(tableStorageBuilder =>
    {
        tableStorageBuilder.Settings.ConnectionString = builder.Configuration["ConnectionStrings:Storage"];
        tableStorageBuilder.Settings.TableName = "appusers";

        tableStorageBuilder
            .WithTableStorageKeyReader<TableStorageKeyReader>()
            .WithPartitionKey(x => x.Id, x => x.Id)
            .WithRowKey(x => x.Username)
            .WithTimestamp(x => x.CreationTime);
    }, name: "tablestorage");
});
```

Example custom key reader from the tests:

```csharp
internal sealed class TableStorageKeyReader : ITableStorageKeyReader<AppUser, AppUserKey>
{
    public (string PartitionKey, string RowKey) Read(
        AppUserKey key,
        TableStorageSettings<AppUser, AppUserKey> settings)
        => (key.Id.ToString(), string.Empty);

    public AppUserKey Read(
        AppUser entity,
        TableStorageSettings<AppUser, AppUserKey> settings)
        => new(entity.Id);
}
```

## Connection service example

This is the other pattern used in the integration tests.

```csharp
builder.Services.AddRepository<AppUser, AppUserKey>(repositoryBuilder =>
{
    repositoryBuilder
        .WithTableStorage<AppUser, AppUserKey, TableStorageConnectionService, TableStorageKeyReader>(
            name: "tablestorage2");
});
```

The connection service returns a ready-to-use `TableClientWrapper<T, TKey>`.

```csharp
internal sealed class TableStorageConnectionService
    : IConnectionService<AppUser, AppUserKey, TableClientWrapper<AppUser, AppUserKey>>
{
    public TableClientWrapper<AppUser, AppUserKey> GetConnection(
        string entityName,
        string? factoryName = null)
    {
        return new TableClientWrapper<AppUser, AppUserKey>
        {
            Client = new TableClient("<connection-string>", entityName.ToLower()),
            Settings = new TableStorageSettings<AppUser, AppUserKey>
            {
                PartitionKey = "Id",
                RowKey = "Username",
                Timestamp = "CreationTime",
                PartitionKeyFromKeyFunction = x => x.Id.ToString(),
                PartitionKeyFunction = x => x.Id.ToString(),
                RowKeyFunction = x => x.Username,
                TimestampFunction = x => x.CreationTime
            }
        };
    }
}
```

## Configuration and defaults

`TableStorageConnectionSettings` exposes:

| Property | Notes |
| --- | --- |
| `ConnectionString` | Used when present. If both this and `EndpointUri` are set, connection string wins. |
| `EndpointUri` | Table service endpoint for managed identity mode. |
| `ManagedIdentityClientId` | Null means system-assigned identity. |
| `TableName` | Defaults to `typeof(T).Name`. |
| `ClientOptions` | Passed to Azure Tables SDK. |

Builder overload defaults:

- direct builder lifetime: `Singleton`
- connection service lifetime: `Scoped`

## Key mapping API

`ITableStorageRepositoryBuilder<T, TKey>` exposes:

| Method | What it configures |
| --- | --- |
| `WithPartitionKey(model, key)` | Model property and key-side extractor for `PartitionKey`. |
| `WithRowKey(model, key)` | Model property and key-side extractor for `RowKey`. |
| `WithRowKey(model)` | Only the entity-side row key extractor. |
| `WithTimestamp(model)` | The model property name used for timestamp-aware query translation. |
| `WithTableStorageKeyReader<T>()` | Custom `ITableStorageKeyReader<T, TKey>`. |

## Important key behavior

The default key reader reconstructs keys like this:

- for key-based operations it uses `PartitionKeyFromKeyFunction(key)` and `RowKeyFromKeyFunction(key)`
- for entity-to-key reconstruction it uses the configured entity-side key functions

That leads to an important caveat:

- `WithRowKey(x => x.Prop)` does not configure `RowKeyFromKeyFunction`
- it also does not populate the stored `RowKey` name used for query translation

So the one-argument `WithRowKey(...)` overload is not enough for many real key-based scenarios. In practice, when `TKey` is not directly representable by the partition key alone, prefer a custom `ITableStorageKeyReader<T, TKey>`.

## Lifecycle and provisioning

### Direct builder path

When you use `WithTableStorageAsync(...)` or `WithTableStorage(...)`, the package creates the table during registration by calling `CreateTableIfNotExistsAsync(...)`.

### Connection service path

When you use `WithTableStorage<T, TKey, TConnectionService>(...)`, table creation is your responsibility inside the connection service.

### Bootstrap behavior

`TableStorageRepository<T, TKey>.BootstrapAsync()` currently returns `true` and does nothing.

So for this package, provisioning is tied to direct registration, not to `WarmUpAsync()`.

## Query behavior

`QueryAsync(...)` supports Azure-side filtering only in a narrow set of cases.

What it tries to push down:

- only the first `Where` expression
- only comparisons involving mapped `PartitionKey`, `RowKey`, or `Timestamp`

Everything else is effectively local:

- filtering on normal model properties
- `OrderBy` / `ThenBy`
- paging semantics
- aggregate operations

The flow is:

1. optionally build a Table Storage filter string
2. enumerate rows from Azure Tables
3. deserialize JSON `Value` into models
4. apply Repository Framework filter operations in memory

## Query limitations to know about

- non-key model properties are never server-filtered because they live inside serialized JSON
- `Top` and `Skip` are partially applied during table enumeration before the final local filter/order phase
- aggregate methods such as `Count`, `Sum`, `Min`, `Max`, and `Average` materialize items and run in memory
- `BatchAsync(...)` is just a sequential loop, not an Azure Tables transactional batch

## CRUD semantics

- `InsertAsync` calls `UpdateAsync`, so it overwrites existing rows instead of failing on duplicates
- `UpdateAsync` uses `UpsertEntityAsync(..., TableUpdateMode.Replace)`
- `GetAsync` catches missing-row exceptions and returns `default`
- `DeleteAsync` directly calls `DeleteEntityAsync(...)`

If you need strict create-only behavior, build that check above the repository.

## Named registrations and factory behavior

The optional `name` parameter is a Repository Framework factory name, not a table name.

It is used to:

- resolve the correct repository registration
- resolve the matching key reader factory registration
- resolve the matching connection service factory registration

In connection-service mode, the repository calls:

```csharp
connectionService.GetConnection(typeof(T).Name, name)
```

So the service receives the CLR model name, not the configured `TableName`.

## CQRS examples

```csharp
await builder.Services.AddCommandAsync<User, UserKey>(async commandBuilder =>
{
    await commandBuilder.WithTableStorageAsync(tableStorageBuilder =>
    {
        tableStorageBuilder.Settings.ConnectionString = builder.Configuration["ConnectionStrings:Storage"];
        tableStorageBuilder
            .WithPartitionKey(x => x.TenantId, x => x.TenantId)
            .WithRowKey(x => x.Id, x => x.Id);
    });
});

await builder.Services.AddQueryAsync<User, UserKey>(async queryBuilder =>
{
    await queryBuilder.WithTableStorageAsync(tableStorageBuilder =>
    {
        tableStorageBuilder.Settings.ConnectionString = builder.Configuration["ConnectionStrings:Storage"];
        tableStorageBuilder
            .WithPartitionKey(x => x.TenantId, x => x.TenantId)
            .WithRowKey(x => x.Id, x => x.Id);
    });
});
```

## When to use this package

Use it when you want:

- Azure Table Storage as a simple key-addressed repository backend
- custom partition/row key control
- a lightweight adapter where table rows hold JSON documents

Avoid it when you need rich server-side querying over many model properties, because that is not what the current implementation is optimized for.

---

## repository/repositoryframework-infrastructure-dynamics-dataverse

> Rystem.RepositoryFramework.Infrastructure.Dynamics.Dataverse adds a Microsoft Dataverse adapter for Repository Framework.

# Rystem.RepositoryFramework.Infrastructure.Dynamics.Dataverse

`Rystem.RepositoryFramework.Infrastructure.Dynamics.Dataverse` adds a Microsoft Dataverse adapter for Repository Framework.

It auto-provisions a Dataverse table for your model, but the storage model is much simpler than a typical Dataverse-first mapping: every repository property is stored as a string column, and most queries run in memory after fetch.

## Installation

```bash
dotnet add package Rystem.RepositoryFramework.Infrastructure.Dynamics.Dataverse
```

## Architecture

For each registered model, the package works with one Dataverse table.

- table logical name: `Prefix + TableName.ToLower()`
- primary attribute logical name: `Prefix + PrimaryKey.ToLower()`
- every model property becomes a Dataverse string attribute
- primitive values are stringified
- non-primitive values are JSON serialized

So this package uses Dataverse mainly as a managed record store, not as a strongly typed Dataverse-schema translator.

## Registration APIs

Available on all three patterns:

- `WithDataverse(...)`

Supported for:

- `IRepositoryBuilder<T, TKey>`
- `ICommandBuilder<T, TKey>`
- `IQueryBuilder<T, TKey>`

## Example

This matches the repository API tests.

```csharp
builder.Services.AddRepository<CalamityUniverseUser, string>(repositoryBuilder =>
{
    repositoryBuilder.WithDataverse(dataverseBuilder =>
    {
        dataverseBuilder.Settings.Prefix = "repo_";
        dataverseBuilder.Settings.SolutionName = "Solution001";
        dataverseBuilder.Settings.TableName = "CalamityUniverseUser";

        dataverseBuilder.Settings.SetConnection(
            builder.Configuration["Dataverse:Environment"]!,
            new DataverseAppRegistrationAccount(
                builder.Configuration["Dataverse:ClientId"]!,
                builder.Configuration["Dataverse:ClientSecret"]!));
    });
});
```

Example model from the tests:

```csharp
public sealed class CalamityUniverseUser
{
    public string? Id { get; set; }
    public string? Name { get; set; }
    public string? Email { get; set; }
    public int Port { get; set; }
    public bool IsAdmin { get; set; }
    public Guid GroupId { get; set; }
}
```

## Builder API

`IDataverseRepositoryBuilder<T, TKey>` exposes:

| Member | Purpose |
| --- | --- |
| `Settings` | Connection and Dataverse table settings |
| `WithColumn(expr, customPrefix)` | Override the prefix used for one property |

`DataverseOptions<T, TKey>` exposes:

| Property | Default | Notes |
| --- | --- | --- |
| `Prefix` | `new_` | Global prefix for the logical table and column names |
| `TableName` | `typeof(T).Name` | Display and schema base name |
| `PrimaryKey` | `Id` | Name of the Dataverse primary attribute used to store the repository key |
| `SolutionName` | `null` | Used when creating a new table |
| `Description` | `null` | Falls back to an auto-generated description |
| `Environment` | required | Set through `SetConnection(...)` |
| `ApplicationIdentity` | required | Set through `SetConnection(...)` |

## Connection configuration

Use:

```csharp
dataverseBuilder.Settings.SetConnection(
    environment,
    new DataverseAppRegistrationAccount(clientId, clientSecret));
```

Internally the package creates a `ServiceClient` with a client-secret connection string like:

```text
Url=https://{Environment}.dynamics.com;AuthType=ClientSecret;ClientId=...;ClientSecret=...;RequireNewInstance=true
```

This package currently documents and implements only the app-registration client-secret path.

## Warm-up and provisioning

`WithDataverse(...)` automatically registers a warm-up action.

At startup, `BootstrapAsync()`:

1. checks whether the Dataverse table exists
2. creates it if missing
3. checks every model property column
4. creates any missing columns as `StringAttributeMetadata`

You should still run:

```csharp
await app.Services.WarmUpAsync();
```

That is the path the repository expects for auto-provisioning.

## What gets provisioned

When the table is created:

- ownership type is `UserOwned`
- the primary Dataverse attribute is a string column with max length `100`

When model properties are created:

- primitive properties become string columns with max length `100`
- non-primitive properties become string columns with max length `2000`

So even if your .NET property is `int`, `bool`, `Guid`, or a complex object, the stored Dataverse attribute is still a string attribute.

## Key behavior

The repository key `TKey` is stored in the Dataverse primary attribute column.

- primitive `TKey` values are stored with `ToString()`
- non-primitive `TKey` values are stored as JSON

Important nuance:

- `PrimaryKey` config controls the Dataverse primary attribute name
- it does not automatically mean the same property on your model is the repository key source

For example, the tests register `CalamityUniverseUser` with `TKey = string`, while the Dataverse table still uses the default logical primary attribute based on `Id`.

## Query behavior

`QueryAsync(...)` is mostly client-side.

The repository issues a Dataverse query with:

- `TopCount = 100`
- the configured `ColumnSet`
- no translated Repository Framework filter expression

Then it:

1. materializes the returned Dataverse entities into models
2. rebuilds `Entity<T, TKey>` values
3. applies Repository Framework filters in memory

Practical consequence:

- `Where`, ordering, paging, and aggregates all operate on the fetched in-memory subset
- only the first 100 Dataverse rows are visible to `QueryAsync(...)`

## CRUD behavior

Key-based methods do use Dataverse-side filtering.

- `GetAsync`, `ExistAsync`, `UpdateAsync`, and `DeleteAsync` query by the logical primary key column
- `InsertAsync` creates a new Dataverse row directly

`UpdateAsync` first finds the existing Dataverse row and then updates it by Dataverse row id.

## Batch and aggregate behavior

- `BatchAsync(...)` is a sequential loop over insert/update/delete operations
- there is no Dataverse bulk pipeline or transaction support in this package
- aggregate operations such as `Count`, `Sum`, `Min`, `Max`, and `Average` run in memory after `QueryAsync(...)`

## Custom column prefix caveat

`WithColumn(x => x.Property, customPrefix: "...")` exists, but the current implementation is less reliable than the API suggests.

Important source-backed caveats:

- column existence checks during bootstrap primarily look for unprefixed or globally prefixed names
- `ColumnSet` is built before `WithColumn(...)` overrides the property prefix

So per-column custom prefixes may not behave consistently across provisioning and reads. If you need robust mappings, prefer a single global `Prefix` for the whole table.

## Solution behavior caveat

`SolutionName` is used when creating a new Dataverse table.

The current implementation does not perform a broader ongoing solution-management workflow for already existing tables or attributes.

## CQRS examples

```csharp
builder.Services.AddCommand<AccountModel, string>(commandBuilder =>
{
    commandBuilder.WithDataverse(dataverseBuilder =>
    {
        dataverseBuilder.Settings.Prefix = "repo_";
        dataverseBuilder.Settings.SetConnection(
            builder.Configuration["Dataverse:Environment"]!,
            new DataverseAppRegistrationAccount(
                builder.Configuration["Dataverse:ClientId"]!,
                builder.Configuration["Dataverse:ClientSecret"]!));
    });
});

builder.Services.AddQuery<AccountModel, string>(queryBuilder =>
{
    queryBuilder.WithDataverse(dataverseBuilder =>
    {
        dataverseBuilder.Settings.Prefix = "repo_";
        dataverseBuilder.Settings.SetConnection(
            builder.Configuration["Dataverse:Environment"]!,
            new DataverseAppRegistrationAccount(
                builder.Configuration["Dataverse:ClientId"]!,
                builder.Configuration["Dataverse:ClientSecret"]!));
    });
});
```

## When to use this package

Use it when you want:

- Dataverse-backed persistence behind Repository Framework abstractions
- automatic table and column provisioning at startup
- a simple storage layer where complex values can be serialized into Dataverse string attributes

Avoid it when you need deep Dataverse-native query translation or strongly typed Dataverse attribute mapping, because the current implementation is intentionally much thinner than that.

---

## Rystem.RepositoryFramework.Infrastructure.EntityFramework

> !NuGet(https://img.shields.io/nuget/v/Rystem.RepositoryFramework.Infrastructure.EntityFramework)(https://www.nuget.org/packages/Rystem.RepositoryFramework.Infra

### [What is Rystem?](https://github.com/KeyserDSoze/Rystem)

# Rystem.RepositoryFramework.Infrastructure.EntityFramework

[![NuGet](https://img.shields.io/nuget/v/Rystem.RepositoryFramework.Infrastructure.EntityFramework)](https://www.nuget.org/packages/Rystem.RepositoryFramework.Infrastructure.EntityFramework)
[![NuGet Downloads](https://img.shields.io/nuget/dt/Rystem.RepositoryFramework.Infrastructure.EntityFramework)](https://www.nuget.org/packages/Rystem.RepositoryFramework.Infrastructure.EntityFramework)

Entity Framework Core integration for the Rystem repository ecosystem.

This package gives you a reusable generic repository implementation backed by `DbContext`, plus fluent registration extensions for repository, command, and query patterns.

## Resources

- Complete Documentation: [https://rystem.net](https://rystem.net)
- MCP Server for AI: [https://rystem.cloud/mcp](https://rystem.cloud/mcp)
- Discord Community: [https://discord.gg/tkWvy4WPjt](https://discord.gg/tkWvy4WPjt)
- Support the Project: [https://www.buymeacoffee.com/keyserdsoze](https://www.buymeacoffee.com/keyserdsoze)

---

## Installation

```bash
dotnet add package Rystem.RepositoryFramework.Infrastructure.EntityFramework
```

The current package metadata in `src/Repository/RepositoryFramework.Infrastructures/RepositoryFramework.Infrastructure.EntityFramework/RepositoryFramework.Infrastructure.EntityFramework.csproj` is:

- package id: `Rystem.RepositoryFramework.Infrastructure.EntityFramework`
- version: `10.0.6`
- target framework: `net11.0`
- main EF dependency: `Microsoft.EntityFrameworkCore` `10.0.3`

---

## Package architecture

| Area | Purpose |
|---|---|
| `WithEntityFramework(...)` extensions | Register the generic EF-backed repository on repository, command, or query builders |
| `EntityFrameworkRepository<T, TKey, TEntityModel, TContext>` | Concrete implementation that talks to `DbContext` and `DbSet` |
| `EntityFrameworkOptions<T, TKey, TEntityModel, TContext>` | Minimal provider options: `DbSet` and optional `References` |
| Translation builders | Map repository models and key shapes to EF entity models |
| Same-model overloads | Convenience overloads that auto-map same-name properties |

---

## Mental model

This package is intentionally thin.

You bring:

- the `DbContext`
- the EF entity model
- the repository model exposed to the rest of the app
- the key mapping

The package provides the generic implementation that converts repository calls into:

- `DbSet.AddAsync(...)`
- `DbSet.Update(...)`
- `DbSet.FindAsync(...)`
- translated LINQ queries over `IQueryable`
- aggregate operations like count, sum, average, min, and max

---

## Prerequisites

Before using `WithEntityFramework(...)`, register your context yourself.

```csharp
builder.Services.AddDbContext<SampleContext>(options =>
{
    options.UseSqlServer(builder.Configuration["ConnectionStrings:Database"]);
});
```

The EF provider does not create or configure the `DbContext` for you.

---

## The key rule: map the repository key explicitly

The generic EF repository depends on `RepositoryMapper<T, TKey, TEntityModel>` for key lookups and key extraction.

In practice, that means you should configure `WithKey(...)` for the EF entity key whenever you use this provider.

This is true even with the same-model overloads.

For scalar keys, the key-side expression is typically just `x => x`.

```csharp
.WithKey(x => x, x => x.Identificativo)
```

Without an explicit key mapping, methods like `ExistAsync`, `GetAsync`, and key retrieval from inserted/query results do not have enough information to work correctly.

---

## Same model setup

Use the 3-generic overload when the repository model and the EF entity model are the same type.

```csharp
builder.Services.AddDbContext<SampleContext>(options =>
{
    options.UseSqlServer(builder.Configuration["ConnectionStrings:Database"]);
});

builder.Services.AddRepository<User, int>(repositoryBuilder =>
{
    repositoryBuilder
        .WithEntityFramework<User, int, SampleContext>(efOptions =>
        {
            efOptions.DbSet = db => db.Users;
            efOptions.References = dbSet => dbSet.Include(x => x.IdGruppos);
        })
        .WithKey(x => x, x => x.Identificativo);
});
```

What this overload does for you:

- registers the generic EF repository with `ServiceLifetime.Scoped` by default
- automatically calls `Translate<T>().WithSamePorpertiesName()` for same-name property mappings

What it does not do for you:

- it does not infer the repository key mapping automatically
- it does not register the `DbContext`

So even in the same-model path, `WithKey(...)` is the important final step.

---

## Separate repository and EF models

Use the 4-generic overload when your repository model differs from the EF entity model.

This is the pattern used in the repo tests for `MappingUser` mapped to the EF `User` entity.

```csharp
builder.Services.AddRepository<MappingUser, int>(repositoryBuilder =>
{
    repositoryBuilder.WithEntityFramework<MappingUser, int, User, SampleContext>(efOptions =>
    {
        efOptions.DbSet = db => db.Users;
        efOptions.References = dbSet => dbSet.Include(x => x.IdGruppos);
    });

    repositoryBuilder.Translate<User>()
        .With(x => x.Username, x => x.Nome)
        .With(x => x.Email, x => x.IndirizzoElettronico)
        .With(x => x.Id, x => x.Identificativo)
        .WithKey(x => x, x => x.Identificativo);
});
```

This is the right approach when:

- your domain model uses different property names
- your EF model is generated from an existing schema
- you want to hide database-only fields from the application layer

---

## `EntityFrameworkOptions` reference

`EntityFrameworkOptions<T, TKey, TEntityModel, TContext>` intentionally stays small.

| Property | Type | Required | Purpose |
|---|---|---|---|
| `DbSet` | `Func<TContext, DbSet<TEntityModel>>` | yes | Select the EF set to use |
| `References` | `Func<DbSet<TEntityModel>, IQueryable<TEntityModel>>?` | no | Apply `Include(...)` or other query shaping for reads |

### `DbSet`

This is mandatory.

```csharp
efOptions.DbSet = db => db.Users;
```

### `References`

Use this for eager loading on `GetAsync` and `QueryAsync`.

```csharp
efOptions.References = dbSet => dbSet.Include(x => x.IdGruppos);
```

Important nuance: the generic repository uses `References` only for read enumeration paths:

- `GetAsync(...)`
- `QueryAsync(...)`

Other methods use the plain `DbSet`:

- `ExistAsync(...)`
- `DeleteAsync(...)`
- `OperationAsync(...)`

So `References` is for read graph shaping, not a global query policy.

---

## CQRS variants

The EF registration extension also exists for command-only and query-only setups.

```csharp
builder.Services.AddCommand<User, int>(commandBuilder =>
{
    commandBuilder
        .WithEntityFramework<User, int, SampleContext>(efOptions =>
        {
            efOptions.DbSet = db => db.Users;
        })
        .WithKey(x => x, x => x.Identificativo);
});

builder.Services.AddQuery<User, int>(queryBuilder =>
{
    queryBuilder
        .WithEntityFramework<User, int, SampleContext>(efOptions =>
        {
            efOptions.DbSet = db => db.Users;
            efOptions.References = dbSet => dbSet.Include(x => x.IdGruppos);
        })
        .WithKey(x => x, x => x.Identificativo);
});
```

Default lifetime is still `Scoped`, which is the natural choice for `DbContext`-based work.

---

## Query and aggregate behavior

The EF provider delegates query construction to the shared repository filter model from the abstractions package.

That means consumer code stays the same:

```csharp
var page = await repository
    .Where(x => x.Username.Contains("eku"))
    .OrderByDescending(x => x.Id)
    .PageAsync(1, 2);

var sum = await repository.SumAsync(x => x.Id);
var average = await repository.AverageAsync(x => x.Id);
var max = await repository.MaxAsync(x => x.Id);
var min = await repository.MinAsync(x => x.Id);
```

In the repo tests, these queries and aggregates are exercised against both the mapped-model and same-model EF registrations.

---

## Operational notes from the source

### Service lifetime

- `WithEntityFramework(...)` defaults to `ServiceLifetime.Scoped`
- this matches normal `DbContext` usage
- you can override the lifetime, but deviating from `Scoped` should be deliberate

### Inserts and updates

- `InsertAsync(...)` maps the repository model to the EF entity, calls `AddAsync(...)`, saves changes, then maps the stored entity back
- `UpdateAsync(...)` maps the repository model to a new EF entity instance and calls `DbSet.Update(...)`

### Deletes

`DeleteAsync(...)` uses:

```csharp
await _dbSet.FindAsync(new object[] { key }, cancellationToken)
```

So the generic provider is most natural when `TKey` matches the actual EF primary key shape.

If your repository key is a wrapper or a richer object around the EF key, a handwritten storage implementation may be a better fit.

### Batch operations

`BatchAsync(...)` loops over operations and delegates to `InsertAsync`, `UpdateAsync`, and `DeleteAsync` one by one.

That means:

- it is not transactional by itself
- it triggers `SaveChangesAsync(...)` per item through those inner operations
- it is convenient, but not optimized for large EF bulk workloads

### Bootstrap and warm-up

`EntityFrameworkRepository<T, TKey, TEntityModel, TContext>.BootstrapAsync()` currently returns `true` immediately.

So this package does not add any EF-specific warm-up behavior of its own. Calling `WarmUpAsync()` at app startup is still safe if your application already uses it across providers.

---

## When to use custom storage instead

The repo test infrastructure includes both generic EF usage and a handwritten EF-backed repository.

The custom storage path is used for `AppUser` with `AppUserKey`:

```csharp
services.AddRepository<AppUser, AppUserKey>(repositoryBuilder =>
{
    repositoryBuilder.SetStorage<AppUserStorage>();
    repositoryBuilder.Translate<User>()
        .With(x => x.Id, x => x.Identificativo)
        .With(x => x.Username, x => x.Nome)
        .With(x => x.Email, x => x.IndirizzoElettronico);
});
```

That is a good option when:

- your key type does not align cleanly with EF primary key lookup
- you need storage-specific logic that the generic provider does not cover
- you want exact control over how entities are queried, inserted, updated, or deleted

Use the generic provider first when it fits; drop to custom storage when the model/key mismatch becomes awkward.

---

## Practical examples from the repo

### Same-model EF repository

The test infrastructure registers `User` directly with the same-model overload:

```csharp
services.AddRepository<User, int>(repositoryBuilder =>
{
    repositoryBuilder
        .WithEntityFramework<User, int, SampleContext>(efOptions =>
        {
            efOptions.DbSet = db => db.Users;
            efOptions.References = dbSet => dbSet.Include(x => x.IdGruppos);
        })
        .WithKey(x => x, x => x.Identificativo);
});
```

### Mapped domain model over EF entity

The same test infrastructure also registers `MappingUser` over the same EF `User` table with explicit translation rules:

```csharp
services.AddRepository<MappingUser, int>(repositoryBuilder =>
{
    repositoryBuilder.WithEntityFramework<MappingUser, int, User, SampleContext>(efOptions =>
    {
        efOptions.DbSet = db => db.Users;
        efOptions.References = dbSet => dbSet.Include(x => x.IdGruppos);
    });

    repositoryBuilder.Translate<User>()
        .With(x => x.Username, x => x.Nome)
        .With(x => x.Email, x => x.IndirizzoElettronico)
        .With(x => x.Id, x => x.Identificativo)
        .WithKey(x => x, x => x.Identificativo);
});
```

### Business hooks still compose normally

Because EF registration works through the same repository builders as every other provider, you can keep using business hooks and other abstractions-layer features.

```csharp
services.AddBusinessForRepository<User, int>()
    .AddBusinessBeforeInsert<UserBeforeInsertBusiness>()
    .AddBusinessBeforeInsert<UserBeforeInsertBusiness2>();
```

---

## Related packages

| Package | Purpose |
|---|---|
| `Rystem.RepositoryFramework.Abstractions` | Core contracts, registration builders, filters, and translation model |
| `Rystem.RepositoryFramework.Infrastructure.InMemory` | In-memory provider for tests and demos |
| `Rystem.RepositoryFramework.Api.Server` | Expose repositories as HTTP endpoints |

If you are continuing through the repository area, this package is the main relational-provider bridge after `src/Repository/RepositoryFramework.Abstractions/README.md`.

---

## repository/repositoryframework-infrastructure-mssql

> Rystem.RepositoryFramework.Infrastructure.MsSql adds a lightweight SQL Server adapter for Repository Framework.

# Rystem.RepositoryFramework.Infrastructure.MsSql

`Rystem.RepositoryFramework.Infrastructure.MsSql` adds a lightweight SQL Server adapter for Repository Framework.

It reflects your model into one SQL table, but query translation is minimal: reads load rows from SQL and most Repository Framework filtering runs in memory.

## Installation

```bash
dotnet add package Rystem.RepositoryFramework.Infrastructure.MsSql
```

## Architecture

The package maps one table per model type.

- schema defaults to `dbo`
- table name defaults to `typeof(T).Name`
- every public property becomes a column
- one property must be marked as the primary key
- non-primitive properties are stored as JSON strings in SQL

This makes the provider easy to configure, but it is not a full LINQ-to-SQL translation layer.

## Registration APIs

Available on all three patterns:

- `WithMsSql(...)`

Supported for:

- `IRepositoryBuilder<T, TKey>`
- `ICommandBuilder<T, TKey>`
- `IQueryBuilder<T, TKey>`

## Example

This mirrors the API tests.

```csharp
builder.Services.AddRepository<Cat, Guid>(repositoryBuilder =>
{
    repositoryBuilder.WithMsSql(msSqlBuilder =>
    {
        msSqlBuilder.Schema = "repo";
        msSqlBuilder.ConnectionString = builder.Configuration["ConnectionStrings:Database"];

        msSqlBuilder
            .WithPrimaryKey(x => x.Id, column =>
            {
                column.ColumnName = "Key";
            })
            .WithColumn(x => x.Paws, column =>
            {
                column.ColumnName = "Zampe";
                column.IsNullable = true;
            });
    });
});
```

Example model from the tests:

```csharp
public sealed class Cat
{
    public Guid Id { get; set; }
    public string? Name { get; set; }
    public int? Something { get; set; }
    public IEnumerable<Room> Rooms { get; set; } = new List<Room>();
    public int Paws { get; set; }
}
```

`Rooms` is a non-primitive property, so it is stored as JSON in SQL.

## Builder API

`IMsSqlRepositoryBuilder<T, TKey>` exposes:

| Member | Purpose |
| --- | --- |
| `ConnectionString` | SQL Server connection string |
| `Schema` | Target schema, default `dbo` |
| `TableName` | Target table name, default `typeof(T).Name` |
| `WithPrimaryKey(expr, cfg)` | Mark one property as the SQL primary key |
| `WithColumn(expr, cfg)` | Customize another column |

`PropertyHelper<T>` exposes:

| Property | Notes |
| --- | --- |
| `ColumnName` | Override the SQL column name |
| `IsNullable` | Controls `NOT NULL` generation |
| `SqlType` | Override the inferred SQL type |
| `Dimension` | Override SQL type dimensions such as `(100)` or `(14,4)` |
| `IsAutomaticCreated` | Present in the API, but not currently used by the repository implementation |

## Type mapping

The package infers SQL types from CLR property types.

Examples from the current mapper:

- `Guid` -> `uniqueidentifier`
- `string` -> `varchar(100)`
- `DateTime` -> `datetime2`
- `decimal` -> `decimal(14,4)`
- non-primitive types -> `varchar(max)` with JSON payloads

Nullable CLR types become nullable columns unless you override them.

## Required configuration

In practice you need:

- `ConnectionString`
- one `WithPrimaryKey(...)` call

If no primary key is configured, `BootstrapAsync()` throws.

## Warm-up and provisioning

This package has startup hooks, but the current implementation is not as complete as the old README implied.

### What `BootstrapAsync()` actually does

`SqlRepository<T, TKey>.BootstrapAsync()`:

1. checks whether a primary key is configured
2. checks whether any columns exist for the table name
3. creates the schema if missing
4. creates the table if missing

### Important current limitation

Despite method names and earlier docs, the package does not currently merge new columns into an existing table.

The helper named `MsSqlCreateTableOrMergeNewColumnsInExistingTableAsync()` is empty.

### Registration-shape caveat

- repository and command registrations add warm-up hooks that call that empty helper
- query registrations add a warm-up hook that calls `BootstrapAsync()`

So auto-provisioning is currently more reliable for query registrations than for repository/command registrations.

If you depend on startup schema creation for repository or command registrations, verify it in your environment instead of assuming it happens.

## Query behavior

`QueryAsync(...)` runs this shape of SQL:

```sql
select [col1],[col2],... from [Schema].[TableName]
```

It does not translate Repository Framework filters to SQL `WHERE`, `ORDER BY`, `TOP`, or paging clauses.

Instead it:

1. reads rows from SQL
2. materializes models
3. applies Repository Framework filters in memory

Practical consequence:

- `Where`, ordering, paging, and aggregates are mostly client-side
- large tables will be scanned more than you might expect

## Aggregate behavior

Aggregate operations such as:

- `Count`
- `Sum`
- `Min`
- `Max`
- `Average`

materialize items through the repository query flow and then compute results in memory.

## CRUD behavior

- `GetAsync` and `ExistAsync` query by the configured primary key column
- primitive keys are stored with `ToString()`
- non-primitive keys are stored as JSON in the primary key column
- inserts and updates only send non-null property values as SQL parameters

Important consequence:

- the package cannot update a column to `NULL` through the current parameter-building logic

## Batch behavior

`BatchAsync(...)` is a sequential loop over insert, update, and delete calls.

There is:

- no SQL transaction wrapping the whole batch
- no bulk insert path
- no rollback behavior

## Other limitations to know about

- only one primary key column is supported
- there is no composite key mapping
- table existence checks use `INFORMATION_SCHEMA.COLUMNS` filtered only by table name, not by schema name
- method names suggest schema evolution support, but the implementation is currently create-only

## CQRS examples

```csharp
builder.Services.AddCommand<Cat, Guid>(commandBuilder =>
{
    commandBuilder.WithMsSql(msSqlBuilder =>
    {
        msSqlBuilder.ConnectionString = builder.Configuration["ConnectionStrings:Database"];
        msSqlBuilder.WithPrimaryKey(x => x.Id, column =>
        {
            column.ColumnName = "Key";
        });
    });
});

builder.Services.AddQuery<Cat, Guid>(queryBuilder =>
{
    queryBuilder.WithMsSql(msSqlBuilder =>
    {
        msSqlBuilder.ConnectionString = builder.Configuration["ConnectionStrings:Database"];
        msSqlBuilder.WithPrimaryKey(x => x.Id, column =>
        {
            column.ColumnName = "Key";
        });
    });
});
```

## When to use this package

Use it when you want:

- a simple reflection-based SQL Server backend
- explicit table and column naming control
- JSON storage for complex properties without extra mapping layers

Be careful if you expect server-side query translation or automatic schema evolution, because the current implementation is much thinner than that.

---

## repository/repositoryframework-migrationtools

> Rystem.RepositoryFramework.MigrationTools adds IMigrationManager<T, TKey> for moving data from one Repository Framework registration to another.

# Rystem.RepositoryFramework.MigrationTools

`Rystem.RepositoryFramework.MigrationTools` adds `IMigrationManager<T, TKey>` for moving data from one Repository Framework registration to another.

It is designed around named registrations: one source factory and one destination factory. The source must be readable, the destination must be writable.

## Installation

```bash
dotnet add package Rystem.RepositoryFramework.MigrationTools
```

## Architecture

The migration manager resolves services through Repository Framework factories.

- source: `IQuery<T, TKey>` when available, otherwise `IRepository<T, TKey>`
- destination: `ICommand<T, TKey>` when available, otherwise `IRepository<T, TKey>`
- destination-as-repository: optional, used only for existence checks and destination cleanup

This lets you migrate across:

- repository to repository
- query to command
- query to repository
- repository to command

as long as the named registrations exist.

## Basic example

```csharp
builder.Services
    .AddRepository<User, string>(repositoryBuilder =>
    {
        repositoryBuilder.WithInMemory(builder =>
        {
            builder.PopulateWithRandomData(1000);
        }, name: "source");
    })
    .AddRepository<User, string>(repositoryBuilder =>
    {
        repositoryBuilder.WithInMemory(name: "target");
    })
    .AddMigrationManager<User, string>(options =>
    {
        options.SourceFactoryName = "source";
        options.DestinationFactoryName = "target";
        options.NumberOfConcurrentInserts = 10;
    });

var serviceProvider = builder.Services.Finalize();
await serviceProvider.WarmUpAsync();
```

Then inject the manager and run the migration:

```csharp
public sealed class MigrationRunner(IMigrationManager<User, string> migrationManager)
{
    public Task<bool> RunAsync(CancellationToken cancellationToken)
        => migrationManager.MigrateAsync(x => x.Id!, cancellationToken: cancellationToken);
}
```

## Registering `IMigrationManager<T, TKey>`

Use `AddMigrationManager<T, TKey>(...)`.

```csharp
builder.Services.AddMigrationManager<User, string>(options =>
{
    options.SourceFactoryName = "source";
    options.DestinationFactoryName = "target";
    options.NumberOfConcurrentInserts = 20;
});
```

### `MigrationOptions<T, TKey>`

| Property | Default | Notes |
| --- | --- | --- |
| `SourceFactoryName` | required | Must match a named `IQuery<T, TKey>` or `IRepository<T, TKey>` registration. |
| `DestinationFactoryName` | required | Must match a named `ICommand<T, TKey>` or `IRepository<T, TKey>` registration. |
| `NumberOfConcurrentInserts` | `10` | Upper bound used by the migration loop before it waits for the current batch of insert tasks. |

Startup validation performed by `AddMigrationManager(...)`:

- `SourceFactoryName` and `DestinationFactoryName` are normalized to empty strings when null
- source and destination names must be different, otherwise registration throws

## `MigrateAsync(...)`

```csharp
Task<bool> MigrateAsync(
    Expression<Func<T, TKey>> navigationKey,
    bool checkIfExists = false,
    bool deleteEverythingBeforeStart = false,
    CancellationToken cancellationToken = default)
```

### What the current implementation does

1. resolve the configured source and destination factories
2. optionally clear the destination first
3. read the entire source using `QueryAsync(IFilterExpression.Empty)`
4. materialize the full result set into memory with `ToListAsync()`
5. insert entities into the destination in batches of concurrent tasks

This package is therefore a straightforward bulk copy helper, not a streaming migration pipeline.

## Source and destination requirements

| Scenario | Source requirement | Destination requirement |
| --- | --- | --- |
| basic migration | `IQuery<T, TKey>` or `IRepository<T, TKey>` | `ICommand<T, TKey>` or `IRepository<T, TKey>` |
| `checkIfExists = true` | same as above | `IRepository<T, TKey>` |
| `deleteEverythingBeforeStart = true` | same as above | `IRepository<T, TKey>` |

When a requirement is not met, the manager throws an `ArgumentException` with a descriptive message.

## Examples by scenario

### Migrate from one named repository to another

```csharp
builder.Services
    .AddRepository<Order, long>(repositoryBuilder =>
    {
        repositoryBuilder.WithInMemory(builder =>
        {
            builder.PopulateWithRandomData(500);
        }, name: "old");
    })
    .AddRepository<Order, long>(repositoryBuilder =>
    {
        repositoryBuilder.WithInMemory(name: "new");
    })
    .AddMigrationManager<Order, long>(options =>
    {
        options.SourceFactoryName = "old";
        options.DestinationFactoryName = "new";
        options.NumberOfConcurrentInserts = 25;
    });
```

### Migrate between different storage backends

```csharp
builder.Services
    .AddRepository<Product, Guid>(repositoryBuilder =>
    {
        repositoryBuilder.WithEntityFramework<AppDbContext>(x => x.Products, name: "sql");
    })
    .AddRepository<Product, Guid>(repositoryBuilder =>
    {
        repositoryBuilder.WithBlobStorage(storage =>
        {
            storage.Settings.ConnectionString = builder.Configuration["ConnectionStrings:Storage"];
        }, name: "blob");
    })
    .AddMigrationManager<Product, Guid>(options =>
    {
        options.SourceFactoryName = "sql";
        options.DestinationFactoryName = "blob";
        options.NumberOfConcurrentInserts = 20;
    });
```

### Skip items that already exist

```csharp
await migrationManager.MigrateAsync(
    navigationKey: x => x.Id,
    checkIfExists: true,
    cancellationToken: cancellationToken);
```

When `checkIfExists` is enabled, the manager calls `ExistAsync(entity.Key!)` on the destination repository before inserting.

### Clear destination before migrating

```csharp
await migrationManager.MigrateAsync(
    navigationKey: x => x.Id,
    deleteEverythingBeforeStart: true,
    cancellationToken: cancellationToken);
```

When `deleteEverythingBeforeStart` is enabled, the manager loads the destination with `ToListAsync()` and deletes items one by one with `DeleteAsync(...)` before starting inserts.

## Important behavior notes from the source

These details matter when you use the package in production-like migrations.

### `navigationKey` is currently not used

`MigrateAsync(...)` accepts `Expression<Func<T, TKey>> navigationKey`, but the current implementation inserts using `entity.Key!` from the source query result and never evaluates the expression.

Practical consequence:

- the migration currently depends on the source repository returning correct `Entity<T, TKey>.Key` values
- changing `navigationKey` does not change the destination key in the current implementation

### Source data is fully materialized first

The migration manager executes:

```csharp
await _source.QueryAsync(IFilterExpression.Empty, cancellationToken: cancellationToken)
    .ToListAsync();
```

That means:

- the whole source dataset is loaded before inserts begin
- memory usage grows with the full migration size
- there is no built-in pagination or chunked source enumeration

### Destination cleanup is sequential

When `deleteEverythingBeforeStart` is `true`, destination deletion happens one item at a time.

### Final insert batch caveat

The current implementation waits only when the in-flight task count becomes greater than `NumberOfConcurrentInserts`, and it does not explicitly await the final partial batch before returning `true`.

For small or non-divisible workloads, that means the method can report completion before the last queued inserts have definitely finished.

If you rely on strict end-of-migration completion semantics, verify the destination after the call or patch the implementation before using it for critical data moves.

## Cancellation behavior

The migration loop checks `cancellationToken.IsCancellationRequested` before queueing each new insert. When cancellation is observed there, the method returns `false`.

Already-started insert tasks are not rolled back.

## Warm-up note

The migration package does not bootstrap repositories for you. If your source or destination uses warm-up driven infrastructure, such as seeded in-memory repositories, run `WarmUpAsync()` before starting the migration.

## When to use this package

Use it when you want:

- a simple named-source to named-destination migration helper
- a way to copy data between Repository Framework integrations without writing one-off glue code
- a migration utility for test environments, storage switches, or one-time backfills

For very large datasets or strict completion guarantees, treat the current package as a starting point and review the implementation in `RepositoryFramework.MigrationTools/Managers/MigrationManager.cs` before depending on it operationally.

---

## global

> Rystem.RepositoryFramework.TypescriptGenerator is a .NET CLI tool that inspects C# Repository Framework models and emits a TypeScript client layer for rystem.re

# Rystem.RepositoryFramework.TypescriptGenerator

`Rystem.RepositoryFramework.TypescriptGenerator` is a .NET CLI tool that inspects C# Repository Framework models and emits a TypeScript client layer for `rystem.repository.client`.

It generates:

- TypeScript model files
- raw/clean mappers when JSON names or date types require them
- transformers for models and complex keys
- `bootstrap/repositorySetup.ts`
- `services/repositoryLocator.ts`

## Installation

```bash
# global
dotnet tool install -g Rystem.RepositoryFramework.TypescriptGenerator

# local
dotnet new tool-manifest
dotnet tool install Rystem.RepositoryFramework.TypescriptGenerator
```

The tool command name is:

```bash
rystem-ts
```

## Prerequisites

- .NET 10 SDK
- the frontend package `rystem.repository.client`

```bash
npm install rystem.repository.client
```

## What the tool actually does

The generator builds your target project, loads the produced assembly, analyzes the requested model and key types with reflection, then writes TypeScript files to the destination folder.

Practical consequence:

- generation is not metadata-only
- your target project must build successfully

## Command

```bash
rystem-ts generate --dest <destination> --models <definitions> [options]
```

### Options

| Option | Alias | Required | Notes |
| --- | --- | --- | --- |
| `--dest` | `-d` | yes | Output folder |
| `--models` | `-m` | yes | Repository definitions |
| `--project` | `-p` | recommended | Path to the `.csproj` to build |
| `--overwrite` |  | no | Defaults to `true` |
| `--include-deps` |  | no | Also scan built dependencies in the output folder |
| `--deps-prefix` |  | no | Filter dependency loading by prefix when `--include-deps` is enabled |

## Model definition format

```text
"{Model,Key,Type[,Factory[,BackendFactory]]},{Model2,Key2,Type2,...}"
```

Fields:

- `Model`: C# model type name, simple or fully qualified
- `Key`: C# key type name or primitive like `string`, `Guid`, `int`
- `Type`: `Repository`, `Query`, or `Command`
- `Factory`: optional client-side registration name; defaults to `Model`
- `BackendFactory`: optional server factory segment appended to the generated API path

Legacy bracket form like `[{...},{...}]` is also accepted.

## Examples

```bash
rystem-ts generate \
  --project ./src/MyApi/MyApi.csproj \
  --dest ./src/generated/repository \
  --models "{User,Guid,Repository,users}"
```

```bash
rystem-ts generate \
  --project ./src/MyApi/MyApi.csproj \
  --dest ./src/generated/repository \
  --models "{Calendar,LeagueKey,Repository,serieA,serieA},{Team,Guid,Query,teams}" \
  --include-deps \
  --deps-prefix "MyCompany."
```

## Output structure

The generator writes these folders:

```text
<destination>/
  types/
    DateMappers.ts
    <lowercase-model-file>.ts
    index.ts
  transformers/
    <ModelName>Transformer.ts
    index.ts               # only when transformers are emitted
  bootstrap/
    repositorySetup.ts
  services/
    repositoryLocator.ts
```

Notes:

- model filenames are lowercase base names, not necessarily exact CLR names
- `transformers/index.ts` is written only when there are transformers to export

## Generated TypeScript model shape

Depending on the analyzed type, each `types/*.ts` file can contain:

- TypeScript `enum`s
- raw interfaces that match wire JSON names
- clean interfaces with camel-cased property names
- raw/clean mapper functions
- helper classes for nested arrays and dictionaries

The generator emits raw + clean models only when it needs them, mainly for:

- `System.Text.Json` `[JsonPropertyName]` differences
- `DateTime`, `DateTimeOffset`, or `DateOnly`

## Type mapping behavior

Important mappings from the current implementation:

- `string`, `char` -> `string`
- numeric primitives and `decimal` -> `number`
- `bool` -> `boolean`
- `Guid` -> `string`
- `DateTime`, `DateTimeOffset`, `DateOnly` -> raw `string`, clean `Date`
- `TimeSpan`, `TimeOnly` -> `string`
- non-primitive custom objects -> generated interfaces
- arrays -> `T[]`
- dictionaries -> `Record<K, V>`
- enums -> numeric TypeScript `enum`

Non-primitive nullable/reference handling is simplified on the TypeScript side, so review emitted optional properties when null-vs-missing distinctions matter.

## Generic types

The generator understands open and closed generics.

- it emits the open generic model file once
- closed generic repository registrations reuse that base model
- generated bootstrap/transformers pass mapper functions for generic arguments when needed

## Generated bootstrap

`bootstrap/repositorySetup.ts` wires `RepositoryServices` for you.

```typescript
import { setupRepositoryServices } from "./bootstrap/repositorySetup";

setupRepositoryServices({
  baseUrl: "https://localhost:7058/api/",
});
```

The generated config surface is intentionally small:

```typescript
setupRepositoryServices({
  baseUrl: "https://localhost:7058/api/",
  headersEnricher: async (endpoint, uri, method, headers, body) => ({
    ...headers,
    Authorization: `Bearer ${getToken()}`,
  }),
  errorHandler: async (endpoint, uri, method, headers, body, err) => {
    if (err?.status === 401) {
      await refreshToken();
      return true;
    }
    return false;
  },
});
```

## Generated repository locator

`services/repositoryLocator.ts` exposes typed accessors over `RepositoryServices`.

```typescript
import { RepositoryLocator } from "./services/repositoryLocator";

const user = await RepositoryLocator.users.get("some-id");
const items = await RepositoryLocator.users.query().execute();
await RepositoryLocator.users.insert("some-id", userToSave);
```

It generates the correct client registration method based on the descriptor type:

- `Repository` -> `addRepository`
- `Query` -> `addQuery`
- `Command` -> `addCommand`

## Server-side alignment

The generated paths are meant for Repository Framework API endpoints.

Typical server setup:

```csharp
builder.Services.AddRepository<User, Guid>(repositoryBuilder =>
{
    repositoryBuilder.WithInMemory();
});

builder.Services.AddApiFromRepositoryFramework().WithPath("api");

var app = builder.Build();
app.UseApiFromRepositoryFramework().WithNoAuthorization();
```

## Important caveats

### `--project` is effectively required in most real runs

The CLI can auto-discover a `.csproj` only when exactly one exists in the current directory. In practice, passing `--project` explicitly is the reliable path.

### `.dll` input is not a true standalone flow today

The option text says `--project` can point to a `.csproj` or `.dll`, but the pipeline still performs `dotnet build` logic around a project path. Treat `.csproj` as the supported input.

### The tool always builds in `Release`

It invokes `dotnet build -c Release --no-restore` before analyzing output.

### Generated config surface is smaller than the runtime supports

The emitted `RepositoryConfig` only covers:

- `baseUrl`
- `headersEnricher`
- `errorHandler`

If you need runtime settings like custom `uri`, casing, or key separator tweaks, you may need to extend the generated bootstrap manually.

## When to use this tool

Use it when you want:

- TypeScript models kept in sync with Repository Framework DTOs
- ready-made `rystem.repository.client` bootstrap code
- generated transformers for dates, JSON-name differences, and complex keys

If you need full control over the frontend surface, treat the generated files as a starting point and commit only the parts you want to keep stable.

---

## repository/repositoryframework-web-components

> Rystem.RepositoryFramework.Web.Components provides a server-side Blazor admin UI on top of Repository Framework registrations.

# Rystem.RepositoryFramework.Web.Components

`Rystem.RepositoryFramework.Web.Components` provides a server-side Blazor admin UI on top of Repository Framework registrations.

It gives you generic pages for:

- query/list
- show
- create
- edit
- delete
- theme and language settings

and lets you customize menu labels, icons, form rendering, localization, and edit-page actions per repository.

## Installation

```bash
dotnet add package Rystem.RepositoryFramework.Web.Components
```

## What this package actually adds

The package registers:

- Razor Pages for the built-in UI area
- package host pages (`/_Host` and `/_AuthorizedHost` inside the package area)
- menu, localization, modal, loading, copy, and Radzen-related services
- per-repository UI metadata driven by Repository Framework registrations

It does not replace normal Blazor Server setup.

You still need:

- `AddServerSideBlazor()`
- `app.MapBlazorHub()`
- your own authentication middleware if you enable authenticated UI

## Minimal setup

This is the working shape used by the sample app.

```csharp
var builder = WebApplication.CreateBuilder(args);

builder.Services.AddServerSideBlazor();

builder.Services
    .AddRepositoryUi(settings =>
    {
        settings.Name = "Repository App";
        settings.Icon = "dashboard";
    })
    .AddDefaultSkinForUi();

var app = builder.Build();

app.UseStaticFiles();
app.UseRouting();
app.MapBlazorHub();
app.AddDefaultRepositoryEndpoints();

app.Run();
```

## Main registration API

### `AddRepositoryUi(...)`

```csharp
builder.Services.AddRepositoryUi(settings =>
{
    settings.Name = "Admin";
    settings.Icon = "savings";
    settings.Image = "/logo.png";
});
```

`AppSettings` includes:

| Property | Notes |
| --- | --- |
| `Name` | Required app name shown in the UI |
| `Icon` | Optional Material icon name |
| `Image` | Optional top-bar image |
| `Palette` | Active palette settings |
| `Sizing` | Sizing and typography settings |
| `RazorPagesForRoutingAdditionalAssemblies` | Extra assemblies for the Blazor router |

### `AddRepositoryUi<T>(...)`

There is also a generic overload intended to add an extra assembly for routing.

Important caveat: the current implementation does not preserve that additional assembly setting correctly, so treat this overload as unreliable for now.

## Endpoint mapping

Use:

```csharp
app.AddDefaultRepositoryEndpoints();
```

This method:

- calls `UseStaticFiles()`
- enables request localization when configured
- maps `/Repository/Language/{culture}`
- maps `/Repository/Settings/Theme/{themeKey}`
- maps `/Repository/Identity/Logout` when authenticated UI is enabled
- maps Razor Pages
- maps fallback to the package host page

It does not map the Blazor hub for you.

## Authentication

Use:

```csharp
builder.Services
    .AddRepositoryUi(settings =>
    {
        settings.Name = "Admin";
    })
    .WithAuthenticatedUi();
```

What this actually does:

- switches fallback from the package `/_Host` page to the package `/_AuthorizedHost` page
- enables the logout endpoint at `/Repository/Identity/Logout`

What it does not do:

- configure ASP.NET authentication
- configure cookies or OpenID Connect
- add `UseAuthentication()` or `UseAuthorization()`

Those are still your responsibility.

## Localization

Enable built-in localization with:

```csharp
builder.Services
    .AddRepositoryUi(settings =>
    {
        settings.Name = "Admin";
    })
    .AddDefaultLocalization();
```

The package then enables language switching through:

- `GET /Repository/Language/{culture}`

Important notes:

- the current supported cultures are hardcoded internally to `en-US`, `es-ES`, `it-IT`, `fr-FR`, and `de-DE`
- the endpoint redirects to the app root, not back to the current page

### Per-repository localization

```csharp
builder.Services
    .AddRepository<AppUser, int>(settings =>
    {
        settings
            .WithLocalization<AppUser, int, IStringLocalizer<SharedResource>>();
    });
```

## Themes and skins

### Default skins

```csharp
builder.Services
    .AddRepositoryUi(settings =>
    {
        settings.Name = "Admin";
    })
    .AddDefaultSkinForUi();
```

This registers:

- `Light`
- `Dark`

### Custom skin

```csharp
builder.Services
    .AddRepositoryUi(settings =>
    {
        settings.Name = "Admin";
    })
    .AddDefaultSkinForUi()
    .AddSkinForUi("Corporate", palette =>
    {
        palette.Primary = "#003366";
        palette.Secondary = "#0066cc";
        palette.BackgroundColor = "#f4f6f8";
        palette.Color = "#1a1a2e";
    });
```

Runtime switching happens through:

- `GET /Repository/Settings/Theme/{themeKey}`

Important note: the theme cookie is written with `Secure = true`, so HTTPS is the safe assumption for real use.

## Per-repository customization

These extensions hang off `IRepositoryBuilder<T, TKey>`.

| Method | Purpose |
| --- | --- |
| `SetDefaultUiRoot<T, TKey>()` | Make this repository the landing page for the package router |
| `DoNotExposeInUi<T, TKey>()` | Hide the repository from the menu |
| `ExposeFor<T, TKey>(index)` | Set menu ordering |
| `WithIcon<T, TKey>(icon)` | Set menu icon |
| `WithName<T, TKey>(name)` | Set menu label |
| `AddAction<T, TKey, TAction>()` | Add a custom edit-page action |
| `MapPropertiesForUi<T, TKey, TUiMapper>()` | Customize form rendering and defaults |
| `WithLocalization<T, TKey, TLocalization>()` | Attach a localizer for this repository |

### Example

```csharp
builder.Services
    .AddRepository<AppUser, int>(settings =>
    {
        settings
            .WithIcon("manage_accounts")
            .WithName("User")
            .ExposeFor(2)
            .SetDefaultUiRoot()
            .MapPropertiesForUi<AppUser, int, AppUserDesignMapper>()
            .WithLocalization<AppUser, int, IStringLocalizer<SharedResource>>();
    });
```

## Custom edit actions

Register actions with `AddAction<T, TKey, TAction>()`.

```csharp
public sealed class ArchiveUserAction : IRepositoryEditAction<AppUser, int>
{
    public string Name => "Archive";
    public string? IconName => "archive";

    public ValueTask<bool> InvokeAsync(Entity<AppUser, int> entity)
    {
        return ValueTask.FromResult(true);
    }
}
```

The action appears on the edit page and dependencies are resolved from DI.

## Property UI mapping

Implement `IRepositoryUiMapper<T, TKey>` and register it with `MapPropertiesForUi<T, TKey, TUiMapper>()`.

This lets you configure:

- default values
- default values loaded from repositories
- single-choice dropdowns
- multi-choice dropdowns
- text editor behavior

## Host pages and runtime requirements

The package ships its own host pages inside the area and maps fallback to them.

The package host includes:

- `<base href="~/" />`
- `HeadOutlet`
- `RepositoryApp`
- `_framework/blazor.server.js`
- the `RepositoryStyle` and `RepositoryScript` partials

So you do not need to create your own `_Host.cshtml` just to use the packaged UI.

## Built-in routes

Repository pages:

- `/Repository/{Name}/Query`
- `/Repository/{Name}/Create`
- `/Repository/{Name}/Edit/{Key}`
- `/Repository/{Name}/Show/{Key}`
- `/Repository/Settings`

Utility endpoints:

- `/Repository/Language/{culture}`
- `/Repository/Settings/Theme/{themeKey}`
- `/Repository/Identity/Logout` when authenticated UI is enabled

If you do not set a default UI root with `SetDefaultUiRoot()`, unmatched/fallback navigation ends on the router's not-found content.

## Important caveats

- `AddRepositoryUi(...)` does not replace `AddServerSideBlazor()` or `MapBlazorHub()`
- `WithAuthenticatedUi()` does not configure auth middleware; it only switches the package host and logout route
- language and theme endpoints redirect to the app root, not the current page
- supported cultures are fixed internally
- `AddRepositoryUi<T>(...)` is intended for additional router assemblies but is not reliable in the current implementation

## When to use this package

Use it when you want:

- a quick back-office UI over Repository Framework registrations
- server-side Blazor CRUD screens without hand-writing each page
- per-repository customization through metadata and DI

If you need a fully custom frontend, this package is better used as a reference or internal admin surface than as the only UI for public-facing workflows.
